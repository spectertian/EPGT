package com.example.audioidentifysample;

import java.lang.ref.WeakReference;

import tv.shafa.identify.AudioIdentify;
import tv.shafa.identify.AudioIdentifyResultListener;
import tv.shafa.identify.IRecorder;
import tv.shafa.identify.data.IdentifyProgram;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.AnimationDrawable;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends Activity {
	
	private Button mIdtBtn;
	private Button mCancelBtn;
	private TextView mIdtResultTxtView;
	private ImageView mIdtImgView;
	private AnimationDrawable animation;
	
	private static final String UNIT_TAG_EMPTY = "00";	
	private static final String NO_ENTITLE = "no channel rights";
	private static final String NO_PLAYBILL = "no play bill";
		
	private AudioIdentify mAudioIdentify;
	
	private MyRecorder myRecorder;
	
	static class MyHandler extends Handler {
		private final WeakReference<MainActivity> mActivity;

		MyHandler(MainActivity activity) {
			mActivity = new WeakReference<MainActivity>(activity);
		}

		@Override
		public void handleMessage(Message msg) {
			MainActivity theActivity = mActivity.get();
			if (theActivity != null) {
				theActivity.handleMessage(msg);
			}
		}
	};
	
	private MyHandler mHandler;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		mIdtResultTxtView = (TextView)findViewById(R.id.idtResultTxtView);
		mIdtBtn = (Button)findViewById(R.id.idtBtn);
		mCancelBtn = (Button)findViewById(R.id.idtBtn1);
		mIdtImgView = (ImageView)findViewById(R.id.idtImgView);
		animation = (AnimationDrawable) mIdtImgView.getBackground();
		
		mIdtBtn.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v) {
				mIdtResultTxtView.setText(R.string.identifying);
				mIdtImgView.setVisibility(View.VISIBLE);
				animiStart();
				mAudioIdentify.start(new MyRecorder());
				//mAudioIdentify.start();
			}
		});

		mCancelBtn.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				mIdtResultTxtView.setText(R.string.identify_result);
				mIdtImgView.setVisibility(View.INVISIBLE);
				mAudioIdentify.stop();
				animiStop();				
			}
		});
		
		mHandler = new MyHandler(this);
		
		myRecorder = new MyRecorder();
		
		mAudioIdentify = new AudioIdentify(Constants.COMCID,Constants.COMLICENSE);
		mAudioIdentify.setAudioIdentifyResultListener(new AudioIdentifyResultListener() {

			@Override
			public void onIdentifyResult(int result, String reason,
					IdentifyProgram iProgram) {
				// TODO Auto-generated method stub
				Message msg = mHandler.obtainMessage();
				msg.what = result;
				if (result == 0) {
					msg.obj = iProgram;
				} else {
					msg.obj = reason;
				}
				mHandler.sendMessage(msg);				
			}
			
		});
		
		mAudioIdentify.setRecorder(myRecorder);
	}
		
	private void handleMessage(Message msg) {
		switch (msg.what) {
		case AudioIdentifyResultListener.AUDIO_IDENTITY_RESULT_OK:
			mAudioIdentify.stop();
			animiStop();
			mIdtImgView.setVisibility(View.INVISIBLE);
			
			IdentifyProgram ip = (IdentifyProgram)msg.obj;
			if (ip != null) {
				// 处理得到的频道和节目信息
				long channelId = ip.getChannel_id();
				String channelName = ip.getChannel_name();   //频道名称
				String channelLogo = ip.getChannel_logo();	  //频道logo Url,48x48(px)
				String channelProvider = ip.getChannel_provider();
				long columnId = ip.getProgramming().getColumn_id();  
				String columnName = ip.getProgramming().getColumn_name();//栏目名称
				String columnLogo = ip.getProgramming().getColumn_logo();//栏目logo Url,48x48(px) 
				long unitId = ip.getProgramming().getUnit_id();
				String unitTag = ip.getProgramming().getUnit_tag();//第几集，如果没有分集时为00
				String unitImage = ip.getProgramming().getUnit_image();//栏目第几集海报Url,720x240(px)

				String showcontent = null;
				if (columnName != null || unitTag != null) {
					if (unitTag.equals(UNIT_TAG_EMPTY)) {
						showcontent = channelName + "正在播放" + columnName;
					}else{	
						showcontent = channelName + "正在播放" + columnName + unitTag;
					}
					mIdtResultTxtView.setText(showcontent);
				} else {
					String reson = NO_PLAYBILL + channelName;
					showIdentifyDialog(MainActivity.this, 1, reson);
				}
			} 
			break;
		case AudioIdentifyResultListener.AUDIO_IDENTITY_RESULT_FAIL:
		case AudioIdentifyResultListener.AUDIO_IDENTITY_RESULT_ERROR:
			String reason = (String)msg.obj;
			showIdentifyDialog(MainActivity.this, msg.what, reason);
			break;
		default:
			break;
		}
	}

	private void showIdentifyDialog(Context context, int result, String reason) {
		final AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setCancelable(false);
		builder.setIcon(android.R.drawable.btn_star);
		builder.setTitle(R.string.identify_result_title);
		
		//NO_PLAYBILL：该频道没有节目单 ;NO_ENTITLE：该频道没有开通授权
		if (reason.startsWith(NO_PLAYBILL)) {
			builder.setMessage(reason.substring(12) + getResources().getString(R.string.fail_result_no_playbill));
		} else if (reason.equals(NO_ENTITLE)) {
			builder.setMessage(getResources().getString(R.string.fail_result_no_entitle));
		} else {
			builder.setMessage(reason);
		}
		
		builder.setPositiveButton(R.string.try_again, new DialogInterface.OnClickListener() {  
			public void onClick(DialogInterface dialog, int whichButton) {  
				dialog.dismiss();
				mIdtImgView.setVisibility(View.VISIBLE);
				animiStart();
				mAudioIdentify.start(new MyRecorder());
				//mAudioIdentify.start();
			}  
		}); 
		
		builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
				animiStop();
				mIdtImgView.setVisibility(View.INVISIBLE);
				dialog.dismiss();
				mIdtResultTxtView.setText(R.string.identify_result);
			}
		});
		builder.show();
	}

	private void animiStart(){
		animation.start();
	}
	private void animiStop(){
		animation.stop();
	}

	public class MyRecorder implements IRecorder {

		private int audioSource = MediaRecorder.AudioSource.MIC;
		private int sampleRateInHz = AudioIdentify.DEFAULT_SAMPLE_RATE;
		private int channelConfig = AudioFormat.CHANNEL_IN_MONO;
		private int audioFormat = AudioFormat.ENCODING_PCM_16BIT;

		private int bufferSizeInBytes = 0;
		
		private AudioRecord audioRecord;
		
		public MyRecorder() {
			bufferSizeInBytes = AudioRecord.getMinBufferSize(sampleRateInHz, channelConfig, audioFormat);
		}

		@Override
		public boolean startRecording() {
			if (audioRecord == null) {
				audioRecord = new AudioRecord(audioSource, sampleRateInHz, channelConfig, audioFormat, bufferSizeInBytes*10);
				audioRecord.startRecording();
			}
			return true;
		}

		@Override
		public void stopRecording() {
			if (audioRecord != null) {
				audioRecord.stop();
				audioRecord.release();
				audioRecord = null;
			}
		}

		@Override
		public int read(short[] audioData, int offsetInShorts, int sizeInShorts) {
			if (audioRecord != null) {
				return audioRecord.read(audioData, offsetInShorts, sizeInShorts);
			} else 
				return -1;			
		}

		@Override
		public int getRecordBufferSize() {
			return bufferSizeInBytes/2;			
		}		
	}
	

	@Override
	protected void onResume() {
		super.onResume();
		// TODO 语音模块重置，申请硬件资源，启动接收监听
	}

	@Override
	protected void onPause() {
		super.onPause();
		// TODO 暂停语音模块接收监听，释放硬件资源
		mIdtResultTxtView.setText(R.string.identifying);
		mIdtImgView.setVisibility(View.INVISIBLE);
		mAudioIdentify.stop();
		animiStop();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		// TODO 释放语音模块
		mAudioIdentify=null;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			mAudioIdentify.stop();
			animiStop();
			finish();
            return false;
        }
		return false;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
}
