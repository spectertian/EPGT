package com.example.audioidentifysample;

public class Constants {
	public static final String COMCID = "1000035";
	public static final String COMLICENSE = "1.01EHBCiBJUDHESAKUCIESBEKSIEJSUiHAJEOcc";
}
