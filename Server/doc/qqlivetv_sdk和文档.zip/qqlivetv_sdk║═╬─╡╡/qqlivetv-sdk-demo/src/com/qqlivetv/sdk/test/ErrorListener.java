package com.qqlivetv.sdk.test;

import com.qqlivetv.sdk.Sdk;

public class ErrorListener implements Sdk.OnErrorListener {

	@Override
	public void onErrorListener(int arg0, String arg1, Exception arg2,
			String arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onErrorListener(int arg0, String arg1, String arg2,
			String arg3, String arg4) {
		// TODO Auto-generated method stub
		
	}

}
