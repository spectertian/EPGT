package com.qqlivetv.sdk.test;

import java.util.List;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Message;
import android.widget.Toast;

import com.qqlivetv.sdk.videoview.FVideoView;
import com.qqlivetv.sdk.Def.VIDItem;
import com.qqlivetv.sdk.Def.VODVideoItem.VODVideoClarity;

public class VODVideoView extends FVideoView implements
		FVideoView.OnErrorListener, FVideoView.OnBufferStateChangeListener,
		FVideoView.OnSkipVideoOPEDListener {

	private Activity mActivity;
	private ProgressDialog pDialog = null;
	
	public VODVideoView(Activity activity,int resId) {
		super(activity,resId);
		mActivity = activity;
		this.setOnErrorListener(this);
		this.setOnBufferStateChangeListener(this);
		
		pDialog = new ProgressDialog(mActivity);
		pDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		pDialog.setMessage("正在缓冲….");		
	}

	/**
	 * 由开发者实现出现等待动画
	 */
	@Override
	public void showLoadingAnimation() {
		if(!pDialog.isShowing())
			pDialog.show();
	}

	/**
	 * 由开发者关闭出现等待动画
	 */
	@Override
	public void closeLoadingAnimation() {
		if(pDialog.isShowing())
			pDialog.dismiss();
	}

	@Override
	public boolean onError(MediaPlayer arg0, int errno, int extra, int errorCount,final int fvIndex) {
		if(errorCount==0){
			//保存历史记录
		}else if(errorCount == 2){
			//判断异常来源
			
			//网络正常却无法播放,弹出对话框
		}
		
		return false;
	}

	/**
	 * 缓冲之后触发的事件
	 */
	@Override
	public void onNoBufferListener() {
		closeLoadingAnimation();//关闭等待动画
	}

	/**
	 * 准备缓冲触发的事件
	 */
	@Override
	public void onStartBufferListener() {
		showLoadingAnimation();//显示等待动画
	}

	@Override
	public void onSkipVideoEDListener(int arg0) {
		Toast.makeText(mActivity, "跳过片头....", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onSkipVideoOPListener(int arg0) {
		Toast.makeText(mActivity, "跳过片尾....", Toast.LENGTH_SHORT).show();
	}
}
