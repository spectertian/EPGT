package com.qqlivetv.sdk.test;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.qqlivetv.sdk.Def;
import com.qqlivetv.sdk.Def.VIDItem;
import com.qqlivetv.sdk.Def.VODVideoItem;
import com.qqlivetv.sdk.Sdk;
import com.qqlivetv.sdk.Def.SearchItems;
import com.qqlivetv.sdk.json.JSONParse;
import com.qqlivetv.sdk.json.URLBuilder;
import com.qqlivetv.sdk.json.VODParse;
import com.qqlivetv.sdk.prebuffer.Prebuffer;
import com.qqlivetv.sdk.report.OZReport;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {
    /** Called when the activity is first created. */
	private Button btnSearch,btnGetClarity,btnGetUrl,btnPrebuffer,btnPlayVid,btnExit;
	final static private String TAG="MainActivity";
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        //----初始化QQLIVETV SDK----//
        String cacheDir = Environment.getExternalStorageDirectory().getAbsolutePath() 
        		+ "/Android/data/"+getPackageName()+"/sdk_files";
		
        deleteAllFile(cacheDir);//先删除缓冲过的文件
        Log.e(TAG,"cacheDir:"+cacheDir);
        
        Sdk.init_App(this.getApplicationContext(), 
				Def.OSTYPE.TCL,
				cacheDir,
				new ErrorListener());
        
        //Sdk.setAccount("410566292");//测试QQ
        Sdk.setSkipVideoOPEDEnable(true);//跳过片头片尾
		Sdk.setLogEnable(true);//允许打印LOG
		Sdk.setSaveLogEnable(true);//允许保存Log
		
        btnSearch=(Button) this.findViewById(R.id.btnSearch);
        btnSearch.setOnClickListener(buttonOnClickListener);
        
        btnGetClarity=(Button) this.findViewById(R.id.btnGetClarity);
        btnGetClarity.setOnClickListener(buttonOnClickListener);
        
        btnGetUrl=(Button) this.findViewById(R.id.btnGetUrl);
        btnGetUrl.setOnClickListener(buttonOnClickListener);
        
        btnPrebuffer=(Button)this.findViewById(R.id.btnPrebuffer);
        btnPrebuffer.setOnClickListener(buttonOnClickListener);
        
        btnPlayVid=(Button) this.findViewById(R.id.btnPlayVID);
        btnPlayVid.setOnClickListener(buttonOnClickListener);
        
        btnExit=(Button)this.findViewById(R.id.btnExit);
        btnExit.setOnClickListener(buttonOnClickListener);
    }
	
    private OnClickListener buttonOnClickListener=new OnClickListener(){
		@Override
		public void onClick(View v) {
			String vid1 = "t00114uu293";	
			String vid2 = "t0011wktu6u";
			String coverId="e51zela13gm1zno";//"v3bb9vrrdxvwg0q";//

			if(v==btnSearch){//打印搜索结果
				printSearchResult("非诚勿扰");
			}
			else if(v==btnGetClarity){
				printVideoClarity(vid1);
				printVideoClarity(vid2);
			}
			else if(v==btnGetUrl){//打印获取的剧集视频链接地址
				printVideoUrl(vid1);
				//printVideoUrl(vid2);
			}
			else if(v==btnPrebuffer){//预加载10秒
				btnPlayVid.setVisibility(View.INVISIBLE);
				startPrebuffer(coverId,0);
				showBtnPlayVidHandler.sendEmptyMessageDelayed(0, 10000);
			}
			else if(v==btnPlayVid){//打开播放器，播放视频
				//开始播放
				Intent intent = new Intent(MainActivity.this, TestVideoViewActivity.class);
				intent.putExtra(TestVideoViewActivity.OPEN_COVER_ID, coverId);
				startActivity(intent);
			}else if(v==btnExit){
				Sdk.release();
				finish();
			}
		}
    };
    
	private Handler showBtnPlayVidHandler = new Handler(){  
        
        public void handleMessage(Message msg) {  
        	btnPlayVid.setVisibility(View.VISIBLE);
        }
	};
	
    private void printSearchResult(String keyWord){
    	int PAGE_SIZE_MAX =  20;
    	String urlString = URLBuilder.makeSearchUrl(0,
    			PAGE_SIZE_MAX,
    			0,
    			keyWord);
    	SearchItems result=JSONParse.getSearchItems(urlString);
    	Log.e(TAG,"搜索结果总数:"+result.search_total);
    	Log.e(TAG,"当前页结果数量:"+result.items.size());
    	for(int i=0;i<result.items.size();i++){
    		SearchItems.Item item = result.items.get(i);
    		Log.e(TAG,"演员:"+item.actors);
    		Log.e(TAG,"导演:"+item.directors);
    		Log.e(TAG,"地区:"+item.area);
    		Log.e(TAG,"清晰度:"+item.edition);
    		Log.e(TAG,"图片地址:"+item.imgurl);
    		Log.e(TAG,"标题:"+item.title);
    		Log.e(TAG,"描述:"+item.descriptor);
    	}
    }
    
    private void printVideoClarity(String vid){
    	try{
    		VIDItem vidItem = VODParse.getVIDItem(vid,
					Def.ClarityType.SD_ENAME,
					Def.ClarityType.SD_ENAME);
    		
			if(vidItem==null){
				String msg = Sdk.getDisableTips();
				if(TextUtils.isEmpty(msg)==false)
					Log.e(TAG,msg);
			}
			
    		if (vidItem != null) {
				for(int i=0;i<vidItem.lstClarity.size();i++){
					Log.e(TAG,"VID:"+vid+",clarity:"+vidItem.lstClarity.get(i).name);
				}
			}
    	}catch(Exception e){
 			// TODO Auto-generated catch block
 			e.printStackTrace();
    	}
    }
    
    private void printVideoUrl(String vid){
    	try {
			VIDItem vidItem = VODParse.getVIDItem(vid,
					Def.ClarityType.HD_ENAME,//目标清晰度，想要高清清晰度的链接
					Def.ClarityType.SD_ENAME);//默认清晰度，没有高清则获取标清的链接
			
			if(vidItem==null){
				String msg = Sdk.getDisableTips();
				if(TextUtils.isEmpty(msg)==false)
					Log.e(TAG,msg);
			}
			if (vidItem != null) {
				for(int i=0;i<1;i++){
					String mp4 = VODParse.getFVideoUrl(vidItem, i);
					Log.e(TAG,vidItem.title+":"+"No."+i+"分片,清晰度:"+vidItem.clarity.name+" URL:" + mp4);
				}
			}
    	} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
    }
    
    private void startPrebuffer(String coverid,int index){
    	VODVideoItem vodVideoItem = VODParse.getVODVideoItem(coverid, 
				Def.ClarityType.HD_ENAME,
				Def.ClarityType.SD_ENAME);
    	
    	VIDItem vidItem = VODParse.getVIDItem(vodVideoItem.lstItem.get(index).vid,
				Def.ClarityType.HD_ENAME,//目标清晰度，想要高清清晰度的链接
				Def.ClarityType.SD_ENAME);//默认清晰度，没有高清则获取标清的链接
		
    	String mp4 = VODParse.getFVideoUrl(vidItem, 0);//获取第一个分片的链接
    	Prebuffer.startFastDownload(vidItem.lstFVideo.get(0).fileName, mp4);
    }
    
    /**
     * 删除所有文件
     * @param folderFullPath
     * @return
     */
	public static boolean deleteAllFile(String folderFullPath) {
		boolean ret = false;
		File file = new File(folderFullPath);
		if (file.exists()) {
			if (file.isDirectory()) {
				File[] fileList = file.listFiles();
				for (int i = 0; i < fileList.length; i++) {
					String filePath = fileList[i].getPath();
					deleteAllFile(filePath);
				}
			}
			if (file.isFile()) {
				file.delete();
			}
		}
		return ret;
	}
}