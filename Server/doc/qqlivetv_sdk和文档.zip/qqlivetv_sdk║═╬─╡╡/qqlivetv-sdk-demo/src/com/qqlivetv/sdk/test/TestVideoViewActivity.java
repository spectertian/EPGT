package com.qqlivetv.sdk.test;

import com.qqlivetv.sdk.Def;
import com.qqlivetv.sdk.Def.VODVideoItem;
import com.qqlivetv.sdk.json.VODParse;
import com.qqlivetv.sdk.prebuffer.Prebuffer;
import com.qqlivetv.sdk.report.JNIReport;
import com.qqlivetv.sdk.report.OZReport;
import com.qqlivetv.sdk.videoview.ExVideoView;
import com.qqlivetv.sdk.videoview.ExVideoView.OnTimerRunnableListener;
import com.qqlivetv.sdk.videoview.FVideoView;
import com.tencent.qqlive.api.JniStatistic;

import android.app.Activity;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.SeekBar;
import android.widget.Toast;

public class TestVideoViewActivity extends Activity  implements OnPreparedListener,OnTimerRunnableListener,OnCompletionListener{
	final String TAG="TestVideoViewActivity";
	public final static String OPEN_COVER_ID = "QQLIVE.OPEN.INTENT.LIVE.OPEN_COVER_ID";
	private VODVideoView fVideoView;
	private SeekBar seekBar;
	private Button btnPlayPause;
	private VODVideoItem vodVideoItem;
	private boolean isTouching=false;
	private long startTimeMillis;
    @Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.form_player);
		final String coverid = this.getIntent().getStringExtra(OPEN_COVER_ID);
		
		//----初始化组件----//
		fVideoView = new VODVideoView(this,R.id.f_player_videoview);
		fVideoView.setOnPreparedListener(this);
		fVideoView.setOnTimerRunnableListener(this);
		fVideoView.setOnCompletionListener(this);
		
		seekBar = (SeekBar) this.findViewById(R.id.f_player_seekbar);
		seekBar.setOnTouchListener(mOnTouchListener);
		
		btnPlayPause = (Button)this.findViewById(R.id.f_player_btnPlayPause);
		btnPlayPause.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {

				if(fVideoView.isPaused())
					fVideoView.start();
				else if (fVideoView.isPlaying())
					fVideoView.pause();
			}
		});

		//----播放Cover ID的指定剧集----//
		new Thread(){
			public void run(){
				vodVideoItem = VODParse.getVODVideoItem(coverid, 
						Def.ClarityType.HD_ENAME,
						Def.ClarityType.SD_ENAME);
				fVideoView.playVid(vodVideoItem, 0, 0);
			}
		}.start();
		
		startTimeMillis=System.currentTimeMillis();//计算首次缓冲的时间
	}
	
    private OnTouchListener mOnTouchListener = new OnTouchListener(){

		@Override
		public boolean onTouch(View v, MotionEvent event) {
			if(event.getAction()==MotionEvent.ACTION_DOWN){
				fVideoView.readySeekTo();
				isTouching=true;
			}else if(event.getAction()==MotionEvent.ACTION_UP){
				fVideoView.confirmSeekTo(seekBar.getProgress());
				isTouching=false;
			}
			return false;
		}
	};

	@Override
	public void onPrepared(MediaPlayer mp) {
		long duration = System.currentTimeMillis() - startTimeMillis;
		Toast.makeText(this, "Prepared cost:"+duration+" ms", Toast.LENGTH_SHORT).show();
		seekBar.setMax(fVideoView.getDuration());
	}

	@Override
	public void onPause(){
		fVideoView.release();
		Prebuffer.stopFastDownloads();
		finish();
		super.onPause();
	}
	
	@Override
	public void onTimerRunnableListener_1s() {
		if(isTouching)
			return;
		if(fVideoView==null)
			return;
		
		if(fVideoView.isPaused() || fVideoView.isPlaying())
			seekBar.setProgress(fVideoView.getCurrentPosition());
	}

	@Override
	public void onCompletion(MediaPlayer mp) {
		int currentItemIndex = vodVideoItem.getCurrentItemIndex();
		if (currentItemIndex < vodVideoItem.lstItem.size() - 1) {//剧集还没播放结束
			vodVideoItem.setCurrentItemIndex(currentItemIndex+1);
			new Thread() {
				public void run() {
					fVideoView.playVid(vodVideoItem,
							vodVideoItem.getCurrentItemIndex(),
							0);
				}
			}.start();
		} else if (currentItemIndex == vodVideoItem.lstItem.size() - 1){// 全部剧集播放结束
			finish();
		}
	}

}