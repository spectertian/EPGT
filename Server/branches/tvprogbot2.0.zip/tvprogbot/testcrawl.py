#!/usr/bin/env python
#-*- coding: utf-8 -*-

import sys
from datetime import date
from datetime import timedelta

tvsou_config = {'channel_id': '34', 'tv_id': 12}
#BTV卡酷少儿 更新速度慢 
btv_config = {'crawl_url': 'http://www.btv.org/btvindex/jmyg/node_16663.htm', 'default':True}
#btv_config = {'crawl_url': 'http://www.btv.com.cn/btvindex/jmyg/node_16662.htm', 'default':True}
jstv_config = {'crawl_url': 'http://www.jstv.com/2008jsbc/jmb/include/curweek.js', 'default':True}
eastmovie_config = {}
smgbb_config = {'crawl_url': 'http://prolist.smgbb.cn/?c=%E5%AE%81%E5%A4%8F%E5%8D%AB%E8%A7%86', 'default':True}
#cntv_config = {'catid': 34, 'name': 'btv1'}
cntv_config = {'catid': 28, 'name': 'cctvMusic'}
cntv_config = {'catid': 28, 'name': 'CCTV1'}
#cntv_config = {'catid': 34, 'name': 'henan'}
cntv_config = {'catid': 35, 'name': 'fengyunzuqiu'}
cntv_config = {'catid': 35, 'name': 'dianshizhinan'}
cntv_config = {'catid': 35, 'name': 'dianshizhinan'}
cntv_config = {'catid': 'jingwai', 'name': 'fenghuangzhongwen'}
sewise_config = {'channel_id': '5b53152f52f2efe9b4f85bd55f3751dd'}
#电视剧频道
#http://prolist.smgbb.cn/?day=2012-03-31&c=%E5%AE%81%E5%A4%8F%E5%8D%AB%E8%A7%86

from TVProgbot.db.mongodb import MongoDB
from TVProgbot.site.btv_site import BTVSite
from TVProgbot.site.hisports_site import HisportsSite
from TVProgbot.site.eastmovie_site import EastMovieSite
from TVProgbot.site.jstv_site import JSTVSite    
from TVProgbot.site.btv_site import BTVSite
from TVProgbot.site.tvsou_api import SiteTvsouApi
from TVProgbot.site.smgbb_site import SMGBBSite
from TVProgbot.site.cntv_site import CntvSite
from TVProgbot.site.sewise_api import SewiseApi

from TVProgbot import config
config.load("conf/tvprogbot.conf")

if __name__ == '__main__':

    day = date.today()+ timedelta(days=0)
    #s = SMGBBSite(smgbb_config)
    #s = SiteTvsouApi(tvsou_config)
    #s = BTVSite(btv_config)
    #s = HisportsSite(eastmovie_config)
    #s = EastMovieSite(eastmovie_config)
    #s = CntvSite(cntv_config)
    #s = SMGBBSite(smgbb_config)
    s = SewiseApi(sewise_config)
    programs = s.Crawl(day)
    for program in programs:
        print program['name']
    print len(programs)
    db = MongoDB.getMongoDB()
    db.insertProgramCollection(programs)
    sys.exit()
    
    db = MongoDB.getMongoDB()
    correct_program = db.getIncorrectProgram('cctv2', '4dc79873edcd88f275001380')
    print correct_program['correct_wiki_id']
    for channel in channels:
        print channel['code']
    db.updateLatestProgramEndTime('5dfcaefe6e7203df9fbe61ffd64ed1c4', '2012-03-21', 'tvsou', '')
    sys.exit()

