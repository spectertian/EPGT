# -*- coding: utf-8 -*-

from TVProgbot.wiki_site.BaiduBaike import BaiduBaike

a = BaiduBaike()
#a.Crawl("http://baike.baidu.com/view/2478917.htm#sub7517540")
#a.Crawl("http://baike.baidu.com/view/7168269.htm")
#a.Crawl("http://baike.baidu.com/view/1425082.htm")
#a.Crawl("http://baike.baidu.com/view/5458272.htm")
print a.Crawl("http://baike.baidu.com/view/10786.htm#sub6245628")
