# -*- coding: utf-8 -*-
'''
Created on 2012-2-7

@author: zhigang
'''
from TVProgbot import util
from TVProgbot.WikiDict import WikiDict
from TVProgbot.site import tvsou_api
from TVProgbot.db.mongodb import MongoDB
from TVProgbot.task import task

from multiprocessing import Process, Queue, active_children
from datetime import datetime
import time
#import json
from TVProgbot import webserver

def main():
    logger = util.get_logger()
    logger.info("Starting...")
    logger.info("Building Wiki Dict...")
    wiki_dict = WikiDict.getDict()
    wiki_dict.initDict()
    logger.info("Wiki Dict Build Complete.")
    
    logger.info("Start webserver...")
    webserver.server_run()

