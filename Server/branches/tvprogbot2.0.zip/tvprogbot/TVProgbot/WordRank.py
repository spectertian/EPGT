# -*- coding: utf-8 -*-
'''
Created on 2012-5-31

@author: zhigang
'''
from __future__ import division
import re

class WordRank:
    debug = False
    
    def __init__(self):
        pass
        
    def compute(self, channel, program, wiki, word):
        """word priperties"""    
        self.initWordVal(program, wiki, word);
        """计算词组匹配权重"""
        algorithms = [
                      self.wordLenRank,
                      self.wordPosRank,
                      self.releaseYearRank,
                      self.playTimeRank
                    ]
        total_rank = 0.0
        for algorithm in algorithms:
            rank = algorithm(channel, program, wiki, word)
            if self.debug:
                print algorithm, rank
            total_rank += rank     
        average_rank = (total_rank / (len(algorithms) * 10)) * 10  # 计算平均得分
        if average_rank >= 5:
            if wiki['model'] == 'television':
                average_rank += 0.3
            elif wiki['model'] == 'teleplay':
                average_rank += 0.2                
            elif wiki['model'] == 'film':
                average_rank += 0.1
        if self.debug:
            print "[%s]%s average_rank: %s, %s[%s], TotalRank: %s" % \
                 (wiki['model'], word['word'], average_rank, wiki['title'], wiki['_id'], total_rank)
        return average_rank

    """初始化词组值"""            
    def initWordVal(self, program, wiki, word):     
        self.program_name = program['name']
        self.prfix_str = (self.program_name)[0:word['pos']].strip()
        self.last_start = word['pos'] + len(word['word'])
        self.last_str = (self.program_name)[self.last_start:].strip()
        self.last_str_len = len(self.last_str)
        self.is_first_word = False
        self.prfix_str_has_keyword = False
        self.last_str_has_symbol = False           
        
        if wiki['model'] == 'television':
            if word['pos'] == 0:
                self.is_first_word = True
            if re.search(u"^\d?[\(（　\:：]", self.last_str):
                self.last_str_has_symbol = True                
        elif wiki['model'] == u"film":
            if re.search(u'影院|电影|午夜经典[:：《]?$', self.prfix_str):
                self.prfix_str_has_keyword = True
            if re.search(u"^\d?[\(（　\:：]", self.last_str):
                self.last_str_has_symbol = True
            if word['pos'] == 0:                
                self.is_first_word = True     
        elif wiki['model'] == u'teleplay':
            if re.search(u'剧场|电视剧|连续剧|集剧[:：《]?$', self.prfix_str):
                self.prfix_str_has_keyword = True
            if re.search(u"^\d+|\(\d+\)|（\d+）$", self.last_str):
                self.last_str_has_symbol = True
            if word['pos'] == 0:
                self.is_first_word = True
            else:
                m = re.search(u':|：', self.program_name)
                if m:
                    if (m.start()+1) == word['pos']:
                        self.is_first_word = True        

    def wordLenRank(self, channel, program, wiki, word):
        """检查匹配出的字符串在整个节目名称中所占比例"""
        program_name = ''
        if self.is_first_word:
            program_name = self.program_name
        else:                
            if wiki['model'] == 'television':
                name_list = re.split(u':|：', self.program_name)
                program_name = name_list[0]
            elif wiki['model'] == u"film":
                program_name = self.program_name
            elif wiki['model'] == u"teleplay":
                if self.prfix_str_has_keyword:
                    name_list = re.split(u':|：', self.program_name)
                    program_name = name_list.pop()
                    program_name = re.sub(u'\d{1,2}', '', program_name, 1)
        
        if self.last_str_has_symbol:
            name_list = re.split(u'\s|\(|（|\:|：', program_name)
            program_name = name_list[0]
        name_len = len(program_name)    
        if name_len > 0 and program_name.find(word['word']) == -1:
            return 5
        elif name_len == 0:
            return 5
        else:
            return len(word['word'])/len(program_name) * 10
    
    def wordPosRank(self, channel, program, wiki, word):
        if wiki['model'] == 'television':
            if re.search(u'剧场|电视剧|连续剧|影院|电影|集剧[:：《]?$', self.prfix_str):
                return -5
            if self.is_first_word:
                if not self.last_str or self.last_str_has_symbol or self.last_str_len <= 2:
                    return 5
        elif wiki['model'] == u"film":
            #print '------------------', last_str, '--------------------'
            if re.search(u'剧场|电视剧|连续剧|栏目|集剧|重播|首播[:：《]?$', self.prfix_str):
                return -5
            if self.prfix_str_has_keyword:
                if not self.last_str or self.last_str_has_symbol:
                    return 10
                elif self.last_str_len <= 2:
                    return 8
                else:
                    return 5
            elif self.is_first_word:
                if not self.last_str or self.last_str_has_symbol or re.search(u'^上|下|\d$',self.last_str):
                    return 5
        elif wiki['model'] == u'teleplay':
            if re.search(u'影院|电影|栏目[\ :：《]?$', self.prfix_str):
                return -5
            if self.prfix_str_has_keyword:
                if not self.last_str or self.last_str_has_symbol:
                    return 10
                else:
                    return 8
            elif self.is_first_word:
                if self.last_str_has_symbol:
                    return 10
                elif not self.last_str:
                    return 5
        return 0

    def releaseYearRank(self, channel, program, wiki, word):
        if wiki['model'] == u"film" or wiki['model'] == u'teleplay':
            if wiki.has_key("released") and len(wiki['released']) >= 4:
                released = wiki['released']
                try:
                    release_year = int(released[0:4], 10)
                    rank = (release_year / 10000) + 5
                    return rank
                except:
                    pass
        return 5

    def playTimeRank(self, channel, program, wiki, word):
        """节目播出时长评分减分"""
        try:
            playtime = program['end_time']-program['start_time']
            playtime_minutes = playtime.seconds / 60
            if wiki['model'] == u"film":
                if playtime_minutes < 49:
                    return -5
            elif wiki['model'] == u"teleplay":        
                if playtime_minutes < 15:
                    return -5
            elif wiki['model'] == u"television":
                if playtime_minutes < 10:
                    return -5
        except:
            return 5
        else:
            return 5