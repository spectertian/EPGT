#!/usr/bin/env python
#-*- coding: utf-8 -*-
'''
Created on 2012-2-15

@author: luren
'''
from TVProgbot.site.base import SiteBase
from datetime import date
from datetime import datetime
import TVProgbot.BeautifulSoup as BeautifulSoup
import time
import pytz
import re

class SMGBBSite(SiteBase):
    """
    SMG东方宽屏在线数据采集
    Url: http://prolist.smgbb.cn/
    """
    def __init__(self, config):
        SiteBase.__init__(self, config)
        
    def Crawl(self, date):
        channel_url = self.config['crawl_url']
        programs = self.get_day(channel_url, date)
        return programs

    def get_day(self, channel_url, day):
        date = day.strftime("%Y-%m-%d")
        channel_url = '%s&day=%s' % (channel_url, date)
        print channel_url
        return self.crawlPrograms(channel_url, date)
    
    def crawlPrograms(self, url, date):
        try:
            html = self.request(url)
            soup = BeautifulSoup.BeautifulStoneSoup(html,
                                    fromEncoding="utf-8",
                                    convertEntities=BeautifulSoup.BeautifulStoneSoup.HTML_ENTITIES
                                )
            table_content = soup.find('table')
            contents =  table_content.tbody.contents            
        except:
            return []

        programs = []
        if contents:
            for element in contents:
                if isinstance(element, BeautifulSoup.Tag):
                    elem = element.contents
                    if len(elem) == 2:
                        start_time = '%s %s' % (date, elem[0].string)
                        program_name = self.filter_program(elem[1].string)
                        #print program_name
                        if start_time and program_name:
                            start_time = datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S")
                            #print start_time , program_name.encode('gb18030')
                            tz = pytz.timezone("Asia/Shanghai")
                            start_time = tz.localize(start_time)
                            program = {
                               "name": program_name,
                               "time": start_time.strftime("%H:%M"),
                               "date": start_time.strftime("%Y-%m-%d"),
                               "start_time": start_time,
                               'referer': 'smgbb_site'
                            }
                            programs.append(program)
        return programs                
                                      
    def filter_program(self, program_name):
        program_name = program_name.strip()
        if program_name.find(u"《》") == 1:
            return ''
        elif re.search(u"^\d+$", program_name):
            return ''
        else:
            program_name = re.sub(u"[！|》]{1}", "", program_name)
            return program_name
     