# -*- coding: utf-8 -*-
'''
Created on 2012-6-27

@author: luren
@desc: 深圳市矽伟智科技有限公司EPG数据API
'''

import pytz
from datetime import datetime
from TVProgbot.BeautifulSoup import BeautifulSoup
from TVProgbot.site.base import SiteBase

class SewiseApi(SiteBase):
    
    def Crawl(self, date):
        programs = []
        if self.config.has_key('channel_id'):
            channel_id = self.config['channel_id']
            programs = self.get_day(channel_id, date)
        return programs

    def get_day(self, channel_id, day):
        """抓取单天记录"""
        date_str = day.strftime("%Y-%m-%d")
        url = "http://219.232.160.101/webservice/tv/?do=epg&id=%s&date=%s" % (channel_id, date_str)
        #print url
        content = self.request(url)
        self.xml_content = BeautifulSoup(content,
                                         fromEncoding="utf-8",
                                         convertEntities=BeautifulSoup.XML_ENTITIES)
        
        programs = []
        items = self.xml_content.mhpeventpg.contents
        if items:
            for item in items:
                item_eventname = item.find('eventname')
                item_period = item.find('period')
                if item_eventname != -1 and item_period != -1:                    
                    program_name = item_eventname['name']
                    #program_drama = item_eventname.eventtext.string
                    #if program_drama == None:
                    #    program_drama = ''
                    #end_time = item_period['duration']
                    start_time = '%s %s' % (date_str, item_period['start'])
                    start_time = datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S")
                    tz = pytz.timezone("Asia/Shanghai")
                    start_time = tz.localize(start_time)                
                    #print program_name, start_time
                    program = {
                               "name": program_name.strip(),
                    #           'drama': program_drama.strip(),
                               "time": start_time.strftime("%H:%M"),
                               "date": start_time.strftime("%Y-%m-%d"),
                               "start_time": start_time,
                               'referer': 'sewise'
                            }
                    programs.append(program)
        return programs
