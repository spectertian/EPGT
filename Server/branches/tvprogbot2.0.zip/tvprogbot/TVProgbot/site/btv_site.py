#!/usr/bin/env python
#-*- coding: utf-8 -*-
'''
Created on 2012-2-15

@author: luren
'''
from TVProgbot.site.base import SiteBase
from datetime import date
from datetime import datetime
import TVProgbot.BeautifulSoup as BeautifulSoup
import time
import pytz
import re

class BTVSite(SiteBase):
    """
    BTV在线数据采集
    Url: http://www.btv.org/btvindex/jmyg/node_16500.htm
    """
    def __init__(self, config):
        SiteBase.__init__(self, config)
        self.programs = {}
        
    def Crawl(self, date):
        channel_url = self.config['crawl_url']
        programs = self.get_day(channel_url, date)
        return programs

    def get_day(self, channel_url, day):
#        print channel_url
        if not self.programs:
            self.crawlPrograms(channel_url)  
        date = day.strftime("%Y-%m-%d")   
        if self.programs.has_key(date):
            return self.programs[date]

    def crawlPrograms(self, channel_url):
        try:
            html = self.request(channel_url)
            self.html_soup = BeautifulSoup.BeautifulSOAP(html,
                                fromEncoding="utf-8",
                                convertEntities=BeautifulSoup.BeautifulSOAP.XHTML_ENTITIES)
            items =  self.html_soup.findAll('div', {"class": "jmyg_c"})            
        except:
            return []

        TIME_REG = re.compile('(\d{1,2}\:\d{1,2})')
        for item in items:
            program_date = item.find('h2')
            match = re.findall('(\d+){1,2}', program_date.string)
            date = ''
            date_expand = lambda m:len(m) < 2 and m.rjust(2,'0') or m
            if match:
                mouth, day = match
                date = '%s-%s-%s' %(time.strftime('%Y'),date_expand(mouth), date_expand(day))
            program_data = item.nextSibling
            str_time, program_name, programs_list = ['','',[]]
            for program_item in program_data: 
                if isinstance(program_item, BeautifulSoup.Tag):
                    program_item_element = []
                    for elem in program_item.contents:
                        if isinstance(elem, BeautifulSoup.NavigableString):
                            program_item_element.append(elem)
                        elif isinstance(elem, BeautifulSoup.Tag):
                            for el in elem:
                                if isinstance(el, BeautifulSoup.NavigableString):
                                    program_item_element.append(el)
                                    
                    program_item = ''.join(program_item_element).strip()
                    m = TIME_REG.match(program_item)
                    if m:
                        str_time = '%s %s' % (date, m.group(1))
                        program_name = TIME_REG.sub('', program_item)
                        if str_time and program_name:
                            try:
                                #print str_time , program_name.encode('gb18030')
                                start_time = datetime.strptime(str_time, "%Y-%m-%d %H:%M")
                                tz = pytz.timezone("Asia/Shanghai")
                                start_time = tz.localize(start_time)                           
                                program = {
                                   "name": program_name.strip(),
                                   "time": start_time.strftime("%H:%M"),
                                   "date": start_time.strftime("%Y-%m-%d"),
                                   "start_time": start_time,
                                   'referer': 'btv_site'
                                }
                                programs_list.append(program)
                            except:
                                pass
            self.programs[date] = programs_list              
     
