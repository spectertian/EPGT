#!/usr/bin/env python
#-*- coding: utf-8 -*-
'''
Created on 2012-3-29

@author: luren
'''
from TVProgbot.site.base import SiteBase
from datetime import date
from datetime import datetime
import TVProgbot.BeautifulSoup as BeautifulSoup
import time
import pytz
import re
import string

class CntvSite(SiteBase):
    """
    布谷电视在线数据采集
    Url: http://bugu.cntv.cn/nettv/ibugu/28/CCTV1/20120329.shtml
    """
    cntv_url = string.Template('http://bugu.cntv.cn/nettv/ibugu/${catid}/${name}/${date}.shtml')
    
    def __init__(self, config):
        SiteBase.__init__(self, config)
        self.programs = {}
        
    def Crawl(self, date):
        cntv_url = self.cntv_url.substitute({'catid': self.config['catid'],'name': self.config['name'], 'date': date.strftime("%Y%m%d")})
        programs = self.get_day(cntv_url, date)
        return programs        

    def get_day(self, channel_url, date):
#        print channel_url
        try:
            html = self.request(channel_url)
            soup = BeautifulSoup.BeautifulSoup(html,      
                                convertEntities=BeautifulSoup.BeautifulSoup.XHTML_ENTITIES
                            )
            soup_border = soup.find('div', {'class': 'border1'})
            soup_border = BeautifulSoup.BeautifulSoup(str(soup_border))
            soup_table = soup_border.find('table', {'class': 'twocol'})
            soup_tables = soup_table.findAll('table')
        except:
            return []
            
        table_elements, programs = ([],[])
        if soup_tables:
            for table in soup_tables:
                table_elements.extend(table.contents)
        if table_elements:
            str_time, program = ('','')
            for element in table_elements:
                if isinstance(element, BeautifulSoup.Tag):
                    str_time = element.contents[1].getString()
                    program_name = element.contents[3].getString()
                    if str_time and program_name:
                        start_time = "%s %s" % (date.strftime("%Y-%m-%d"), str_time)
                        #print start_time , program_name.encode('gb18030')
                        start_time = datetime.strptime(start_time, "%Y-%m-%d %H:%M")
                        tz = pytz.timezone("Asia/Shanghai")
                        start_time = tz.localize(start_time)                           
                        program = {
                           "name": program_name.strip(),
                           "time": start_time.strftime("%H:%M"),
                           "date": start_time.strftime("%Y-%m-%d"),
                           "start_time": start_time,
                           'referer': 'cntv_site'
                        }
                        programs.append(program)                       
        return programs