# -*- coding: utf-8 -*-
'''
Created on 2012-2-7

@author: zhigang
'''

from datetime import datetime
#from datetime import timedelta
import pytz

from TVProgbot.BeautifulSoup import BeautifulSoup

from TVProgbot.site.base import SiteBase

class SiteTvsouApi(SiteBase):
    
    def Crawl(self, date):
        programs = []
        if self.config.has_key('channel_id'):
            channel_id = self.config['channel_id']
            programs = self.get_day(channel_id, date)
        return programs
#        today = datetime.now()
#        empty = 0
#        for i in range(0, self.day_num):
#            if empty >= 3:
#                break
#            
#            day = self.start_date + timedelta(days=i)
#            programs = self.get_day(channel_id, day)
#            
#            if programs:
#                self.programs = self.programs + programs
##                self.save(programs)
#            else:
#                empty = empty + 1
        

    def get_day(self, channel_id, day):
        """抓取单天记录"""
        url = "http://hz.tvsou.com/jm/hw8901.asp?id=%s&Date=%s" % (channel_id, day.strftime("%Y-%m-%d"))
        #print url
        content = self.request(url)
        content = content.decode('gb18030').encode('utf-8')
        self.xml_content = BeautifulSoup(content,
                                         fromEncoding="utf-8",
                                         convertEntities=BeautifulSoup.XHTML_ENTITIES)
        
        programs = []
        items = self.xml_content.findAll('c')
        for item in items:
            start_time = item.find('pt')
            program_name = item.find('pn')
#            tvsou_tags = item.find('pp')
#            tvsou_wiki_id = item.find('fid2')
            if program_name and program_name.string:
                program_name = program_name.string
                if program_name == u'搜视':
                    continue
                start_time = start_time.string
                start_time = datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S")
                tz = pytz.timezone("Asia/Shanghai")
                start_time = tz.localize(start_time)
#                program_title = unescape(program_title)
                program_name = program_name.replace(u"(本节目由搜视网提供)", u"")
                program_name = program_name.replace(u"(本节目表由搜视网提供)", u"")
                program_name = program_name.strip(u'&amp;')
                #print start_time.strftime("%Y-%m-%d"), '===', program_name.encode('gb18030')
                program = {
                           "name": program_name.strip(),
                           "time": start_time.strftime("%H:%M"),
                           "date": start_time.strftime("%Y-%m-%d"),
                           "start_time": start_time,
                           'referer': 'tvsou'
                           }
                programs.append(program)
        return programs
