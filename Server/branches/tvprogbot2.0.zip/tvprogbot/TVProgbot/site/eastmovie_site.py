#!/usr/bin/env python
#-*- coding: utf-8 -*-
'''
Created on 2012-2-27

@author: luren
'''
from TVProgbot.site.base import SiteBase
from datetime import date
from datetime import datetime
from datetime import timedelta
import TVProgbot.BeautifulSoup as BeautifulSoup
import time
import pytz
import re

class EastMovieSite(SiteBase):
    """
    东方电影在线数据采集
    Url: http://www.eastmovie.com.cn/Article/ShowClass.asp?ClassID=24
    """
    def __init__(self, config):
        SiteBase.__init__(self, config)
        self.propram_url_list = {}
        
    def Crawl(self, date):
        programs = self.get_day(date)
        return programs

    def get_day(self, day):
        if not self.propram_url_list:
            self.crawlProgramListUrl()

        date = day.strftime('%Y-%m-%d')
        if self.propram_url_list.has_key(date):
            return self.crawlPrograms(day, self.propram_url_list[date])
                
    def crawlPrograms(self, day, url):
#        print url
        try:
            html = self.request(url)
            programs = []
            TIME_REG = re.compile('(^\d{1,2}\:\d{2})')
            html = html.decode('gb18030').encode('utf-8')
            soup = BeautifulSoup.BeautifulStoneSoup(html,
                                    fromEncoding="utf-8",
                                    convertEntities=BeautifulSoup.BeautifulStoneSoup.HTML_ENTITIES
                                )
            content = soup.find('div', {'class':'content'})
        except:
            return []
            
        if content:
            for element in content.contents:
                if isinstance(element, BeautifulSoup.NavigableString):
                    program_row = element
                elif isinstance(element, BeautifulSoup.Tag):
                    program_row = element.getString()
                    
                m = TIME_REG.match(program_row)
                if m:
                    start_time = (lambda m: len(m) < 5 and m.rjust(5,'0') or m)(str(m.group(1)))
                    program_name = TIME_REG.sub('', program_row)
                    if int(start_time[0:2]) > 5:
                        start_time = '%s %s' % (day.strftime('%Y-%m-%d'), start_time)
                    else:
                        start_time = '%s %s' % ((day + timedelta(days=1)), start_time)
                    if start_time and program_name:
                        #print start_time, program_name.encode('gb18030')                       
                        start_time = datetime.strptime(start_time, "%Y-%m-%d %H:%M")
                        tz = pytz.timezone("Asia/Shanghai")
                        start_time = tz.localize(start_time)
                        program_date = start_time.strftime("%Y-%m-%d")
                        program = {
                           "name": program_name.strip(),
                           "time": start_time.strftime("%H:%M"),
                           "date": program_date,
                           "start_time": start_time,
                           'referer': 'eastmovie_site'
                        }
                        programs.append(program)
        return  programs           
    
    def crawlProgramListUrl(self):
        try:
            url = 'http://www.eastmovie.com.cn/Article/ShowClass.asp?ClassID=24'
            html = self.request(url)
            html = html.decode('gb18030').encode('utf-8')
            soup = BeautifulSoup.BeautifulSOAP(html,
                                    fromEncoding="utf-8",
                                    convertEntities=BeautifulSoup.BeautifulSOAP.XHTML_ENTITIES)
            content_list = soup.find('div', {'class': 'content_list'})            
        except:
            return []

        if content_list:
            content_table = content_list.table
            content_table = content_table.findAll('tr')
            for tr in content_table:
                a = tr.find('a')
                if isinstance(a, BeautifulSoup.Tag):
                    date = re.sub('[^\d+]', '-', a['title']).rstrip('-')
                    date  = datetime.strptime(date, "%Y-%m-%d")
                    date = date.strftime('%Y-%m-%d')
                    self.propram_url_list[date] = 'http://www.eastmovie.com.cn' + a['href']         
     