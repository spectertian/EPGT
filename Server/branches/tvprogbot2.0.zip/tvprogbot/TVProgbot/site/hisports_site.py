#!/usr/bin/env python
#-*- coding: utf-8 -*-
'''
Created on 2012-2-29

@author: luren
'''
from TVProgbot.site.base import SiteBase
from datetime import date
from datetime import datetime
from datetime import timedelta
import TVProgbot.BeautifulSoup as BeautifulSoup
import time
import pytz
import re

class HisportsSite(SiteBase):
    """
    五星体育在线数据采集
    Url: www.hisports.com/index.html
    """
    def __init__(self, config):
        SiteBase.__init__(self, config)
        self.programs = {}
        
    def Crawl(self, date):
        programs = self.get_day(date)
        return programs

    def get_day(self, day):
        if not self.programs:
            self.crawlPrograms() 
        date = day.strftime("%Y-%m-%d")
        if self.programs.has_key(date):
            return self.programs[date]
        
    def crawlPrograms(self):
        site_url = 'www.hisports.com/index.html'
#        print channel_url
        try:
            html = self.request(site_url)
            TIME_REG = re.compile('(^\d{2}:\d{2})', re.M)
            soup = BeautifulSoup.BeautifulStoneSoup(html,
                                    fromEncoding="utf-8",
                                    convertEntities=BeautifulSoup.BeautifulStoneSoup.HTML_ENTITIES
                                )      
    
            element_days = soup.find('div', {'class': 'titlelistB'})
            element_days = element_days.findNextSiblings('div', {'class': 'zhouliu'}, limit=4)
            element_programs = soup.find('div', {'class': 'newlist'})
            element_programs = element_programs.findNextSiblings('div', {'class': 'newA'}, limit=4)            
        except:
            return []
            
        if element_days and element_programs:
            i = 0
            for element in element_days:
                if element_programs[i].find('p') :
                    program_contents = element_programs[i].find('p').contents
                else:
                    program_contents = element_programs[i].contents
                match = re.findall('(\d+){1,2}', element.span.getString())
                date = ''
                if match:
                    m, d = match
                    date = '%s-%s-%s' %(time.strftime('%Y'), m, d)
                    #print date, program_contents
                    #print '--------------------------------'
                    for elem in program_contents:
                        if isinstance(elem, BeautifulSoup.NavigableString):
                            program_row = elem
                        elif isinstance(elem, BeautifulSoup.Tag):
                            program_row = elem.getString()

                        if program_row:                        
                            program_row = program_row.replace(u'：', ':')
                            mt = TIME_REG.search(program_row)
                            if mt:
                                start_time =  mt.group(1)
                                program_name = TIME_REG.sub('', program_row)
                                #计算日期
                                if int(start_time[0:2]) < 6 or (int(start_time[0:2]) == 6 and int(start_time[3:]) < 30):
                                    dateformat = datetime.strptime(date, "%Y-%m-%d")+ timedelta(days=1)
                                    start_time = '%s %s' % (dateformat.strftime("%Y-%m-%d"), start_time)                                 
                                else:
                                    start_time = '%s %s' % (date, start_time)                                   
                                if start_time and program_name:
                                    #print start_time, program_name.encode('gb18030')
                                    #print '--------------------------------'                                    
                                    start_time = datetime.strptime(start_time, "%Y-%m-%d %H:%M")
                                    tz = pytz.timezone("Asia/Shanghai")
                                    start_time = tz.localize(start_time)
                                    program_date = start_time.strftime("%Y-%m-%d") 
                                    program = {
                                       "name": program_name.strip(),
                                       "time": start_time.strftime("%H:%M"),
                                       "date": program_date,
                                       "start_time": start_time,
                                       'referer': 'hisports_site'
                                    } 
                                    if not self.programs.has_key(program_date):
                                         self.programs[program_date] = []            
                                    self.programs[program_date].append(program)
                i += 1
              
      