#!/usr/bin/env python
#-*- coding: utf-8 -*-
'''
Created on 2012-2-17

@author: luren
'''
import time, pytz, re
from datetime import date
from datetime import datetime
from TVProgbot.site.base import SiteBase

class JSTVSite(SiteBase):
    """
    JSTV 江苏网络电视数据采集
    Url: http://www.jstv.com/2008jsbc/jmb/include/curweek.js
    """
    def __init__(self, config):
        SiteBase.__init__(self, config)
        self.programs = {}
        self.channel_list = {
                        1:{
                            'code' : '322fa7b66243b8d0edef9d761a42f263',
                            'name' : '江苏卫视'
                        },
                        2: {
                            'code' : '8997a5a46f2b2f73af589e7075fde1ff',
                            'name' : '江苏城市'
                        },
                        3: {
                            'code' : '70d3931ad7b8a08380027e10b9f6a8db',
                            'name' : '江苏综艺'
                        },
                        4: {
                            'code' : '35482ad8ed0e51daaed52b3307282520',
                            'name' : '江苏公共'
                        },
                        5: {
                            'code' : '600bd02be669f8c255d12704fa37fa30',
                            'name' : '江苏体育'
                        },
                        6: {
                            'code' : 'jsintertv_asia',
                            'name' : '江苏国际'
                        }
                    }

    def Crawl(self, date):
        channel_url = self.config['crawl_url']
        programs = self.get_day(channel_url, date)
        return programs

    def get_day(self, channel_url, day):
#        print channel_url
        if not self.programs:
            self.crawlPrograms(channel_url)

        date = day.strftime("%Y-%m-%d")
        if self.programs.has_key(date):
            return self.programs[date]

    def crawlPrograms(self, channel_url):
        try:
            html = self.request(channel_url)
        except:
            return None         
    
        #content 先用gb18030解码 再用 utf-8编码
        #content = content.decode('gb18030').encode('utf-8')
        week_data = re.split('var livejson_\w+=', html)
        week_data = week_data[1:]

        for week_item in week_data:
            week_item = eval(week_item, {})
            channels_data = week_item['channel']
            for channel_item in channels_data:
                if channel_item.has_key('timepart'):
                    channelid = channel_item['channelid']
                    tvprogram_data = channel_item['timepart']
                    print channelid
                    for tvprogram_item in tvprogram_data:
                        if tvprogram_item:
                            for tvprogram in tvprogram_item:
                                end_time = tvprogram[0]
                                program_name = tvprogram[1]
                                time = tvprogram[3]
                                end_time = datetime.strptime(end_time, "%Y/%m/%d %H:%M:%S")
                                tz = pytz.timezone("Asia/Shanghai")
                                end_time = tz.localize(end_time)
                                date = end_time.strftime("%Y-%m-%d")
                                #print date ,time, program_name
##                                program = {
##                                   "name": program_name,
##                                   "time": time,
##                                   "date": date,
##                                   "start_time": start_time,
##                                   "end_time" : end_time.strftime("%H:%M"),
##                                   'referer': 'jstv_site'
##                               }

                                break

            break












