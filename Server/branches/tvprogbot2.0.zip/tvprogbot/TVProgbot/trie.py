#!/usr/bin/python
# -*- coding: utf-8 -*-

__author__= "luren"
__date__ = "2012-01-14"
__modified__ = "2012-05-30"

class Trie:
    def __init__(self):
        self.data = {}
        
    def add(self, word):
        ref = self.data
        for char in word:
            ref[char] = ref.has_key(char) and ref[char] or {}
            ref = ref[char]
        ref[""] = 1    

    def dump(self):
        return self.data
    
    def isRootNode(self, char):
        ref = self.dump()
        if ref.has_key(char):
            return True
        else:
            return False        
       
    def search(self, text):
        results = []
        i = 0
        wordlen = len(text)
        while(i < wordlen):
            if self.isRootNode(text[i]):
                results = self.__match(results, text[i:], i)
            i+=1    
        return results;
    
    def __match(self, results, text, offset=0):
        ref = self.dump()
        word = ''
        i = 0
        p = 0
        toback = False  #设置回溯
        wordlen = len(text)
        while (i < wordlen):
            char = text[i]
            if ref.has_key(char):
                word = word+char
                ref = ref[char]
                if toback == False:
                    p = i
                toback = True
                if ref.has_key("") and ref[""] == 1:
                    item = {'word': word, 'pos': p+offset}
                    results = self.__appendItem(results, item)
            else:
                ref = self.dump()
                word = ''
                if toback:
                    i = i-1
                    toback = False
            i+=1
        return results    

    def __appendItem(self, results, item):
        exists = False
        if len(results) > 0:
            for find in results:
                if find['pos'] == find['pos'] and find['word'] == item['word']:
                    exists = True
                    break;
        if exists == False:        
            results.append(item)
        return results
        
#class Trie:
#    def __init__(self):
#        self.data = {}
#        
#    def add(self, word):
#        ref = self.data
#        for char in word:
#            ref[char] = ref.has_key(char) and ref[char] or {}
#            ref = ref[char]
#        ref[""] = 1    
#
#    def dump(self):
#        return self.data
#    
#    def search(self, text):
#        ref = self.dump()
#        finds = []
#        word = ''
#        i = 0
#        p = 0
#        toback = False  #设置回溯
#        wordlen = len(text)
#
#        while (i < wordlen):
#            char = text[i]
#            if ref.has_key(char):
#                word = word+char
#                ref = ref[char]
#                if toback == False:
#                    p = i
#                toback = True
#                
#                if ref.has_key("") and ref[""] == 1:
#                    item = {'word': word, 'pos': p}
#                    finds.append(item)
##                    print word
#            else:
#                ref = self.dump()
#                word = ''
#                if toback:
#                    i = i-1
#                    toback = False
#            i+=1
#        return finds

trie = Trie()        
if __name__ == '__main__':
    import time
    print time.clock()
    #for i in range(100000):
    #    w = u'神奇蜘蛛侠%d' % i
    ##    print w
    #    t.add(w)
    #    
    #t.add(u'神奇蜘蛛侠')
    #t.add(u'贪慕虚荣')
    #t.add(u'晴川')
    #t.add(u'八阿哥')
    #t.add(u'宫')
    #t.add(u'女子')
    #t.add(u'贪慕虚荣的女子')
    #t.add(u'独自留在了宫外')
    #
    #str = u'八阿哥误会晴川是贪慕虚荣的女子,把她独自留在了宫外。顽皮的十八阿哥听说二哥的宫里来了戏班子，闹着要看大闹天宫。素言趁机与十八阿哥玩起了捉迷藏，进入太子的新房撒满火药，企图借机烧死太子。十八阿哥为了闹新房，躲进新房里。献舞的素言点着了火药，新房着起大火，把十八阿哥困在里面。 \
    #    素言趁乱离开了太子宫。素言为误伤了十八阿哥的性命懊悔不已。四阿哥劝慰她，为了天下百姓，就要一直向着他们的目标一直走下去。'

    words = [u'大捷',u'中国人',u'伟大',u'军队',u'中国人民',u'解放军',u'中国人民解放军',u'解放']
    for w in words:
        trie.add(w)
    
    #str = u'国产影院大捷'
    str = u'中国人民解放军解放全中国'
    results= trie.search(str)
    for item in results:
        print "%s: %s" % (item['word'], item['pos'])

    print time.clock()

