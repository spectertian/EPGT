# -*- coding: utf-8 -*-
'''
Created on 2012-2-2

@author: zhigang
'''
from TVProgbot.db.mongodb import MongoDB
from TVProgbot import config
from TVProgbot.trie import trie
import shelve
import hashlib
import os, re

class WikiDict:
    mongodb = None
    dbm = None
    wiki_dict = None
    
    @classmethod
    def getDict(cls):
        if not cls.wiki_dict:
            cls.wiki_dict = WikiDict()
        return cls.wiki_dict
    
    def __init__(self):
        pass

    def initDict(self):
        """初始化字典，包括创建Trie树"""
        dict_file = config.getDictFile()
        if os.path.isfile(dict_file):
            os.remove(dict_file)
        self.dbm = shelve.open(dict_file, 'n')
        self.mongodb = MongoDB.getMongoDB()
        
        offset = 0
        while True:
            words = self.mongodb.getWikiNames(offset, 1000)
            if not words:
                break
            for word in words:
                trie.add(word['word'])
                hash_key = hashlib.md5(word['word'].encode('utf-8')).hexdigest()
                if self.dbm.has_key(hash_key):
                    hash_ids = self.dbm[hash_key]
                    hash_ids.append(word['id'])
                    self.dbm[hash_key] = hash_ids
                else:
                    self.dbm[hash_key] = [word['id']]
            offset = offset + 1000 
        return True

    def getWikiId(self, word):
        """根据词组返回对应的维基ID"""
        hash_key = hashlib.md5(word.encode('utf-8')).hexdigest()
        if self.dbm.has_key(hash_key):
            word_ids = self.dbm[hash_key]
        else:
            word_ids = []
        return word_ids