# -*- coding: utf-8 -*-
'''
Created on 2012-2-2

@author: zhigang
'''

from TVProgbot import config

#import pytz

from pymongo import Connection
from pymongo import ReplicaSetConnection
from pymongo import ReadPreference
from pymongo import ASCENDING, DESCENDING
try:
    from bson.objectid import ObjectId
except ImportError:
    from pymongo.objectid import ObjectId

from datetime import datetime
from datetime import timedelta
import re

class MongoDB():
    conn = None
    db = None
    mongodb = None
    
    @classmethod
    def getMongoDB(cls):
        """单例方法，返回MongoDB对象"""
        if not cls.mongodb:
            cls.mongodb = MongoDB()
        return cls.mongodb
    
    def __init__(self):
        """初始化MongoDB连接"""
        server = config.getMongoDBServer()
        database = config.getMongoDBDatabase()
        replicaSet = config.getReplicaSet()
        slaveOkay = config.getSlaveOK()
        
        if replicaSet:
            if slaveOkay:
                read_preference = ReadPreference.SECONDARY
            else:
                read_preference = ReadPreference.PRIMARY
            self.conn = ReplicaSetConnection(server,
                                             tz_aware=True,
                                             replicaSet=replicaSet,
                                             read_preference=read_preference)
        else:
            self.conn = Connection(server,tz_aware=True)
        
        self.db = self.conn[database]
    
    def getWikiById(self, wiki_id):
        """根据ID返回维基详细信息"""
        wiki = self.db.wiki.find_one({"_id": ObjectId(wiki_id)},
                                     fields=['title', 'tags', 'model', 'released']
                                     )
        return wiki
    
    def getChannels(self):
        """返回完整频道列表"""
        channels = self.db.channel.find(fields=['name','config','code','disable_tags'], limit=2000)
        return channels
    
    def getChannelByCode(self, channel_code):
        """根据channel_code返回频道详细信息"""
        channel = self.db.channel.find_one({"code": channel_code})
        return channel

    def getChannelById(self, channel_id):
        """根据ID获取频道信息
        """
        channel = self.db.channel.find_one({"_id": ObjectId(channel_id)})
        return channel
    
    def getChannelsInCode(self): 
        channels = self.db.channel.find({"code": 
                        {"$in": ['5dfcaefe6e7203df9fbe61ffd64ed1c4', 'dragontv', '09c1add87829f698cd22e8f9dfc80c5c', 'cctv4_america']}
                    }
                ) 
        return channels
        
    def getTelevision(self, channel_code, date, time):
        """根据频道及日期、时间获取栏目播出数据"""
        date_to_time = datetime.strptime("%s %s" % (date, time), "%Y-%m-%d %H:%M")
        week_day = date_to_time.weekday()
        # Python中星期一为0
        week_day = week_day + 1
        # 时间范围冗余上下各10分钟
        start_time = (date_to_time - timedelta(minutes=10)).strftime("%H:%M")
        end_time = (date_to_time + timedelta(minutes=10)).strftime("%H:%M")
        television = self.db.television.find({"channel_code": channel_code,
                                             "week_day": str(week_day),
                                             "play_time": {"$gte": start_time, "$lte": end_time}})
        if television:
            return television
        else:
            return False
    
    def getWikiNames(self, skip = 0, limit = 10):
        """获取所有的维基名称与别名，用于创建分词词典"""
        wikis = self.db.wiki.find({'model': {'$ne':'actor'}},
                                    fields=["title","alias","blocked"],
                                    skip=skip,limit=limit,
                                    sort=[("created_at", ASCENDING)])
        names = []
        for wiki in wikis:
            """跳过已屏蔽的维基"""
            if wiki.has_key('blocked') and wiki['blocked'] == True:
                continue
            names.append({"id": unicode(wiki['_id']), 'word': wiki['title']})
            if wiki.has_key('alias') and wiki['alias']:
                for wiki_alias in wiki['alias']:
                    wiki_alias = wiki_alias.strip()
                    if wiki_alias:
                        names.append({"id": unicode(wiki['_id']), 'word': wiki_alias})
        return names
    
    def insertPrograms(self, programs):
        """批量插入Program数据"""
        self.db.program.insert(programs)
        return True
    
    def removeProgramDay(self, channel_code, date):
        """删除一天节目数据，防止数据出现重复"""
        date_str = date.strftime("%Y-%m-%d")
        self.db.program.remove({
                                "channel_code": channel_code,
                                "date": date_str
                            })
        return True

    def insertProgramCollection(self, programs):
        """多来源节目单插入"""
        self.db.program_collection.insert(programs)
        return True
    
    def removeProgramCollectionDay(self, channel_code, date, referer):
        """删除一天节目数据，防止数据出现重复"""
        date_str = date.strftime("%Y-%m-%d")
        self.db.program_collection.remove({
                                    "channel_code": channel_code,
                                    "date": date_str,
                                    "referer" : referer
                                })
        return True
    
    def getIncorrectProgram(self, channel_code, incorrect_wiki_id):
        correct = self.db.program_correct.find_one({"channel_code": channel_code,
                                                "incorrect_wiki_id": incorrect_wiki_id},
                                                sort=[("updated_at", DESCENDING)]
                                            )
        return correct  

    def getChannelLatestProgram(self, channel_code, date, referer):
        latest_program = self.db.program.find_one({
                                                    "channel_code": channel_code,
                                                    "date": date,
                                                    "referer": referer    
                                                },
                                                timeout=False,
                                                sort=[("start_time", DESCENDING)]
                                            )
        return latest_program
    
    def updateProgramById(self, program_id, dict_value):
        self.db.program.update({"_id": program_id}, {"$set": dict_value})
    
    def removeProgramById(self, program_id):
        self.db.program.remove({"_id": program_id})
        
    def getChannelLatestProgramCollection(self, channel_code, date, referer):
        latest_program = self.db.program_collection.find_one({
                                                    "channel_code": channel_code,
                                                    "date": date,
                                                    "referer": referer    
                                                },
                                                timeout=False,
                                                sort=[("start_time", DESCENDING)]
                                            )
        return latest_program
    
    def updateProgramCollectionById(self, program_id, dict_value):
        self.db.program_collection.update({"_id": program_id}, {"$set": dict_value})
        
    def removeProgramCollectionById(self, program_id):
        self.db.program_collection.remove({"_id": program_id})
        
    def updateLatestProgramEndTime(self, channel_code, date, referer, end_time):
        self.db.program.update({"_id": latest_program['_id']}, {"$set": {"end_time": end_time}})
    def getPrograms(self, skip=0,limit=10):
        programs = self.db.program.find(skip=skip, limit=limit)
        return programs
    def updateProgramStatus(self, program_id, status = 0):
        self.db.program.update({"_id": program_id}, {"$set": {"status": status}})
        
