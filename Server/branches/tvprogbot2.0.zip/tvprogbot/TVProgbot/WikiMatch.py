# -*- coding: utf-8 -*-
'''
Created on 2012-2-8

@author: zhigang
'''
from TVProgbot.WikiDict import WikiDict
from TVProgbot.db.mongodb import MongoDB
from TVProgbot.WordRank import WordRank
from TVProgbot.trie import trie
from datetime import datetime
from datetime import date
from datetime import timedelta
import pytz
import re

class WikiMatch:
    db = None
    wiki = None
    debug = False
    instance = None
    
    @classmethod
    def getWikiMatch(cls):
        if not cls.instance:
            cls.instance = WikiMatch()
        return cls.instance
    
    def __init__(self):
        self.db = MongoDB.getMongoDB()
    
    def match(self, channel, program):
        program['name'] = re.sub(u'^现场直播[:|：]|直播[:|：]|首播[:|：]|重播[:|：]', "", program['name'])
        self.wiki = self.matchByTelevision(channel, program)
        if not self.wiki:
            wiki_processes = [self.matchByDict,
                            #self.programCorrect
                            ] 
            for process in wiki_processes:
                process(channel, program)
        return self.wiki

    def matchByTelevision(self, channel, program):
        """根据节目播出时间来获取关联的维基"""
        name = program['name']
        date = program['date']
        time = program['time']
        channel_code = channel['code']
        televisions = self.db.getTelevision(channel_code, date, time)
        if televisions:
            for television in televisions:
                if not television['wiki_id']:
                    continue
                try:
                    # index 方法若找不到字符会抛出 ValueError 异常
                    name.index(television['wiki_title'])
                    self.wiki = self.db.getWikiById(television['wiki_id'])
                except ValueError, e:
                    pass
    
    def matchByDict(self, channel, program):
        """根据字典智能计算出关联的维基"""
        wiki_dict = WikiDict.getDict()
        word_rank = WordRank()
        word_rank.debug = self.debug
        words = trie.search(program['name'])
        
        if self.debug:
            print '--------------trie.search-----------------------'
            for w in words:
                print 'word:',w['word'].encode('gb18030'), 'pos:',w['pos']
            print '-------------------------------------------------'    
        
        best_rank = 0.0
        best_wiki = None
        for word in words:
            wiki_ids = wiki_dict.getWikiId(word['word'])
            for wiki_id in wiki_ids:
                wiki = self.db.getWikiById(wiki_id)
                if self.isBaned(channel, program, wiki):
                    continue                
                rank = word_rank.compute(channel, program, wiki, word)
                if rank > best_rank:
                    best_rank = rank
                    best_wiki = wiki
        if best_rank >= 5:
            self.wiki = best_wiki
    
    def programCorrect(self, channel, program):
        """纠正节目, 栏目无期限、电影电视剧30天"""
        correct = self.db.getIncorrectProgram(channel['code'], unicode(self.wiki['_id']))
        if correct:
            if correct['correct_wiki_id'] == correct['incorrect_wiki_id']:
                return
            elif self.wiki['model'] == 'television':
                self.wiki = self.db.getWikiById(correct['correct_wiki_id'])
            else:
                diffday = datetime.strptime(program['date'], "%Y-%m-%d") - datetime.strptime(correct['date'], "%Y-%m-%d")
                if diffday.days >= -30 and diffday.days < 30:
                    self.wiki = self.db.getWikiById(correct['correct_wiki_id'])
                            
    def isBaned(self, channel, program, wiki):
        """判断某频道是否屏蔽某标签的维基"""
        if channel.has_key('disable_tags'):
            disable_tags = channel['disable_tags']
            for tag in disable_tags:
                if wiki.has_key('tags') and tag in wiki['tags']:
                    return True 

def wikimatch(channel, programs):
    program_data = []
    prev_program = None;
    for program in programs:
        """extra properies"""        
        created_at = datetime.now()
        tz = pytz.timezone("Asia/Shanghai")
        created_at = tz.localize(created_at)                            
        program['channel_code'] = channel['code']
        program['publish'] = True
        program['created_at'] = created_at
        program['updated_at'] = created_at
        """create program end time"""
        prev_program_end_time = program['start_time'] - timedelta(minutes=1)
        if prev_program:
            prev_program['end_time'] = prev_program_end_time
        program = programRelateWiki(channel, program)
        """append last program"""
        # playtime = prev_program['end_time'] - prev_program['start_time']
        # if playtime.seconds < 120:
        #    continue
        program_data.append(program)
        prev_program = program

    return program_data

def programRelateWiki(channel, program):
    """match wiki"""
    wiki_match = WikiMatch.getWikiMatch()
    wiki = wiki_match.match(channel, program)
    if wiki:
        program['wiki_id'] = unicode(wiki["_id"])
        if wiki.has_key('tags'):
            program['tags'] = wiki['tags']
        else:
            program['tags'] = []
    return program        
