# -*- coding: utf-8 -*-

import re

from TVProgbot.BeautifulSoup import BeautifulSoup
from TVProgbot.BeautifulSoup import Tag
from TVProgbot.site.base import SiteBase

class BaiduBaike(SiteBase):
    """百度百科节目信息抓取"""

    def Crawl(self, baike_url):
        """抓取单个节目信息
        """
        content = self.request(baike_url)
        content = content.decode('gb18030').encode('utf-8')

        baike_soup = BeautifulSoup(content, fromEncoding="utf-8",
                                    convertEntities=BeautifulSoup.HTML_ENTITIES)

        baike_url_split = baike_url.split("#")
        if len(baike_url_split) > 1:
            anchor = baike_url_split[1]
            #print anchor
            start_point = baike_soup.find("a", attrs={"name": anchor})
            #print start_point
            content_div = start_point.findNext("div", id=re.compile("^sec-content"))
            #print content_div
        else:
            #anchor = ''
            content_div = baike_soup.find("div", id=re.compile("^sec-content"))
        #print content_div
        if content_div:
            wiki_card = self.get_card_info(content_div)
            summary = self.get_wiki_summary(content_div)
            episodes = self.get_wiki_episode(content_div)
            wiki = wiki_card
            wiki['content'] = summary
            wiki['episodes'] = episodes

            return wiki

        return None

    def get_card_info(self, content_soup):
        """解析百度百科卡片信息，内容包括导演、主演等信息

        :content_soup: @todo
        :returns: @todo

        """
        card_td = content_soup.find("div", "card-info").findNext("table")\
                .findAll("td", attrs={"class": re.compile("^card")})
        wiki_info = {}
        i = 0
        while i < len(card_td):
            #print card_td[i].text
            card_title = card_td[i].text
            card_value = card_td[i+1].text
            if re.match(u"中文名", card_title):
                wiki_info["title"] = card_value
            elif re.match(ur"其它译名|外文名", card_title):
                wiki_info["alias"] = card_value
            elif re.match(u"上星时间|上映时间", card_title):
                wiki_info["play_time"] = card_value
                wiki_info["released_time"] = card_value
            elif re.match(u"总制片人|策划", card_title):
                wiki_info["producer"] = card_value
            elif re.match(u"集数", card_title):
                wiki_info["episode_count"] = card_value
            elif re.match(u"主演", card_title):
                wiki_info["starring"] = card_value.split(u"，")
            elif re.match(u"类型", card_title):
                wiki_info["tags"] = card_value.split(u"，")
            elif re.match(u"出品公司", card_title):
                wiki_info["distributor"] = card_value
            elif re.match(u"导演", card_title):
                wiki_info["director"] = card_value
            elif re.match(u"编剧", card_title):
                wiki_info["writer"] = card_value
            elif re.match(u"对白语言", card_title):
                wiki_info["language"] = card_value
            elif re.match(u"片长", card_title):
                wiki_info["runtime"] = card_value
            i += 2

        return wiki_info

    def get_wiki_summary(self, content_soup):
        """解析百度百科剧情介绍

        :content_soup: @todo
        :returns: @todo

        """
        summary = []
        summary_content_soup = content_soup.find("div", attrs={"class":re.compile("card-summary-content")}).find("p")
        if summary_content_soup:
            summary.append(summary_content_soup.text + "\n\n")

        summary_more_header = content_soup.find("div", attrs={"class":re.compile("lemma-main-content")})\
                .find("span",attrs={"class":"headline-content"})
        if summary_more_header and summary_more_header.text == u"剧情简介":
            content_lemma = summary_more_header.findParent("div", attrs={"class":re.compile("lemma-main-content")})
            h2_count = 0
            for con in content_lemma:
                if isinstance(con, Tag):
                    if con.name == u"h2":
                        h2_count += 1
                    if con.name == u"a":
                        summary.append(con.text)
                    if con.name == "div" and con.get("class") == "spctrl":
                        summary.append("\n")
                    continue
                    #print con.get("class")
                if h2_count >= 2:
                    break
                summary.append(con)

        return "".join(summary)

    def get_wiki_episode(self, content_soup):
        """解析百度百科分集介绍

        :content_soup: @todo
        :returns: @todo

        """
        episode_ul = content_soup.find("ul", attrs={"class":"plot-content-ul"})
        episodes = []
        if episode_ul:
            for li_soup in episode_ul:
                episode = {}
                title = li_soup.find("div",attrs={"class":"plot_title"})
                if title:
                    episode["title"] = title.text
                    title.extract()  # 删除 title 元素

                    episode_content = []
                    for line in li_soup:
                        if isinstance(line, Tag):
                            if line.name == "div" and line.get("class") == "spctrl":
                                episode_content.append("\n\n")
                            elif line.name == "a":
                                episode_content.append(line.text)
                        else:
                            episode_content.append(line)
                        
                    episode["content"] = "".join(episode_content)

                    episodes.append(episode)

        return episodes

