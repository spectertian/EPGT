# -*- coding: utf-8 -*-
'''
Created on 2012-2-7

@author: zhigang
'''

from datetime import datetime
from datetime import date
from datetime import timedelta
import pytz

import TVProgbot.config
from TVProgbot import util
from TVProgbot.db.mongodb import MongoDB
from TVProgbot.WikiMatch import wikimatch

from TVProgbot.site.tvsou_api import SiteTvsouApi
from TVProgbot.site.btv_site import BTVSite
from TVProgbot.site.hisports_site import HisportsSite
from TVProgbot.site.eastmovie_site import EastMovieSite
from TVProgbot.site.cntv_site import CntvSite
from TVProgbot.site.smgbb_site import SMGBBSite
from TVProgbot.site.sewise_api import SewiseApi

def task(task_queue):
    logger = util.get_logger()
    db = MongoDB.getMongoDB()
    crawl_modules = {
                'tvsou' : SiteTvsouApi,
#                'btv_site': BTVSite,
                'hisports_site': HisportsSite,
                'eastmovie_site': EastMovieSite,
#                'cntv_site': CntvSite,
#                'smgbb_site': SMGBBSite,
                'sewise': SewiseApi
            }

    for channel in iter(task_queue.get, 'STOP'):
        code = channel['code']
        logger.info("Crawl %s" % code)
        config = channel['config']
        for site, conf in config.iteritems():
            if crawl_modules.has_key(site) and callable(crawl_modules[site]):
                skip_date = TVProgbot.config.getBotSkipDate()
                crawl_day = TVProgbot.config.getBotCrawlDay()
                start_date = date.today()
                if start_date.weekday() != 0:
                    start_date = start_date + timedelta(days=skip_date)
                s = crawl_modules[site](conf)
                """to loop crawl for date"""
                for i in range(crawl_day):
                    crawl_date = start_date + timedelta(days=i)
                    programs = s.Crawl(crawl_date)
                    if programs:
                        program_data = wikimatch(channel, programs)
                        # 获取第一条数据，用于将昨天最后一条增加结果时间
                        first_program = program_data[0]
                        prev_program_end_time = first_program['start_time'] - timedelta(minutes=1)

                        # 获取昨天最后一条节目
                        yesterday_date = (first_program['start_time'] - timedelta(days=1)).strftime("%Y-%m-%d")
                        if conf.has_key('default') and conf['default'] == True:
                            latest_program = db.getChannelLatestProgram(channel['code'], yesterday_date, site)
                            if latest_program:
                                db.updateProgramById(latest_program["_id"], {"end_time": prev_program_end_time})
                        else:
                            latest_program = db.getChannelLatestProgramCollection(channel['code'], yesterday_date, site)
                            if latest_program:
                                db.updateProgramCollectionById(latest_program["_id"], {"end_time": prev_program_end_time})
                        try:
                            if conf.has_key('default') and conf['default'] == True:
                                db.removeProgramDay(channel['code'], crawl_date)
                                db.insertPrograms(program_data)
                            else:
                                db.removeProgramCollectionDay(channel['code'], crawl_date, site)
                                db.insertProgramCollection(program_data)
                        except:
                            pass
