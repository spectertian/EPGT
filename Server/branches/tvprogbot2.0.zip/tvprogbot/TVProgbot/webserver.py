# -*- coding: utf-8 -*-

# 蜘蛛抓取Webserver，用来接收参数执行任务

try:
    from twisted.internet import epollreactor
    epollreactor.install()
except:
    pass

from twisted.web.server import Site
from twisted.web.resource import Resource
from twisted.internet import reactor

from multiprocessing import Process, Queue, active_children

from TVProgbot.WikiDict import WikiDict
from TVProgbot.site.tvsou_api import SiteTvsouApi
from TVProgbot.site.btv_site import BTVSite
from TVProgbot.site.hisports_site import HisportsSite
from TVProgbot.site.eastmovie_site import EastMovieSite
from TVProgbot.site.cntv_site import CntvSite
from TVProgbot.site.smgbb_site import SMGBBSite
from TVProgbot.site.sewise_api import SewiseApi

from TVProgbot.wiki_site.BaiduBaike import BaiduBaike

from TVProgbot.db.mongodb import MongoDB
from TVProgbot.WikiMatch import wikimatch
from TVProgbot import config
from TVProgbot.task import task
from TVProgbot import util

import json
from datetime import datetime
import time
import threading
import os
import subprocess

class SingleChannel(Resource):
    """抓取单个频道"""

    def render_GET(self, request):
        db = MongoDB.getMongoDB()
        channel_id = request.args['channel_id'][0]
        date = request.args['date'][0]
        site = request.args['site'][0]

        channel = db.getChannelById(channel_id)
        if site == "tvsou":
            s = SiteTvsouApi(channel["config"]["tvsou"])
        elif site == "btv_site":
            s = BTVSite(channel["config"]["btv_site"])
        elif site == "hisports_site":
            s = HisportsSite(channel["config"]["hisports_site"])
        elif site == "eastmovie_site":
            s = EastMovieSite(channel["config"]["eastmovie_site"])
        elif site == "cntv_site":
            s = CntvSite(channel["config"]["cntv_site"])
        elif site == "smgbb_site":
            s = SMGBBSite(channel["config"]["smgbb_site"])
        elif site == "sewise":
            s = SewiseApi(channel["config"]["sewise"])

        crawl_date = datetime.strptime(date, "%Y-%m-%d")
        programs = s.Crawl(crawl_date)
        program_matched = wikimatch(channel, programs)

        programs_json = []
        for program in program_matched:
            program["start_time"] = program["start_time"].strftime("%Y-%m-%d %H:%M:%S")
            if program.has_key("end_time"):
                program["end_time"] = program["end_time"].strftime("%Y-%m-%d %H:%M:%S")
            program["created_at"] = program["created_at"].strftime("%Y-%m-%d %H:%M:%S")
            program["updated_at"] = program["updated_at"].strftime("%Y-%m-%d %H:%M:%S")
            programs_json.append(program)


        return json.dumps(programs_json)

class BatchTask(Resource):
    """启动批量节目抓取"""

    def render_GET(self, request):
        task = threading.Thread(target=self.start_batch)
        task.start()
        return "Running..."

    def start_batch(self):
        """线程任务，启动抓取
        """
        logger = util.get_logger()
        logger.info("Building Wiki Dict...")
        wiki_dict = WikiDict.getDict()
        wiki_dict.initDict()
        run_queue = Queue(100)
        task_num = int(config.getTaskNum())
        processes = [Process(target=task, args=(run_queue,))
                             for i in range(task_num)]
        for p in processes:
            p.daemon = True
            p.start()
        
        mdb = MongoDB.getMongoDB()
        channels = mdb.getChannels()
        #channels = mdb.getChannelsInCode()
        i = 0
        for channel in channels:
            #if i >= 10:
                #break
            
            while run_queue.full():
                # 若任务队列已满，则等待
                time.sleep(3)
                
            if channel.has_key('config'):
                run_queue.put(channel)
            else:
                logger.error("Channel %s config error." % channel['code'])
            i = i + 1
        
        for i in range(task_num):
            run_queue.put("STOP")
        
        for p in processes:
            p.join()

        # 抓取完成后执行wikiplay方法
        """execute symofny wikiplay script"""
        wikiplay_task = config.getWikiplayTask()
        logger.info("Execute:" + wikiplay_task)
        #os.system(wikiplay_task)
        task_proc = subprocess.Popen(wikiplay_task, shell=True,
                stdin = subprocess.PIPE,
                stdout = subprocess.PIPE,
                stderr = subprocess.PIPE)
        stdout_value, stderr_value = task_proc.communicate()
        logger.info("Task stdout %s", stdout_value)
        logger.info("Task stderr %s", stderr_value)

        logger.info("Task Finash")

class WikiFetch(Resource):
    """维基抓取WebService"""

    def render_GET(self, request):
        url = request.args['url'][0]
        baike = BaiduBaike()
        wiki = baike.Crawl(url)

        return json.dumps(wiki)

def server_run():
    """开始运行Webserver
    :returns: @todo

    """
    root = Resource()
    root.putChild("channel", SingleChannel())
    root.putChild("batch_task", BatchTask())
    root.putChild("wiki_fetch", WikiFetch())
    factory = Site(root)
    port = config.getWebserverPort()
    reactor.listenTCP(int(port), factory)
    reactor.run()

