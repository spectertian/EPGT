# -*- coding: utf-8 -*-
'''
Created on 2012-2-7

@author: zhigang
'''

import multiprocessing
import logging

import config

__logger = None
def get_logger():
    global __logger
    if not __logger:
        __logger = multiprocessing.get_logger()
        
        log_path = config.getLogPath() 
        hdlr = logging.FileHandler(log_path)
        formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
        hdlr.setFormatter(formatter)
        __logger.addHandler(hdlr)
        __logger.setLevel(logging.INFO)
    
    return __logger