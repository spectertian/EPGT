# -*- coding: utf-8 -*-
'''
Created on 2012-2-2

@author: zhigang
'''

from ConfigParser import ConfigParser
from ConfigParser import NoOptionError

_cp = ConfigParser()
def load(config_file):
    _cp.read(config_file)
    
def getMongoDBServer():
    server = _cp.get('mongodb', 'server')
    return server

def getMongoDBDatabase():
    database = _cp.get('mongodb', 'database')
    return database

def getReplicaSet():
    try:
        replicaSet = _cp.get('mongodb', 'replicaSet')
    except NoOptionError:
        replicaSet = False
    return replicaSet

def getSlaveOK():
    try:
        slaveOK = _cp.get('mongodb', 'slaveOkay')
    except NoOptionError:
        slaveOK = False
    return slaveOK

def getDictFile():
    dict_file = _cp.get('dict', 'file')
    return dict_file

def getLogPath():
    log_path = _cp.get('log', 'log_path')
    return log_path

def getBotSkipDate():
    skip_date = _cp.getint('bot', 'skip_date')
    return skip_date

def getBotCrawlDay():
    crawl_day = _cp.getint('bot', 'crawl_day')
    return crawl_day

def getWikiplayTask():
    wikiplay_task = _cp.get('final_task', 'wikiplay')
    return wikiplay_task
   
def getWebserverPort():
    port = _cp.get('webserver', 'port')
    return port

def getTaskNum():
    """批量抓取进程数目
    :returns: @todo

    """
    num = _cp.get('task', 'task_num')
    return num
