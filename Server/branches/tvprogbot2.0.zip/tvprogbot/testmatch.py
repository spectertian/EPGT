# -*- coding: utf-8 -*-
'''
Created on 2012-2-9

@author: zhigang
'''
import time
from TVProgbot.WikiDict import WikiDict
from TVProgbot import WikiMatch
from datetime import datetime

if __name__ == '__main__':
    from TVProgbot import config
    from TVProgbot.db.mongodb import MongoDB
    config.load("conf/tvprogbot.conf")
    
    print '-------------------------------------------------'   
    print 'start building dict:', time.clock()
    wiki_dict = WikiDict.getDict()
    wiki_dict.initDict()
    print 'building dict complete:', time.clock()
    print '-------------------------------------------------'

    wiki_match = WikiMatch.WikiMatch()
    wiki_match.debug = True
    
    #program_txt = u'20集连续剧《乡里乡亲住高楼》10'
    #program_txt = u'豪情剧场：《野鸭子》 10'
    #program_txt = u'偶像独播剧场：好女春华 10'
    #program_txt = u'梦剧场 连续剧 巾帼枭雄（18）（35分钟版）'
    #program_txt = u'离爱9-10（普）'
    #program_txt = u'28集连续剧《我们俩的婚姻》 21'
    #program_txt = u'《红星剧场》44集剧：乡村爱情小夜曲（38）'
    program_txt = u'剧场：双枪李向阳之再战松井 1'
    #program_txt = u'大丽家的往事2'
    #program_txt = u'《午茶剧场》瑶山大剿匪（2）'
    #program_txt = u'纪录片如此动人（下）'
    #program_txt = u'休闲剧场：血战到底 7'
    #program_txt = u'金芒果独播剧场：如意 27'
    #program_txt = u'精彩剧场：大内低手'
    #program_txt = u'喜羊羊与灰太狼之给快乐加油(3)'
    #program_txt = u'迷途 59'
    #program_txt = u'开心剧场：《化剑》 (21)'
    #program_txt = u'非常了得：孟非巧遇“韦爵爷”';
    #program_txt = u'法治中国:三千公里跨省大追踪（上）'
    #program_txt = u'影院:最爱 21'
    #program_txt = u'媳妇你当家'
    #program_txt = u'新西游记'
    #program_txt = u'风云剧场：青盲'
    program_txt = u'飞虎队'
    program_txt = u'红娘子'
    #program_txt = u'2012年过年七天乐7:1'
    #program_txt = u'真情剧场：中国兄弟连'
    #program_txt = u'经典剧场：樱桃'
    #program_txt = u'重播：记忆'
    #program_txt = u'综艺喜乐汇2'
    #program_txt = u'奋斗'
    #program_txt = u'九品芝麻官'
    #program_txt = u'中国蓝剧场：青盲'
    #program_txt = u'国产影院白求恩'
    program_txt = u'漂亮宝贝 10'
    #program_txt = u'子夜'
    #program_txt = u'一千零一夜：旗袍 31'
    #program_txt = u'最爱'
    #program_txt = u'丝路·发现精编版'
    #program_txt = u'开心剧场:爱 3'
    #program_txt = u'拍案惊奇'
    #program_txt = u'开心剧场：浪漫向左婚姻往右 3'
    #program_txt = u'开心剧场:120集:72家房客Ⅰ(66.67)(首播)'
    #program_txt = u'闯关'
    #program_txt = u'上午剧场：飞虎队'
    #program_txt = u'清新剧场：刁蛮俏御医 4'
    #program_txt = u'上午剧场:28集电视连续剧:我和老妈一起嫁 22'
    #program_txt = u'电视剧：媳妇是怎样炼成的 1'
    #program_txt = u'青盲之拍案惊奇'
    #program_txt = u'给你幸福'
    #program_txt = u'电影频道梦工场:数字电影娱乐资讯'
    #program_txt = u'黄金剧场·34集连续剧:小麦进城(34)'
    #program_txt = u'来的都是客'
    #program_txt = u'红军东征23'
    #program_txt = u'野鸭子19'
    #program_txt = u'2012财经小辞典38'
    #program_txt = u'真心话'
    #program_txt = u'飞虎神鹰'
    #program_txt = u'密使'
    #program_txt = u'白天下午剧场：秘杀名单'
    #program_txt = u'美亚保险康诊无忧经典/卓越计划'
    #program_txt = u'大金 流光能空气清洁器健康人生组合';
    #program_txt = u'经典剧场:28集电视剧:家里家外(15)'
    program_txt = u'梦想的话（88008）'
    #program_txt = u'特别呈现:大明宫1'
    #program_txt = u'香港电影周双龙吐珠'
    #program_txt = u'红玫瑰黑玫瑰14-15'
    #program_txt = u'国产影院大捷'
    #program_txt = u'黄金强档剧场战争泪9-11'
    #program_txt = u'东方 110'
    #program_txt = u'香港电影周双龙吐珠'
    #program_txt = u'国产影院大捷'
    #program_txt = u'肝胆相照(中国香港) 主演: 刘德华,张国强'
    #program_txt = u'环球影院铁面无私(美国) 主演: 凯文•科斯特纳,肖恩•康纳利'
    #program_txt = u'香港电影周皇家师姐'
    #program_txt = u'香港电影周皇家师姐III:雌雄大盗'
    #program_txt = u'午夜经典歌舞青春2'
    #program_txt = u'不死潜龙2(美国) 主演:劳勃•马德里'
    #program_txt = u'现场直播：NBA美国职业篮球联赛季后赛东部决赛第3场(08:30)'
    #program_txt = u'深夜剧场:包青天之碧血丹心（11)'
    #program_txt = u'You Are the Chef 洋厨房（1422）'
    #program_txt = u'水友互动挑战赛War3（竞技天堂1890E）'
    #program_txt = u'前妻 （19）'
    program_txt = u'还珠格格I 19'
    db = MongoDB.getMongoDB()
    #correct = db.getProgramCorrect('6d66325c27b7647781761f059c554a8c', '4ee1bd09edcd883942001ef7')
    #print unicode(correct['_id'])
    #__import__('sys').exit()
    channel = db.getChannelByCode('jztv_high')
    #print 'program_txt:', program_txt
    start_time = datetime.strptime("2012-04-10 15:35:00", "%Y-%m-%d %H:%M:%S")
    end_time = datetime.strptime("2012-04-10 17:25:00", "%Y-%m-%d %H:%M:%S")
    wiki = wiki_match.match(channel, {"name": program_txt, "date": "2012-04-10", "time": "12:03", 'start_time': start_time, 'end_time': end_time})
    if wiki:
        print 'result:[%s] %s [%s]' % (wiki['model'], wiki['title'], wiki['_id'])
    
if __name__ == 'main__':
    import re, sys
    program_txt = u'环球影院不死潜龙2(美国) 主演:劳勃•马德里'
    program_txt = u'现场直播：NBA美国职业篮球联赛季后赛东部决赛第3场(08:30)'
    program_txt = re.sub(u'^现场直播[:|：]|直播[:|：]', "", program_txt)
    print program_txt
    #
    #name_list = re.split(u':|：|影院|电影|经典', program_txt)
    #
    #for name in name_list:
    #    print name
    sys.exit();
    from datetime import datetime
    start_time = datetime.strptime("2012-04-10 19:30:00", "%Y-%m-%d %H:%M:%S")
    end_time = datetime.strptime("2012-04-10 19:45:00", "%Y-%m-%d %H:%M:%S")
    playtime = end_time - start_time
    print dir(playtime)
    print playtime.seconds  / 60
    
    