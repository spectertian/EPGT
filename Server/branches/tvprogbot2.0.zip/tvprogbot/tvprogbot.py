#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
Created on 2012-2-2

@author: zhigang
'''

__author__ = 'yinzhigang'

import os
import sys
#reload(sys)
#sys.setdefaultencoding('utf-8')

from multiprocessing import freeze_support

import TVProgbot
from TVProgbot import config
from TVProgbot import util
#from TVProgbot.db.mongodb import MongoDB
from TVProgbot.WikiDict import WikiDict
from TVProgbot import webserver

#from TVProgbot.site import tvsou_api
#
#import pytz
#from datetime import datetime

def main():
    TVProgbot.main.main()
    #webserver.server_run()

def usage():
    """参数说明"""
    print 'Usage: %s {-c config_file|-h|--help}' % sys.argv[0]

if __name__ == '__main__':
    freeze_support();
    
    import getopt
    argv = sys.argv
    try:
        opts, args = getopt.getopt(argv[1:], "hc:", ["help"])
    except getopt.GetoptError:
        usage()
        sys.exit(2)

    conf_file = None
    for o, a in opts:
        if o == '-c':
            conf_file = a
        if o in ('-h', '--help'):
            usage()
    if not conf_file:
        path = os.path.dirname(os.path.realpath(sys.argv[0]))
        if os.path.isfile(path):
            path = os.path.dirname(path)
        conf_file = os.path.join(path, 'conf/tvprogbot.conf')
    config.load(conf_file)
    """execute main"""
    main()
    
    """process the end task"""
    #import os, time
    #time.sleep(5)
    #logger = util.get_logger()
    #"""execute symofny wikiplay script"""
    #wikiplay_task = config.getWikiplayTask()
    #logger.info("Execute:" + wikiplay_task)
    #os.system(wikiplay_task)
    
#    mdb = MongoDB.getMongoDB()
#    offset = 0
#    while True:
#        wiki_names = mdb.getWikiNames(offset, 1000)
#        if not wiki_names:
#            break
#        
#        for name in wiki_names:
#            trie.add(name['word'])
#        offset = offset + 1000
#    
#    print offset

#    wiki_dict = WikiDict.getDict()
#    wiki_dict.initDict()
#    
#    programs = [u"白天下午剧场：仙剑奇侠传3",
#                u"偶像剧场：樊梨花 第2集",
#                u"电视剧：西游记 5",
#                u"白天上午剧场：仙剑奇侠传3",
#                u"开心剧场：康熙微服私访记五 13",
#                u"老大的幸福 36",
#                u"清晨剧场:30集连续剧:真假东宫(22)",
#                u"午夜剧场：风声传奇",
#                u"亮剑13",
#                u"人与自然:探秘自然",
#                u"第一动画乐园",
#                u"2012吉尼斯中国之夜3",
#                u"阳光路上32",
#                u"国产影院英雄地英雄泪",
#                u"环球影院网络惊魂(美国) 主演: 妮基•迪洛许,迪米•阿克贝",
#                u"沙场:航母大海战--重兵压境",
#                u"Real Fun秀真集（504）",
#                u"家有儿女(二)38",
#                u"少林寺传奇之十三棍僧14",
#                u"桥隆飙 21",
#                u"活力影院：天下美人",
#                u"47集剧:旗袍(33)",
#                u"活力影院:钟无艳",
#                u"下午剧场：步步惊心",
#                u"武状元苏乞儿",
#                u"非诚勿扰",
#                ]
#    
#    for program in programs:
#        print program
#        words = trie.search(program)
#        print words
#        for word in words:
#            word_id = wiki_dict.getWordId(word['word'])
#            print word['word'],word_id
#        print "============================="
    
#    mdb = mongodb.MongoDB()
#    wiki = mdb.getWikiById("4f2786131151098220003032")
#    tz = pytz.timezone("Asia/Shanghai")
#    updated_at = wiki['updated_at']
#    updated_at = updated_at.astimezone(tz)
#    
#    start_time = datetime.strptime('2012-2-2 17:14', "%Y-%m-%d %H:%M")
#    start_time = tz.localize(start_time)
#    print start_time
    #print config.getReplicaSet()
