<?php

/**
 * attachmentCategorys module helper.
 *
 * @package    epg
 * @subpackage attachmentCategorys
 * @author     Mozi Tek
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class attachment_categorysGeneratorHelper extends BaseAttachment_categorysGeneratorHelper
{
}
