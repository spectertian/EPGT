<a href="<?php echo url_for('@program_index').'?id='.$channel->getId();?>">管理</a>
