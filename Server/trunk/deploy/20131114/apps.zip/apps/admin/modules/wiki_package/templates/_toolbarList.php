<header>
  <h2 class="content"><?php echo $pageTitle?></h2>
  <nav class="utility">
    <li class="view-recommended"><a href="<?php echo url_for('wiki_package/index')?>">维基包列表</a></li>
    <li class="add"><a href="<?php echo url_for('wiki_package/add');?>">添加维基</a></li>
  </nav>
</header>