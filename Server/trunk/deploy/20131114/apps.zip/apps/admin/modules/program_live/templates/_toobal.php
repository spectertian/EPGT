<header class="toolbar">
  <h2 class="content">直播监控</h2>
  <nav class="utility">
	<li class="recommended"><a href="<?php echo url_for('program_live/liveEdit')?>">设置监控页面</a></li>
  </nav>
</header>