<?php

/**
 * channel module configuration.
 *
 * @package    epg
 * @subpackage channel
 * @author     Mozi Tek
 * @version    SVN: $Id: configuration.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class channelGeneratorConfiguration extends BaseChannelGeneratorConfiguration
{
}
