<header>
  <h2 class="content">开发者列表</h2>
  <nav class="utility">
    <li class="add"><a href="<?php echo url_for('developer/new');?>">添加</a></li>
    <li class="delete"><a href="javascript:if(confirm('确定删除吗？')){submitform('delete');}">删除</a></li>
  </nav>
</header>