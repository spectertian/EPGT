<p style='margin:auto;font-weight:bold;font-size:30px'>您暂无此操作权限  
 <a style='font-size:15px' href='<?php echo $url ?>'>点此返回</a>
</p>