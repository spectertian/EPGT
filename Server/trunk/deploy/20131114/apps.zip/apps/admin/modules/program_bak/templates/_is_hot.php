<img src="<?php echo image_path($program->getExt('hot'));?>" alt="热门">
