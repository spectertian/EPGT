<div id="toolbar-box">
    <div class="t"><div class="t"><div class="t"></div></div></div>
    <div class="m">
                <div class="toolbar" id="toolbar">
                    <table class="toolbar">
                        <tbody>
                            <tr>
                                </td>
                                <td class="button" style="width: 80px; text-align:center">
                                    <a class="toolbar addNewProgram" href="#" onclick="return false;" title="添加节目">
                                        <span title="添加新节目" class="icon-32-publish"></span>
                                        添加节目
                                    </a>
                                </td>
                                <td class="button" style="width: 80px; text-align:center">
                                    <a href="#" onclick="return false;" class="toolbar delete">
                                        <span class="icon-32-delete" title="Delete"></span>
                                        删除
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
            </div>
            <div class="header icon-48-addedit" style='font-size:16px;font-weight:bold;color:#fff'>节目单</div>
        <div class="clr"></div>
    </div>
    <div class="b"><div class="b"><div class="b"></div></div></div>
</div>