<header>
  <h2 class="content"><?php echo $pageTitle?></h2>
  <nav class="utility">
  </nav>
</header>