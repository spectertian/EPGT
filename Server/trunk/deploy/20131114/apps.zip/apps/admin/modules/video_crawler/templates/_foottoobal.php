<header class="toolbar">
  <nav class="utility">
<!--    <li class="app-add"><a class="toolbar addNewEndProgram" href="#" onclick="return false;" title="添加节目">添加节目</a></li>-->
    <li class="app-add"> <a href="#" onclick="save_onekey();return false;" class="toolbar">一键保存</a></li>
    <li class="delete"><a class="toolbar" href="#">删除</a></li>
  </nav>
</header>