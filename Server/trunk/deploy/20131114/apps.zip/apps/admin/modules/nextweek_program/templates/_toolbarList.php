<header>
  <h2 class="content"><?php echo $pageTitle ?></h2>
  <nav class="utility">
	<li class="back"><a href="<?php echo "/nextweek_program/list?date=".$date;?> ">返回列表</a></li>
  </nav>
</header>
