<td id="toolbar-add" class="button">
    <a href="<?php echo url_for('@wiki').'/select?height=600&width=800';?>" class="thickbox" title="请选择一个类型"><span title="New" class="icon-32-new"></span>
新增</a></td>
