<form method="get" action="">
    <label>关键字：</label>
    <input name="q" id="q"  value="<?php echo $q?>" type="text">
 <input type="submit" value="查询"> &nbsp;
