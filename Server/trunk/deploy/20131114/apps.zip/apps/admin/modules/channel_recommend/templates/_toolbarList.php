<header>
  <h2 class="content">频道推荐列表</h2>
  <nav class="utility">
  <li class="add"><a href="<?php echo url_for("channel_recommend/add?channel_id=$channel_id")?>">添加</a></li>
  </nav>
</header>