<header>
  <h2 class="content">监控频道设置</h2>
  <nav class="utility">
    <li class="save"><a href="#" onclick="javascript:submitform()" id="save_data">保存设置</a></li>
    <li class="back"><a href="<?php echo url_for('program_live/index')?>">监控页面</a></li>

  </nav>
</header>