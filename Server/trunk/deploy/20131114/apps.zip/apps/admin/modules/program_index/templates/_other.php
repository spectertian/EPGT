<a href="<?php echo url_for('@program_template').'?id='.$program_index->getId();?>" title="添加节目时【使用模板】可载入的节目">管理</a>&nbsp;
