<?php

/**
 * attachmentCategorys module configuration.
 *
 * @package    epg
 * @subpackage attachmentCategorys
 * @author     Mozi Tek
 * @version    SVN: $Id: configuration.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class attachment_categorysGeneratorConfiguration extends BaseAttachment_categorysGeneratorConfiguration
{
}
