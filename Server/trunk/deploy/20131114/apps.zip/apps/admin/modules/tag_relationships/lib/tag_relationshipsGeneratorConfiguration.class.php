<?php

/**
 * tag_relationships module configuration.
 *
 * @package    epg
 * @subpackage tag_relationships
 * @author     Mozi Tek
 * @version    SVN: $Id: configuration.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class tag_relationshipsGeneratorConfiguration extends BaseTag_relationshipsGeneratorConfiguration
{
}
