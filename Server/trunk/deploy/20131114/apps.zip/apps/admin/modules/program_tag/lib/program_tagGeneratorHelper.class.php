<?php

/**
 * program_tag module helper.
 *
 * @package    epg
 * @subpackage program_tag
 * @author     Mozi Tek
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class program_tagGeneratorHelper extends BaseProgram_tagGeneratorHelper
{
}
