<?php

/**
 * program module helper.
 *
 * @package    epg
 * @subpackage program
 * @author     Mozi Tek
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class programGeneratorHelper extends BaseProgramGeneratorHelper
{
}
