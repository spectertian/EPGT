<!doctype html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>404</title>
<link rel="shortcut icon" href="favicon.ico" />
</head>
<body style="width:100%; height:100%; margin:0; padding:0; background:#000;">
<div style="position:absolute; top:0; left:0; width:14%; height:60%; background:#ccc;"></div>
<div style="position:absolute; top:0; left:14%; width:14%; height:60%; background:#b9cb05;"></div>
<div style="position:absolute; top:0; left:28%; width:14%; height:60%; background:#42d2b9;"></div>
<div style="position:absolute; top:0; left:42%; width:14%; height:60%; background:#49dd05;"></div>
<div style="position:absolute; top:0; left:56%; width:14%; height:60%; background:#ae03b4;"></div>
<div style="position:absolute; top:0; left:70%; width:14%; height:60%; background:#a90d00;"></div>
<div style="position:absolute; top:0; left:84%; width:16%; height:60%; background:#0300b3;"></div>
<div style="position:absolute; top:60%; left:0; width:14%; height:11%; background:#0400b7;"></div>
<div style="position:absolute; top:60%; left:14%; width:14%; height:11%; background:#111;"></div>
<div style="position:absolute; top:60%; left:28%; width:14%; height:11%; background:#ab02b5;"></div>
<div style="position:absolute; top:60%; left:42%; width:14%; height:11%; background:#111;"></div>
<div style="position:absolute; top:60%; left:56%; width:14%; height:11%; background:#42d2b9;"></div>
<div style="position:absolute; top:60%; left:70%; width:14%; height:11%; background:#111;"></div>
<div style="position:absolute; top:60%; left:84%; width:16%; height:11%; background:#ccc;"></div>
<div style="position:absolute; top:71%; left:0; width:17%; height:29%; background:#0b3f64;"></div>
<div style="position:absolute; top:71%; left:17%; width:18%; height:29%; background:#fdfdfd;"></div>
<div style="position:absolute; top:71%; left:35%; width:18%; height:29%; background:#3a0070;"></div>
<div style="position:absolute; top:71%; left:53%; width:17%; height:29%; background:#111;"></div>
<div style="position:absolute; top:71%; left:70%; width:4%; height:29%; background:#000;"></div>
<div style="position:absolute; top:71%; left:74%; width:6%; height:29%; background:#111;"></div>
<div style="position:absolute; top:71%; left:80%; width:4%; height:29%; background:#1d1d1d;"></div>
<div style="position:absolute; top:71%; left:84%; width:16%; height:29%; background:#111;"></div>
<div style="position:absolute; top:50%; left:50%; width:960px; height:200px; margin:-200px 0 0 -480px; line-height:200px; text-align:center; font-size:64px; color:#fff; font-family:'microsoft yahei';">404错误。</div>
</body>
</html>