<?php

/**
 * DoubanMovie Form.
 */
class DoubanMovieForm extends BaseDoubanMovieForm
{
}