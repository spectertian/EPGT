<?php

/**
 * WikiRecommend Form.
 */
class WikiRecommendForm extends BaseWikiRecommendForm
{
}