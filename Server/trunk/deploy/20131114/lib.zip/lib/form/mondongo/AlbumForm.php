<?php

/**
 * Album Form.
 */
class AlbumForm extends BaseAlbumForm
{
}