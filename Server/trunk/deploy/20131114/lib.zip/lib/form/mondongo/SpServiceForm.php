<?php

/**
 * SpService Form.
 */
class SpServiceForm extends BaseSpServiceForm
{
}