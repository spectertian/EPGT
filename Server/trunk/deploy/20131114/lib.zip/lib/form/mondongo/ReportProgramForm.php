<?php

/**
 * ReportProgram Form.
 */
class ReportProgramForm extends BaseReportProgramForm
{
}