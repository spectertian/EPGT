<?php

/**
 * ProgramSport Form.
 */
class ProgramSportForm extends BaseProgramSportForm
{
}