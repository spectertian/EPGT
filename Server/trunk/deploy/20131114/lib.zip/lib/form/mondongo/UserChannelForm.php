<?php

/**
 * UserChannel Form.
 */
class UserChannelForm extends BaseUserChannelForm
{
}