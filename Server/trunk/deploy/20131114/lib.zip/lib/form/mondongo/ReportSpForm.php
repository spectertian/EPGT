<?php

/**
 * ReportSp Form.
 */
class ReportSpForm extends BaseReportSpForm
{
}