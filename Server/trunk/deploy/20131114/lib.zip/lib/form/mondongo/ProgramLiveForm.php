<?php

/**
 * ProgramLive Form.
 */
class ProgramLiveForm extends BaseProgramLiveForm
{
}