<?php

/**
 * DoubanCelebrity Form.
 */
class DoubanCelebrityForm extends BaseDoubanCelebrityForm
{
}