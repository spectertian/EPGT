<?php

/**
 * YesterdayProgram Form.
 */
class YesterdayProgramForm extends BaseYesterdayProgramForm
{
}