<?php

/**
 * ShortMoviePackageItem Form.
 */
class ShortMoviePackageItemForm extends BaseShortMoviePackageItemForm
{
}