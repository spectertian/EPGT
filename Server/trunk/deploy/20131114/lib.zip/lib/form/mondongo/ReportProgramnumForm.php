<?php

/**
 * ReportProgramnum Form.
 */
class ReportProgramnumForm extends BaseReportProgramnumForm
{
}