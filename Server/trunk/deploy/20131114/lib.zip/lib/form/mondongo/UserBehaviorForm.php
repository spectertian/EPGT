<?php

/**
 * UserBehavior Form.
 */
class UserBehaviorForm extends BaseUserBehaviorForm
{
}