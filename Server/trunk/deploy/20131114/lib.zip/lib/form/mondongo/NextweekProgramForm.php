<?php

/**
 * NextweekProgram Form.
 */
class NextweekProgramForm extends BaseNextweekProgramForm
{
}