<?php

/**
 * SimpleAdvert Form.
 */
class SimpleAdvertForm extends BaseSimpleAdvertForm
{
}