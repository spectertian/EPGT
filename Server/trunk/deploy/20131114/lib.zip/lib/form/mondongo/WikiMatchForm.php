<?php

/**
 * WikiMatch Form.
 */
class WikiMatchForm extends BaseWikiMatchForm
{
}