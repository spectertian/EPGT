<?php

/**
 * ProgramArchiver Form.
 */
class ProgramArchiverForm extends BaseProgramArchiverForm
{
}