<?php

/**
 * ChannelUpdate Form.
 */
class ChannelUpdateForm extends BaseChannelUpdateForm
{
}