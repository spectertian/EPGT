<?php

/**
 * TvsouMatchWiki Form.
 */
class TvsouMatchWikiForm extends BaseTvsouMatchWikiForm
{
}