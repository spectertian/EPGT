<?php

/**
 * ProgramTemp Form.
 */
class ProgramTempForm extends BaseProgramTempForm
{
}