<?php

/**
 * ShortMoviePackage Form.
 */
class ShortMoviePackageForm extends BaseShortMoviePackageForm
{
}