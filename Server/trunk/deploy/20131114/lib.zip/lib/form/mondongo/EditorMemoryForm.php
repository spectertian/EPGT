<?php

/**
 * EditorMemory Form.
 */
class EditorMemoryForm extends BaseEditorMemoryForm
{
}