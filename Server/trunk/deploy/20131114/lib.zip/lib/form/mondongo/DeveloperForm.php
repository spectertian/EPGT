<?php

/**
 * Developer Form.
 */
class DeveloperForm extends BaseDeveloperForm
{
}