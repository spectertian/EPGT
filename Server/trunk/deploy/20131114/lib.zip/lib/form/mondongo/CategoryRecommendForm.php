<?php

/**
 * CategoryRecommend Form.
 */
class CategoryRecommendForm extends BaseCategoryRecommendForm
{
}