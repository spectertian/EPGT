<?php

/**
 * Comment Form.
 */
class CommentForm extends BaseCommentForm
{
}