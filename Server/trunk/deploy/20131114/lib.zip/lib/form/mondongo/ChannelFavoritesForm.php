<?php

/**
 * ChannelFavorites Form.
 */
class ChannelFavoritesForm extends BaseChannelFavoritesForm
{
}