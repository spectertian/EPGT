<?php

/**
 * ProgramRec Form.
 */
class ProgramRecForm extends BaseProgramRecForm
{
}