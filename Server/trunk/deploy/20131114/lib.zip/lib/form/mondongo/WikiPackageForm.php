<?php

/**
 * WikiPackage Form.
 */
class WikiPackageForm extends BaseWikiPackageForm
{
}