<?php

/**
 * Setting Form.
 */
class SettingForm extends BaseSettingForm
{
}