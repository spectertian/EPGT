<?php

/**
 * WikiLiverecommend Form.
 */
class WikiLiverecommendForm extends BaseWikiLiverecommendForm
{
}