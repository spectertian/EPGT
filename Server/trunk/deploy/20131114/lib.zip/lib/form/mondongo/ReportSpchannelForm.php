<?php

/**
 * ReportSpchannel Form.
 */
class ReportSpchannelForm extends BaseReportSpchannelForm
{
}