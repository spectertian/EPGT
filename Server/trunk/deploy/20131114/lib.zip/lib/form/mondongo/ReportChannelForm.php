<?php

/**
 * ReportChannel Form.
 */
class ReportChannelForm extends BaseReportChannelForm
{
}