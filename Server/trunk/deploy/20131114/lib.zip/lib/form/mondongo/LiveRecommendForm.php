<?php

/**
 * LiveRecommend Form.
 */
class LiveRecommendForm extends BaseLiveRecommendForm
{
}