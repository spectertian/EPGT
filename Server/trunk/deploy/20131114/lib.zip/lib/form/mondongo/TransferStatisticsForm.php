<?php

/**
 * TransferStatistics Form.
 */
class TransferStatisticsForm extends BaseTransferStatisticsForm
{
}