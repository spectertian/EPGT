<?php

/**
 * VideosZhui Form.
 */
class VideosZhuiForm extends BaseVideosZhuiForm
{
}