<?php

/**
 * VideoPlaylist Form.
 */
class VideoPlaylistForm extends BaseVideoPlaylistForm
{
}