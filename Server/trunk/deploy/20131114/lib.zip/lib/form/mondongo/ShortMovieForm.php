<?php

/**
 * ShortMovie Form.
 */
class ShortMovieForm extends BaseShortMovieForm
{
}