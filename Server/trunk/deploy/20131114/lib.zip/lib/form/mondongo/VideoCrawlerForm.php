<?php

/**
 * VideoCrawler Form.
 */
class VideoCrawlerForm extends BaseVideoCrawlerForm
{
}