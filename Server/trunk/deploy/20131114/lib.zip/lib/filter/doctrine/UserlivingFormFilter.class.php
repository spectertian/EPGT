<?php

/**
 * Userliving filter form.
 *
 * @package    epg2.0
 * @subpackage filter
 * @author     Huan Tek
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class UserlivingFormFilter extends BaseUserlivingFormFilter
{
  public function configure()
  {
  }
}
