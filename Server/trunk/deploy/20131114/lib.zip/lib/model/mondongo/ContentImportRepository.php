<?php

/**
 * Repository of ContentImport document.
 */
class ContentImportRepository extends \BaseContentImportRepository
{
}