<?php

/**
 * Repository of Terminal document.
 */
class TerminalRepository extends \BaseTerminalRepository
{
}