<?php

/**
 * SimpleAdvert document.
 */
class SimpleAdvert extends \BaseSimpleAdvert
{
}