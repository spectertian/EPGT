<?php

/**
 * NextweekProgram document.
 */
class NextweekProgram extends \BaseNextweekProgram
{
}