<?php

/**
 * ReportSpchannel document.
 */
class ReportSpchannel extends \BaseReportSpchannel
{
}