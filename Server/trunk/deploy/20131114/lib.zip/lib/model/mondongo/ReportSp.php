<?php

/**
 * ReportSp document.
 */
class ReportSp extends \BaseReportSp
{
}