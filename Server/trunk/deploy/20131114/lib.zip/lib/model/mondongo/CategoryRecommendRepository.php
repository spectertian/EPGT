<?php

/**
 * Repository of CategoryRecommend document.
 */
class CategoryRecommendRepository extends \BaseCategoryRecommendRepository
{
}