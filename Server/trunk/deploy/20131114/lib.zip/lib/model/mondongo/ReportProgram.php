<?php

/**
 * ReportProgram document.
 */
class ReportProgram extends \BaseReportProgram
{
}