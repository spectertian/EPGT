<?php

/**
 * Repository of LiveRecommend document.
 */
class LiveRecommendRepository extends \BaseLiveRecommendRepository
{
}