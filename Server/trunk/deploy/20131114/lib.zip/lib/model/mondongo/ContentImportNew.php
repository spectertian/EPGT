<?php
/**
 * ContentImport document.
 */
class ContentImportNew extends ContentImport
{
    public function  setId($value) {
        parent::setPropety('_id', $value);
    }
}