<?php

/**
 * ChannelUpdate document.
 */
class ChannelUpdate extends \BaseChannelUpdate
{
}