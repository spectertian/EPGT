<?php

/**
 * LiveRecommend document.
 */
class LiveRecommend extends \BaseLiveRecommend
{
}