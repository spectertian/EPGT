<?php

/**
 * Setting document.
 */
class Setting extends \BaseSetting
{
}