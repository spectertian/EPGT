<?php

/**
 * ReportProgramnum document.
 */
class ReportProgramnum extends \BaseReportProgramnum
{
}