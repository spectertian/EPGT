<?php

/**
 * Repository of ProgramRec document.
 */
class ProgramRecRepository extends \BaseProgramRecRepository
{
}