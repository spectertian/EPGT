<?php

/**
 * Developer document.
 */
class Developer extends \BaseDeveloper
{
}