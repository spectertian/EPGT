<?php

/**
 * ShortMoviePackageItem document.
 */
class ShortMoviePackageItem extends \BaseShortMoviePackageItem
{
}