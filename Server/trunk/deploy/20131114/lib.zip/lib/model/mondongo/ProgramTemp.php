<?php

/**
 * ProgramTemp document.
 */
class ProgramTemp extends \BaseProgramTemp
{
}