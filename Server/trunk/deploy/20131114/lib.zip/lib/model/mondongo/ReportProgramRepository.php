<?php

/**
 * Repository of ReportProgram document.
 */
class ReportProgramRepository extends \BaseReportProgramRepository
{
}