<?php

/**
 * ContentInject document.
 */
class ContentInjectNew extends ContentInject
{
    public function  setId($value) {
        parent::setPropety('_id', $value);
    }
}