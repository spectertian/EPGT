<?php

/**
 * ShortMoviePackage document.
 */
class ShortMoviePackage extends \BaseShortMoviePackage
{
}