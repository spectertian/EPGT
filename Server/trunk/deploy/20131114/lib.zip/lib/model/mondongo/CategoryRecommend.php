<?php

/**
 * CategoryRecommend document.
 */
class CategoryRecommend extends \BaseCategoryRecommend
{
}