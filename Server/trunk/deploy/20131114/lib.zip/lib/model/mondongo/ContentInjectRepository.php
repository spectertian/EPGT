<?php

/**
 * Repository of ContentInject document.
 */
class ContentInjectRepository extends \BaseContentInjectRepository
{
}