<?php

/**
 * Repository of Album document.
 */
class AlbumRepository extends \BaseAlbumRepository
{
}