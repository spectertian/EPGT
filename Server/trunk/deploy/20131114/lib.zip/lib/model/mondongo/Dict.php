<?php

/**
 * Dict document.
 */
class Dict extends \BaseDict
{
}