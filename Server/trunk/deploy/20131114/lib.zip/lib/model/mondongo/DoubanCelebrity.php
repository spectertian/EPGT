<?php

/**
 * DoubanCelebrity document.
 */
class DoubanCelebrity extends \BaseDoubanCelebrity
{
}