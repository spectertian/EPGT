<?php

/**
 * Repository of DoubanMovie document.
 */
class DoubanMovieRepository extends \BaseDoubanMovieRepository
{
}