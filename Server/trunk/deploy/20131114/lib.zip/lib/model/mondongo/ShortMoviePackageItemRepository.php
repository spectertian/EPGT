<?php

/**
 * Repository of ShortMoviePackageItem document.
 */
class ShortMoviePackageItemRepository extends \BaseShortMoviePackageItemRepository
{
}