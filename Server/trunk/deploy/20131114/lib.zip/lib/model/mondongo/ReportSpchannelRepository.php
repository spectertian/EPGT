<?php

/**
 * Repository of ReportSpchannel document.
 */
class ReportSpchannelRepository extends \BaseReportSpchannelRepository
{
}