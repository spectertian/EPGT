<?php

/**
 * ProgramArchiver document.
 */
class ProgramArchiver extends \BaseProgramArchiver
{
}