<?php

/**
 * ShortMovie document.
 */
class ShortMovie extends \BaseShortMovie
{
  
}