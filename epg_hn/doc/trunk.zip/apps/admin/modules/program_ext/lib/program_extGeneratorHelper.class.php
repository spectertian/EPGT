<?php

/**
 * program_ext module helper.
 *
 * @package    epg
 * @subpackage program_ext
 * @author     Mozi Tek
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class program_extGeneratorHelper extends BaseProgram_extGeneratorHelper
{
}
