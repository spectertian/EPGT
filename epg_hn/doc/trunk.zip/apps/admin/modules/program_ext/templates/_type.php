<?php
$arr    = array('new' => '新节目', 'top' => '推荐', 'hot' => '热播');
echo $arr[$program_ext->getStyle()];

?>
