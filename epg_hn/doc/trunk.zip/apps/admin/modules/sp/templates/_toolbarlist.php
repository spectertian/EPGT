<header>
  <h2 class="content"><?php echo $pageTitle?></a></h2>
  <nav class="utility">
    <li class="add"><a href="<?php echo url_for("sp/add")?>">添加</a></li>
	<!--
    <li class="delete"><a class="toolbar" onclick="javascript:submitform('batchDelete')" href="#">删除</a></li>
	-->
  </nav>
</header>
