<td id="toolbar-new" class="button">
    <a href="javascript:init();"><span title="New" class="icon-32-new"></span>批量添加</a>
</td>
