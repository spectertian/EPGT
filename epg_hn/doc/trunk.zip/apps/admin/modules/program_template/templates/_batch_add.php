<td class="button">
    <a class="toolbar" href="javascript:init();">
        <span title="批量添加" class="icon-32-new"></span>批量添加</a>
</td>