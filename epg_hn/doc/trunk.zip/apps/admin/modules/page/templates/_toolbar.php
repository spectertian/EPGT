<div id="toolbar" class="toolbar">
    <table class="toolbar">
        <tbody>
            <tr>
                <td id="toolbar-publish" class="button">
                    <a class="toolbar" onclick="javascript:submitform()" href="#"><span title="保存" class="icon-32-save"></span>保存</a>
                </td>
                <td class="button">
                    <a href="<?php echo url_for('page/index');?>"><span class="icon-32-cancel"></span>返回列表</a>
                </td>
            </tr>
        </tbody>
    </table>
</div>
