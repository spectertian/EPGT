<?php

/**
 * media module configuration.
 *
 * @package    epg
 * @subpackage media
 * @author     Mozi Tek
 * @version    SVN: $Id: configuration.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class mediaGeneratorConfiguration extends BaseMediaGeneratorConfiguration
{
}
