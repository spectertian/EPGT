<?php sfContext::getInstance()->getConfiguration()->loadHelpers('GetFileUrl');?>
<?php 
  if($tagsList){
    foreach($tagsList as $key=>$val){
      echo "<span onclick='javascript:showson_();'>aaaaaaaa</span>";
    }
  }
?>