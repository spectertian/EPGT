<a href="<?php echo url_for('@program_template').'/index/id/'.$program_index->getId();?>"><?php echo $program_index->getTitle();?></a>
