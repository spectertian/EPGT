<?php

/**
 * admin module helper.
 *
 * @package    epg
 * @subpackage admin
 * @author     Mozi Tek
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class themeGeneratorHelper extends BaseThemeGeneratorHelper
{
}
