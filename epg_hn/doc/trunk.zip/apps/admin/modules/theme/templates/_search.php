<form method="get" action="">
                    专题名称:
                    <input type="text" value="<?php echo $mc?>" name="mc" id="mc">
                    <input type="submit" value="查询">
</form><br />