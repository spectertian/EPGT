<?php
echo getStamp($wiki->getStyle());
?>
