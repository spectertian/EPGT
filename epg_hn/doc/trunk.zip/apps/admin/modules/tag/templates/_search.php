<form method="get" action="">
                    标签名称:
                    <input type="text" value="<?php echo $mc?>" name="mc" id="mc">
                    <input type="submit" value="查询">
</form>