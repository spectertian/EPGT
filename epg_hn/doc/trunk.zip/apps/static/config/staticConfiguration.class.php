<?php

class staticConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
