<?php

class henan_tvConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
