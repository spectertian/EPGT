 <div class="footer">
    <div class="back" id="footer_back">
      <div class="action button">返回</div>
    </div>
    <div class="pages">
      <div class="action pgu button" rel="pageUp">上页</div>
      <div class="action pgd button" rel="pageDown">下页</div>
    </div>
<!--    <div class="normal" id="footer_play">
      <div class="button disabled">播放节目</div>
    </div>
    <div class="normal" id="footer_source">
      <div class="button disabled">片库资源</div>
    </div>-->
    <div class="help">
      <span>按</span>
      <span class="arrows">&lt; &gt;</span>
      <span>键选择，按</span>
      <span class="button">OK</span>
      <span>键确认</span>
    </div>
</div>
