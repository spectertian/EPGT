<?php
// n/j 7/8
// m/d 07/08
echo weekdays_nav('m/d');
?>
