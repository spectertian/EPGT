<script type="text/javascript">
    $(function(){
        var wiki_id = '';
        var back_target = '';
        $('#home-left').list({
            direction: 'V',
            focus: function(event) {
                $(this).addClass('hover');
                //var title = $(this).find('div.title').text();
                //$('#footer_info_title').text(title);
                //$('.info').removeClass('display-none');
            },
            blur: function(event) {
                $(this).removeClass('hover');
            },
            left: function(event) {
                $('#home-right').data('ui').focus();
            },
            right: function(event) {
                $('#home-right').data('ui').focus();
            },
            enter: function(event, item) {
                wiki_id = item.attr('rel');
                back_target = '#home-left';
                var wiki_url = '<?php echo url_for('wiki/detail?id='); ?>' + wiki_id;
               $("#wiki-sizer").load(wiki_url, function() {
                    $("#main-nav-sizer").addClass("display-none");
                    $("#wiki-sizer").attr('return_target', back_target);
                    $("#wiki-sizer").removeClass("display-none");
                    $('#tab').data('ui').focus();
                });
                /*
                back_target = '#home-left';
                var popup = $('#popup');
                popup.removeClass('display-none');
                popup.list('focus');
                popup.data('back', $(this));
                */
            },
            change: function(event, ui) {
            },
            up: function( event, ui ) {
                $('#menu-bar').data('ui').focus();
            }
        });
        $('#home-right').grid({
            coords: [3 , 1],
            change: function(event, ui) {
                //var title = ui.to.find('div.title').text();
                //$('#footer_info_title').text(title);
                //$('.info').show();
            },
            enter: function(event, item) {
                wiki_id = item.attr('rel');
                back_target = '#home-right';
                var wiki_url = '<?php echo url_for('wiki/detail?id='); ?>' + wiki_id;
                $("#wiki-sizer").load(wiki_url, function() {
                    $("#main-nav-sizer").addClass("display-none");
                    $("#wiki-sizer").attr('return_target', back_target);
                    $("#wiki-sizer").removeClass("display-none");
                    $('#tab').data('ui').focus();
                });
                /* 2010-11-11
                back_target = '#home-right';
                var popup = $('#popup');
                popup.removeClass('display-none');
                popup.list('focus');
                popup.data('back', $(this));
                */
            },
            leftBorde: function(event, ui) {
                $('#home-left').data('ui').focus();
            },
            rightBorde: function(event, ui) {
                $('#home-left').data('ui').focus();
            },
            upBorde: function (event , pos ){
                $('#menu-bar').data('ui').focus();
            }

        });
        /* 2010-11-11
        $('#popup').list({
            direction: 'V',
            enter: function(event, item) {
                var href = item.attr('href');
                if(href == 'closePoup') {
                    var back = $(this).data('back');
                    $('#popup').addClass('display-none');
                    back.data('ui').focus();
                } else if (href == 'showDetail') {
                    $('#popup').addClass('display-none');
                    var wiki_url = '<?php echo url_for('wiki/show?id='); ?>' + wiki_id;
                    $("#wiki-sizer").load(wiki_url, function() {
                        $("#main-nav-sizer").addClass("display-none");
                        $("#wiki-sizer").attr('return_target', back_target);
                        $("#wiki-sizer").removeClass("display-none");

                        $('#footer_back').list('focus');
                    });
                }
            }
        });
        */
    });
</script>
<div class="epg-home">
    <div id="home-left">
        <div class="action spotlight" rel="51778979ed454ba635000000">
            <div class="frame">
                <div class="title">《盛夏晚晴天》</div>
                <div class="description">根据柳晨枫同名小说改编,由杨幂,刘恺威,吴建飞,樊少皇等人主演。</div>
                <div class="button">查看详情</div>
            </div>
            <img src="public/home_spotlight.jpg?v=7" width="895" height="498" alt="">
        </div>
    </div>
    <div id="home-right">
        <div class="featured">
            <ul>
                <li class="action" rel="5191a013ed454b0761000001">
                    <div class="frame">
                        <div class="title">《宝贝》</div>
                        <div class="button">详情</div>
                    </div>
                    <img src="public/home_featured1.jpg?v=7" width="268" height="156" alt="">
                </li>
                <li class="action" rel="518c58c1ed454b7e23000002">
                    <div class="frame">
                        <div class="title">《大宅门1912》</div>
                        <div class="button">详情</div>
                    </div>
                    <img src="public/home_featured2.jpg?v=7" width="268" height="156" alt="">
                </li>
                <li class="action" rel="518224e2ed454bbc22000000">
                    <div class="frame">
                        <div class="title">《陆贞传奇》</div>
                        <div class="button">详情</div>
                    </div>
                    <img src="public/home_featured3.jpg?v=7" width="268" height="156" alt="">
                </li>
            </ul>
        </div>
    </div>
</div>

<div class="footer">
    <div class="info display-none">
        <span id="footer_info_title"></span>
        <span class="progress">
            <span class="track" style="width:20%"></span>
        </span>
        <span>00:30/01:30</span>
    </div>
    <div class="help">
        <span>按</span>
        <span class="arrows">&lt; &gt;</span>
        <span>键选择，按</span>
        <span class="button">OK</span>
        <span>键确认</span>
    </div>
</div>

<?php   include_partial('tcl/popup'); ?>