<?php

/**
 * MigrationVersion filter form.
 *
 * @package    epg
 * @subpackage filter
 * @author     Mozi Tek
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class MigrationVersionFormFilter extends BaseMigrationVersionFormFilter
{
  public function configure()
  {
  }
}
