<?php

/**
 * program_ext module configuration.
 *
 * @package    epg
 * @subpackage program_ext
 * @author     Mozi Tek
 * @version    SVN: $Id: configuration.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class program_extGeneratorConfiguration extends BaseProgram_extGeneratorConfiguration
{
}
