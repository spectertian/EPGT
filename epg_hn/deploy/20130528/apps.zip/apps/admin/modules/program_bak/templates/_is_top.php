<img src="<?php echo image_path($program->getExt('top'));?>" alt="推荐">
