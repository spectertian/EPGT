<img src="<?php echo image_path($program->getExt('new'));?>" alt="新节目">
