<?php

/**
 * program_template module configuration.
 *
 * @package    epg
 * @subpackage program_template
 * @author     Mozi Tek
 * @version    SVN: $Id: configuration.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class program_templateGeneratorConfiguration extends BaseProgram_templateGeneratorConfiguration
{
}
