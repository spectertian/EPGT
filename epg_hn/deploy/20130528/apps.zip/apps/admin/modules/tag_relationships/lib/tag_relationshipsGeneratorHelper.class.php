<?php

/**
 * tag_relationships module helper.
 *
 * @package    epg
 * @subpackage tag_relationships
 * @author     Mozi Tek
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class tag_relationshipsGeneratorHelper extends BaseTag_relationshipsGeneratorHelper
{
}
