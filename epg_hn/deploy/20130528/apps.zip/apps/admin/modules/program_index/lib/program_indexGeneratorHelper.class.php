<?php

/**
 * program_index module helper.
 *
 * @package    epg
 * @subpackage program_index
 * @author     Mozi Tek
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class program_indexGeneratorHelper extends BaseProgram_indexGeneratorHelper
{
}
