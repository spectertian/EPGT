<?php

/**
 * tv_station module helper.
 *
 * @package    epg
 * @subpackage tv_station
 * @author     Mozi Tek
 * @version    SVN: $Id: helper.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class tv_stationGeneratorHelper extends BaseTv_stationGeneratorHelper
{
}
