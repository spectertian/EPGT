<header>
  <h2 class="content"><?php echo $pageTitle?></h2>
  <nav class="utility">
    <li class="view-recommended"><a href="<?php echo url_for('recommend/index')?>">推荐列表</a></li>
    <li class="add"><a href="<?php echo url_for('recommend/add');?>">添加推荐</a></li>
  </nav>
</header>