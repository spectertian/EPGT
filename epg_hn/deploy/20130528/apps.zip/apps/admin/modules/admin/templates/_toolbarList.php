<header>
  <h2 class="content">管理员列表</h2>
  <nav class="utility">
    <li class="add"><a href="<?php echo url_for("admin/new")?>">添加</a></li>
  
<li class="delete"><a class="toolbar" onclick="javascript:if(confirm('确定删除吗？')){submitform('batchDelete')}" href="#">删除 </a></li>

	</nav>
</header>
