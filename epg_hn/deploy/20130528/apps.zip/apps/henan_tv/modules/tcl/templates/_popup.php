<div id="popup" class="display-none">
    <div class="popup">
        <div class="play">
            <ul>
                <!--li class="disabled ">播放节目</li>
                <li class="disabled">片库资源</li-->
                <li class="action" href="showDetail">节目详情</li>
                <li class="action" href="closePoup">取消</li>
            </ul>
        </div>
    </div>
    <div class="popup-bg"></div>
</div>