'edit': {
    "cover" : {"src" : "image_path"},
    "onair" : [
            {"title":"xxx", "channel":"cctv1"},
            {"title":"xxx", "channel":"cctv1"},
            {"title":"xxx", "channel":"cctv1"},
            {"title":"xxx", "channel":"cctv1"},
            {"title":"xxx", "channel":"cctv1"},
            {"title":"xxx", "channel":"cctv1"}
    ],
    "items" : [
        {"src":"xx.jpg", "title":"xxx"}, 
        {"src":"xx.jpg", "title":"xxx"},
        {"src":"xx.jpg", "title":"xxx"}    
    ],
    "ranking" : [
        {"src":"xx.jpg", "title":"xxxx", "cat":"xxx","producer":"xxx","count":"8.0"},
        {"title":"xxx"},
        {"title":"xxx"},
        {"title":"xxx"},
        {"title":"xxx"},
        {"title":"xxx"},
        {"title":"xxx"},
        {"title":"xxx"},
        {"title":"xxx"},
        {"title":"xxx"}
    ]
}

