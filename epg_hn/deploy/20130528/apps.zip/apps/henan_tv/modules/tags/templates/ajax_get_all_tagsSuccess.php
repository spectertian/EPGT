<ul id="all-tags">
    <li class="action active" rel="all"><span>全部</span></li>
    <li class="action" rel='新闻'><span>新闻</span></li>
    <li class="action" rel="娱乐"><span>娱乐</span></li>
    <li class="action" rel="电视剧"><span>电视剧</span></li>
    <li class="action" rel="体育"><span>体育</span></li>
    <li class="action" rel="生活"><span>生活</span></li>
    <li class="action" rel="电影"><span>电影</span></li>
    <li class="action" rel="动画片"><span>动画片</span></li>
    <li class="action" rel="纪录片"><span>纪录片</span></li>
    <li class="action" rel="外语"><span>外语</span></li>
</ul>