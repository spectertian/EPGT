<?php

/**
 * Programe_user Form.
 */
class Programe_userForm extends BasePrograme_userForm
{
}