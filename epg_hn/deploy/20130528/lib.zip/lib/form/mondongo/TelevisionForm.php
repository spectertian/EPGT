<?php

/**
 * Television Form.
 */
class TelevisionForm extends BaseTelevisionForm
{
}