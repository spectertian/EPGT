<?php

/**
 * UserShare Form.
 */
class UserShareForm extends BaseUserShareForm
{
}