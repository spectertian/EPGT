<?php

/**
 * ContentInject Form.
 */
class ContentInjectForm extends BaseContentInjectForm
{
}