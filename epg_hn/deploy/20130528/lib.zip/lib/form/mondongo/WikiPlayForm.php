<?php

/**
 * WikiPlay Form.
 */
class WikiPlayForm extends BaseWikiPlayForm
{
}