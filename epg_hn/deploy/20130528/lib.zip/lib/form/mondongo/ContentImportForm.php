<?php

/**
 * ContentImport Form.
 */
class ContentImportForm extends BaseContentImportForm
{
}