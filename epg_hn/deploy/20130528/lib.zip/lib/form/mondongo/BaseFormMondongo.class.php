<?php

/**
 * Mondongo Base Class.
 */
abstract class BaseFormMondongo extends sfMondongoForm
{
  public function setup()
  {
  }
}