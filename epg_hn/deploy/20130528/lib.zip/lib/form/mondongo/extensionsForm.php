<?php

/**
 * extensions Form.
 */
class extensionsForm extends BaseextensionsForm
{
}