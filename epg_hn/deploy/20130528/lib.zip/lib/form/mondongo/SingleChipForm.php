<?php

/**
 * SingleChip Form.
 */
class SingleChipForm extends BaseSingleChipForm
{
}