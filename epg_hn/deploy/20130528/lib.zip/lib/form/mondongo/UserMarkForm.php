<?php

/**
 * UserMark Form.
 */
class UserMarkForm extends BaseUserMarkForm
{
}