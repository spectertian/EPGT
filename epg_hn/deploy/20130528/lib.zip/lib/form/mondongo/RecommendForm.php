<?php

/**
 * Recommend Form.
 */
class RecommendForm extends BaseRecommendForm
{
}