<?php

/**
 * Dict Form.
 */
class DictForm extends BaseDictForm
{
}