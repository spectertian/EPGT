<?php

class AdminTable extends Doctrine_Table
{

}