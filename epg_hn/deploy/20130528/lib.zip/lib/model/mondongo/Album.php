<?php

/**
 * Album document.
 */
class Album extends \BaseAlbum
{
}