<?php

/**
 * ContentInject document.
 */
class ContentInject extends \BaseContentInject
{
}