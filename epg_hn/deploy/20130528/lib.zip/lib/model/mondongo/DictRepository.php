<?php

/**
 * Repository of Dict document.
 */
class DictRepository extends \BaseDictRepository
{
}