<?php

/**
 * extensions document.
 */
class extensions extends \Baseextensions
{
}