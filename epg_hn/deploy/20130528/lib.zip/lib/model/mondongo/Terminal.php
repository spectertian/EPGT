<?php

/**
 * Terminal document.
 */
class Terminal extends \BaseTerminal
{
}