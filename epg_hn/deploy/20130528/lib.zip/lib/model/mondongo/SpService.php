<?php

/**
 * SpService document.
 */
class SpService extends \BaseSpService
{
}