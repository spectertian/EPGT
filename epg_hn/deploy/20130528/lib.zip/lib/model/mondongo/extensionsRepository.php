<?php

/**
 * Repository of extensions document.
 */
class extensionsRepository extends \BaseextensionsRepository
{
}