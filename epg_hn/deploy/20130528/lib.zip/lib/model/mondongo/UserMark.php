<?php

/**
 * UserMark document.
 */
class UserMark extends \BaseUserMark
{
}