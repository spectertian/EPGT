<?php

/**
 * EditorMemory document.
 */
class EditorMemory extends \BaseEditorMemory
{
}