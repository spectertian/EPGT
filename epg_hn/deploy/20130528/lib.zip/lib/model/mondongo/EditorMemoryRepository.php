<?php

/**
 * Repository of EditorMemory document.
 */
class EditorMemoryRepository extends \BaseEditorMemoryRepository
{
}