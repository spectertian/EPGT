<?php

/**
 * Repository of Setting document.
 */
class SettingRepository extends \BaseSettingRepository
{
}