<?php

/**
 * UserShare document.
 */
class UserShare extends \BaseUserShare
{
}