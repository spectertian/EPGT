<?php

/**
 * ChannelFavorites document.
 */
class ChannelFavorites extends \BaseChannelFavorites
{
}