<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Exception
 *
 * @author lizhi
 */
class Weibo_Exception extends Exception {
    //put your code here
}
?>
