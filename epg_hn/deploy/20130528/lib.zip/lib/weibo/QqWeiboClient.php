<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of QqWeiboClient
 *
 * @author lizhi
 */
class QqWeiboClient extends WeiboClient {
    //put your code here
}
?>
