$L.init("radio");
var allChannelsList = ServiceDB.getServiceList();
var radioList = allChannelsList.filterService(ServiceDB.LIST_TYPE_SERVICE, "RADIO");

var allServiceList = [];

Utility.setEnv("serviceType", "RADIO");

var mp = new MPlayer();
var Av_stopMode = 1;
mp.player.setStopMode(Av_stopMode);
var timerManager = new TimerManager();
var channelBar, volumeBar, OKList, descBox, audioChannel, audioChannelText;
var currTvIndex = 0;
var currChannelList;
var currService;
var audioChannelOptions = [];
var audioTrackMode = $G.sysDa.get("Av.audioTrackMode") != "" ? parseInt($G.sysDa.get("Av.audioTrackMode")) : 0;
var volumeMode = $G.sysDa.get("VolumeSaveMode") != "" ? parseInt($G.sysDa.get("VolumeSaveMode")) : 0;
var showTipsFlag = false;
var pfTimer, channelBarTimer;
var userId=Utility.getSystemInfo("UID");
var caSerialNum = CA.serialNumber;
var stbSerialNum = SysInfo.STBSerialNumber;
var codeStr = "Y-coship-coship" + currIp + "-etc";
var helpTailAddr = "cardid=" + caSerialNum + "&clientid=" + stbSerialNum + "&method=&channel=0000:000:00:0000&code=" + codeStr + "&uitype=" + 1;

//此函数是将所有的service从各自的list中取出存入到一个数组中，方便显示和获取
var caSerialNum = CA.serialNumber;
var stbSerialNum = SysInfo.STBSerialNumber;
function initServiceList() {
	for (var i=0; i < radioList.length; i++) {
		allServiceList.push(radioList.getAt(i));
	}
}
var radioListView = new List(16, showChannelList, channelOnFocusMove, channelOnFocus, channelOnBlur);

function showChannelList(item, index, focusIndex) {
	$("proIndex_" + focusIndex).innerText = item ? $G.leftPadStr(index + 1, "0", 3) : "";
	$("proName_" + focusIndex).innerText = item ? item.name : "";
}
function channelOnFocusMove(oldPos, newPos) {
	$("proList_" + oldPos).className = "";
	$("proList_" + newPos).className = "proOnFocus";
}
function channelOnFocus(index) {
	$("proList_" + index).className = "proOnFocus";
}
function channelOnBlur(index) {
	$("proList_" + index).className = "";
}

var channelNumObj = {
	inputStr: '',
	currPos: 0,
	inputTimeoutFlag: -1,
	showTimeoutFlag: -1,
	isVisible: false,
	isInputStatus: false,
	getInput: function(inputNum) {
		this.showChannelNumber();
		this.isVisible = true;
		if(!this.isInputStatus){
			this.inputStr = '';
			this.inputStr += inputNum;
			this.isInputStatus = true;
		} else this.inputStr += inputNum;
		
		if (this.inputStr.length <= 3) {
			clearTimeout(this.inputTimeoutFlag);
			this.currPos++;
			var self = this;
			this.isInputStatus = true;
			this.inputTimeoutFlag = setTimeout(function(){self.openChannel();}, 3000);		
		} else {
			clearTimeout(this.inputTimeoutFlag);
			this.inputStr = "" + inputNum;
			this.inputTimeoutFlag = setTimeout(function(){self.openChannel();}, 3000);
		}
		$("channel_num").innerText = this.generateChannelNumber(this.paddingInputNumber(this.inputStr, 3, "0"));
		$("channel_name").innerText = $L.INPUT_TIP;
	},
	openChannel: function() {
		if (this.inputStr == '') { return; }
		clearTimeout(this.inputTimeoutFlag);
		setChannel(Math.floor(this.inputStr));
		this.isInputStatus = false;
	},
	showChannelNumber: function() {
		clearTimeout(this.showTimeoutFlag);
	},
	hideChannelNumber: function() {
		clearTimeout(this.inputTimeoutFlag);
		clearTimeout(this.showTimeoutFlag);
		this.inputStr = "";
		this.currPos = 0;
		this.isVisible = false;
		this.isInputStatus = false;
	},
	generateChannelNumber: function(n) {
		n = n.toString();
		var channelNum = '';
		for (var i = 0; i < n.length ; i++) {
			var number = n.substr(i, 1);
			if (number != '0')
				channelNum += parseInt(number);
			else
				channelNum +=  "0";
		}
		return channelNum;
	},
	paddingInputNumber: function(str, length, padding) {
		str = str.toString();
		var paddingLength = length - str.length;
		for (var i = 0; i< paddingLength; i++)
			str = padding + str;
		return str;
	}
	
};

var delFlag = false, goOrder = false, shiftProOrder = false;

function eventHandler(evt){
	if (goSearch || goOrder) {
		srhConfirmHandler(evt);
		return;
	}
	if (delFlag) {
		delEventHandler(evt);
		return;
	}
	Utility.println("play.js key = "+evt.code);
	
	switch (evt.code) {
		case "KEY_UP":
			if (descFlag_0 || descFlag_1) return;
			if (OKList.isVisible) {
				radioListView.up();
				changeOKListAD();
			} else {
				changeChannel(1);
				if (channelNumObj.isInputStatus) {
					channelNumObj.hideChannelNumber();
				}
			}
			break;
		case "KEY_DOWN":
			if (descFlag_0 || descFlag_1) return;
			if (OKList.isVisible) {
				radioListView.down();
				changeOKListAD();
			} else {
				changeChannel(-1);
				if (channelNumObj.isInputStatus) {
					channelNumObj.hideChannelNumber();
				}
			}
			break;
		case "KEY_LEFT":
			if (descFlag_0 || descFlag_1) return;
			if (OKList.isVisible) {
				radioListView.left();
				changeOKListAD();
			} else {				
				changeVolume(-1);
			}
			break;
		case "KEY_RIGHT":
			if (descFlag_0 || descFlag_1) return;
			if (OKList.isVisible) {
				radioListView.right();
				changeOKListAD();
			} else {
				changeVolume(1);
			}
			break;
		case "KEY_VOLUME_UP":
			if (descFlag_0 || descFlag_1) return;
			if (!OKList.isVisible) {
				changeVolume(1);
			}
			break;
		case "KEY_VOLUME_DOWN":
			if (descFlag_0 || descFlag_1) return;
			if (!OKList.isVisible) {
				changeVolume(-1);
			}
			break;
		case "KEY_AUDIO":
			if (descFlag_0 || descFlag_1) return;
			changeAudioChannel();
			break;
		case "KEY_MUTE":
			if (descFlag_0 || descFlag_1) return;
			setMute();
			break;
		case "KEY_PAGE_UP":
			if (OKList.isVisible) {
				radioListView.pageUp();
				changeOKListAD();
			}	
			break;
		case "KEY_PAGE_DOWN":
			if (OKList.isVisible) {
				radioListView.pageDown();
				changeOKListAD();
			} else {
				window.location.href = "proSysInfo.htm";
			}		
			break;
		case "KEY_ENTER":
			if (descFlag_0 || descFlag_1) return;
			if (!OKList.isVisible) {
				if (channelNumObj.isInputStatus) {
					channelNumObj.isInputStatus = false;
					channelNumObj.openChannel();
					return;
				}
				if (channelBar.isVisible) channelBar.hide();
				if (volumeBar.isVisible) volumeBar.hide();
				OKList.show();
				Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 21);
			} else {
				currService = allServiceList[radioListView.currIndex];
				radioList.moveTo(radioListView.currIndex + 1);
				setChannel(radioListView.currIndex + 1);
				OKList.hide();
			}
			break;
		case "KEY_EXIT":
			if (OKList.isVisible) {
				OKList.hide();
			} else if (descFlag_0 || descFlag_1) {
				hideDesc();
			}
			if (channelBar.isVisible) channelBar.hide();
			if (volumeBar.isVisible) volumeBar.hide();
			break;
		case "KEY_CHANNEL_DOWN":
			if (descFlag_0 || descFlag_1) return;
			if (!OKList.isVisible) {
				changeChannel(-1);
			}
			break;
		case "KEY_CHANNEL_UP":
			if (descFlag_0 || descFlag_1) return;
			if (!OKList.isVisible) {
				changeChannel(1);
			}
			break;
		case "KEY_YELLOW":
			var nRet = -1;
			if (OKList.isVisible) {
				window.location.href = "../epg/epg.htm";
				return;
			}
			mp.player.setStopMode(0);
			mp.player.stop();
			setMisUiStatusEnv(4);
			Utility.ioctlWrite("NM_Key"," KeyName:"+ 97);
			window.location.href = "http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-002&userCode="+userId;
			/*nRet = AppManager.startLocalAppByID('HTRDJavaStock','');
			if (nRet == 0){
				stopAitManager();
			}*/
			break;
		case "KEY_RED":
			if (OKList.isVisible) {
				window.location.href = "../epg/currDayNotice.htm";
				return;
			}
			window.location.href = "../epg/currDayNotice.htm";
			break;
		case "KEY_BLUE":
			if (OKList.isVisible) {
				window.location.href = "../epg/cateEpg.htm";
				return;
			}
			showAppList();
			break;
		case "KEY_GREEN":
			if (OKList.isVisible) {
				window.location.href = "../epg/appointNotice.htm";
				return;
			}
			mp.player.setStopMode(0);
			mp.player.stop();
			Utility.ioctlWrite("NM_Key"," KeyName:"+ 99);
			window.location.href = "http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=08-001&userCode="+userId;
			break;	
		case "KEY_AUTO_SEARCH":
			if (!goSearch) {
				goSearch = true;
				showConfirmDiv("您确定要重新搜索节目吗？", false);
			}
			break;
		case "KEY_BACK":
			if (descFlag_0 || descFlag_1) {
				hideDesc();
				return;
			}
			if (OKList.isVisible) {
				OKList.hide();
			} else if (channelBar.isVisible) {
				channelBar.hide();
			} else {
				openLastChannel();
			}
			
			break;
		case "KEY_NUMERIC":
			if (descFlag_0 || descFlag_1) return;
			if (!OKList.isVisible) {
				clearPF();
				showChannelBar();
				channelNumObj.getInput(evt.param);
			} else if (OKList.isVisible) {
				var temNum = parseInt(evt.param);
				if ((temNum == 1) || (temNum == 2)) {
					delFlag = true;
					delChoice = temNum;
					showDelConfirmDiv(temNum);
				}
			}
			break;
		case "DVB_PRESENT_EVENT_REFRESH":
		case "DVB_FOLLOWING_EVENT_REFRESH":
			clearTimeout(pfTimer);
			pfTimer = setTimeout(initPF, 1000);
			break;
		case "CA_COMMAND":
			break;
		case "KEY_INFO":
			if (!OKList.isVisible) {
				showInfo();
			}
			break;
		case "DVB_SHOW_INFO":
			onDisplayMessageEvent(DVB.getShowEvents());
			break;
		case "DVB_HIDE_INFO":
			hiddenTips();
			break;
		case "GETEVENT_CHANNEL_DESCRIPTION":
			var messageId = event.userInt;
			var evtstr = DVB.getEvent(45002, messageId);
			var infoObj = eval('('+evtstr+')');
			$("unAthorizedInfo").innerHTML =  infoObj.str;
			break;
		case "MIS_GETEPG_STATUS":
			var misStr = DVB.getEvent(45783, event.userInt);
			if (misStr == "success") {		// 成功
				if (volumeBar.isVisible) {	
					$("volumeBarDiv").style.visibility = "visible";
				} else if (OKList.isVisible) {								
					$("ok_list_ad_div").style.visibility = "visible";		
				}
			} else {
				if (volumeBar.isVisible) {	
					$("volumeBarDiv").style.visibility = "hidden";
				} else if (OKList.isVisible) {								
					$("ok_list_ad_div").style.visibility = "hidden";		
				}
			}
			
			if (volumeBar.isVisible) {					
				Utility.ioctlWrite("NM_VolChange","nAction:"+2);
			} else if (OKList.isVisible) {	
				Utility.ioctlWrite("NM_Menu", "nAction:" + 3 + ",code:" + 21);
			}
			break;
		case "DVB_PLAY_SUCCESS":
			if (channelBar.isVisible) {
				$("channel_bar_ad").src = "misads://typeIndex=21";
			}
			break;
		case "KEY_LOVE":
			if (!isAuthorized) {
				mp.player.setStopMode(0);
				mp.player.stop();
				window.location.href = "http://hditv.jsamtv.com/epg/show.do?app=cpg&hd=y&content=favor&cardid=" + caSerialNum + "&clientid=" + stbSerialNum;
			}
			break;
		case "KEY_TV_RADIO":
			window.location.href = "../play/play.htm";
			break;
		case "KEY_PAUSE":
			//mp.player.setStopMode(0); 
			//mp.player.stop();
			//Utility.ioctlWrite("NM_Key"," KeyName:"+ 3864);
			//window.location.href = "http://hdamsp.jsamtv.com/smarttv.do";
			break;
		case "KEY_DIANBO":
			Utility.ioctlWrite("NM_Key"," KeyName:"+ 3883);
			mp.player.setStopMode(0);
			mp.player.stop();
			Utility.setEnv("nowFocus",2);
			Utility.setEnv("picNowFocus",10);
			Utility.setEnv("backFocus","NoPicFocus");
			window.location.href = "http://hditv.jsamtv.com/epg/show.do?app=vpg&hd=y&content=vodhome&" + helpTailAddr;
			break;
		case "KEY_OC":
			mp.player.setStopMode(0);
			mp.player.stop();
			Utility.ioctlWrite("NM_Key"," KeyName:"+ 464);
			window.location.href = "http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-015&userCode="+userId;
			break;
		case "XLET_ACTIVE":
			//window.location.reload();
			setMisUiStatusEnv(6);// 通知如加系统进入播放页面
			allChannelsList = ServiceDB.getServiceList();
			radioList = allChannelsList.filterService(ServiceDB.LIST_TYPE_SERVICE, "RADIO");
			initServiceList();
			Utility.setEnv("Mis_AdvCallback", "stop_adv");
			mp.fullScreen();
			playVideo(radioList.currentService.getLocation());
			break;
		case "KEY_VOD":
			//mp.player.setStopMode(0);
			//mp.player.stop();
			//Utility.ioctlWrite("NM_Key"," KeyName:"+ 2730);
			//window.location.href = "http://hdamsp.jsamtv.com/widget.do";
			break;
		case "KEY_TIMESHIFT":
			/*Utility.ioctlWrite("NM_Key"," KeyName:"+ 2731);
			mp.player.setStopMode(0);
			mp.player.stop();
			window.location.href = "http://hditv.jsamtv.com/epg/show.do?app=cpg&hd=y&content=channelback&cardid=" + caSerialNum + "&clientid=" + stbSerialNum +"&method=&channel=" + addrJSON.channelInfo + "&code=" + addrJSON.codeInfo;
			*/
			break;
	}
}
var delPos = 0;
function showDelConfirmDiv(temNum) {
	var currChoice = parseInt(temNum);
	if (currChoice == 1) {
		$("delTip").innerText = $L.DEL_TIP_0;
	} else if (currChoice == 2) {
		$("delTip").innerText = $L.DEL_TIP_1;
	}
	$("delDiv").style.visibility = "visible";
	$("delDiv_bt" + delPos).className = "currBtn";
}
function delEventHandler(evt) {
	switch (evt.code) {
		case "KEY_LEFT":
		case "KEY_RIGHT":
			delBtnLR();
			break;
		case "KEY_ENTER":
			delService();
			break;
		case "KEY_EXIT":
			delFlag = false;
			$("delDiv").style.visibility = "hidden";
			break;
	}
}
var delChoice = 0;
function delBtnLR() {
	$("delDiv_bt" + delPos).className = "";
	delPos = (delPos + 1) % 2;
	$("delDiv_bt" + delPos).className = "currBtn";
}

function delService() {
	if (delPos == 0) {
		if (delChoice == 1) {
			var tempService = allServiceList[radioListView.currIndex];
			tempService.delFlag = true;
			allServiceList.splice(radioListView.currIndex, 1);
			//需要看看现网逻辑再做
			if (allServiceList.length == 0) {
				SysSetting.deleteAllService();
				ServiceDB.save();
				delFlag = false;
				$("delDiv").style.visibility = "hidden";
				window.location.reload();
				return;
			} else {
				if (radioListView.currIndex == currTvIndex) {
					OKList.hide();
					ServiceDB.save();
					delFlag = false;
					$("delDiv").style.visibility = "hidden";
					window.location.reload();
					return;
				} else if (radioListView.currIndex == allServiceList.length) {
					radioListView.setBlur();
					radioListView.currIndex -= 1;
				}
				radioListView.bindData(allServiceList, radioListView.currIndex, 0);
				radioListView.setFocus();
			}
		} else if (delChoice == 2) {
			//暂时不考虑删除全部节目
			allServiceList = [];			
			SysSetting.deleteAllService();
			ServiceDB.save();
			delFlag = false;
			$("delDiv").style.visibility = "hidden";
			window.location.reload();
			return;
		}
	} else {
		delBtnLR();
	}
	ServiceDB.save();
	delFlag = false;
	$("delDiv").style.visibility = "hidden";
}

var showTipsType = 0, isAuthorized = true;
function onDisplayMessageEvent(events) {
	var info = "";
	Utility.println("onDisplayMessageEvent evt length = "+events.length);
	if (events.length > 0) {
		var maxId = 0;//events.length-1;
		Utility.println("evt type = "+events[maxId].type+" sub type = "+events[maxId].msgSubType);
		switch (events[maxId].type) {
			case 40023:
				showTipsType = 0;
				if (allChannelsList.length == 0) {
					info = $GL.NO_SERVICE;
				} else {
					info = $GL.NO_SIGNAL;
				}
				showTips(info);
				break;
			case 40081:
				var tipsArr = ['',$L.CA_1, $L.CA_2, $L.CA_3, $L.CA_4, $L.CA_5, $L.CA_6, $L.CA_7, $L.CA_8, $L.CA_9, $L.CA_10, $L.CA_11, $L.CA_12, $L.CA_13, $L.CA_14, $L.CA_15, $L.CA_16, $L.CA_17, $L.CA_18, $L.CA_19, $L.CA_20, $L.CA_21,$L.CA_22];
				var type = Number(events[maxId].msgSubType);
				if(type == 1 || type == 2 || type == 3 || type == 10)
				{
					Utility.ioctlWrite("NM_Error","nAction:"+1+",code:"+40081+",subcode:"+type);
				}

				showTipsType = 0;
				if (type < 23) {
					info = tipsArr[type];
					if(type == 9) {	
						$("channelDes").style.visibility = "visible";
						$("desContent").style.visibility = "visible";
						var displayStr = Utility.ioctlRead("channelDescription");
						Utility.setEnv("NM_CaStatus", "failed");
						isAuthorized = false;
						if (channelBar.isVisible) {
							$("pro_fav").style.visibility = "visible";
						}
						showTipsType = 1;
					} else {
						showTipsType = 0;
						showTips(info);
					}
				} else if (type == 23) {//在屏幕上消除alarm消息-23
					hiddenTips();
					
				}
				break;
			case 40083:
				var tipsArr = ['',$L.CA_MSG_0,'','',$L.CA_MSG_1];
				var type = Number(events[maxId].msgSubType);
				if(type == 1){
					showTipsType = 0;
					var info = $L.NO_CARD;
					showTips(info);
				}else{
					showTipsType = 0;
					info = tipsArr[type];
					showTips(info);
					$("channelDes").style.visibility = "hidden";
					$("unAthorizedInfo").innerHTML =  "";
				}
				break;
		}
	}
}
function thirdSecret() {
	$("alert_title").innerText = $GL.TIPS;
	$("alert_text").innerText = "第三方加密节目";
	$('alert').style.visibility = "visible";
}
function hideThird() {
	$("alert_title").innerText = "";
	$("alert_text").innerText = "";
	$('alert').style.visibility = "hidden";
}
function showTips(_tips){
	if(showTipsType==0){
		if($("channelDes").style.visibility == "visible"){
			$("channelDes").style.visibility = "hidden";
			$("unAthorizedInfo").innerHTML =  "";
		}
		$("alert_title").innerText = $GL.TIPS;
		$('alert_text').innerText = _tips;
		$('alert').style.visibility = "visible";
		
	}else{
		if($("alert").style.visibility == "visible"){
			$("alert").style.visibility = "hidden";
		}
		$("channelDes").style.visibility = "visible";
	}
	if(!showTipsFlag){
		showTipsFlag=true;
	}
}
function hiddenTips(){
	// 如加广告需要获取当前节目解扰状态，隐藏ca提示框时设置为解扰成功
	Utility.setEnv("NM_CaStatus", "success");
	
	$('alert').style.visibility = "hidden";
	showTipsFlag = false;
	$("channelDes").style.visibility = "hidden";
	$("unAthorizedInfo").innerHTML =  "";
	isAuthorized = true;
	var events = DVB.getShowEvents();
	if (events.length > 0) {
		onDisplayMessageEvent(events);
	}
}

function init(){
	// 销毁oc轮播，防止oc占用内存不释放
	Utility.destroyOC();
	mp.fullScreen();
	Utility.println("========play.js====init====startAitManager=======");
	Utility.ioctlWrite("motoStopGroup", "");	//停止moto的搜索groupID
	Utility.ioctlWrite("motoKey2Dvb", "");		//将键值转化为中间件标准键值
	initText();
	audioChannelOptions = [{displayValue: $GL.TRACK_LEFT, sysValue: 'Left'},{displayValue: $GL.TRACK_RIGHT, sysValue: 'Right'},{displayValue: $GL.TRACK_STEREO, sysValue: 'Stereo'}];
	if (radioList.length == 0) {
		goSearch = true;
		showConfirmDiv("节目为空，请按‘节目搜索’键重新搜索！", true);
		return;
	}
	channelBarTimer = $G.sysDa.get("Pf.timeout") != "" ? parseInt($G.sysDa.get("SYS_TIMEOUT"))*1000 : 5000;
	channelBar = new Con($("channel_bar"), false, channelBarTimer, "channelBar");
	volumeBar = new Con($("volume_bar"), false, 5000, "volumeBar");
	OKList = new Con($("ok_list"), false, -1, "OKList");
	descBox = new Con($("desc_box"), false, -1, "descBox");
	audioChannelText = new LRButton("audio_channel_text", function(){}, function(){}, showAudioChannel, function(){});
	audioChannelText.bindData(audioChannelOptions);

	
	initServiceList();
	currChannelList = radioList;
	$G.sysDa.set("Mediaplayer.groupIndex", 1);
	currService = currChannelList.currentService;
	currTvIndex = currChannelList.findIndex(currService);
	initSound();
	playVideo(currService.getLocation());
	showChannelBar();	
	showDateTime();
	onDisplayMessageEvent(DVB.getShowEvents());
	$("channel_bar_ad").src = "misads://typeIndex=21";
}
var shiftProStatus = false;
function isTimeShiftPro(service) {
	var tempService = service;
	var tsID = tempService.tsId;
	var serviceID = tempService.serviceId;
	var returnValue = CITV.isSupportPlayBack(tsID, serviceID);
	if (returnValue) {
		Utility.println("============这是一个时移节目==============");
		$("timeShift").style.visibility = "visible";
		shiftProStatus = true;
		if (channelBar.isVisible) {
			$("pro_back").style.visibility = "visible";
		}
	} else {
		if ($("timeShift").style.visibility == "visible") {
			$("timeShift").style.visibility = "hidden";
		}
		shiftProStatus = false;
	}
}
function initText(){
	var textArr = {OKList_title:$L.OKLIST_TITLE, confirmTitle:$GL.TIPS,confirmBtn_ok:$GL.OK,soundTitle:$L.SOUND,
					  p_7:$GL.TIPS, box_infor:$GL.INPUT_LOCAL_PSW,tip_4:$L.TIP_4,tip_5:$L.TIP_5,
					  tip_0:$GL.TIP_0,tip_1:$GL.TIP_1,tip_2:$GL.TIP_2,tip_3:$GL.TIP_3,delDiv_title:$GL.TIPS,
					  desTitle:$GL.TIPS,des_0:$L.DES, delDiv_bt0:$GL.OK, delDiv_bt1:$GL.CANCEL,
					  infoTips:$L.BACK_TIPS,
					  srhConfirmTitle:$GL.TIPS,srhConfirmBtn_0:$GL.OK,srhConfirmBtn_1:$GL.CANCEL};
	for(var id in textArr){
		$(id).innerText = textArr[id];
	}
}

function initSound(){
	var volume;
	if (volumeMode == 0) {
		volume = currService ? currService.volume : mp.player.getVolume();
	} else {
		volume = $G.sysDa.get("UniformVolume") != "" ? parseInt($G.sysDa.get("UniformVolume")) : 16;
	}
	mp.player.setVolume(volume);
	$("volume_value").innerText = volume;
	$("volume_progress").style.width = 375 / 31 * volume + "px";
	if (mp.player.getMuteFlag() == 1) {
		$('mutePic').style.visibility = "visible";
		$("muteTxt").innerText = $L.MUTE_TXT;
	}
}

function onPassSuccess() {
	mp.player.unlockPlay();
	$("error_text").innerText = "";
}

function onPassFailed() {
	$("error_text").innerText = $GL.PSW_INVALID;
}

function showDateTime(){
	$("currTime").innerText = $G.dateFormat(new Date(), "hh:mm");
	var timer = new Timer("dateTime");
	timerManager.add(timer);
	timer.exec(showDateTime, 60000);
}
//根据现网逻辑，为了马赛克页面的进入修改成按照location来播放节目
var beginVolume, endVolume;
function playVideo(location){
	AitManager.changeService(location);
	if (currService.videoPID != 0) {
		$("bgImage").style.background = "transparent";
		$("radioTips").style.visibility = "hidden";
	} else {
		$("bgImage").style.background = "url(../images/radio_bg.jpg) no-repeat";
		$("radioTips").style.visibility = "visible";
	}
	mp.player.setSingleMedia(location);
	mp.player.playFromStart();
	if (volumeMode == 0) {
		beginVolume = currService.volume;
	} else {
		beginVolume = mp.player.getVolume();	
	}
	mp.player.setVolume(beginVolume);
	
	var audioTrack ;
	if (audioTrackMode == 1) {
		audioTrack = $G.sysDa.get("AudioTrack") != "" ?$G.sysDa.get("AudioTrack") : "Left";
	}
	else {
		audioTrack = currService.audioTrack;
	}
	mp.player.setCurrentAudioChannel(audioTrack);
	
	$G.setFrontPanelDisplay((currTvIndex + 1), 1);
	$G.sysDa.set("Mediaplayer.serviceIndex", currTvIndex);
}

function Con(obj, isVisible, delayTime, name){
	var self = this;
	self.isVisible = isVisible;
	self.obj = obj;
	self.name = name;
	self.delayTime = delayTime;
	var timer = new Timer(name);
	timerManager.add(timer);
	
	self.show = function(){
		self.obj.style.visibility = "visible";
		self.isVisible = true;
		if (self.delayTime != -1) {
			var timer = timerManager.get(self.name);
			timer.exec(self.hide, self.delayTime);
		}
		if (self.name == "OKList") {
			radioListView.bindData(allServiceList, currTvIndex, 0);
			radioListView.setFocus();
			changeOKListAD();
		}
		if (self.name == "channelBar") {
			//显示ChannelBar时，隐藏应用提示
			hideAppDownLoadIcon(); 
			$("tvNumDiv").style.visibility = "visible";
			if (shiftProStatus) {
				$("pro_back").style.visibility = "visible";
			} else if (!isAuthorized) {
				$("pro_fav").style.visibility = "visible";
			}
			initChannelContent();
		}
		if (self.name == "volumeBar") {
			$("volume_bar_ad").src = "misads://typeIndex=22";	// 获取广告图片
			Utility.ioctlWrite("NM_VolChange", "nAction:"+1+",volume:"+beginVolume);
		}
	};
	
	self.hide = function(){
		self.obj.style.visibility = "hidden";
		self.isVisible = false;
		self.clearTimer();
		if(self.name == "OKList") {
			$("ok_list_ad_div").style.visibility = "hidden";
			radioListView.setBlur();
			Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 21);
		}
		if (self.name == "channelBar") {
			$("tvNumDiv").style.visibility = "hidden";
			$("audio_channel_text").innerText = "";
			$("pro_lock").style.visibility = "hidden";
			if ($("pro_fav").style.visibility == "visible") {
				$("pro_fav").style.visibility = "hidden";
			} else if ($("pro_back").style.visibility == "visible") {
				$("pro_back").style.visibility = "hidden";
			}
			if (audioFlag) {
				audioFlag = false;
			}
			
			//应用的提示图标在channelBar消失后再显示
			apps = AppsCollection.getApplications("TransportType=OC-ServiceBound");
			if (apps.length > 0) {
				showAppDownLoadIcon();
			} 
		 
			$G.debug("====在图标消失的时候保存的声道值为========", audioChannelText.getValue());
			$G.sysDa.set("AudioTrack",audioChannelText.getValue());
			$G.sysDa.submit();
		}
		if (self.name == "volumeBar") {
			$("volumeBarDiv").style.visibility = "hidden";
			ServiceDB.save();
			if(!setMuteAction){
				Utility.ioctlWrite("NM_VolChange", "nAction:"+0+",volume:"+endVolume);				
			}
			beginVolume = endVolume;
		}
	};
	/**
	 * 重设Timer
	 * @param {Number} _delayTime 不传时，则按默认。否则按此新值执行隐藏
	 */
	self.resetTimer = function(_delayTime){
		if (self.delayTime != -1) {
			var timer = timerManager.get(self.name);
			var delay = self.delayTime;
			if(typeof(_delayTime)!="undefined"){
				delay = _delayTime;
			}
			timer.exec(self.hide, delay);
		}
	};
	
	self.clearTimer = function(){
		var timer = timerManager.get(self.name);
		timer.clear();
	}
}
var searchBtPos = 0, goSearch = false, sec=11, secTimer=-1;
function showConfirmDiv(_tips, first) {
	$('srhConfirmDiv').style.visibility = "visible";
	$('srhConfirmTxt').innerText = _tips;
	if (first) {
		countDown();
	} else {
		$("srhConfirmBtn_0").innerText = "确定";
	}
}
function countDown() {
	if(sec > 0){
		sec--;
		$("srhConfirmBtn_0").innerText = "确定(" + sec + ")";
		secTimer = setTimeout(countDown, 1000);
	} else {
		secTimer=-1;
		window.location.href = "../setting/auto_search.htm?searchType=2";
	}
	
}

function srhConfirmHandler(evt) {
	switch (evt.code) {
		case "KEY_LEFT":
		case "KEY_RIGHT":
			$('srhConfirmBtn_'+searchBtPos).style.background = "url(../images/bt_02.png) no-repeat";
			searchBtPos = (searchBtPos+1)%2;
			$('srhConfirmBtn_'+searchBtPos).style.background = "url(../images/bt_01.png) no-repeat";
			break;
		case "KEY_ENTER":
			if (goSearch && searchBtPos == 0) {
				mp.player.setStopMode(0);
				mp.player.stop();
				window.location.href = "../setting/auto_search.htm?searchType=2";
			} else if (shiftProOrder && searchBtPos == 0) {
				mp.player.setStopMode(0);
				mp.player.stop();
				window.location.href = "时移节目订购页面！";
			}  else {
				$('srhConfirmBtn_'+searchBtPos).style.background = "url(../images/bt_02.png) no-repeat";
				searchBtPos = 0;
				$('srhConfirmBtn_'+searchBtPos).style.background = "url(../images/bt_01.png) no-repeat";
				goSearch = false;
				shiftProOrder = false;
				$('srhConfirmDiv').style.visibility = "hidden";
				$('srhConfirmTxt').innerText = "";
			}
			break;
	}
}

function initChannelContent(){
	clearTimeout(pfTimer);
	var service = currService;
	if (service) {
		var serviceIndex = currChannelList.findIndex(service);
		var chNum = $G.leftPadStr(serviceIndex + 1, "0", 3);
		$("channel_num").innerText = chNum;
		$("channel_name").innerText = service.name.sub(20);
	}
	Utility.ioctlWrite("NM_Epg", "nAction:"+1);
	
	//var tvNum = Utility.getEnv("MIS_TVCode") != "" ? Utility.getEnv("MIS_TVCode") : "00000000";
	//$("tvNum").innerText = $L.TV_NUM + tvNum;
	
	var sdpTvNum = CITV.getParamInfo("TVCode") != "" ? CITV.getParamInfo("TVCode") : "00000000";
	$("tvNum").innerHTML = $L.TV_NUM + sdpTvNum;
	
	pfTimer = setTimeout(initPF, 300);
}

function initPF(){
	if (channelNumObj.isInputStatus) return;
	var service = currService;
	var now = new Date();
	if (service) {
		var p = service.presentProgram;
		var f = service.followingProgram;

		if (p) {
			$("p_Time").innerText = $G.dateFormat(p.startTime, "hh:mm");
			$("p_Name").innerText = p.name.sub(40);
		} else {
			$("p_Time").innerText = "";
			$("p_Name").innerText = "";
		}
		if (f) {
			$("f_Time").innerText = $G.dateFormat(f.startTime, "hh:mm");
			$("f_Name").innerText = f.name.sub(40);
		} else {
			$("f_Time").innerText = "";
			$("f_Name").innerText = "";
		}
		var _width = (timeDiff(now, p.startTime) / timeDiff(p.endTime, p.startTime)) * 90;
		if (_width > 90)
			_width = 90;
		$("play_progress_start").style.width = _width + "px";
		if (service.lock) {
			$("pro_lock").style.visibility = "visible";
		} else {
			$("pro_lock").style.visibility = "hidden";
		}
	}	
}
function clearPF() {
	$("p_Time").innerText = "";
	$("p_Name").innerText = "";
	$("f_Time").innerText = "";
	$("f_Name").innerText = "";
	$("play_progress_start").style.width = "0px";
	$("pro_lock").style.visibility = "hidden";
	$("pro_fav").style.visibility = "hidden";
	$("pro_back").style.visibility = "hidden";
}
/*
 * 将Date对象转换为妙
 */
function dateToSecond(date) {
	return date.getHours()*3600 + date.getMinutes()*60 + date.getSeconds();
}
/*
 * 计算Date对象的时间差,返回值为秒
 */
function timeDiff(nowTime, endTime) {
	return (dateToSecond(endTime) - dateToSecond(nowTime));
}

function setChannel(channelNum) {
	if (channelNum == 000) {
		Utility.ioctlWrite("NM_Help", "nAction:"+1);
		mp.player.setStopMode(0);
		mp.player.stop();
		location.href = "http://hdzchannel.jsamtv.com/epg/show.do?app=zchannel&hd=y&content=home&detail=10000&cardid=" + caSerialNum + "&clientid=" + stbSerialNum +"&method=&channel=" + addrJSON.channelInfo + "&code=" + addrJSON.codeInfo;
		return;
	}
	var service = currChannelList.getAt(channelNum - 1);
	if (service) {
		var serviceIndex = currChannelList.findIndex(service);
		var chNum = $G.leftPadStr(serviceIndex + 1, "0", 3);
		$("channel_num").innerText = chNum;
		$("channel_name").innerText = service.name;
		currService = service;
		currChannelList.moveTo(channelNum - 1);
		currTvIndex = currChannelList.findIndex(currService);
		playVideo(currService.getLocation());
		$G.setFrontPanelDisplay((currTvIndex + 1), 1);
		clearPF();
		initChannelContent();
		showChannelBar();
	} else {
		$("channel_name").innerText = "没有这个节目";
	}
}


function changeChannel(offset){
	if (volumeBar.isVisible) volumeBar.hide();
	$("channelDes").style.visibility = "hidden";
	$("unAthorizedInfo").innerHTML =  "";
	DVB.clearShowEvent();
	currTvIndex = currChannelList.findIndex(currChannelList.currentService);
	Utility.println("============马赛克进入换台前的index============" + currTvIndex);
	currTvIndex += offset;
	if (currTvIndex > currChannelList.length - 1) 
		currTvIndex = 0;
	else if (currTvIndex < 0) {
		currTvIndex = currChannelList.length - 1;
	}
	setChannel(currTvIndex+1);
}

function showChannelBar() {
	if (volumeBar.isVisible) volumeBar.hide();
	if (!channelBar.isVisible) {
		channelBar.show();
	} else {
		channelBar.resetTimer(channelBarTimer);
	}
}

function openLastChannel() {
	var lastLocation = mp.player.getServiceLocation(3);
	if(typeof(lastLocation)=='undefined' || lastLocation=="") return;
	var service = new Service(lastLocation);
	if (service && service.type) {
		if (service.type == DVB.SERVICE_TYPE_RADIO) {
			currTvIndex = currChannelList.findIndex(service);
			if (currTvIndex == -1) {
				currTvIndex = 0;
			}
			setChannel(currTvIndex+1);
		} else {
			return;
		}
	}
}

function changeVolume(offset) {
	var volume;
	if (volumeMode == 0) {
		volume = currService ? currService.volume : mp.player.getVolume();
	} else {
		volume = mp.player.getVolume();
	}
	volume += offset;
	if (volume < 0) volume = 0;
	if (volume > 31) volume = 31;
	if (volumeMode == 0) {
		currService.volume = volume;
	} else {
		$G.sysDa.set("UniformVolume", volume);
	}
	mp.player.setVolume(volume);
	setMuteAction = false;
	endVolume = volume; // add volume end
	$("volume_value").innerText = volume;
	$("volume_progress").style.width = 375 / 31 * volume + "px";
	volumeBar.show();
	if (channelBar.isVisible) channelBar.hide();
	if (mp.player.getMuteFlag() == 1) {
		setMuteFlag(0);
	}
}

var setMuteAction = false;
function setMute() {
	setMuteAction = true;
	var muteFlag = mp.player.getMuteFlag();
	muteFlag = muteFlag == 0 ? 1 : 0;
	setMuteFlag(muteFlag);
}

function setMuteFlag(flag) {
	mp.player.setMuteFlag(flag);
	setMuteAction = flag;
	if (flag == 0) {//有声
		var volume;
		if (volumeMode == 0) {
			volume = currService ? currService.volume : mp.player.getVolume();
		} else {
			volume = mp.player.getVolume();
		}
		beginVolume = volume;
		endVolume = volume;	
	
		$('mutePic').style.visibility = "hidden";
		volumeBar.show();
	} else {
		volumeBar.hide();
		$('mutePic').style.visibility = "visible";
		$("muteTxt").innerText = $L.MUTE_TXT;
	}
}

var audioFlag = false;

function changeAudioChannel() {
	if (!channelBar.isVisible) {
		showChannelBar();
	}
	var currAudioChannel = mp.player.getCurrentAudioChannel();
	if (!audioFlag) {
		audioChannelText.setValue(currAudioChannel);
		audioFlag = true;
	} else {
		audioChannelText.right();
		if (audioTrackMode == 0) {
			currService.audioTrack = audioChannelText.getValue();
		}
		mp.player.setCurrentAudioChannel(audioChannelText.getValue());
	}
}

function showAudioChannel(id, value) {
	$(id).innerText = value;
}

var descFlag_0 = false, descFlag_1 = false;
function showInfo() {
	if (!channelBar.isVisible && !descFlag_0 && !descFlag_1) {
		showChannelBar();
	} else if (!descFlag_0 && !descFlag_1) {
		channelBar.hide();
		showDesc(0);
		Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 02);
	} else if (!descFlag_1 && descFlag_0) {
		Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 02);
		showDesc(1);
		Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 03);
	} else if (descFlag_1) {
		hideDesc();
	} 
}
var addrJSON = {
	channelInfo : "",
	codeInfo : ""
}
function urlParse() {
	var channel, code;
	var service = currService;
	var serviceID = service.serviceId;
	var freq = service.frequency;
	var modulation = service.modulation;
	var symbol = service.symbolRate;
	
	channel = serviceID + "." + freq + "." + modulation + "." + symbol;
	addrJSON.channelInfo = channel;
	
	var ethenets = Network.ethenets[0];
	var ipAddr = ethenets.IPs[0];
	var currIp = ipAddr.IPAddres;
	
	if (isAuthorized) {
		code = "Y-coship-coship-" + currIp + "-etc";
	} else {
		code = "N-coship-coship-" + currIp + "-etc";
	}	
	addrJSON.codeInfo = code;
}

function showDesc(num) {
	var proIndex = num;
	$("proInfo").style.visibility = "visible";	
	var descText = "";
	var service = currService;
	if (service) {
		var program_0 = service.presentProgram;
		var program_1 = service.followingProgram;
		var description = "";
		if (proIndex == 0) {
			descFlag_0 = true;
			$("serviceTit").innerText = program_0.name;
			description = program_0.description;
			$("infoTitle").innerText = $L.INFO_CURR;
		} else if (proIndex == 1) {
			descFlag_0 = false;
			descFlag_1 = true;
			description = program_1.description;
			$("serviceTit").innerText = program_1.name;
			$("infoTitle").innerText = $L.INFO_NEXT;
		}
		descText = description.length >= 4 ? description : $L.NO_PRO_INFO;
	} else {
		descText = $L.NO_PRO_INFO;
	}
	$("serviceInfo").innerText = descText;
	channelBar.hide();
}

function hideDesc() {
	if (descFlag_0) {
		descFlag_0 = false;
		Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 02);
	} else if (descFlag_1) {
		descFlag_1 = false;
		Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 03);
	}
	$("proInfo").style.visibility = "hidden";	
}

function misChangeEpgAd() {
	var service = allServiceList[allChannelListView.currIndex];
	var networkID = service.onId;
	var tsID = service.tsId;
	var serviceID = service.serviceId;
	$("ok_list_ad").src = "misads://typeIndex=23:"+networkID+":"+tsID+":"+serviceID;
}

/*
	oklist连续按键优化。两次按键之间小于一定时间间隔时
	不重新获取广告图片。
*/
var misEpgAdvTimer;
function changeOKListAD() {
	clearTimeout(misEpgAdvTimer);
	misEpgAdvTimer = setTimeout(misChangeEpgAd, 500);
}

function exitPage(){
	Utility.ioctlWrite("NM_ServOut","nAction:"+0);
	if (OKList.isVisible) {
		OKList.hide();
	} else if (channelBar.isVisible) {
		channelBar.hide();
	} else if ($('mutePic').style.visibility == "visible") {
		$('mutePic').style.visibility = "hidden";
	}
	timerManager.clearAll();
	DVB.clearShowEvent();
	ServiceDB.save();
	$G.sysDa.submit();
}
