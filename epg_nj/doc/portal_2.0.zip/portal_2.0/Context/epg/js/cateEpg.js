﻿$L.init("epg");
var cateListName = [];
var cateIndex = 0, startIndex = 0, currCateIndex = 0;
var currCateList,proListView;
var infoFlag = false, orderInfoFlag = false, conflictFlag = false;
var isFromRadio = false;
if (Utility.getEnv("serviceType") == "RADIO") {
	isFromRadio = true;
}

function eventHandler(evt) {
	switch(evt.code) {
		case "KEY_UP":
			if (infoFlag || orderInfoFlag || conflictFlag) return;
			proListView.up();
			break;
		case "KEY_DOWN":
			if (infoFlag || orderInfoFlag || conflictFlag) return;
			proListView.down();
			break;
		case "KEY_PAGE_DOWN":
			if (infoFlag || orderInfoFlag || conflictFlag) return;
			proListView.pageDown();
			break;
		case "KEY_PAGE_UP":
			if (infoFlag || orderInfoFlag || conflictFlag) return;
			proListView.pageUp();
			break;
		case "KEY_LEFT":
			if (infoFlag || orderInfoFlag) return;
			if (conflictFlag) {
				buttonLR();
			} else {
				moveLR(-1);
			}
			break;
		case "KEY_RIGHT":
			if (infoFlag || orderInfoFlag) return;
			if (conflictFlag) {
				buttonLR();
			} else {
				moveLR(1);
			}
			break;
		case "KEY_INFO":
			if (orderInfoFlag || conflictFlag) {
				return;
			} else {
				var currProgram = currCateList[proListView.currIndex];
				if (!infoFlag) {
					showInfo();
				}
			}
			break;
		case "KEY_ENTER":
			if (conflictFlag) {
				conflictHandler();
			} else if (infoFlag || orderInfoFlag) {
				return;
			} else {
				orderProgram();
			}
			break;
		case "KEY_BACK":
			if (infoFlag || orderInfoFlag) {
				hideInfo();
			} else if (isFromRadio) {
				window.location.href = "../radio/radio_play.htm";
			} else {
				$G.exitToPlay();
			}
			break;
		case "KEY_EXIT":
			if (isFromRadio) {
				window.location.href = "../radio/radio_play.htm";
			} else {
				$G.exitToPlay();
			}
			break;
		case "KEY_RED":
			window.location.href = "currDayNotice.htm";
			break;
		case "KEY_YELLOW":
			window.location.href = "epg.htm";
			break;
		case "KEY_GREEN":
			window.location.href = "appointNotice.htm";
			break;
	}
}

function init() {
	if (isFromRadio) {
		$("bgImage").style.background = "url(../images/radio.jpg) no-repeat";
	}
	EPG.enter();
	initTxt();
	initCateTitle();
	proListView = new List(5, initProList, onFocusMove, onFocus, onBlur);
	showProgram();
	Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 43);
	setTimeout('Utility.ioctlRead("EPG")',500);
}

function initTxt() {
	cateListName = [
		{name:$L.CATE_0},
		{name:$L.CATE_1},
		{name:$L.CATE_2},
		{name:$L.CATE_3},
		{name:$L.CATE_4},
		{name:$L.CATE_5},
		{name:$L.CATE_6},
		{name:$L.CATE_7},
		{name:$L.CATE_8},
		{name:$L.CATE_9},
		{name:$L.CATE_10}
		];
	var txtArr = {
		menuTitle:($L.PROG_NAME + "—" + $L.PROG_NAME_2),
		title_0:$L.TIME,
		title_1:$L.CHANNEL,
		title_2:$L.PROGRAM,
		title_3:$L.STATUS,
		tip_0:$L.PROG_TIPS_0,
		tip_1:$L.PROG_TIPS_1,
		tip_2:$L.PROG_TIPS_2,
		tip_3:$L.PROG_TIPS_3,
		tip_4:$GL.TIP_0,
		tip_5:$GL.TIP_1,
		tip_6:$GL.TIP_2,
		tip_7:$GL.TIP_3,
		alert_title:$L.INFO_TITLE,
		alert_tip:$L.INFO_TIPS,
		confirmTitle:$GL.TIPS,
		confirmBtn_0:$GL.OK,
		confirmBtn_1:$GL.CANCEL
	};
	for (var id in txtArr) {
		$(id).innerText = txtArr[id];
	}
}

function initProList(item, index, focusIndex) {
	if (item) {
		$("time_" + focusIndex).innerText = $G.dateFormat(item.startTime, "hh:mm") + "-" + $G.dateFormat(item.endTime, "hh:mm");
		$("channelName_" + focusIndex).innerText = item.getService().name ? item.getService().name : "";
		$("proName_" + focusIndex).innerHTML = item.name.sub(18);
		if (Orders.isOrdered(item)) {
			$("isBooked_" + focusIndex).style.visibility = "visible";
		} else {
			$("isBooked_" + focusIndex).style.visibility = "hidden";
		}
		if (item.description.length >= 4) {
			$("info_" + focusIndex).style.visibility = "visible";
		} else {
			$("info_" + focusIndex).style.visibility = "hidden";
		}
	} else {
		$("time_" + focusIndex).innerText = "";
		$("channelName_" + focusIndex).innerText = "";
		$("proName_" + focusIndex).innerHTML = "";
		$("isBooked_" + focusIndex).style.visibility = "hidden";
		$("info_" + focusIndex).style.visibility = "hidden";
	}
}
function onFocusMove(oldPos, newPos) {
	$("listFocus").style.top = 76 + 50*newPos + "px";
}
function onFocus(index) {
	$("listFocus").style.top = 76 + 50*index + "px";
	$("listFocus").style.visibility = "visible";
}
function onBlur(index) {
	$("listFocus").style.visibility = "hidden";
}

function initCateTitle() {
	for (var i=0; i<7; i++) {
		$("cate_" + i).innerText = cateListName[startIndex + i].name;
	}
}

function showProgram() {
	Utility.println("==============cateListKey[cateIndex]=================" + cateIndex);
	switch (cateIndex) {
		case  0:
			currCateList = EPG.getProgramsByContentType(EPG.CONTENT_TYPE_MOVIE);
			break;
		case  1:
			currCateList = EPG.getProgramsByContentType(EPG.CONTENT_TYPE_NEWS);
			break;
		case  2:
			currCateList = EPG.getProgramsByContentType(EPG.CONTENT_TYPE_SHOW);
			break;
		case  3:
			currCateList = EPG.getProgramsByContentType(EPG.CONTENT_TYPE_SPORTS);
			break;
		case  4:
			currCateList = EPG.getProgramsByContentType(EPG.CONTENT_TYPE_CHILDREN);
			break;
		case  5:
			currCateList = EPG.getProgramsByContentType(EPG.CONTENT_TYPE_MUSIC);
			break;
		case  6:
			currCateList = EPG.getProgramsByContentType(EPG.CONTENT_TYPE_ARTS);
			break;
		case  7:
			currCateList = EPG.getProgramsByContentType(EPG.CONTENT_TYPE_SOCIAL);
			break;
		case  8:
			currCateList = EPG.getProgramsByContentType(EPG.CONTENT_TYPE_EDUCATION);
			break;
		case  9:
			currCateList = EPG.getProgramsByContentType(EPG.CONTENT_TYPE_LEISURE);
			break;
		case  10:
			currCateList = EPG.getProgramsByContentType(EPG.CONTENT_TYPE_OTHER);
			break;
	}
	/*
	for(var i = 0,len = currCateList.length; i< len;i++){
		var flag = diffMinute(currCateList[i].endTime);
		if(flag < 0){
			currCateList[i].delFlag = true;
			ServiceDB.save();
			currCateList.splice(i,1);
		}
	}
	*/
	var index = proListView.currIndex || 0;
	proListView.bindData(currCateList, index);
	if (currCateList.length > 0) {
		proListView.setFocus();
	} else {
		proListView.setBlur();
	}
}

function moveLR(_dis) {
	$("cate_" + currCateIndex).className = "";
	cateIndex += _dis;
	if (cateIndex < 0)	cateIndex = 0;
	if (cateIndex > 10)	cateIndex = 10;
	
	currCateIndex += _dis;
	if (currCateIndex < 0 && cateIndex >= 0) {
		currCateIndex = 0;
		startIndex += _dis;
		if (startIndex < 0)	startIndex = 0;
		initCateTitle();
	} else if (currCateIndex > 6) {
		currCateIndex = 6;
		startIndex += _dis;
		if (startIndex > 4) startIndex = 4;
		initCateTitle()
	}
	proListView.currIndex = 0;
	showProgram();
	$("cate_" + currCateIndex).className = "currHead";
}
function showInfo() {
	infoFlag = true;
	$("alert").style.visibility = "visible";
	$("alert_content").innerText = currCateList[proListView.currIndex].description;
	Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 46);
}
function hideInfo() {
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 46);
	if(infoFlag) infoFlag = false;
	if(orderInfoFlag) orderInfoFlag = false;
	$("alert").style.visibility = "hidden";
	$("alert_content").innerText = "";
}
var btPos = 0;
function orderProgram() {
	var currProgram = currCateList[proListView.currIndex];
	var order = new Order(currCateList[proListView.currIndex].getLocation());
	if (Orders.isOrdered(currProgram)) {
		Orders.deleteOrder(currProgram);
		$("isBooked_" + (proListView.currIndex) % 5).style.visibility = "hidden";
	} else {
		switch (Orders.add(order)) {
			case Orders.OK:
				$("isBooked_" + (proListView.currIndex) % 5).style.visibility = "visible";
				break;
			case Orders.ERROR_TIME:
				showOrderInfo($L.ORDER_0);
				break;
			case Orders.ERROR_SERVICE:
				showOrderInfo($L.ORDER_1);
				break;
			case Orders.ERROR_CONFLICT:
				var conflictOrders = Orders.getConflictOrders(order);
				var orderType = Orders.getAt(0);
				var tipInfo = "";
				if (orderType.type == 2) {
					tipInfo = $L.ORDER_3.param("NVOD", conflictOrders[0].name);
				} else {
					tipInfo = $L.ORDER_3.param(conflictOrders[0].serviceName, conflictOrders[0].name);
				}
				showAlert(tipInfo);
				break;
			case Orders.ERROR_MAXCOUNT:
				showOrderInfo($L.ORDER_2);
				break;
		}
	}
}
function conflictHandler() {
	var currProgram = currCateList[proListView.currIndex];
	if (btPos == 0) {
		var tempOrder = new Order(currProgram.getLocation());
		Orders.deleteConflicts(tempOrder);
		Orders.add(tempOrder);
		hideAlert();
		$("isBooked_" + (proListView.currIndex) % 5).style.visibility = "visible";
		proListView.bindData(currCateList, proListView.currIndex, 0);
		proListView.setFocus();
	} else if (btPos == 1) {
		hideAlert();
		buttonLR();
	}
}
function buttonLR() {
	$("confirmBtn_" + btPos).style.background = "url(../images/bt_02.png) no-repeat center";
	btPos = (btPos + 1) % 2;
	$("confirmBtn_" + btPos).style.background = "url(../images/bt_01.png) no-repeat center";
}
function showOrderInfo(_content) {
	orderInfoFlag = true;
	$("alert").style.visibility = "visible";
	$("alert_title").innerText = $L.INFO_TITLE;
	$("alert_content").innerText = _content;
}
function hideOrderInfo() {
	$("alert").style.visibility = "hidden";
	$("alert_title").innerText = "",
	$("alert_content").innerText = "";
	orderInfoFlag = false;
}
function showAlert(_tips) {
	conflictFlag = true;
	$("confirmDiv").style.visibility = "visible";
	$("confirmTxt").innerText = _tips;
}
function hideAlert() {
	$("confirmDiv").style.visibility = "hidden";
	$("confirmTxt").innerText = "";
	conflictFlag = false;
}
function exitPage() {
	Orders.deleteByFlag();
	Orders.save();
	stopMediaPlayer();
	Utility.ioctlRead("EPGExit");
	EPG.exit();
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 43);
}

function diffMinute(date) {	
	var currDate = new Date();
	var rtMinutes = Math.floor(timeDiff(date, currDate) / 60);
	return rtMinutes;
}

function dateToSecond(date) {
	return date.getHours()*3600 + date.getMinutes()*60 + date.getSeconds();
}

function timeDiff(endTime, nowTime) {
	return (dateToSecond(endTime) - dateToSecond(nowTime));
}
refreshTime();
var currEpgTimer = [];
function refreshTime() {
	showProgram();
	setTimeout(refreshTime,60000);
}

var CurrDayFlag = false;
function isCurrDay(date) {
	var tempDate = date;
	var currDay = new Date();
	if (tempDate.getDate() == currDay.getDate()) {
		CurrDayFlag = false;
	} else {
		CurrDayFlag = true;
	}
}
