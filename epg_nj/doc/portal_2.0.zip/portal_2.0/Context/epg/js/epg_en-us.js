$L.extend({
	PROG_NAME:"Program Guide",
	INFO_TITLE:"brief introduction",
	INFO_TIPS:"Press Exit key to return",
	CURR_TIP:'↑ ↓ View; "1" key to cancel the current appointment, "2" to cancel all appointments.',
	
	OKLIST_TITLE:"Program Guide - all channels",
	DEL_TIP_0:"Are you sure you want to delete this program?",
	DEL_TIP_1:"Are you sure you want to delete all the programs?",
	
	FAV_TIPS:"您已经预定了该节目，不能再次预定！",
	//当前预告
	PROG_NAME_0:"The current notice",
	PROG_NAME_1:"Week notice",
	PROG_NAME_2:"Classification notice",
	PROG_NAME_3:"All Channels",
	PROG_NAME_4:"Favorite Channels",
	PROG_NAME_5:"Reservation Management",
	PROG_CHOICE:"For selected channel",
	PROG_TIPS_0:"↑ ↓ browsing, ← → to enter the single channel view,",
	PROG_TIPS_1:"That programs have an appointment",
	PROG_TIPS_2:"Information key to view the content of profiles, confirm the key appointment.",
	PROG_TIPS_3:"Description of programs that have",
	PROG_NAME_6:"Single Channel View",
	
	PROG_TIPS_4:"Select the number keys 1-7 weeks",
	SYS_TIPS:'"↑ ↓" key to select "OK" button to enter, "Exit" key to return',
	FAV_0:'Enter key cut to add channels, the arrow keys to switch, "1" key to delete a channel',
	FAV_1:'"2" key to delete all the channels, flip key page, exit key to exit',
	
	DATE:"Date",
	PLAY_TIME:"Broadcast time",
	
	CHANNEL:"Channel",
	PROGRAM:"Program",
	TIME:"Time",
	STATUS:"Status",
	
	AV_0 : "Video output format:",
	AV_1 : "Video output format:",
	
	TIP_0:"F1 Day notice",
	TIP_1:"F2 Week notice",
	TIP_2:"F3 Classification notice",
	TIP_3:"F4 Reservation Management",
	
	
	CATE_0:"Movie",
	CATE_1:"News",
	CATE_2:"Show",
	CATE_3:"Sports",
	CATE_4:"Children",
	CATE_5:"Music",
	CATE_6:"Art",
	CATE_7:"Society",
	CATE_8:"Education",
	CATE_9:"Leisure",
	CATE_10:"Others",
	
	WEEK_TITLE:"Week notice",
	INFO_TITLE:"brief introduction",
	INFO_TIPS:"Press Exit key to return",
	
	DATE:"Date",
	PLAY_TIME:"Broadcast time",
	
	CHANNEL:"Channel",
	PROGRAM:"Program",
	TIME:"Time",
	STATUS:"Status",
	
	PROG_TIPS_0:"↑ ↓ browsing, ← → to switch view,",
	PROG_TIPS_1:"That programs have an appointment",
	PROG_TIPS_2:"Information key to view the content of profiles, confirm the key appointment.",
	PROG_TIPS_3:"Description of programs that have",
	
	PROG_TIPS_4:"Select the number keys 1-7 weeks",
	
	ORDER_MANAGE: "Manage Order",
	EPG_TITLE:"Program Guide",
	TV : "TV",
	RADIO : "RADIO",
	FAV : "FAV",
	ORDER_0 : "Book program has expired",
	ORDER_1 : "Illegal scheduled program",
	ORDER_2 : "Book full",
	ORDER_3 : "Book your program with '{0}' '{1}' program conflict, <br />whether the coverage",
	TIP_0 : "Order",
	TIP_1 : "Cancellation",
	TIP_2 : "Full screen",
	NOLIST : "No channel list",
	CANCEL : "Cancel Order",
	RECOVER : "Recovery Book",
	SWITCH_TYPE:"Switch Type",
	SWITCH_LIST:"Switch List",
	PRO_INFO:"Pro info",
	TIP_TITLE:"Tip",
	TIP_SURE:"ENTER",
	TIP_CANCLE:"CANCLE",
	NO_PRO_LIST: "No Channel List",
	NO_PRO_INFO: "No Information",
	
	//program_order.js
	PRO_ID : "No.",
	ORDER : "Order",
	CHANNEL_NAME : "Channel",
	PRO_DATE : "Date",
	PRO_TIME : "Time",
	PRO_NAME : "Program Name",
	PAGE_UD : "Page turning"
	
});
