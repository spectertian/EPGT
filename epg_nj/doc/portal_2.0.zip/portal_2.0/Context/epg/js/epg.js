﻿$L.init("epg");
var tvList = ServiceDB.getServiceList().filterService(ServiceDB.LIST_TYPE_SERVICE, "TV");
var radioList = ServiceDB.getServiceList().filterService(ServiceDB.LIST_TYPE_SERVICE, "RADIO");
var currList;
var isFromRadio = false;
if (Utility.getEnv("serviceType") == "RADIO") {
	isFromRadio = true;
	currList = radioList;
} else {
	currList = tvList;
}
var btPos = 0, area = 0, infoFlag = false, orderFlag = false;
var weekdays = [$GL.SUN, $GL.MON, $GL.TUE, $GL.WED, $GL.THU, $GL.FRI, $GL.SAT];
var currDay = (new Date()).getDay();
var inputWeekDay = currDay;
var currServiceIndex, currService, currProgram;
var channelListView = new List(5, initChannelList, onFocusMove0, onFocus0, onBlur0);

function initChannelList(item, index, focusIndex) {
	if (item) {
		$("channelName_" + focusIndex).innerHTML = $G.txtMarquee(item.name, 9, 220);
	} else {
		$("channelName_" + focusIndex).innerHTML = "";
	}
}
function onFocusMove0(oldPos, newPos) {
	$("listFocus_0").style.top = 75 + 52*newPos + "px";
}
function onFocus0(index) {
	$("listFocus_0").style.backgroundImage = "url(../images/currChannel.jpg) no-repeat";
	$("listFocus_0").style.top = 75 + 52*index + "px";
	$("listFocus_0").style.visibility = "visible";
}
function onBlur0(index) {
	$("listFocus_0").style.backgroundImage = "url(../images/leaveChannel.jpg) no-repeat";
	$("listFocus_0").style.top = 75 + 52*index + "px";
	$("listFocus_0").style.visibility = "visible";
}

var proListView = new List(5, initProList, onFocusMove1, onFocus1, onBlur1);
function initProList(item, index, focusIndex) {
	if (item) {
		$("time_" + focusIndex).innerText = $G.dateFormat(item.startTime, "hh:mm") + "-" + $G.dateFormat(item.endTime, "hh:mm");
		$("proName_" + focusIndex).innerHTML = item.name.sub(14);
		if (Orders.isOrdered(item)) {
			$("isBooked_" + focusIndex).style.visibility = "visible";
		} else {
			$("isBooked_" + focusIndex).style.visibility = "hidden";
		}
		if (item.description.length >= 4) {
			$("info_" + focusIndex).style.visibility = "visible";
		} else {
			$("info_" + focusIndex).style.visibility = "hidden";
		}
	} else {
		$("time_" + focusIndex).innerText = "";
		$("proName_" + focusIndex).innerHTML = "";
		$("isBooked_" + focusIndex).style.visibility = "hidden";
		$("info_" + focusIndex).style.visibility = "hidden";
	}
}
function onFocusMove1(oldPos, newPos) {
	$("listFocus_1").style.top = 75 + 52*newPos + "px";
}
function onFocus1(index) {
	$("listFocus_1").style.top = 75 + 52*index + "px";
	$("listFocus_1").style.visibility = "visible";
}
function onBlur1(index) {
	$("listFocus_1").style.visibility = "hidden";
}

function init() {
	if (isFromRadio) {
		$("bgImage").style.background = "url(../images/radio.jpg) no-repeat";
	}
	EPG.enter();
	initTxt();
	initWeek();
	currServiceIndex = currList.findIndex(currList.currentService);
	Utility.println("==========从播放页面进入的时候获得的节目位置===========" + currServiceIndex);
	channelListView.bindData(currList, currServiceIndex, 1);
	channelListView.setFocus();
	currService = currList.getAt(channelListView.currIndex);
	inputNum(currDay);
	Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 42);
	setTimeout('Utility.ioctlRead("EPG")',500);
}
function initWeek() {
	for (var i=0; i<7; i++) {
		$("week_" + i).innerText = weekdays[(currDay + i) % 7];
	}
}
function initTxt() {
	var txtArr = {
		menuTitle:($L.PROG_NAME + "—" + $L.WEEK_TITLE),
		title_0:$L.CHANNEL,
		title_1:$L.TIME,
		title_2:$L.PROGRAM,
		title_3:$L.STATUS,
		tip_0:($L.PROG_TIPS_4 +$L.PROG_TIPS_0),
		tip_1:$L.PROG_TIPS_1,
		tip_2:$L.PROG_TIPS_2,
		tip_3:$L.PROG_TIPS_3,
		tip_4:$GL.TIP_0,
		tip_5:$GL.TIP_1,
		tip_6:$GL.TIP_2,
		tip_7:$GL.TIP_3,
		alert_tip:$L.INFO_TIPS,
		confirmTitle:$L.TIP_TITLE,
		confirmBtn_0:$GL.OK,
		confirmBtn_1:$GL.CANCEL
	};
	for (var id in txtArr) {
		$(id).innerText = txtArr[id];
	}
}
function eventHandler(evt) {
	switch(evt.code) {
		case "KEY_UP":
			if (infoFlag || orderFlag) return;
			if (area == 0) {
				channelListView.up();
				currServiceIndex = channelListView.currIndex;
				currService = currList.getAt(currServiceIndex);
				inputNum(inputWeekDay);
			} else if (area == 1) {
				proListView.up();
			}
			break;
		case "KEY_DOWN":
			if (infoFlag || orderFlag) return;
			if (area == 0) {
				channelListView.down();
				currServiceIndex = channelListView.currIndex;
				currService = currList.getAt(currServiceIndex);
				inputNum(inputWeekDay);
			} else if (area == 1) {
				proListView.down();
			}
			break;
		case "KEY_PAGE_UP":
			if (infoFlag || orderFlag) return;
			if (area == 0) {
				channelListView.pageUp();
				currServiceIndex = channelListView.currIndex;
				currService = currList.getAt(currServiceIndex);
				inputNum(inputWeekDay);
			} else if (area == 1) {
				proListView.pageUp();
			}
			break;
		case "KEY_PAGE_DOWN":
			if (infoFlag || orderFlag) return;
			if (area == 0) {
				channelListView.pageDown();
				currServiceIndex = channelListView.currIndex;
				currService = currList.getAt(currServiceIndex);
				inputNum(inputWeekDay);
			} else if (area == 1) {
				proListView.pageDown();
			}
			break;
		case "KEY_LEFT":
			if (orderFlag) {
				buttonLR();
			} else if (area == 0) {
				 return;
			} else if (area == 1) {
				area = 0;
				proListView.setBlur();
				$("listFocus_0").style.background = "url(../images/currChannel.jpg) no-repeat";
			}
			break;
		case "KEY_RIGHT":
			if (orderFlag) {
				buttonLR();
			} else if (area == 0) {
				 area = 1;
				 $("listFocus_0").style.background = "url(../images/leaveChannel.jpg) no-repeat";
				 proListView.setFocus();
			} else if (area == 1) {
				return;
			}
			break;
		case "KEY_INFO":
			var currSrvProList = currList.getAt(channelListView.currIndex).getPrograms(tempWeekDay);
			currProgram = currSrvProList[proListView.currIndex];
			if (orderFlag)	return;
			if (currProgram.description.length >= 4) {
				if (!infoFlag) {
					infoFlag = true;
					showOrderInfo(currProgram.description);
				} else {
					hideOrderInfo();
				}
			} else {
				return;
			}
			break;
		case "KEY_NUMERIC":
			if (infoFlag || orderFlag) return;
			switch (evt.param) {
				case 1:
				case 2:
				case 3:
				case 4:
				case 5:
				case 6:
				case 7:
					inputNum(evt.param);
					break;
				default:
					break;
			}
			break;
		case "KEY_ENTER":
			if (orderFlag) {
				conflictHandler();
			} else if (area == 1) {
				if (proListView.currIndex == 0 && tempWeekDay == 0) {
					currList.moveTo(channelListView.currIndex);
					if(Utility.getEnv("serviceType") == "RADIO") {
					window.location.href = "../radio/radio_play.htm";	
				} else {
					window.location.href = "../play/play.htm";
				}
				} else {
					orderProgram();
				}
			} else {
				currList.moveTo(channelListView.currIndex);
				if(Utility.getEnv("serviceType") == "RADIO") {
					window.location.href = "../radio/radio_play.htm";	
				} else {
					window.location.href = "../play/play.htm";
				}
			}
			break;
		case "KEY_BACK":
			if (infoFlag || orderFlag) {
				hideOrderInfo();
			} else if (isFromRadio) {
				window.location.href = "../radio/radio_play.htm";
			} else {
				$G.exitToPlay();
			}
			break;
		case "KEY_EXIT":
			if (isFromRadio) {
				window.location.href = "../radio/radio_play.htm";
			} else {
				$G.exitToPlay();
			}
			break;
		case "KEY_RED":
			window.location.href = "currDayNotice.htm";
			break;
		case "KEY_BLUE":
			if(Utility.getEnv("serviceType") == "RADIO") return;
			else window.location.href = "cateEpg.htm";
			break;
		case "KEY_GREEN":
			window.location.href = "appointNotice.htm";
			break;
	}
}
var tempWeekDay = 0;
function inputNum(num) {
	inputWeekDay = num;
	$("week_" + tempWeekDay).className = "";
	tempWeekDay = ((num - currDay) + 7)%7;
	Utility.println("=========================当前按下数字键后转换后的数字为："+tempWeekDay);
	$("week_" + tempWeekDay).className = "currHead";
	proListView.bindData(currService.getPrograms(tempWeekDay), 0, 0);
	if (area == 0) {
		return;
	} else if (area == 1) {
		proListView.setFocus();
	}
	
}
function orderProgram() {
	currProgram = currService.getPrograms(tempWeekDay)[proListView.currIndex];
	Utility.println("============================" + currProgram.name);
	var order = new Order(currProgram.getLocation());
	if (Orders.isOrdered(currProgram)) {
		Orders.deleteOrder(currProgram);
		$("isBooked_" + (proListView.currIndex) % 5).style.visibility = "hidden";
	} else {
		switch (Orders.add(order)) {
			case Orders.OK:
				$("isBooked_" + (proListView.currIndex) % 5).style.visibility = "visible";
				break;
			case Orders.ERROR_TIME:
				orderFlag = true;
				showOrderInfo($L.ORDER_0);
				break;
			case Orders.ERROR_SERVICE:
				orderFlag = true;
				showOrderInfo($L.ORDER_1);
				break;
			case Orders.ERROR_CONFLICT:
				var conflictOrders = Orders.getConflictOrders(order);
				var orderType = Orders.getAt(0);
				var tipInfo = "";
				if (orderType.type == 2) {
					tipInfo = $L.ORDER_3.param("NVOD", conflictOrders[0].name);
				} else {
					tipInfo = $L.ORDER_3.param(conflictOrders[0].serviceName, conflictOrders[0].name);
				}
				showAlert(tipInfo);
				break;
			case Orders.ERROR_MAXCOUNT:
				orderFlag = true;
				showOrderInfo($L.ORDER_2);
				break;
		}
	}
}
function conflictHandler() {
	if (btPos == 0) {
		var tempOrder = new Order(currProgram.getLocation());
		Orders.deleteConflicts(tempOrder);
		Orders.add(tempOrder);
		$("isBooked_" + (proListView.currIndex) % 5).style.visibility = "visible";
		hideAlert();
		proListView.bindData(currService.getPrograms(tempWeekDay), proListView.currIndex, 0);
		proListView.setFocus();
	} else if (btPos == 1) {
		hideAlert();
	}
}
function buttonLR() {
	$("confirmBtn_" + btPos).style.background = "url(../images/bt_02.png) no-repeat center";
	btPos = (btPos + 1) % 2;
	$("confirmBtn_" + btPos).style.background = "url(../images/bt_01.png) no-repeat center";
}
function showOrderInfo(_content) {
	$("alert").style.visibility = "visible";
	Utility.println("=====================" + _content);
	if (orderFlag) {
		$("alert_title").innerText = $GL.TIPS;
	} else {
		$("alert_title").innerText = $L.INFO_TITLE;
		Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 46);
	}
	$("alert_content").innerText = _content;
}
function hideOrderInfo() {
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 46);
	$("alert").style.visibility = "hidden";
	$("alert_title").innerText = "",
	$("alert_content").innerText = "";
	infoFlag = false;
	orderFlag = false;
}
function showAlert(_tips) {
	orderFlag = true;
	$("confirmDiv").style.visibility = "visible";
	$("confirmTxt").innerText = _tips;
}
function hideAlert() {
	$("confirmDiv").style.visibility = "hidden";
	$("confirmTxt").innerText = "";
	orderFlag = false;
}
function exitPage() {
	Orders.deleteByFlag();
	Orders.save();
	stopMediaPlayer();
	Utility.ioctlRead("EPGExit");
	EPG.exit();
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 42);
}