﻿$L.init("epg");
var isFromNVOD = Utility.getEnv("backFromProOrder");
var params = $G.getParams(window.location.href);
var isFromRadio = false;
if (Utility.getEnv("serviceType") == "RADIO") {
	isFromRadio = true;
}
var orderProListView = new List(6, initOrderList, onFocusMove, onFocus, onBlur);
function initOrderList(item, index, focusIndex) {
	if (item) {
		$("date_" + focusIndex).innerText = isCurrDay(item.startTime);
		if (item.type == 2) {
			$("channelName_" + focusIndex).innerText = "NVOD";
		} else {
			$("channelName_" + focusIndex).innerText = item.serviceName ? item.serviceName.sub(7) : "";
		}
		$("startTime_" + focusIndex).innerText = $G.dateFormat(item.startTime, "hh:mm");
		$("proName_" + focusIndex).innerHTML = $G.txtMarquee(item.name, 8, 200);
	} else {
		$("date_" + focusIndex).innerText = "";
		$("channelName_" + focusIndex).innerText = "";
		$("startTime_" + focusIndex).innerText = "";
		$("proName_" + focusIndex).innerHTML = "";
	}
}
function isCurrDay(date) {
	var tempDate = date;
	var currDay = new Date();
	if (tempDate.getDate() == currDay.getDate()) {
		return (tempDate.getDate() + "(今天)");
	} else {
		return (tempDate.getDate() + "日");
	}
}
function onFocusMove(oldPos, newPos) {
	$("listFocus").style.top = 32 + 50*newPos + "px";
}
function onFocus(index) {
	$("listFocus").style.top = 32 + 50*index + "px";
	$("listFocus").style.visibility = "visible";
}
function onBlur(index) {
	$("listFocus").style.top = 32 + 50*index + "px";
	$("listFocus").style.visibility = "hidden";
}
function init() {
	if (isFromRadio) {
		$("bgImage").style.background = "url(../images/radio.jpg) no-repeat";
	}
	initTxt();
	if (Orders.length == 0) {
		//弹出暂无预定节目的提示框
	} else {
		orderProListView.bindData(Orders, 0, 1);
		orderProListView.setFocus();
	}
	Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 44);
}
function initTxt() {
	var txtArr = {
		menuTitle:$L.PROG_NAME_5,
		title_0:$L.DATE,
		title_1:$L.CHANNEL,
		title_2:$L.PLAY_TIME,
		title_3:$L.PROGRAM,
		currTip:$L.CURR_TIP,
		tip_0:$GL.TIP_0,
		tip_1:$GL.TIP_1,
		tip_2:$GL.TIP_2,
		tip_3:$GL.TIP_3,
		delDiv_title:$GL.TIPS,
		delDiv_bt0:$GL.OK,
		delDiv_bt1:$GL.CANCEL
	};
	for (var id in txtArr) {
		$(id).innerText = txtArr[id];
	}
}
function eventHandler(evt) {
	if (delFlag) {
		delEventHandler(evt);
		return;
	}
	switch (evt.code) {
		case "KEY_UP":
			orderProListView.up();
			break;
		case "KEY_DOWN":
			orderProListView.down();
			break;
		case "KEY_PAGE_UP":	
			orderProListView.pageUp();
			break;
		case "KEY_PAGE_DOWN":
			orderProListView.pageDown();
			break;
		case "KEY_NUMERIC":
			if (Orders.length == 0) {
				return;
			}
			var temNum = parseInt(evt.param);
			if ((temNum == 1) || (temNum == 2)) {
				delFlag = true;
				delChoice = temNum;
				showDelConfirmDiv(temNum);
			}
			break;
		case "KEY_BACK":
			if (isFromNVOD == "NVOD") {
				$G.debug("========================", "现在要回到NVOD页面");
				Utility.setEnv("backFromProOrder", "YES");
				window.location.href = "../NVOD/NVOD.htm";
			} else if (isFromRadio) {
				window.location.href = "../radio/radio_play.htm";
			} else {
				$G.exitToPlay();
			}
			break;
		case "KEY_EXIT":
			if (isFromNVOD == "NVOD") {
				$G.debug("========================", "现在要回到NVOD页面");
				Utility.setEnv("backFromProOrder", "YES");
				window.location.href = "../NVOD/NVOD.htm";
			} else if (isFromRadio) {
				window.location.href = "../radio/radio_play.htm";
			} else {
				$G.exitToPlay();
			}
			break;
		case "KEY_RED":
			if (isFromNVOD == "NVOD"){
				return;
			}
			window.location.href = "currDayNotice.htm";
			break;
		case "KEY_YELLOW":
			if (isFromNVOD == "NVOD"){
				return;
			}
			window.location.href = "epg.htm";
			break;
		case "KEY_BLUE":
			if (isFromNVOD == "NVOD"){
				return;
			}
			if(Utility.getEnv("serviceType") == "RADIO") return;
			else window.location.href = "cateEpg.htm";
			break;
	}
}

var delPos = 0, delFlag = false;
function showDelConfirmDiv(temNum) {
	var currChoice = parseInt(temNum);
	if (currChoice == 1) {
		$("delTip").innerText = $L.DEL_TIP_0;
	} else if (currChoice == 2) {
		$("delTip").innerText = $L.DEL_TIP_1;
	}
	$("delDiv").style.visibility = "visible";
	$("delDiv_bt" + delPos).className = "currBtn";
}
function delEventHandler(evt) {
	switch (evt.code) {
		case "KEY_LEFT":
		case "KEY_RIGHT":
			delBtnLR();
			break;
		case "KEY_ENTER":
			delService();
			break;
		case "KEY_EXIT":
			delFlag = false;
			$("delDiv").style.visibility = "hidden";
			break;
	}
}
var delChoice = 0, delPos = 0;
function delBtnLR() {
	$("delDiv_bt" + delPos).className = "";
	delPos = (delPos + 1) % 2;
	$("delDiv_bt" + delPos).className = "currBtn";
}

function delService() {
	if (delPos == 0) {
		if (delChoice == 1) {
			Orders.deleteOrder(Orders.getAt(orderProListView.currIndex));
			if (Orders.length != 0) {
				if (orderProListView.currIndex == Orders.length) {
					orderProListView.currIndex -= 1;
					if (orderProListView.currIndex < 0) {
						orderProListView.currIndex = 0;
					}
					orderProListView.bindData(Orders, orderProListView.currIndex, 1);
					orderProListView.setFocus();
				} else {
					orderProListView.bindData(Orders, orderProListView.currIndex, 1);
					orderProListView.setFocus();
				}
			} else {
				orderProListView.bindData(Orders, 0, 1);
				orderProListView.setBlur();
			}
		} else if (delChoice == 2) {
			Orders.deleteAll();
			orderProListView.bindData(Orders, 0, 1);
			orderProListView.setBlur();
		}
	} else {
		delBtnLR();
	}
	delFlag = false;
	$("delDiv").style.visibility = "hidden";
}

function exitPage() {
	Orders.deleteByFlag();
	Orders.save();
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 44);
}