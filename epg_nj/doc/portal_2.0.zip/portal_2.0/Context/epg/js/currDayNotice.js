﻿$L.init("epg");
Utility.println("-------------------0--------+"+Utility.getTickCount());
var tvList = ServiceDB.getServiceList().filterService(ServiceDB.LIST_TYPE_SERVICE, "TV");
Utility.println("-------------------0--1------+"+Utility.getTickCount());
var radioList = ServiceDB.getServiceList().filterService(ServiceDB.LIST_TYPE_SERVICE, "RADIO");
Utility.println("-------------------0--2------+"+Utility.getTickCount());
var currList, isFromRadio = false;

if (Utility.getEnv("serviceType") == "RADIO") {
	isFromRadio = true;
	currList = radioList;
} else {
	currList = tvList;
}
var currServiceIndex, noticeListView, infoFlag = false;

function eventHandler(evt) {
	switch(evt.code) {
		case "KEY_UP":
			if (infoFlag) return;
			noticeListView.up();
			break;
		case "KEY_DOWN":
			if (infoFlag) return;	
			noticeListView.down();
			break;
		case "KEY_PAGE_UP":
			if (infoFlag) return;
			noticeListView.pageUp();
			break;
		case "KEY_PAGE_DOWN":
			if (infoFlag) return;
			noticeListView.pageDown();
			break;
		case "KEY_LEFT":
		case "KEY_RIGHT":
			if (infoFlag) return;
			currServiceIndex = noticeListView.currIndex;
			if (currList == tvList) {
				window.location.href = "currChannel.htm?index=" + currServiceIndex;
			} else {
				window.location.href = "currChannel.htm?index=" + currServiceIndex + "&type=1";
			}
			
			break;
		case "KEY_INFO":
			currServiceIndex = noticeListView.currIndex;
			var currProgram = currList.getAt(currServiceIndex).presentProgram;
			if (currProgram.description.length >= 4) {
				if (!infoFlag) {
					showInfo();
				} else if(infoFlag) {
					hideInfo();
				}
			}
			break;
		case "KEY_ENTER":
			currServiceIndex = noticeListView.currIndex;
			currList.moveTo(currServiceIndex);
			if(Utility.getEnv("serviceType") == "RADIO") {
				window.location.href = "../radio/radio_play.htm";
			} else {
				window.location.href = "../play/play.htm";
			}
			break;
		case "KEY_EXIT":
			if (infoFlag) {
				hideInfo();
				return;
			} else if (isFromRadio) {
				window.location.href = "../radio/radio_play.htm";
			} else {
				$G.exitToPlay();
			}
			break;
		case "KEY_BACK":	
			if (infoFlag) {
				hideInfo();
				return;
			} else if (isFromRadio) {
				window.location.href = "../radio/radio_play.htm";
			} else {
				$G.exitToPlay();
			}
			break;
		case "KEY_YELLOW":
			window.location.href = "epg.htm";
			break;
		case "KEY_BLUE":
			if(Utility.getEnv("serviceType") == "RADIO") return;
			else window.location.href = "cateEpg.htm";
			break;
		case "KEY_GREEN":
			window.location.href = "appointNotice.htm";
			break;
	}
}

function init() {
	if (isFromRadio) {
		$("bgImage").style.background = "url(../images/radio.jpg) no-repeat";
		$("tip_6").style.color = "#999999";
	}
	//EPG.enter();
	Utility.println("-------------------1--------+"+Utility.getTickCount());
	initTxt();
	Utility.println("-------------------2--------+"+Utility.getTickCount());
	if (currList.findIndex(currList.currentService) != -1) {
		var index = Utility.getEnv("lastIndex");
		if (index != "") {
			currServiceIndex = parseInt(index);
			Utility.setEnv("lastIndex", "");
		} else {
			currServiceIndex = currList.findIndex(currList.currentService);
		}
	} else {
		currServiceIndex = 0;
	}	
	Utility.println("-------------------3--------+"+Utility.getTickCount());
	noticeListView = new List(6, initNextNotice, onFocusMove, onFocus, onBlur);
	noticeListView.bindData(currList, currServiceIndex, 1);
	noticeListView.setFocus();
	Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 41);
	Utility.println("-------------------4--------+"+Utility.getTickCount());
	//stopMediaPlayer();
	setTimeout('startEpg()',500);
}

function startEpg() {
	Utility.ioctlRead("EPG");
	(new MediaPlayer()).stop();
}

function initTxt() {
	var txtArr = {
		menuTitle:($L.PROG_NAME + "—" + $L.PROG_NAME_0),
		title_0:$L.CHANNEL,
		title_1:$L.TIME,
		title_2:$L.PROGRAM,
		title_3:$L.STATUS,
		tip_0:$L.PROG_TIPS_0,
		tip_1:$L.PROG_TIPS_1,
		tip_2:$L.PROG_TIPS_2,
		tip_3:$L.PROG_TIPS_3,
		tip_4:$GL.TIP_0,
		tip_5:$GL.TIP_1,
		tip_6:$GL.TIP_2,
		tip_7:$GL.TIP_3,
		alert_title:$L.INFO_TITLE,
		alert_tip:$L.INFO_TIPS
	};
	for (var id in txtArr) {
		$(id).innerText = txtArr[id];
	}
}
	
function onFocusMove(oldPos, newPos) {
	$("listFocus").style.top = 32 + 50*newPos + "px";
}
function onFocus(index) {
	$("listFocus").style.top = 32 + 50*index + "px";
	$("listFocus").style.visibility = "visible";
}
function onBlur(index) {
	$("listFocus").style.visibility = "hidden";
}

function showInfo() {
	infoFlag = true;
	$("alert").style.visibility = "visible";
	var desc = currList.getAt(currServiceIndex).presentProgram.description;
	if (desc.length > 75){
		$("alert_content").innerText = desc.sub(150);
	}else{
		$("alert_content").innerText = desc;
	}
	Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 46);
}
function hideInfo() {
	infoFlag = false;
	$("alert").style.visibility = "hidden";
	$("alert_content").innerText = "";
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 46);
}
function exitPage() {
	Utility.ioctlRead("EPGExit");
	EPG.exit();
	stopMediaPlayer();
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 41);
}

function diffMinute(date) {	
	var currDate = new Date();
	var rtMinutes = Math.floor(timeDiff(date, currDate) / 60);
	return rtMinutes;
}

function dateToSecond(date) {
	return date.getHours()*3600 + date.getMinutes()*60 + date.getSeconds();
}

function timeDiff(endTime, nowTime) {
	return (dateToSecond(endTime) - dateToSecond(nowTime));
}
refreshTime();
var currEpgTimer = [];
function refreshTime() {
	for(var i = 0; i < 6; i++) {
		currEpgTimer[i] = diffMinute(currList.getAt(i).presentProgram.endTime);
		$G.debug("---------------------------time=",currEpgTimer[i]);
		$G.debug("---------------------------time+++++++++=",$("time_" + i).innerText);
	}
	//noticeListView = new List(6, initNextNotice, onFocusMove, onFocus, onBlur);
	noticeListView.bindData(currList, noticeListView.currIndex, 1);
	noticeListView.setFocus();
	setTimeout(refreshTime,60000);
}

var CurrDayFlag = false;
function isCurrDay(date) {
	var tempDate = date;
	var currDay = new Date();
	if (tempDate.getDate() == currDay.getDate()) {
		CurrDayFlag = false;
	} else {
		CurrDayFlag = true;
	}
}

function initNextNotice(item, index, focusIndex) {
	/*for(var i = 0; i < 6; i++) {
		currEpgTimer[i] = 0;
		currEpgTimer[i] = diffMinute(currList.getAt(i).presentProgram.endTime);	
		$G.debug("---------------------------time=",currEpgTimer[i]);
		$G.debug("---------------------------time+++++++++=",$("time_" + i).innerText);
	}*/
	if (item) {
		$("channelName_" + focusIndex).innerText = item.name;
		switch(focusIndex) {
			case 0:
				if(currEpgTimer[focusIndex] <= 0) {
					$("time_" + focusIndex).innerText = item.followingProgram ? $G.dateFormat(item.followingProgram.startTime, "hh:mm") + "-" + $G.dateFormat(item.followingProgram.endTime, "hh:mm") : "";
					$("proName_" + focusIndex).innerHTML = item.followingProgram ?  item.followingProgram.name.sub(18) : "";
				}
				else  {
					$("time_" + focusIndex).innerText = item.presentProgram ? $G.dateFormat(item.presentProgram.startTime, "hh:mm") + "-" + $G.dateFormat(item.presentProgram.endTime, "hh:mm") : "";
					$("proName_" + focusIndex).innerHTML = item.presentProgram ?  item.presentProgram.name.sub(18) : "";
				}
				break;
			case 1:
				if(currEpgTimer[focusIndex] <= 0) {
					$("time_" + focusIndex).innerText = item.followingProgram ? $G.dateFormat(item.followingProgram.startTime, "hh:mm") + "-" + $G.dateFormat(item.followingProgram.endTime, "hh:mm") : "";
					$("proName_" + focusIndex).innerHTML = item.followingProgram ?  item.followingProgram.name.sub(18) : "";
				}
				else  {
					$("time_" + focusIndex).innerText = item.presentProgram ? $G.dateFormat(item.presentProgram.startTime, "hh:mm") + "-" + $G.dateFormat(item.presentProgram.endTime, "hh:mm") : "";
					$("proName_" + focusIndex).innerHTML = item.presentProgram ?  item.presentProgram.name.sub(18) : "";
				}
				break;
			case 2:
				if(currEpgTimer[focusIndex] <= 0) {
					$("time_" + focusIndex).innerText = item.followingProgram ? $G.dateFormat(item.followingProgram.startTime, "hh:mm") + "-" + $G.dateFormat(item.followingProgram.endTime, "hh:mm") : "";
					$("proName_" + focusIndex).innerHTML = item.followingProgram ?  item.followingProgram.name.sub(18) : "";
				}
				else  {
					$("time_" + focusIndex).innerText = item.presentProgram ? $G.dateFormat(item.presentProgram.startTime, "hh:mm") + "-" + $G.dateFormat(item.presentProgram.endTime, "hh:mm") : "";
					$("proName_" + focusIndex).innerHTML = item.presentProgram ?  item.presentProgram.name.sub(18) : "";
				}
				break;
			case 3:
				if(currEpgTimer[focusIndex] <= 0) {
					$("time_" + focusIndex).innerText = item.followingProgram ? $G.dateFormat(item.followingProgram.startTime, "hh:mm") + "-" + $G.dateFormat(item.followingProgram.endTime, "hh:mm") : "";
					$("proName_" + focusIndex).innerHTML = item.followingProgram ?  item.followingProgram.name.sub(18) : "";
				}
				else  {
					$("time_" + focusIndex).innerText = item.presentProgram ? $G.dateFormat(item.presentProgram.startTime, "hh:mm") + "-" + $G.dateFormat(item.presentProgram.endTime, "hh:mm") : "";
					$("proName_" + focusIndex).innerHTML = item.presentProgram ?  item.presentProgram.name.sub(18) : "";
				}
				break;
			case 4:
				if(currEpgTimer[focusIndex] <= 0) {
					$("time_" + focusIndex).innerText = item.followingProgram ? $G.dateFormat(item.followingProgram.startTime, "hh:mm") + "-" + $G.dateFormat(item.followingProgram.endTime, "hh:mm") : "";
					$("proName_" + focusIndex).innerHTML = item.followingProgram ?  item.followingProgram.name.sub(18) : "";
				}
				else  {
					$("time_" + focusIndex).innerText = item.presentProgram ? $G.dateFormat(item.presentProgram.startTime, "hh:mm") + "-" + $G.dateFormat(item.presentProgram.endTime, "hh:mm") : "";
					$("proName_" + focusIndex).innerHTML = item.presentProgram ?  item.presentProgram.name.sub(18) : "";
				}
				break;
			case 5:
				if(currEpgTimer[focusIndex] <= 0) {
					$("time_" + focusIndex).innerText = item.followingProgram ? $G.dateFormat(item.followingProgram.startTime, "hh:mm") + "-" + $G.dateFormat(item.followingProgram.endTime, "hh:mm") : "";
					$("proName_" + focusIndex).innerHTML = item.followingProgram ?  item.followingProgram.name.sub(18) : "";
				}
				else  {
					$("time_" + focusIndex).innerText = item.presentProgram ? $G.dateFormat(item.presentProgram.startTime, "hh:mm") + "-" + $G.dateFormat(item.presentProgram.endTime, "hh:mm") : "";
					$("proName_" + focusIndex).innerHTML = item.presentProgram ?  item.presentProgram.name.sub(18) : "";
				}
				break;
		}
		if (Orders.isOrdered(item.followingProgram)) {
			$("isBooked_" + focusIndex).style.visibility = "visible";
		} else {
			$("isBooked_" + focusIndex).style.visibility = "hidden";
		}
		if (item.followingProgram.description.length >= 4) {
			$("info_" + focusIndex).style.visibility = "visible";
		} else {
			$("info_" + focusIndex).style.visibility = "hidden";
		}
	} else {
		$("channelName_" + focusIndex).innerText = "";
		$("time_" + focusIndex).innerText = "";
		$("proName_" + focusIndex).innerHTML = "";
		$("isBooked_" + focusIndex).style.visibility = "hidden";
		$("info_" + focusIndex).style.visibility = "hidden";
	}
}