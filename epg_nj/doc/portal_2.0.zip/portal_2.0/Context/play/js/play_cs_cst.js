$L.init("play");
var filePath = Utility.getEnv("STB.systemPath")+"/config/shortcut.config";
var file = new File(filePath);
file.open("r", 1);
var size = file.getSize();
Utility.println("-------filePath "+filePath+"--size = "+size);
var shortDatastr = file.readFile(0, size);
file.close();
//Utility.println("----------data = "+shortDatastr);
var shortData = [];
if (shortDatastr && shortDatastr != "") shortData = eval(shortDatastr);
else shortData = [];
Utility.println("----------shortData.length = "+shortData.length);
var allChannelsList = ServiceDB.getServiceList();
var tvList = allChannelsList.filterService(ServiceDB.LIST_TYPE_SERVICE, "TV");
//var mosaicServiceList = allChannelsList.filterService(0, 6);
var broadcastList = allChannelsList.filterService(ServiceDB.LIST_TYPE_SERVICE,'DATA_BROADCAST');
var allServiceList = [];
var isFromMosaic = Utility.getEnv("fromLink");
var mp = new MPlayer();
var Av_stopMode = 1;
mp.player.setStopMode(Av_stopMode);
var timerManager = new TimerManager();
var channelBar, volumeBar, OKList, descBox, audioChannel, audioChannelText, passwordBox;
var currTvIndex = 0;
var currChannelList;
var currService;
var audioChannelOptions = [];
var audioTrackMode = $G.sysDa.get("Av.audioTrackMode") != "" ? parseInt($G.sysDa.get("Av.audioTrackMode")) : 0;
var volumeMode = $G.sysDa.get("VolumeSaveMode") != "" ? parseInt($G.sysDa.get("VolumeSaveMode")) : 0;
var showTipsFlag = false;
var pfTimer, channelBarTimer;
var appListView;
var appFlag = false;
var apps;
var focusAppItem ;
var misCanPlayVideo = true;		// 该变量主要用来判定在退出如加mis应用后，需不需要在重新播发节目
var misCanStopAdv = false;
var misStartStatus = false,singalFlag = false;
var isFromZeroChannel = Utility.getEnv("zeroChannel");
Utility.setEnv("reloadFlag", "true");
if (isFromZeroChannel != "") {
	Utility.setEnv("zeroChannel", "");
	//Utility.ioctlWrite("NM_Help", "nAction:"+0);
}
var userId=Utility.getSystemInfo("UID");
var caSerialNum = CA.serialNumber;


var stbSerialNum = SysInfo.STBSerialNumber;
var codeStr = "Y-coship-coship" + currIp + "-etc";
Utility.setEnv("serviceType", "TV");
var audioChannels = {};
var ethernet = Network.ethernets[0] , mac;
var modulations = ['', 'QAM16', 'QAM32', 'QAM64', 'QAM128', 'QAM256'];
var recoverUpdateFlag = Utility.getEnv("recoverUpdate");
var helpTailAddr = "cardid=" + caSerialNum + "&clientid=" + stbSerialNum + "&method=&channel=0000:000:00:0000&code=" + codeStr + "&uitype=" + 1;

// voip call
var phoneRecordObj;

// 广告刷新标识位
var ADTimer = 0;

//此函数是将所有的service从各自的list中取出存入到一个数组中，方便显示和获取
function initServiceList() {
	for (var i=0; i < tvList.length; i++) {
		allServiceList.push(tvList.getAt(i));
	}
	/*if (mosaicServiceList.length > 0) {
		allServiceList.push(mosaicServiceList.getAt(0));
	}*/
	for (var i=0; i < broadcastList.length; i++) {
		allServiceList.push(broadcastList.getAt(i));
	}
	for (var i=0; i < shortData.length; i++) {
		allServiceList.push(shortData[i]);
	}
}
var allChannelListView = new List(16, showChannelList, channelOnFocusMove, channelOnFocus, channelOnBlur);
function showChannelList(item, index, focusIndex) {
	if (item) {
		$("proIndex_" + focusIndex).innerText = item.logicNumber;
		if (item.logicNumber == 801) {
			$("proName_" + focusIndex).innerText = "阳光政务";
		} else if (item.logicNumber == 802) {
			$("proName_" + focusIndex).innerText = "生活资讯";
		} else if (item.logicNumber == 864) {
			$("proName_" + focusIndex).innerText = "最新推荐";
		} else {
			$("proName_" + focusIndex).innerText = item.name;
		}
	} else {
		$("proIndex_" + focusIndex).innerText = "";
		$("proName_" + focusIndex).innerText = "";
	}
}
function channelOnFocusMove(oldPos, newPos) {
	$("proList_" + oldPos).className = "";
	$("proList_" + newPos).className = "proOnFocus";
}
function channelOnFocus(index) {
	$("proList_" + index).className = "proOnFocus";
}
function channelOnBlur(index) {
	$("proList_" + index).className = "";
}

var channelNumObj = {
	inputStr: '',
	currPos: 0,
	inputTimeoutFlag: -1,
	showTimeoutFlag: -1,
	isVisible: false,
	isInputStatus: false,
	getInput: function(inputNum) {
		this.showChannelNumber();
		this.isVisible = true;
		if(!this.isInputStatus){
			this.inputStr = '';
			this.inputStr += inputNum;
			this.isInputStatus = true;
		} else this.inputStr += inputNum;
		
		if (this.inputStr.length <= 3) {
			clearTimeout(this.inputTimeoutFlag);
			this.currPos++;
			var self = this;
			this.isInputStatus = true;
			this.inputTimeoutFlag = setTimeout(function(){self.openChannel();}, 2000);		
		} else {
			clearTimeout(this.inputTimeoutFlag);
			this.inputStr = "" + inputNum;
			this.inputTimeoutFlag = setTimeout(function(){self.openChannel();}, 2000);
		}
		$("channel_num").innerText = this.generateChannelNumber(this.paddingInputNumber(this.inputStr, 3, "0"));
		$("channelNumTopID").innerText = this.generateChannelNumber(this.paddingInputNumber(this.inputStr, 3, "0"));
		$("channel_name").innerText = $L.INPUT_TIP;
	},
	openChannel: function() {
		if (this.inputStr == '') { return; }
		clearTimeout(this.inputTimeoutFlag);
		setChannel(Math.floor(this.inputStr));
		this.isInputStatus = false;
	},
	showChannelNumber: function() {
		clearTimeout(this.showTimeoutFlag);
	},
	hideChannelNumber: function() {
		clearTimeout(this.inputTimeoutFlag);
		clearTimeout(this.showTimeoutFlag);
		this.inputStr = "";
		this.currPos = 0;
		this.isVisible = false;
		this.isInputStatus = false;
	},
	generateChannelNumber: function(n) {
		n = n.toString();
		var channelNum = '';
		for (var i = 0; i < n.length ; i++) {
			var number = n.substr(i, 1);
			if (number != '0')
				channelNum += parseInt(number);
			else
				channelNum +=  "0";
		}
		return channelNum;
	},
	paddingInputNumber: function(str, length, padding) {
		str = str.toString();
		var paddingLength = length - str.length;
		for (var i = 0; i< paddingLength; i++)
			str = padding + str;
		return str;
	}
};

function find(phoneNum){
	var recorFile = Utility.getEnv("STB.systemPath")+"/config/phonebook.txt";
	var voipRecord = new VoipRecord(recorFile);
	voipRecord.make();

	if(voipRecord.length == 0) return "陌生人";
	
	for(var index = 0; index < voipRecord.length; index++){
		if (voipRecord.data[index].cellPhone == phoneNum) {
			return voipRecord.data[index].name;
		}
	}
	return "陌生人";
}

function getCaller(){
	var caller = [],callerName =  "";
	Utility.println("==================play=====phoneRecordObj.phoneNumber===================" + phoneRecordObj.phoneNumber);
	if('0'== phoneRecordObj.type){
		var reg = /([\d]+)/gi;
		var str = phoneRecordObj.phoneNumber;
		var rs = reg.exec(str)[1];
		caller[0] = rs;
	}else{
		var reg = /[\+][\d]{4}([\d]+)/gi;
		var str = phoneRecordObj.phoneNumber;
		var rs = reg.exec(str)[1];
		caller[0] = rs;// 电话号码*/
	}
	callerName = find(caller[0]);
	caller[1] = callerName;
	caller[2] = Utility.getEnv("ROOT_PATH") + "voip/images/caller_pic.png";
	return caller;
}

var delFlag = false;
function eventHandler(evt){
	if (goSearch) {
		srhConfirmHandler(evt);
		return;
	}
	if (passwordBox && passwordBox.isVisible) {
		if (passwordEventHandler(evt))
			return;
	}
	if (delFlag) {
		delEventHandler(evt);
		return;
	}
	if (appFlag) {
		processAppListEvent(evt);
		return;
	}
	
	Utility.println("play.js key = "+evt.code);
	Utility.ioctlWrite("motoKey2Dvb", "");//临时解决方法，发现有时按键不响应，强制将键值转化为中间件标准键值
	
	switch (evt.code) {
		case "KEY_UP":
			Utility.println("----------getStopMode2 = "+mp.player.getStopMode());
			clearTimeout(playVideoTimer);
			clearTimeout(pfTimer);
			clearTimeout(ADTimer);
			if (descFlag_0 || descFlag_1) return;
			if(singalFlag) return;
			if (OKList.isVisible) {
				allChannelListView.up();
				ADTimer = setTimeout("changeOKListAD()",80);
			} else {
				//clearTimeout(playVideoTimer);
				if (isFromMosaic == "YES") {
					isFromMosaic = "";
					Utility.setEnv("fromLink", "");
				}
				changeChannel(1);
				if (channelNumObj.isInputStatus) {
					channelNumObj.hideChannelNumber();
				}
			}
			break;
		case "KEY_DOWN":
			Utility.println("----------getStopMode3 = "+mp.player.getStopMode());
			clearTimeout(playVideoTimer);
			clearTimeout(pfTimer);
			clearTimeout(ADTimer);
			if (descFlag_0 || descFlag_1) return;
			if(singalFlag) return;
			if (OKList.isVisible) {
				allChannelListView.down();
//				changeOKListAD();
				ADTimer = setTimeout("changeOKListAD()",80);
			} else {
				//clearTimeout(playVideoTimer);
				if (isFromMosaic == "YES") {
					isFromMosaic = "";
					Utility.setEnv("fromLink", "");
				}
				changeChannel(-1);
				if (channelNumObj.isInputStatus) {
					channelNumObj.hideChannelNumber();
				}
			}
			break;
		case "KEY_LEFT":
			if (descFlag_0 || descFlag_1) return;
			if(singalFlag) return;
			if (OKList.isVisible) {
				allChannelListView.left();
				changeOKListAD();
			}
			else {
				changeVolume(-1);
			}
			break;
		case "KEY_RIGHT":
			if (descFlag_0 || descFlag_1) return;
			if(singalFlag) return;
			if (OKList.isVisible) {
				allChannelListView.right();
				changeOKListAD();
			}
			else {
				changeVolume(1);
			}
			break;
		case "KEY_VOLUME_UP":
			if (descFlag_0 || descFlag_1) return;
			if(singalFlag) return;
			if (!OKList.isVisible) {
				changeVolume(1);
			}
			break;
		case "KEY_VOLUME_DOWN":
			if (descFlag_0 || descFlag_1) return;
			if(singalFlag) return;
			if (!OKList.isVisible) {
				changeVolume(-1);
			}
			break;
		case "KEY_AUDIO":
			if (descFlag_0 || descFlag_1) return;
			changeAudioChannel();
			break;
		case "KEY_MUTE":
			if (descFlag_0 || descFlag_1) return;
			if(singalFlag) return;
			setMute();
			break;
		case "KEY_PAGE_UP":
			if(singalFlag) return;
			if (shiftProStatus && !OKList.isVisible) {
				mp.player.setStopMode(1);
				mp.player.stop();
				if (isAuthorized) {
					window.location.href = "http://hditv.jsamtv.com/epg/show.do?app=cpg&auth=y&hd=y&content=order&cardid=" + caSerialNum + "&clientid=" + stbSerialNum +"&method=pauselive&channel=" + currService.serviceId + ":" + currService.frequency + ":" + modulations[currService.modulation].substring(3) +  ":" + currService.symbolRate + "&code=" + addrJSON.codeInfo;
				} else {
					window.location.href = "http://hditv.jsamtv.com/epg/show.do?app=cpg&auth=n&hd=y&content=order&cardid=" + caSerialNum + "&clientid=" + stbSerialNum +"&method=pauselive&channel=" + currService.serviceId + ":" + currService.frequency + ":" + modulations[currService.modulation].substring(3) +  ":" + currService.symbolRate + "&code=" + addrJSON.codeInfo;
				}
				return;
			} else if (OKList.isVisible) {
				allChannelListView.pageUp();
				changeOKListAD();
			}
			break;
		case "KEY_PAGE_DOWN":
			if(singalFlag) return;
			if (OKList.isVisible) {
				allChannelListView.pageDown();
				changeOKListAD();
			} else {
				//stopAitManager();
				showSingalBox();
			}		
			break;
		case "KEY_ENTER":
			if (descFlag_0 || descFlag_1) return;
			if(singalFlag) return;
			if (!OKList.isVisible) {
				if (channelNumObj.isInputStatus) {
					channelNumObj.isInputStatus = false;
					channelNumObj.openChannel();
					return;
				}
				if (channelBar.isVisible) {
					channelBar.hide();
					$("channelNumTopID").style.visibility = "hidden";
				}
				if (volumeBar.isVisible) 
					volumeBar.hide();
				// oklist会占用顶部和底部用于显示字幕的区域。因此，在显示oklist前，应把字幕隐藏。
				Utility.setEnv("Mis_AdvCallback", "hide_caption_adv");
				
				OKList.show();
				Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 01);
			}
			else {
				currService = allServiceList[allChannelListView.currIndex];
				if (currService) {
					if (currService.type == 12) {
						AppManager.startLocalAppByID("Third", currService.serviceId, "C");
						var isCoded = parseInt(Utility.ioctlRead("ThirdEntitle"));
						if (isCoded == 1) {
							hiddenTips();
							mp.player.setStopMode(0);
							mp.player.stop();
							var ocUrl = currService.getLocation();
							Utility.setEnv("ocUrl", ocUrl);
							stopAitManager();
							window.location.href = "oc_play.htm";
						}
						else 
							if (isCoded == 0) {
								mp.player.setStopMode(0);
								mp.player.stop();
								thirdSecret();
								thirdTimer = setTimeout(function(){
									hideThird();
								}, 5000);
							}
					}
					/*else if (currService.logicNumber == 800) {
					 pauseAitManager();
					 window.location.href = "mosaic.htm";
					 } */
					else { //判断对OKList是否没有改变，如果不改变，就不再重新播放一次了
						tvList.moveTo(currService.logicNumber);
						setChannel(currService.logicNumber);
					}
				}
				OKList.hide();
			}
			break;
		case "KEY_EXIT":
			if (OKList.isVisible) {
				OKList.hide();
			} else if (descFlag_0 || descFlag_1) {
				hideDesc();
			}
			if (channelBar.isVisible) {
				channelBar.hide();
				$("channelNumTopID").style.visibility = "hidden";
			}
			if (volumeBar.isVisible) volumeBar.hide();
			hideAppDownLoadIcon();
			break;
		case "KEY_CHANNEL_DOWN":
			clearTimeout(playVideoTimer);
			clearTimeout(pfTimer);
			if (descFlag_0 || descFlag_1) return;
			if(singalFlag) return;
			if (!OKList.isVisible) {
				//clearTimeout(playVideoTimer);
				if (isFromMosaic == "YES") {
					isFromMosaic = "";
					Utility.setEnv("fromLink", "");
				}
				changeChannel(-1);
				if (channelNumObj.isInputStatus) {
					channelNumObj.hideChannelNumber();
				}
			}
			break;
		case "KEY_CHANNEL_UP":
			clearTimeout(playVideoTimer);
			clearTimeout(pfTimer);
			if (descFlag_0 || descFlag_1) return;
			if(singalFlag) return;
			if (!OKList.isVisible) {
				//clearTimeout(playVideoTimer);
				if (isFromMosaic == "YES") {
					isFromMosaic = "";
					Utility.setEnv("fromLink", "");
				}
				changeChannel(1);
				if (channelNumObj.isInputStatus) {
					channelNumObj.hideChannelNumber();
				}
			}
			break;
		case "KEY_YELLOW":
			//window.location.href = "../mutimedia/usb.htm";
			//return;
			var nRet = -1;
			if (OKList.isVisible) {
				stopAitManager();
				window.location.href = "../epg/epg.htm";
				return;
			}
			mp.player.setStopMode(0);
			mp.player.stop();
			SysSetting.panelDisplayText(" ");
			SysSetting.panelDisplayText("Stoc");
			Utility.ioctlWrite("NM_Key"," KeyName:"+ 97);
			window.location.href = "http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-002&userCode="+userId;
			break;
		case "KEY_RED":
			stopAitManager();
			if (OKList.isVisible) {
				window.location.href = "../epg/currDayNotice.htm";
				return;
			}
			window.location.href = "../epg/currDayNotice.htm";
			break;
		case "KEY_BLUE":
			if (OKList.isVisible) {
				pauseAitManager();
				window.location.href = "../epg/cateEpg.htm";
				return;
			}
			showAppList();
			break;
		case "KEY_GREEN":
			//Utility.ioctlWrite("enter2DGame","");
			{			
				var runShell = "2dgame:sleep 1 \n \
				cd /kmod \n  \
				echo $PWD\nrmmod hifb.ko \n \
				insmod hifb.ko video=\"hifb:vram0_size:0, vram2_size:40960\" \n \
				mount -t vfat /dev/sda1 /mnt/hd/HDD1 \n \
				sleep 1 \n \
				cd /root/ \n \
				killall dfbprepare \n \
				./dfbprepare & \n \
				sleep 2 \n \
				/usb/usb0/trans/gamecollection/start.sh \n \
				while [ -f /tmp/game/game_start.tm ];do \n \
				    sleep 1 \n \
				done \n \
				killall dfbprepare \n \
				sleep 1";
				AppManager.startLocalAppByID(runShell, "", "C");
			}
			stopAitManager();
			if (OKList.isVisible) {
				window.location.href = "../epg/appointNotice.htm";
				return;
			}
			mp.player.setStopMode(0);
			mp.player.stop();
			Utility.ioctlWrite("NM_Key"," KeyName:"+ 99);
			window.location.href = "http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=08-001&userCode="+userId;
			break;	
		case "KEY_AUTO_SEARCH":
			if (!goSearch) {
				goSearch = true;
				showConfirmDiv("您确定要重新搜索节目吗？", false);
			}
			break;
		case "KEY_BACK":
			if(singalFlag) {
				hideSingalBox();
				return;
			}
			if (descFlag_0 || descFlag_1) {
				hideDesc();
				return;
			}
			if (OKList.isVisible) {
				OKList.hide();
			} else if (channelBar.isVisible) {
				channelBar.hide();
				$("channelNumTopID").style.visibility = "hidden";
			} else if (isFromMosaic == "YES") {
				isFromMosaic = "";
				Utility.setEnv("fromLink", "");
				window.location.href = "mosaic.htm";
			} else {
				if (passwordBox.isVisible) {
					passwordBox.hide();
				}
				openLastChannel();
			}
			break;
		case "KEY_NUMERIC":
			if (descFlag_0 || descFlag_1) return;
			if(singalFlag) return;
			if (!OKList.isVisible) {
				clearPF();
				showChannelBar();
				channelNumObj.getInput(evt.param);
			} else if (OKList.isVisible) {
				var temNum = parseInt(evt.param);
				if ((temNum == 1) || (temNum == 2)) {
					delFlag = true;
					delChoice = temNum;
					showDelConfirmDiv(temNum);
				}
			}
			break;
		case "DVB_PRESENT_EVENT_REFRESH":
		case "DVB_FOLLOWING_EVENT_REFRESH":
			clearTimeout(pfTimer);
			pfTimer = setTimeout("initPF()", 1000);
			break;
		case "CA_COMMAND":
			break;
		case "KEY_INFO":
			if(singalFlag) return;
			if (!OKList.isVisible) {
				showInfo();
			}
			break;
		case "DVB_SHOW_INFO":
			onDisplayMessageEvent(DVB.getShowEvents());
			break;
		case "DVB_HIDE_INFO":
			hiddenTips();
			break;
		case "GETEVENT_CHANNEL_DESCRIPTION":
			var messageId = event.userInt;
			var evtstr = DVB.getEvent(45002, messageId);
			var infoObj = eval('('+evtstr+')');
			$("unAthorizedInfo").innerHTML =  infoObj.str;
			Utility.println("=====GETEVENT_CHANNEL_DESCRIPTION=========" + infoObj.str);
			break;
		case "MIS_ENTER_APP":			// 进入mis应用消息，进入mis应用之后不应响应除mis消息和待机消息之外的任何消息。
			Utility.setEnv("MIS_APP_STATUS", "TRUE");
			break;
		case "MIS_QUIT_APP":			// 退出mis应用消息
			Utility.setEnv("MIS_APP_STATUS", "FALSE");
			if (misCanPlayVideo) {		// 该变量为true时，则在退出mis应用后需重新播发当前节目
				misCanStopAdv = false;	// 退出mis应用时，不允许调用stop
				mp.fullScreen();
				mp.player.stop();
				changeChannel(0);
			}
			break;
		case "MIS_SWITCH_PROGRAM":		// 通过mis应用换台消息
			Utility.setEnv("MIS_APP_STATUS", "FALSE");
			misCanStopAdv = false;		// 如加换台时，不允许调用stop
			if (misSwitchProgram()) {
				// 通过mis应用切台成功，则在退出mis应用时不应重新播放节目
				misCanPlayVideo = false;	
				setTimeout(function(){misCanPlayVideo = true;}, 2400);
			}
			break;
		case "MIS_ENTER_BROADCAST":		// 通过mis应该进入到各个页面
			Utility.setEnv("MIS_APP_STATUS", "FALSE");
			if (misLinkUrl()) {
				misCanPlayVideo = false;
				setTimeout(function(){misCanPlayVideo = true;}, 2400);
			}
			break;
		case "MIS_REQUEST_USSTATUS":	// 如加请求当前UI状态消息
			// 收到该消息后，需把当前UI状态通过环境变量传给如加监控系统
			setMisUiStatus();
			break;
		case "MIS_GETEPG_STATUS":
			var misStr = DVB.getEvent(45783, event.userInt);
			if (misStr == "success") {		// 成功
				if (volumeBar.isVisible) {	
					$("volumeBarDiv").style.visibility = "visible";
				} else if (OKList.isVisible) {								
					$("ok_list_ad_div").style.visibility = "visible";		
				}
			} else {
				if (volumeBar.isVisible) {	
					$("volumeBarDiv").style.visibility = "hidden";
				} else if (OKList.isVisible) {								
					$("ok_list_ad_div").style.visibility = "hidden";		
				}
			}
			
			if (volumeBar.isVisible) {					
				Utility.ioctlWrite("NM_VolChange","nAction:"+2);
			} else if (OKList.isVisible) {	
				Utility.println("\n\n+++++++MIS_GETEPG_STATUS+++++++++\n\n");
				//本来是关闭的 
				Utility.ioctlWrite("NM_Menu", "nAction:" + 3 + ",code:" + 01);
			}
			break;
		case "DVB_PLAY_SUCCESS":
			if (channelBar.isVisible) {
				$("channel_bar_ad").src = "misads://typeIndex=21";
			}
			break;
		case "Application_Note":
			Utility.println("========play.js====11====showApplistView=======");
			apps = AppsCollection.getApplications("TransportType=OC-ServiceBound");
			if (!channelBar.isVisible) {
				if (apps.length > 0) {
					// 在应用下载提示框显示之前前，应把如加广告中的泡泡广告隐藏
					Utility.setEnv("Mis_AdvCallback", "hide_bubble_adv");
					
					showAppDownLoadIcon();
				} else {
					hideAppDownLoadIcon();
				}
		 }
			break;
		case "KEY_LOVE":
			if(singalFlag) return;
			Utility.println("+++++++++++++++++++isAuthorized:" +　isAuthorized);
			if (!isAuthorized) {
				mp.player.setStopMode(0);
				mp.player.stop();
				if (isFromMosaic == "YES") {
					var params_2 = $G.getParams(window.location.href);
					var location;
					var tempService;
					if (params_2 && params_2.location != "") {
						location = params_2.location;
						tempService = new Service(location);
					}
					window.location.href = "http://hditv.jsamtv.com/epg/show.do?app=cpg&hd=y&content=favor&cardid=" + caSerialNum + "&clientid=" + stbSerialNum +  "&method=startover&channel=" + tempService.serviceId + ":" + tempService.frequency + ":" + modulations[tempService.modulation].substring(3) +  ":" + tempService.symbolRate + "&code=" + addrJSON.codeInfo;
				} else {
					window.location.href = "http://hditv.jsamtv.com/epg/show.do?app=cpg&hd=y&content=favor&cardid=" + caSerialNum + "&clientid=" + stbSerialNum +  "&method=startover&channel=" + currService.serviceId + ":" + currService.frequency + ":" + modulations[currService.modulation].substring(3) +  ":" + currService.symbolRate + "&code=" + addrJSON.codeInfo;
				}
			} else {
				if (channelNumObj.isInputStatus) {
					channelNumObj.hideChannelNumber();
					channelBar.hide();
					$("channelNumTopID").style.visibility = "hidden";
				}
			}
			break;
		case "KEY_TV_RADIO":
			stopAitManager();
			if (passwordBox.isVisible) {
				passwordBox.hide();
			}
			mp.player.setStopMode(0);
			mp.player.stop();
			window.location.href = "../radio/radio_play.htm";
			break;
		case "DVB_CHANNEL_LOCK":
			passwordBox.show();
			break;
		case "KEY_PAUSE":
			stopAitManager();
			Utility.ioctlWrite("NM_Key"," KeyName:"+ 3864);
			var areaCode = CITV.getParamInfo("areaCode");
			Utility.println("===========areaCode=" + areaCode);
			/*
			if (areaCode == "undefined" || areaCode == "" || areaCode == "0") {
				mp.player.setStopMode(1);
				mp.player.stop();
				CITV.processAreaCode();
				playVideo(tvList.currentService.getLocation());
			}*/
			window.location.href = "http://hdamsp.jsamtv.com/smarttv.do";
			break;
		case "KEY_DIANBO":
			stopAitManager();
			Utility.ioctlWrite("NM_Key"," KeyName:"+ 3883);
			mp.player.setStopMode(0);
			mp.player.stop();
			Utility.setEnv("nowFocus",2);
			Utility.setEnv("picNowFocus",10);
			Utility.setEnv("backFocus","NoPicFocus");
			window.location.href = "http://hditv.jsamtv.com/epg/show.do?app=vpg&hd=y&content=vodhome&" + helpTailAddr;
			break;
		case "KEY_OC":
			stopAitManager();
			mp.player.setStopMode(0);
			mp.player.stop();
			Utility.ioctlWrite("NM_Key"," KeyName:"+ 464);
			window.location.href = "http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-015&userCode="+userId;
			break;
		case "XLET_ACTIVE":
			setMisUiStatusEnv(6);// 通知如加系统进入播放页面
			allServiceList = null;
			allServiceList = [];
			allChannelsList = null;
			tvList = null;
			broadcastList = null;
			allChannelsList = ServiceDB.getServiceList();
			tvList = allChannelsList.filterService(ServiceDB.LIST_TYPE_SERVICE, "TV");
			broadcastList = allChannelsList.filterService(ServiceDB.LIST_TYPE_SERVICE,'DATA_BROADCAST');
			initServiceList();
			Utility.setEnv("Mis_AdvCallback", "stop_adv");
			mp.fullScreen();
			playVideo(tvList.currentService.getLocation());
			onDisplayMessageEvent(DVB.getShowEvents());
			break;
		case "DVB_SMARTCARD_INSERTED":
			//var tvNum_new = Utility.getEnv("MIS_TVCode") != "" ? Utility.getEnv("MIS_TVCode") : "00000000";
			//$("tvNum").innerHTML = $L.TV_NUM + tvNum_new;
			break;
		case "DVB_SMARTCARD_EVULSION":
			$("tvNum").innerHTML = $L.TV_NUM + "00000000";
			Utility.println("===========$L.TV_NUM=" + $("tvNum").innerHTML);
			break;
		case "KEY_VOD":
			stopAitManager();
			Utility.ioctlWrite("NM_Key"," KeyName:"+ 132);
			var areaCode = CITV.getParamInfo("areaCode");
			Utility.println("===========areaCode=" + areaCode);
			/*
			if (areaCode == "undefined" || areaCode == "" || areaCode == "0") {
				mp.player.setStopMode(1);
				mp.player.stop();
				CITV.processAreaCode();
				playVideo(tvList.currentService.getLocation());
			}*/
			window.location.href = "http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=10-003&userCode="+userId;
			break;
		case "KEY_TIMESHIFT":
			pauseAitManager();
			Utility.ioctlWrite("NM_Key"," KeyName:"+ 2731);
			mp.player.setStopMode(0);
			mp.player.stop();
			window.location.href = "http://hditv.jsamtv.com/epg/show.do?app=cpg&hd=y&content=channelback&cardid=" + caSerialNum + "&clientid=" + stbSerialNum +"&method=startover&channel="  + currService.serviceId + ":" + currService.frequency + ":" + modulations[currService.modulation].substring(3) +  ":" + currService.symbolRate + "&code=" + addrJSON.codeInfo;
			break;
		case "NM_UPGRADE":
			netmanager_upgrade();
			break;
			
		case "NM_RESET":
			netnamager_reset();
			break;
	}
}

function netnamager_reset(){
	SysSetting.restoreDefault();
	window.location.reload();
}

function netmanager_upgrade(){
	//读配置文件升级参数,并将参数传递给升级页面
	var sysDa = new DataAccess("ACSConfig.properties");
	var freq = sysDa.get("UpdateFreq")/1000; //跳转页面处理时会*1000,所以此处要转化
	var sym = sysDa.get("updateSymbol");
	var modType = sysDa.get("updateModulation");
	window.location.href = "../setting/softUpgrade.htm?frequency=" + freq + "&symbolRate=" + sym + "&modulation=" + modType;
}

function processAppListEvent(evt) {
	if (!appFlag) return;
	switch (evt.code) {
		case "KEY_UP":
			appListView.up();	
			break;
		case "KEY_DOWN":
			appListView.down();	
			break;
		case "KEY_ENTER":
			if (channelBar.isVisible) {
				channelBar.hide();
				$("channelNumTopID").style.visibility = "hidden";
			}
			if (volumeBar.isVisible) volumeBar.hide();
			hideAppList();
			Utility.println("========play.js===KEY_ENTER =startApp=======");
			AppManagerExt.startApp(apps[appListView.currIndex].appId, null);
			break;
		case "KEY_EXIT":
		case "KEY_BACK":
			hideAppList();
			break;
		case "Application_Note":
			showAppDownload();
			break;
	}
}
var delPos = 0;
function showDelConfirmDiv(temNum) {
	var currChoice = parseInt(temNum);
	if (currChoice == 1) {
		$("delTip").innerText = $L.DEL_TIP_0;
	} else if (currChoice == 2) {
		$("delTip").innerText = $L.DEL_TIP_1;
	}
	$("delDiv").style.visibility = "visible";
	$("delDiv_bt" + delPos).className = "currBtn";
}
function delEventHandler(evt) {
	switch (evt.code) {
		case "KEY_LEFT":
		case "KEY_RIGHT":
			delBtnLR();
			break;
		case "KEY_ENTER":
			delService();
			break;
		case "KEY_EXIT":
			delFlag = false;
			$("delDiv").style.visibility = "hidden";
			break;
	}
}
var delChoice = 0;
function delBtnLR() {
	$("delDiv_bt" + delPos).className = "";
	delPos = (delPos + 1) % 2;
	$("delDiv_bt" + delPos).className = "currBtn";
}

function delService() {
	if (delPos == 0) {
		if (delChoice == 1) {		//这个地方以后有时间可以修改为跟以前一样的，用一个数组来保存普通节目列表以及喜爱节目，在这个地方就可以节省许多代码
			var tempService = allServiceList[allChannelListView.currIndex];
			tempService.delFlag = true;
			allServiceList.splice(allChannelListView.currIndex, 1);
			//需要看看现网逻辑再做
			if (allServiceList.length == 0) {
				SysSetting.deleteAllService();
				ServiceDB.save();
				delFlag = false;
				$("delDiv").style.visibility = "hidden";
				window.location.reload();
				return;
			} else {
				if (allChannelListView.currIndex == currTvIndex) {
					OKList.hide();
					ServiceDB.save();
					delFlag = false;
					$("delDiv").style.visibility = "hidden";
					window.location.reload();
					return;
				} else if (allChannelListView.currIndex == allServiceList.length) {
					allChannelListView.setBlur();
					allChannelListView.currIndex -= 1;
				}
				allChannelListView.bindData(allServiceList, allChannelListView.currIndex, 0);
				allChannelListView.setFocus();
			}
		} else if (delChoice == 2) {
			allServiceList = [];
			SysSetting.deleteAllService();
			ServiceDB.save();
			delFlag = false;
			$("delDiv").style.visibility = "hidden";
			window.location.reload();
			return;
		}
	} else {
		delBtnLR();
	}
	ServiceDB.save();
	delFlag = false;
	$("delDiv").style.visibility = "hidden";
}

/*
	对南京市网部分互动机顶盒（互动机顶盒的软件架构均为中间件架构）发放定向泡泡，此类泡泡单向机顶盒无法收到。
	互动机顶盒收到此类泡泡，泡泡类型为网页浏览，访问定向的URL页面，页面可以为点播页面，互联网页面等
*/
function misLinkUrl() {
	var misUrl = DVB.getEvent(45781, event.userInt);	
	Utility.println("recv js message 45781:" + misUrl);
	var misObj = eval('('+misUrl+')');
	Utility.println("misObj:" + misObj);
	mp.player.setStopMode(0);
	mp.player.stop();
	
	if (misObj.url_type == 'HD') {	// 高清直接跳转
		stopAitManager();
		window.location.href = misObj.url;
	}
	else {		// 到点播、数据广播等页面，需切换分辨率
		Utility.setEnv("ocUrl", misObj.url);
		stopAitManager();
		window.location.href = "oc_play.htm";
	}
	
	return true;
}

/*
	如加换台，此时如加监控系统会通过45780消息把带切换频道的
	network_id,ts_id,service_id发过来。
*/
function misSwitchProgram() {
	var messageId = event.userInt;
	var evtstr = DVB.getEvent(45780, messageId);		// evtstr:"network_id:ts_id:service_id"
	var arr = new Array();
	arr = evtstr.split(":");
	if (arr.length == 3) {
		
		// 切换到当前节目
		if (currChannelList.currentService) {
			var service = currChannelList.currentService;
			if (arr[0]==service.onId && arr[1]==service.tsId && arr[2]==service.serviceId) {
				mp.fullScreen();
				mp.player.stop();
				changeChannel(0);
				return true;
			}
		}
		
		// 在oklist中搜索节目所要切换节目
		var okListLength = currChannelList.length;
		for (i=0; i<okListLength; i++) {
			var service = currChannelList.getAt(i);
			if (service) {
				if (arr[0]==service.onId && arr[1]==service.tsId && arr[2]==service.serviceId) {
					// 切换至相应节目
					mp.player.setStopMode(0);
					mp.player.stop();
					var channelNum = currChannelList.getAt(i).logicNumber;
					setChannel(channelNum);
					return true;
				}
			}
		}
	}
	
	return false;
}

function passwordEventHandler(evt) {
	var flag = true;
	switch (evt.code) {
		case "KEY_NUMERIC":
			passwordBox.input(evt.param);
			break;
		case "KEY_EXIT":
			passwordBox.show();
			break;
		default:
			flag = false;
			break;
	}
	return flag;
}
var showTipsType = 0, isAuthorized = true;
function onDisplayMessageEvent(events) {
	var info = "";
	Utility.println("onDisplayMessageEvent evt length = "+events.length);
	if (events.length > 0) {
		var maxId = 0;//events.length-1;
		Utility.println("evt type = "+events[maxId].type+" sub type = "+events[maxId].msgSubType);
		switch (events[maxId].type) {
			case 40021:
				// 加锁节目比较特殊：需通过设置环境变量Mis_AdvCallback来隐藏字幕广告。
				Utility.setEnv("Mis_AdvCallback", "hide_caption_adv");
				passwordBox.show();
				break;
			case 40023:
				showTipsType = 0;
				if (tvList.length == 0) {
					info = $GL.NO_SERVICE;
				} else {
					info = $GL.NO_SIGNAL;
				}
				showTips(info);
				break;
			case 40081:
				var tipsArr = ['',$L.CA_1, $L.CA_2, $L.CA_3, $L.CA_4, $L.CA_5, $L.CA_6, $L.CA_7, $L.CA_8, $L.CA_9, $L.CA_10, $L.CA_11, $L.CA_12, $L.CA_13, $L.CA_14, $L.CA_15, $L.CA_16, $L.CA_17, $L.CA_18, $L.CA_19, $L.CA_20, $L.CA_21,$L.CA_22];
				var type = Number(events[maxId].msgSubType);
				if (type >= 1 && type <= 22) {
					// 如加广告需要获取当前节目解扰状态，当前为解扰失败状态，设置为failed
					Utility.setEnv("Mis_CaStatus", "failed");	
					Utility.setEnv("NM_CaStatus", "failed");				
				}

				if(type == 1 || type == 2 || type == 10)
				{
					Utility.ioctlWrite("NM_Error","nAction:"+1+",code:"+40081+",subcode:"+type);
				}

				showTipsType = 0;
				if (type < 23) {
					info = tipsArr[type];
					if(type == 9) {	
						$("channelDes").style.visibility = "visible";
						var displayStr = Utility.ioctlRead("channelDescription");
						Utility.setEnv("NM_CaStatus", "failed");
						isAuthorized = false;
						Utility.println("--------------set authorized false");
						$G.sysDa.set("Mediaplayer.isAuthorized", 0);
						if (channelBar.isVisible) {
							$("pro_fav").style.visibility = "visible";
						}
						showTipsType = 1;
					} else {
						showTipsType = 0;
						showTips(info);
					}
				} else if (type == 23) {//在屏幕上消除alarm消息-23
					hiddenTips();	
				}
				break;
			case 40083:
				var tipsArr = ['',$L.CA_MSG_0,'','',$L.CA_MSG_1];
				var type = Number(events[maxId].msgSubType);
				if (type == 1 || type == 4) {
					// 如加广告需要获取当前节目解扰状态，当前为解扰失败状态，设置为failed
					Utility.setEnv("Mis_CaStatus", "failed");
				}

				if(type == 1){
					showTipsType = 0;
					var info = $L.NO_CARD;
					showTips(info);
				}else{
					showTipsType = 0;
					info = tipsArr[type];
					showTips(info);
					$("channelDes").style.visibility = "hidden";
					$("unAthorizedInfo").innerHTML =  "";
				}
				break;
		}
	}
}
function thirdSecret() {
	$("alert_title").innerText = $GL.TIPS;
	$("alert_text").innerText = "第三方加密节目";
	$('alert').style.visibility = "visible";
}
function hideThird() {
	$("alert_title").innerText = "";
	$("alert_text").innerText = "";
	$('alert').style.visibility = "hidden";
}
function showTips(_tips){
	if(showTipsType==0){
		if($("channelDes").style.visibility == "visible"){
			$("channelDes").style.visibility = "hidden";
			$("unAthorizedInfo").innerHTML =  "";
		}
		$("alert_title").innerText = $GL.TIPS;
		$('alert_text').innerText = _tips;
		$('alert').style.visibility = "visible";
		
	}else{
		if($("alert").style.visibility == "visible"){
			$("alert").style.visibility = "hidden";
		}
		$("channelDes").style.visibility = "visible";
	}
	if(!showTipsFlag){
		showTipsFlag=true;
	}
}

function hiddenTips() {
	// 如加广告需要获取当前节目解扰状态，隐藏ca提示框时设置为解扰成功
	Utility.setEnv("Mis_CaStatus", "success");
	Utility.setEnv("NM_CaStatus", "success");
	
	$('alert').style.visibility = "hidden";
	showTipsFlag = false;
	$("channelDes").style.visibility = "hidden";
	$("unAthorizedInfo").innerHTML =  "";
	isAuthorized = true;
	Utility.println("---------hide tips-----set authorized true");
	//$G.sysDa.set("Mediaplayer.isAuthorized", 1);
	var events = DVB.getShowEvents();
	if (events.length > 0) {
		onDisplayMessageEvent(events);
	}
}

function checkVoipLogin() {
	
}
function init(){
	Utility.setEnv("NM_CaStatus", "success");
	$G.sysDa.set("Mediaplayer.isAuthorized", 1);
	Utility.clearBrowserCache();
	setMisUiStatusEnv(6);		// 通知如加系统进入播放页面
	// 销毁oc轮播，防止oc占用内存不释放
	Utility.destroyOC();
	Utility.ioctlWrite("enterOC", "0");
	mp.fullScreen();
	Utility.ioctlWrite("motoStopGroup", "");	//停止moto的搜索groupID
	Utility.ioctlWrite("motoKey2Dvb", "");		//将键值转化为中间件标准键值

	initText();
	audioChannelOptions = [{displayValue: $GL.TRACK_LEFT, sysValue: 'Left'},{displayValue: $GL.TRACK_RIGHT, sysValue: 'Right'},{displayValue: $GL.TRACK_STEREO, sysValue: 'Stereo'}];
	if (tvList.length == 0) {
		goSearch = true;
		showConfirmDiv("节目为空，请按‘确认’键重新搜索！", true);
		channelBar.hide();
		$("channelNumTopID").style.visibility = "hidden";
		return;
	}
	channelBarTimer = $G.sysDa.get("Pf.timeout") != "" ? parseInt($G.sysDa.get("Pf.timeout"))*1000 : 5000;
	channelBar = new Con($("channel_bar"), false, channelBarTimer, "channelBar");
	volumeBar = new Con($("volume_bar"), false, 5000, "volumeBar");
	OKList = new Con($("ok_list"), false, -1, "OKList");
	descBox = new Con($("desc_box"), false, -1, "descBox");
	audioChannelText = new LRButton("audio_channel_text", function(){}, function(){}, showAudioChannel, function(){});
	audioChannelText.bindData(audioChannelOptions);
	
	initServiceList();
//	initSound();
	currChannelList = tvList;
	$G.sysDa.set("Mediaplayer.groupIndex", 0);
	if(isFromMosaic == "YES"){
		var params_2 = $G.getParams(window.location.href);
		if (params_2 && params_2.location != "") {
			var location = params_2.location;
			var tempService = new Service(location);
			var channelName = tempService.name;
			var programName = tempService.presentProgram.name;
			//此处加你的回调动作
			Utility.ioctlWrite("NM_Mosaic", "nAction:"+2+",MosaicName:"+channelName);	
			Utility.ioctlWrite("NM_Mosaic", "nAction:"+3+",MosaicName:"+programName);
			initSound();
			playVideo(params_2.location);
		} 
	}else if(isFromMosaic == "thirdparty"){
		var params_2 = $G.getParams(window.location.href);
		if (params_2 && params_2.location != "") {
			isFromMosaic = "";
			Utility.setEnv("fromLink", "");
			var location = params_2.location;
			var tempService = new Service(location);
			if (tempService.name) {
				var channelName = tempService.name;
				var programName = tempService.presentProgram.name;
				currChannelList.moveTo(currChannelList.findIndex(tempService));
				//此处加你的回调动作
				Utility.ioctlWrite("NM_Mosaic", "nAction:"+2+",MosaicName:"+channelName);	
				Utility.ioctlWrite("NM_Mosaic", "nAction:"+3+",MosaicName:"+programName);
				currService = currChannelList.currentService;
				location = currService.getLocation();
			}
			initSound();
			playVideo(location);
			if (tempService.name) {
				showChannelBar();
				isTimeShiftPro(currService);
			}
		}
	}else {
		currService = currChannelList.currentService;
		initSound();
		playVideo(currService.getLocation());
		showChannelBar();
		isTimeShiftPro(currService);
	}
	showDateTime();
	onDisplayMessageEvent(DVB.getShowEvents());
	$("channel_bar_ad").src = "misads://typeIndex=21";
	
	appListView = new List(5, showApplication, onFocusMove, onFocus, onBlur);
	passwordBox = new PasswordBox("password_box", "password_", onPassSuccess, onPassFailed);
	
	var door = Utility.getEnv("mmcp_open_test_door");
	if (door == "true") {
		checkVoipLogin();
		return;
	}
	if (Utility.getEnv("isNeedUpdate") == "1" && recoverUpdateFlag != "stopUpdate") {
		$G.sysDa.set("NIT_update", 0);
		$G.sysDa.submit();
		Utility.setEnv("isNeedUpdate", "0");
		mp.player.setStopMode(1);
		mp.player.stop();
		window.location.href = "../setting/auto_search.htm?searchType=2";
		return;
	}
	checkVoipLogin();
}
var shiftProStatus = false;
function isTimeShiftPro(service) {
	var tempService = service;
	var tsID = tempService.tsId;
	var serviceID = tempService.serviceId;
	var returnValue = CITV.isSupportPlayBack(tsID, serviceID);
	if (returnValue) {
		Utility.println("============这是一个时移节目==============");
		$("timeShift").style.visibility = "visible";
		shiftProStatus = true;
		if (channelBar.isVisible) {
			$("pro_back").style.visibility = "visible";
			$("timeShift").style.visibility = "visible";
		}
	} else {
		if ($("timeShift").style.visibility == "visible") {
			$("timeShift").style.visibility = "hidden";
		}
		$("timeShift").style.visibility = "hidden";
		shiftProStatus = false;
	}
}
function initText(){
	var textArr = {OKList_title:$L.OKLIST_TITLE, confirmTitle:$GL.TIPS,confirmBtn_ok:$GL.OK,soundTitle:$L.SOUND,
					  p_7:$GL.TIPS, box_infor:$GL.INPUT_LOCAL_PSW,tip_4:$L.TIP_4,tip_5:$L.TIP_5,
					  tip_0:$GL.TIP_0,tip_1:$GL.TIP_1,tip_2:$GL.TIP_2,tip_3:$GL.TIP_3,delDiv_title:$GL.TIPS,
					  desTitle:$GL.TIPS,des_0:$L.DES, delDiv_bt0:$GL.OK, delDiv_bt1:$GL.CANCEL,
					  infoTips:$L.BACK_TIPS,
					  srhConfirmTitle:$GL.TIPS,srhConfirmBtn_0:$GL.OK,srhConfirmBtn_1:$GL.CANCEL};
	for(var id in textArr){
		$(id).innerText = textArr[id];
	}
}

function initSound(){
	var volume;
	if (volumeMode == 0) {
		volume = currService ? currService.volume : mp.player.getVolume();
	} else {
		volume = $G.sysDa.get("UniformVolume") != "" ? parseInt($G.sysDa.get("UniformVolume")) : 16;
	}
	mp.player.setVolume(volume);
	$("volume_value").innerText = volume;
	$("volume_progress").style.width = 375 / 31 * volume + "px";
	if (mp.player.getMuteFlag() == 1) {
		$('mutePic').style.visibility = "visible";
		$("muteTxt").innerText = $L.MUTE_TXT;
	}
}

function onPassSuccess() {
	mp.player.unlockPlay();
	$("error_text").innerText = "";
}

function onPassFailed() {
	$("error_text").innerText = $GL.PSW_INVALID;
}

function showDateTime(){
	$("currTime").innerText = $G.dateFormat(new Date(), "hh:mm");
	var timer = new Timer("dateTime");
	timerManager.add(timer);
	timer.exec(showDateTime, 60000);
}
//根据现网逻辑，为了马赛克页面的进入修改成按照location来播放节目
function playVideo(location){
	// 换台时，需停止如加广告。但若是同台切换或由如加切台时，则无需停止广告。
	if (!location) {
		location = tvList.currentService.getLocation();
	}
	if (location != mp.player.getServiceLocation(0)) {
		if (misCanStopAdv) {
			Utility.setEnv("Mis_AdvCallback", "stop_adv");
		}
	} else {
		// 确保在由主页面返回到play页面时启动广告
		if (!misStartStatus) {
			Utility.setEnv("Mis_AdvCallback", "start_adv");
		}
	}
	misCanStopAdv = true;
	misStartStatus = true;
	
	AitManager.startAitManager(location);
	mp.player.setSingleMedia(location);
	mp.player.playFromStart();
	if (volumeMode == 0) {
		beginVolume = currService.volume;
	} else {
		beginVolume = mp.player.getVolume();	
	}
	mp.player.setVolume(beginVolume);
	
	var audioTrack ;
	if (audioTrackMode == 1) {
		audioTrack = $G.sysDa.get("AudioTrack") != "" ?$G.sysDa.get("AudioTrack") : "Left";
	}
	else {
		audioTrack = currService.audioTrack;
	}
	mp.player.setCurrentAudioChannel(audioTrack);
	
	if (isFromMosaic != "YES") {
		var panelIndex = currService.logicNumber;
		$G.sysDa.set("Mediaplayer.serviceIndex", panelIndex);
		$G.setFrontPanelDisplay(panelIndex, 0);
		currTvIndex = currChannelList.findIndex(currChannelList.currentService);
	} else {
		$G.setFrontPanelDisplay(800, 0);
	}
	Utility.println("----------getStopMode4 = "+mp.player.getStopMode());
}

function stopAitManager() {
	AitManager.stopAitManager();
}

function Con(obj, isVisible, delayTime, name){
	var self = this;
	self.isVisible = isVisible;
	self.obj = obj;
	self.name = name;
	self.delayTime = delayTime;
	var timer = new Timer(name);
	timerManager.add(timer);
	
	self.show = function(){
		self.obj.style.visibility = "visible";
		self.isVisible = true;
		if (self.delayTime != -1) {
			var timer = timerManager.get(self.name);
			timer.exec(self.hide, self.delayTime);
		}
		if (self.name == "OKList") {
			allChannelListView.bindData(allServiceList, currTvIndex, 0);
			allChannelListView.setFocus();
			changeOKListAD();			
		}
		if (self.name == "channelBar") {
			//显示ChannelBar时，隐藏应用提示
			hideAppDownLoadIcon(); 
			$("tvNumDiv").style.visibility = "visible";
			if (shiftProStatus) {
				$("pro_back").style.visibility = "visible";
				$("timeShift").style.visibility = "visible";
			} else if (!isAuthorized) {
				$("pro_fav").style.visibility = "visible";
			}
			$("channelNumTopID").style.visibility = "visible";
			//$("timeShift").style.visibility = "hidden";
			initChannelContent();
		}
		if (self.name == "volumeBar") {
			$("volume_bar_ad").src = "misads://typeIndex=22";	// 获取广告图片
				Utility.ioctlWrite("NM_VolChange", "nAction:"+1+",volume:"+beginVolume);
		}
	};
	
	self.hide = function(){
		self.obj.style.visibility = "hidden";
		self.isVisible = false;
		self.clearTimer();
		if(self.name == "OKList") {
		Utility.println("================================OKList.hide==========================");
			$("ok_list_ad_div").style.visibility = "hidden";
			allChannelListView.setBlur();
			Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 01);
		}
		if (self.name == "channelBar") {
			$("tvNumDiv").style.visibility = "hidden";
			$("audio_channel_text").innerText = "";
			$("pro_lock").style.visibility = "hidden";
			$("timeShift").style.visibility = "hidden";
			if ($("pro_fav").style.visibility == "visible") {
				$("pro_fav").style.visibility = "hidden";
			} else if ($("pro_back").style.visibility == "visible") {
				$("pro_back").style.visibility = "hidden";
				$("timeShift").style.visibility = "hidden";
			}
			if (audioFlag) {
				audioFlag = false;
			}
			$("channelNumTopID").style.visibility = "hidden";
			//应用的提示图标在channelBar消失后再显示
			apps = AppsCollection.getApplications("TransportType=OC-ServiceBound");
			if (apps.length > 0) {
				showAppDownLoadIcon();
			} 
			 if (audioTrackMode == 1) {
		 		$G.debug("====在图标消失的时候保存的声道值为========", audioChannelText.getValue());
				$G.sysDa.set("AudioTrack",audioChannelText.getValue());
				$G.sysDa.submit();
		 	}
		}
		if (self.name == "volumeBar") {
			$("volumeBarDiv").style.visibility = "hidden";
			ServiceDB.save();
			if(!setMuteAction){
				Utility.ioctlWrite("NM_VolChange", "nAction:"+0+",volume:"+endVolume);
			}
			beginVolume = endVolume;
		}
	};
	/**
	 * 重设Timer
	 * @param {Number} _delayTime 不传时，则按默认。否则按此新值执行隐藏
	 */
	self.resetTimer = function(_delayTime){
		if (self.delayTime != -1) {
			var timer = timerManager.get(self.name);
			var delay = self.delayTime;
			if(typeof(_delayTime)!="undefined"){
				delay = _delayTime;
			}
			timer.exec(self.hide, delay);
		}
	};
	
	self.clearTimer = function(){
		var timer = timerManager.get(self.name);
		timer.clear();
	}
}
var searchBtPos = 0, goSearch = false, sec=6, secTimer=-1;
function showConfirmDiv(_tips, first) {
	$('srhConfirmDiv').style.visibility = "visible";
	$('srhConfirmTxt').innerText = _tips;
	if (first) {
		countDown();
	} else {
		$("srhConfirmBtn_0").innerText = "确定";
	}
}
function countDown() {
	if(sec > 0){
		sec--;
		$("srhConfirmBtn_0").innerText = "确定(" + sec + ")";
		secTimer = setTimeout(countDown, 1000);
	} else {
		secTimer=-1;
		window.location.href = "../setting/auto_search.htm?searchType=2";
	}
	
}

function srhConfirmHandler(evt) {
	switch (evt.code) {
		case "KEY_LEFT":
		case "KEY_RIGHT":
			$('srhConfirmBtn_'+searchBtPos).style.background = "url(../images/bt_02.png) no-repeat";
			searchBtPos = (searchBtPos+1)%2;
			$('srhConfirmBtn_'+searchBtPos).style.background = "url(../images/bt_01.png) no-repeat";
			break;
		case "KEY_ENTER":
			if (goSearch && searchBtPos == 0) {
				stopAitManager();
				mp.player.setStopMode(0);
				mp.player.stop();
				window.location.href = "../setting/auto_search.htm?searchType=2";
			} else {
				clearTimeout(secTimer);
				$('srhConfirmBtn_'+searchBtPos).style.background = "url(../images/bt_02.png) no-repeat";
				searchBtPos = 0;
				$('srhConfirmBtn_'+searchBtPos).style.background = "url(../images/bt_01.png) no-repeat";
				goSearch = false;
				$('srhConfirmDiv').style.visibility = "hidden";
				$('srhConfirmTxt').innerText = "";
			}
			break;
	}
}

function initChannelContent() {
	clearTimeout(pfTimer);
	var service = currService;
	if (service) {
		var serviceIndex = service.logicNumber;
		var chNum = $G.leftPadStr(serviceIndex, "0", 3);
		$("channel_num").innerText = chNum;
		$("channelNumTopID").innerText = chNum;
		$("channel_name").innerText = service.name.sub(20);
	}
	Utility.ioctlWrite("NM_Epg", "nAction:"+1);
	
	var tvCode = CITV.getParamInfo("TVCode");
	Utility.println("-------initChannelContent--------TVCode = " + tvCode);
	var sdpTvNum = tvCode != "" ? tvCode : "00000000";
	$("tvNum").innerHTML = $L.TV_NUM + sdpTvNum;
	
	if (service) {
		var p = service.presentProgram;
		var f = service.followingProgram;

		if (p) {
			$("p_Time").innerText = $G.dateFormat(p.startTime, "hh:mm");
			$("p_Name").innerText = p.name.sub(40);
		}
		if (f) {
			$("f_Time").innerText = $G.dateFormat(f.startTime, "hh:mm");
			$("f_Name").innerText = f.name.sub(40);
		}
	}
	pfTimer = setTimeout("initPF()", 800);
}

function initPF(){
	if (channelNumObj.isInputStatus) return;
	var service = currService;
	var now = new Date();
	if (service) {
		var p = service.presentProgram;
		var f = service.followingProgram;

		if (p) {
			$("p_Time").innerText = $G.dateFormat(p.startTime, "hh:mm");
			$("p_Name").innerText = p.name.sub(40);
		} else {
			$("p_Time").innerText = "";
			$("p_Name").innerText = "";
		}
		if (f) {
			$("f_Time").innerText = $G.dateFormat(f.startTime, "hh:mm");
			$("f_Name").innerText = f.name.sub(40);
		} else {
			$("f_Time").innerText = "";
			$("f_Name").innerText = "";
		}
		var _width = (timeDiff(now, p.startTime) / timeDiff(p.endTime, p.startTime)) * 90;
		if (_width > 90)
			_width = 90;
		$("play_progress_start").style.width = _width + "px";
		if (service.lock) {
			$("pro_lock").style.visibility = "visible";
		} else {
			passwordBox.hide();
			$("pro_lock").style.visibility = "hidden";
		}
	}	
}
function clearPF() {
	$("p_Time").innerText = "";
	$("p_Name").innerText = "";
	$("f_Time").innerText = "";
	$("f_Name").innerText = "";
	$("play_progress_start").style.width = "0px";
	$("pro_lock").style.visibility = "hidden";
	$("pro_fav").style.visibility = "hidden";
	$("pro_back").style.visibility = "hidden";
}
/*
 * 将Date对象转换为妙
 */
function dateToSecond(date) {
	return date.getHours()*3600 + date.getMinutes()*60 + date.getSeconds();
}
/*
 * 计算Date对象的时间差,返回值为秒
 */
function timeDiff(nowTime, endTime) {
	return (dateToSecond(endTime) - dateToSecond(nowTime));
}

function setChannel(channelNum) {
	passwordBox.currPos = 0;
	for (var i = 0; i < 4; i++) {
		$("password_" + i).style.color = "#FFF";		
	}
	if (channelNum == 000) {
		Utility.ioctlWrite("NM_Help", "nAction:"+1);
		mp.player.setStopMode(0);
		mp.player.stop();
		location.href = "http://hdzchannel.jsamtv.com/epg/show.do?app=zchannel&hd=y&content=home&detail=10000&cardid=" + caSerialNum + "&clientid=" + stbSerialNum +"&method=&channel=" + addrJSON.channelInfo + "&code=" + addrJSON.codeInfo;
		return;
	}
	if (isFromMosaic == "YES") {
		isFromMosaic = "";
		Utility.setEnv("fromLink", "");
	}
	
	if (channelNum > 900 && channelNum < 1000) {
		var shortLen = shortData.length;
		var isExist = false;
		for (var i=0; i<shortLen; i++) {
				if (channelNum == shortData[i].logicNumber) {
					isExist = true;
					mp.player.setStopMode(0);
					mp.player.stop();
					window.location.href = shortData[i].url + userId;
				}
			}
		if(!isExist) $("channel_name").innerText = "没有这个节目";
	} else if (channelNum > 800 && channelNum < 900) {
			var ocListLen = broadcastList.length;
			var isExist = false;
			for (var i=0; i<ocListLen; i++) {
				if (channelNum == broadcastList.getAt(i).logicNumber) {
					isExist = true;
					var service = broadcastList.getAt(i);
					var ocUrl = service.getLocation();
					Utility.setEnv("ocUrl", ocUrl);
					stopAitManager();
					mp.player.setStopMode(0);
					mp.player.stop();
					window.location.href = "oc_play.htm";
					return;
				}
			}
			if(!isExist) $("channel_name").innerText = "没有这个节目";
	} else {
		var goSwitch = false;
		var len = currChannelList.length;
		for (var i=0; i<len; i++) {
			if (currChannelList.getAt(i).logicNumber == channelNum) {
				currService = currChannelList.getAt(i);
				currChannelList.moveTo(i);
				goSwitch = true;
				break;
			}
		}
		if (!goSwitch) {
			$("channel_name").innerText = "没有这个节目";
		} else {
			if (currService.getLocation() != mp.player.getServiceLocation(0)) {
				hiddenDiv();
			}
			$("channel_name").innerText = currService.name;
			playVideo(currService.getLocation());
			currTvIndex = currChannelList.findIndex(currChannelList.currentService);
			clearPF();
			initChannelContent();
			showChannelBar();
			isTimeShiftPro(currService);
			Utility.ioctlWrite("NM_ServChange", "nAction:" + 1);
		}
	}
}

function hiddenDiv() {
	if (volumeBar.isVisible) volumeBar.hide();
	if($("alert").style.visibility == "visible"){
		//$("alert").style.visibility = "hidden";
		//showTipsFlag = false;
	}
	if (!isAuthorized) {
		$G.sysDa.set("Mediaplayer.isAuthorized", 1);
		isAuthorized = true;
		Utility.setEnv("NM_CaStatus", "success");
	}
	//$("channelDes").style.visibility = "hidden";	//根据广电要求，当按下ok键，oklist消失时，需要重现显示简介消息
}
var playVideoTimer;
function changeChannel(offset){
	passwordBox.currPos = 0;
	$("password_" + passwordBox.currPos).style.color = "#FFF";
	for (var i = 1; i < 4; i++) {
		$("password_" + i).style.color = "#FFF";		
	}
	//clearTimeout(playVideoTimer);
	clearTimeout(pfTimer);
	inputPwdFlag = false;
	hiddenDiv();
	//currTvIndex = currChannelList.findIndex(currChannelList.currentService);
	currTvIndex += offset;
	if (currTvIndex > currChannelList.length - 1) 
		currTvIndex = 0;
	else if (currTvIndex < 0) {
		currTvIndex = currChannelList.length - 1;
	}
	currChannelList.moveTo(currTvIndex);
	currService = currChannelList.getAt(currTvIndex);
	playVideoTimer = setTimeout("playVideo()", 100);
	//playVideo();
	clearPF();
	initChannelContent();
	showChannelBar();
	isTimeShiftPro(currService);
	//Utility.ioctlWrite("NM_ServChange", "nAction:" + 1);
}

function showChannelBar() {
	if (volumeBar.isVisible) volumeBar.hide();
	if (!channelBar.isVisible) {
		channelBar.show();
		$("channelNumTopID").style.visibility = "visible";
	} else {
		channelBar.resetTimer(channelBarTimer);
	}
}

function openLastChannel() {
	var lastLocation = mp.player.getServiceLocation(2);
	if(typeof(lastLocation)=='undefined' || lastLocation=="") return;
	var service = new Service(lastLocation);
	setChannel(service.logicNumber);
}

var beginVolume, endVolume;
function changeVolume(offset) {
	var volume;
	if (volumeMode == 0) {
		volume = currService ? currService.volume : mp.player.getVolume();
	} else {
		volume = mp.player.getVolume();
	}
	volume += offset;
	if (volume < 0) volume = 0;
	if (volume > 31) volume = 31;
	if (volumeMode == 0) {
		currService.volume = volume;
	} else {
		$G.sysDa.set("UniformVolume", volume);
	}
	mp.player.setVolume(volume);
	setMuteAction = false;
	endVolume = volume; // add volume end
	$("volume_value").innerText = volume;
	$("volume_progress").style.width = 375 / 31 * volume + "px";
	volumeBar.show();
	if (channelBar.isVisible) {
		channelBar.hide();
		$("channelNumTopID").style.visibility = "hidden";
	}
	if (mp.player.getMuteFlag() == 1) {
		setMuteFlag(0);
	}
}

var setMuteAction = false;
function setMute() {
	setMuteAction = true;
	var muteFlag = mp.player.getMuteFlag();
	muteFlag = muteFlag == 0 ? 1 : 0;
	setMuteFlag(muteFlag);
}

function setMuteFlag(flag) {
	mp.player.setMuteFlag(flag);
	if (flag == 0) {//有声
		setMuteAction = false;
		var volume;
		if (volumeMode == 0) {
			volume = currService ? currService.volume : mp.player.getVolume();
		} else {
			volume = mp.player.getVolume();
		}
		Utility.println("-------------setMuteFlag------------volume:"+volume);
		beginVolume = volume;
		endVolume = volume;
		$('mutePic').style.visibility = "hidden";
		volumeBar.show();
	} else {
		volumeBar.hide();
		$('mutePic').style.visibility = "visible";
		$("muteTxt").innerText = $L.MUTE_TXT;
	}
}

var audioFlag = false;

function changeAudioChannel() {
	if (!channelBar.isVisible) {
		showChannelBar();
	}
	var currAudioChannel = mp.player.getCurrentAudioChannel();
	if (!audioFlag) {
		audioChannelText.setValue(currAudioChannel);
		audioFlag = true;
	} else {
		audioChannelText.right();
		if (audioTrackMode == 0) {
			currService.audioTrack = audioChannelText.getValue();
		}
		mp.player.setCurrentAudioChannel(audioChannelText.getValue());
	}
}

function showAudioChannel(id, value) {
	$(id).innerText = value;
}

function PasswordBox(boxId, cellId, onSuccess, onFailed) {
	this.boxId = boxId;
	this.cellId = cellId;
	this.isVisible = false;
	this.onSuccess = onSuccess;
	this.onFailed = onFailed;
	this.passStr;
	this.currPos;
	
	this.checkPass = function () {
		var sysPass = $G.sysDa.get("localpwd");
		if (this.passStr == sysPass) {
			this.onSuccess();
			this.hide();
		} else {
			this.onFailed();
			$(this.cellId + this.currPos).style.color = "#111";
			this.reset();
		}
	}
	
	this.reset = function () {
		$(this.cellId + this.currPos).style.color = "#111";
		for (var i = 0; i < 4; i++) {
			$(this.cellId + i).innerText = "*";
			$(this.cellId + i).style.color = "#FFF";		
		}
		//this.cellBlur();
		this.currPos = 0;
		this.passStr = "";
		//this.cellFocus();
	}
	
	this.cellFocus = function () {
		$(this.cellId + this.currPos).style.color = "#111";
	}
	
	this.cellBlur = function () {
		$(this.cellId + this.currPos).style.backgroundImage = "";
		$(this.cellId + this.currPos).style.color = "#111";		
	}
	
	this.focusLeft = function () {
		if (this.currPos == 0) return;
		this.cellBlur();
		this.currPos--;
		this.cellFocus();
	}
	
	this.focusRight = function () {
		if (this.currPos == 3) return;
		this.cellBlur();
		this.currPos++;
		//this.cellFocus();	
	}
	
	this.show = function () {
		$(passwordBox.cellId + passwordBox.currPos).style.color = "#FFF";
		this.currPos = 0;
		this.isVisible = true;
		this.passStr = "";
		$(this.boxId).style.visibility = "visible";
		$("error_text").innerText = "输入本机密码收看节目！";
	};
	
	this.hide = function () {
		this.isVisible = false;
		$(this.boxId).style.visibility = "hidden";
		this.reset();
	};
	
	this.input = function (num) {
		this.passStr += num;
		$(this.cellId + this.currPos).innerText = "*";
		if (this.passStr.length == 4) {
			this.checkPass();
		} else {
			this.focusRight();
		}
	};
	
}
var descFlag_0 = false, descFlag_1 = false;
function showInfo() {
	if (!channelBar.isVisible && !descFlag_0 && !descFlag_1) {
		showChannelBar();
	} else if (!descFlag_0 && !descFlag_1) {
		channelBar.hide();
		$("channelNumTopID").style.visibility = "hidden";
		showDesc(0);
		Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 02);
	} else if (!descFlag_1 && descFlag_0) {
		Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 02);
		showDesc(1);
		Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 03);
	} else if (descFlag_1) {
		hideDesc();
	} 
}
var addrJSON = {
	channelInfo : "",
	codeInfo : ""
}
function urlParse() {
	var channel, code;
	var service = currService;
	var serviceID = service.serviceId;
	var freq = service.frequency;
	var modulation = service.modulation;
	var symbol = service.symbolRate;
	
	channel = serviceID + "." + freq + "." + modulation + "." + symbol;
	addrJSON.channelInfo = channel;
	
	var ethenets = Network.ethenets[0];
	var ipAddr = ethenets.IPs[0];
	var currIp = ipAddr.IPAddres;
	
	if (isAuthorized) {
		code = "Y-coship-coship-" + currIp + "-etc";
	} else {
		code = "N-coship-coship-" + currIp + "-etc";
	}	
	addrJSON.codeInfo = code;
}

function showDesc(num) {
	var proIndex = num;
	$("proInfo").style.visibility = "visible";	
	var descText = "";
	var service = currService;
	if (service) {
		var program_0 = service.presentProgram;
		var program_1 = service.followingProgram;
		var description = "";
		if (proIndex == 0) {
			descFlag_0 = true;
			$("serviceTit").innerText = program_0.name;
			description = program_0.description;
			$("infoTitle").innerText = $L.INFO_CURR;
		} else if (proIndex == 1) {
			descFlag_0 = false;
			descFlag_1 = true;
			description = program_1.description;
			$("serviceTit").innerText = program_1.name;
			$("infoTitle").innerText = $L.INFO_NEXT;
		}
		descText = description.length >= 4 ? description : $L.NO_PRO_INFO;
	} else {
		descText = $L.NO_PRO_INFO;
	}
	$("serviceInfo").innerText = descText;
	channelBar.hide();
	$("channelNumTopID").style.visibility = "hidden";
}

function hideDesc() {
	if (descFlag_0) {
		descFlag_0 = false;
		Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 02);
	} else if (descFlag_1) {
		descFlag_1 = false;
		Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 03);
	}
	$("proInfo").style.visibility = "hidden";	
}


function misChangeEpgAd() {
	var service = allServiceList[allChannelListView.currIndex];
	var networkID = service.onId;
	var tsID = service.tsId;
	var serviceID = service.serviceId;
	$("ok_list_ad").src = "misads://typeIndex=23:"+networkID+":"+tsID+":"+serviceID;
}

/*
	oklist连续按键优化。两次按键之间小于一定时间间隔时
	不重新获取广告图片。
*/
var misEpgAdvTimer;
function changeOKListAD() {
	clearTimeout(misEpgAdvTimer);
	misEpgAdvTimer = setTimeout(misChangeEpgAd, 500);
}

function exitPage(){
	stopAitManager();
	Utility.ioctlWrite("NM_ServOut","nAction:"+0);
	if (OKList.isVisible) {
		OKList.hide();
	} else if (channelBar.isVisible) {
		channelBar.hide();
	} else if ($('mutePic').style.visibility == "visible") {
		$('mutePic').style.visibility = "hidden";
	}
	timerManager.clearAll();
	ServiceDB.save();
	Utility.setEnv("Mis_AdvCallback", "hide_bubble_adv");
	Utility.ioctlWrite("Mis_AdvCallback",  "SysDestroy");		// 退出播放页面，关闭如加广告
	$G.sysDa.submit();
}

/*
	0	: 播放页面全屏播放视频，且无任何UI显示
	1	: 播放页面全屏播放视频，且有音量条显示
	2	: 播放页面全屏播放视频，且有channelbar显示
	3	: 播放页面全屏播放视频，且只有CA警告信息显示
	4	: 除播放页面外的其它页面
	5	: 播放页面全屏播放视频，且顶部和底部显示用来显示字幕的区域没有UI显示
	6	: 其它状态
	注意：若同时满足两种状态则使用较低的状态。
		如：只有音量条显示时，既满足状态1，又满足状态5，则当前状态为状态1；
		又如：只有CA警告信息显示时，既满足状态3，又满足状态5，则当前状态为状态3；
*/
function setMisUiStatusEnv(index) {
	Utility.setEnv("Mis_DisplayStatus", index);	
}

function setMisUiStatus() {
	if (volumeBar.isVisible) {	
		setMisUiStatusEnv(1);	
	} else if (channelBar.isVisible) {
		setMisUiStatusEnv(2);	
	} else if (OKList.isVisible) {								
		// oklist显示时，顶部和底部用于显示字幕的区域有UI显示。属于状态6：其它状态
		setMisUiStatusEnv(6);				
	} else if ($("proInfo").style.visibility == "visible"			// 节目简介框
		|| misIsShowOrder						// 节目预定提醒框
		|| isShowCAGlobalTips						// 节目更新提醒框
		|| (passwordBox && passwordBox.isVisible)			// 密码框
		|| $("mutePic").style.visibility == "visible"			// 静音图标
		|| $("app_list").style.visibility == "visible"			// 应用下载列表
		|| $("app_download").style.visibility == "visible"		// 应用下载提示框
		|| $("delDiv").style.visibility == "visible"			// 删除节目确认弹出框
		|| $("srhConfirmDiv").style.visibility == "visible") {		// 搜索提示框
		setMisUiStatusEnv(5);
	} else if (showTipsFlag) {
		setMisUiStatusEnv(3);		
	} else {
		setMisUiStatusEnv(0);		
	}
}

//应用下载
function showApplication(item, index, fcsIndex) {
	$("app_" + fcsIndex).innerText = item ? item.name : "";
}

function onFocusMove(oldPos, newPos) {
	$("app_focus").style.top = 201 + 68 * newPos + "px";
	$("app_focus").style.backgroundImage = "url(../images/bar68.png)";
	appDetail();
}

function onFocus(index){
	Utility.println("-onFocus--- "+apps[appListView.currIndex].appId);
	$("app_focus").style.top = 201 + 68 * index + "px";
	$("app_focus").style.backgroundImage = "url(../images/bar68.png)";
	appDetail();
}

function onBlur(index) {
	$("app_focus").style.top = 201 + 68 * index + "px";
	$("app_focus").style.backgroundImage = "";
}

function appDetail() {
	Utility.println("----- "+apps[appListView.currIndex].appId);
	Utility.println("----------appListView.currIndex="+appListView.currIndex);
	$("appRight_0").innerText = apps[appListView.currIndex].appId;
	$("appRight_1").innerText = apps[appListView.currIndex].version;
	if (apps[appListView.currIndex].type == "html") 
	{
		$("appRight_2").innerText = "html";
	}
	else 
	{
		$("appRight_2").innerText = "java";
	}
}
var app_download_timer;
function hideAppDownLoadIcon() {
	clearTimeout(app_download_timer);
	$("app_download").style.visibility = "hidden";
}
function showAppDownLoadIcon() {
	clearTimeout(app_download_timer);
	$("app_download").style.visibility = "visible";
	app_download_timer = setTimeout("hideAppDownLoadIcon()", 15000);
}
function showAppDownload() {
	Utility.println("========showAppDownload=======");
	apps = AppsCollection.getApplications("TransportType=OC-ServiceBound");
	if (appFlag) {
		if (apps.length > 0) {
			$("app_list").style.visibility = "visible";
			$("app_focus").style.visibility = "visible";
			appListView.bindData(apps,0);
			appListView.setFocus();
		}  else {
			hideAppList();
		}
	}
	if (apps.length > 0) {
		showAppDownLoadIcon();
	} else {
		hideAppDownLoadIcon();
	}
}

function showAppList() {
	Utility.println("========play.js====11====KEY_BLUE=======");
	apps = AppsCollection.getApplications("TransportType=OC-ServiceBound");
	
	if (apps.length ==1 ) {
		Utility.println("========play.js====AppCount = 1, and start it=======");
		AppManagerExt.startApp(apps[0].appId, null);
	} else if (apps.length > 1 ) {
		appFlag = true;
		$("app_list").style.visibility = "visible";
		$("app_focus").style.visibility = "visible";
		appListView.bindData(apps,0);
		appListView.setFocus();
		Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 05);
	}
}

function hideAppList() {
	appFlag = false;
	$("app_list").style.visibility = "hidden";
	$("app_focus").style.visibility = "hidden";
	$("app_download").style.visibility = "hidden";
	appListView.hide();
	onDisplayMessageEvent(DVB.getShowEvents());
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 05);
}

function initSingalText() {
	var txtArr = { infoTitleID:$L.SYS_TITLE,
		txt_0:$L.S_INFO_10,txt_1:$L.INFO_0,txt_2:$L.INFO_1,txt_3:$L.S_INFO_9,txt_4:$L.INFO_2,
		txt_5:$L.S_INFO_11,txt_6:$L.S_INFO_0,txt_7:$L.S_INFO_2,txt_8:$L.INFO_3,txt_9:$L.INFO_4,
		txt_10:$L.INFO_5, txt_11:$L.INFO_6,txt_12:$L.INFO_7, txt_13:$L.INFO_8,txt_14:$L.INFO_9,txt_15:$L.INFO_10,
		txt_16:$L.SIGNAL_QUALITY,txt_17:$L.SIGNAL_LEVEL,txt_18:$L.ERROR_RATE,bottomID:$L.BACK_TIPS
	};
	for (var id in txtArr) {
		$(id).innerText = txtArr[id];
	}
}

function initInfo() {
	$("value_0").innerText = SysInfo.hardwareVersion;
	$("value_1").innerText = SysInfo.softwareVersion + "("+$G.sysDa.get("Sys.stbTypeCode") + ")";
	$("value_2").innerText = "";
	$("value_3").innerText = SysInfo.STBSerialNumber;
	$("value_4").innerText = mac ? mac : "";
	$("value_5").innerText = SysInfo.softwareReleaseDate;
	$("value_6").innerText = currService ? currService.name : "";
	$("value_7").innerText = audioChannels[mp.player.getCurrentAudioChannel()] ;
	$("value_8").innerText = currService ? currService.tsId : "";
	$("value_9").innerText = currService ? currService.serviceId : "";
	$("value_10").innerText = currService ? currService.PCRPID : "";
	$("value_11").innerText = currService ? currService.videoPID : "";
	$("value_12").innerText = currService ? currService.audioPID : "";
	$("value_13").innerText = currService ? currService.frequency : "";
	$("value_14").innerText = currService ? currService.symbolRate : "";
	$("value_15").innerText = currService ? modulations[currService.modulation] : ""
}

function showSingal() {
	initSingalText();
	mac = ethernet.MACAddress;
	audioChannels = {Left: $GL.TRACK_LEFT, Right: $GL.TRACK_RIGHT,  Stereo: $GL.TRACK_STEREO};
	initInfo();
	showSignalInfo();
}

var currStrength, currEr, currQuality;
function showSignalInfo() {
	clearTimeout(timer);
	currStrength = DVB.signalStrength;
	currEr = DVB.errorRate;
	currQuality = DVB.signalQuality;
	$("value_00").innerText = currQuality + "dB";
	$("progress_0").width = (currQuality / 100) * 260;
	$("value_01").innerText = currStrength + "dBuV";
	$("progress_1").width = (currStrength / 100) * 260;
	$("value_02").innerText = currEr;
	timer = setTimeout("showSignalInfo()", 2000);
}

function showSingalBox() {
	showSingal();
	Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 04);
	$("mainID").style.visibility = "visible";
	singalFlag = true;	
}

function hideSingalBox() {
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 04);
	$("mainID").style.visibility = "hidden";
	singalFlag = false;	
}
