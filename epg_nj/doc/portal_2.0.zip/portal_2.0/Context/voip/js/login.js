document.onkeypress = grabEvent;

function grabEvent(event) {
	var keyCode = event.keyCode || event.which;
	switch(keyCode) {
		case 38:
			break;
		case 40:
			break;
		case 13:
			break;
		case 40500: //登录成功
			voipCfg.set("ISVOIPLOGIN", "loged");
			break;
		case 40501: //登录失败
			voipCfg.set("ISVOIPLOGIN", "failed");
			break;
		default:
			break;
	}
}
var $ = function(id){
	var o = document.getElementById(id);
	return o;
};
function checkPhoneNumberValid(phoneNumber) {
	if (!phoneNumber || phoneNumber == "undefined") {
		return false;
	}
	if (phoneNumber[0] != "+" && isNaN(phoneNumber[0])) {
		return false;
	}
	return true;
}
var voipCfg = new DataAccess("voipconfig.properties");
var loginType = voipCfg.get("login_type"); // 0:使用电话号码登陆; 1:使用IP地址登陆
var phoneNumbe = voipCfg.get("login_phonenum");// "+862525004442";//登陆电话号码
var password = voipCfg.get("login_pwd");// "123456"; //"123456";//登陆密码
var ipAddress = voipCfg.get("login_ip");//登陆IP地址ַ
if (!checkPhoneNumberValid(phoneNumbe)) {
	phoneNumbe = "";
	password = "";
}
function init() {
	$("inputNAME").value = phoneNumbe;
	$("inputPWD").value = password;
}

function compareViopLogin() {
	var loged = 0;
	if(($("inputNAME").value) == phoneNumbe && $("inputPWD").value == password) {
		VideoPhone.login(phoneNumbe, password);
	} else if ($("inputNAME").value && $("inputPWD").value) {
		phoneNumbe = $("inputNAME").value;
		password = $("inputPWD").value;
		VideoPhone.logout();
		voipCfg.set("login_phonenum", phoneNumbe);
		voipCfg.set("login_pwd", password);
		voipCfg.submit();
		voipCfg.set("ISVOIPLOGIN", "failed");
		VideoPhone.login(phoneNumbe, password);
	}
	if ($("inputNAME").value && $("inputPWD").value) {
		location.href = "connect.htm";
	}
}

function getRadioValue(name){
	var radioes = document.getElementsByName(name); 
	for(var i=0;i<radioes.length;i++)
	{
	     if(radioes[i].checked){
	      return radioes[i].value;
	     }
	}
	return 2;
}

function setDeviceType() {
	var radioValue = getRadioValue("radio");  
	if(radioValue == 0) {
		voipCfg.set("AudioDev_Type", 2);
	} else {
		voipCfg.set("AudioDev_Type", radioValue);
	}
}

function doVoipEnter() {
	setDeviceType();
	compareViopLogin();
	voipCfg.submit();
	Utility.println("++++++++++++++++++AudioDev_Type = " + voipCfg.get("AudioDev_Type"));
}

