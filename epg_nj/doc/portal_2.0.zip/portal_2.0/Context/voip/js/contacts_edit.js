var filePath = Utility.getEnv("STB.systemPath")+"/config/phonebook.txt";
var record, phoneData;

var menuListView;
var area = 1;
var oper = 0;
var inpt = 0;

var photoList;
var isChoosePhoto = true;

var locString = String(location.href);
function getParams(url){
	var queryString = url.substr(url.indexOf("?") + 1);
	if (queryString == "") return;
	var requests = [];
	var params = queryString.split("&");
	for (var i = 0; i < params.length; i++) {
		var temp = params[i].split("=");
		if (temp.length < 2) return;
		requests[temp[0]] = temp[1];
	}
	if (params.length == 0) {
		var temp = queryString.split("=");
		if (temp.length < 2) return;
		requests[temp[0]] = temp[1];
	}
	return requests;
}

var $ = function(id){
	var o = document.getElementById(id);
	return o;
};

/*
 * 继承和复写find方法
 */
function ContactRecord(filePath, vRMaxLen){
	VoipRecord.call(this, filePath, vRMaxLen);
}

ContactRecord.prototype = new VoipRecord();

ContactRecord.prototype.find = function(phoneNum){
    for (var index = 0; index < this.length; index++) {
        if (this.data[index].cellPhone == phoneNum) { 
			return index; 
		}
    }
    if (index >= this.length) { 
		return -1; 
	}
}

var typeId = "", listid = 0,phoneNum = "";

var editListView;
var editText = [];

var photos = [];

function showMenu(item, index, focusIndex) {
	$("list_" + focusIndex).innerText = item ? item.name : "";
}

function onFocusMove(oldPos, newPos) {
	$("list_" + oldPos).className = "";
	$("list_" + newPos).className = "current";
	$("editNum_" + inpt).blur();
	inpt = 0;
	$("editNum_1").focus();
	showDetail();
}

function onFocus(index) {
	$("list_" + index).className = "current";
}

function onBlur(index) {
	$("list_" + index).className = "";
}

function init() {
	var voipDa = new DataAccess("voipconfig.properties");
	var phoneStr = voipDa.get("login_phonenum");
	$("phone_num").innerText = phoneStr.length == 13 ? phoneStr.substr(5) : phoneStr.substr(3);
	
	var param = getParams(locString);
	if (param) {
		if (param["id"]) {
			listid = param["id"] - 0;
		}
		if(param["phnNum"]){
			phoneNum = param["phnNum"];
		}
		if(param["type"]){
			typeId = param["type"];
		}
	}
	
	record = new ContactRecord(filePath);
	record.make();
	phoneData = record.data;
	
	menuListView = new List(7, showMenu, onFocusMove, onFocus, onBlur);	
	menuListView.bindData(phoneData,listid);
	menuListView.setBlur();
	$("list_" + menuListView.focusIndex).className = "blur";
	
	$("po_0").innerHTML = menuListView.currPage;
	$("po_1").innerHTML = menuListView.totalPage;
	
	initPhoto();
	
	showInfo();
	
	$("editNum_1").focus();
}

function initText() {
	detailText = [
		{name:"姓名:"},
		{name:"号码:"},
		{name:"保存:"},
		{name:"取消:"}
	];
}

function showPhoto(item, index, focusIndex) {
	$("photo_" + focusIndex).style.background = item ? "url(" + item.blr + ")"  : "";
}

function onPhotoMove(oldPos, newPos, oldIndex, newIndex) {
	$("photo_" + oldPos).className = "";
	$("photo_" + oldPos).style.background = "url(" + photos[oldIndex].blr + ")";
	
	$("photo_" + newPos).className = "current";
	$("photo_" + newPos).style.background = "url(" + photos[newIndex].fcs + ")";
}

function onPhotoFocus(index) {
	$("photo_" + index).className = "current";
	$("photo_" + index).style.background = "";
	$("photo_" + index).style.background = "url(" + photos[photoList.currIndex].fcs + ")";
}

function onPhotoBlur(index) {
	$("photo_" + index).className = "";
	$("photo_" + index).style.background = "";
	$("photo_" + index).style.background = "url(" + photos[photoList.currIndex].blr + ")";
}

function initPhoto(){
	var curruntP = 0;
	var voipCfg = new DataAccess("voipconfig.properties");
	var photoNums = voipCfg.get("USER_DEFAULT_PHOTOS") == "" ? 5 : voipCfg.get("USER_DEFAULT_PHOTOS");
	for(var i = 0; i < photoNums; i++){
		var userPt = {blr:"",fcs:""};
		userPt.blr = "images/photo/photo" + i + "_blur.png";
		userPt.fcs = "images/photo/photo" + i + "_focus.png";
		photos.push(userPt);
	}
	photoList = new RList(3, showPhoto, onPhotoMove, onPhotoFocus, onPhotoBlur);
}

function showInfo() {
	if (typeId == "add") {
		$("editNum_2").value = phoneNum;
		photoList.currIndex = 0;
		photoList.bindData(photos,0);
		photoList.setFocus();
	} else {
		$("editNum_1").value = phoneData[menuListView.currIndex].name ? phoneData[menuListView.currIndex].name : "";
		$("editNum_2").value = phoneData[menuListView.currIndex].cellPhone ? phoneData[menuListView.currIndex].cellPhone : "";
		var photoIndex = phoneData[menuListView.currIndex].photo ? phoneData[menuListView.currIndex].photo : 0;
		photoList.bindData(photos,photoIndex - 0);
		photoList.setFocus();
	}
}

function showDetail() {
	photoList.setBlur();
	$("editNum_1").value = phoneData[menuListView.currIndex].name ? phoneData[menuListView.currIndex].name : "";
	$("editNum_2").value = phoneData[menuListView.currIndex].cellPhone ? phoneData[menuListView.currIndex].cellPhone : "";
	var photoIndex = phoneData[menuListView.currIndex].photo ? phoneData[menuListView.currIndex].photo : 0;
	photoList.bindData(photos,photoIndex - 0);
	photoList.setFocus();

}

function editPhoneDetail() {
	var dataObj = {name:"",cellPhone:"",photo:0};
	dataObj.name = $("editNum_1").value;
	dataObj.cellPhone = $("editNum_2").value  + "";
	dataObj.photo = photoList.currIndex + "";
	record.modify(listid,dataObj);
	record.save();
	return 1;
}

var backTime = 5, backTimeout = -1;
function timeToBack(){
	if(backTime <= 0){
		hideDelTip();
	}else{
		$("backTime").innerHTML = backTime;
		backTime--;
		backTimeout = setTimeout(timeToBack,1000);
	}
}

var delPos = 0, isDel = false, sec=6, secTimer=-1;
function showConfirmDiv(_tips) {
	isDel = true;
	$('delContact').style.visibility = "visible";
	$('tipCont').innerHTML = _tips;
	timeToBack();
}

function addPhoneDetail() {
	var phonNum = $("editNum_2").value;
	var index = record.find(phonNum);
	if (index != -1) {
		showConfirmDiv("该联系人已经存在（<span id='backTime'>5</span>）！");
		return -1;
	} else {
		var dataObj = {
			name: "",
			cellPhone: "",
			photo: 0
		};
		dataObj.name = $("editNum_1").value;
		dataObj.cellPhone = $("editNum_2").value  + "";
		dataObj.photo = photoList.currIndex + "";
		record.add(dataObj);
		record.save();
		return 1;
	}
}

function doEnter() {
	switch(area){
		case 3:
			switch(oper){
				case 0:
					var rnt = 0;
					if (typeId == "add") {
						rnt = addPhoneDetail();
					}else if(typeId == "edit"){
						rnt = editPhoneDetail();
					}
					if (rnt > 0) {
						location.href = "contacts.htm";
					}else{
						return;
					}
				break;
				case 1:
					location.href = "contacts.htm";
				break;
			}
		break;
	}
}

function leftRight(type){
	if(area == 0){
		if (type > 0) {
			photoList.down();
		} else {
			photoList.up();
		}
	}else if(3 == area){
		$("editOper_" + oper).blur();
		oper = (oper + type + 2) % 2;
		$("editOper_" + oper).focus();
	}
}

function upDown(_type){
	if((1 == area && _type < 0) || (2 == area && _type > 0)){
		$("editNum_" + area).blur();
		if(1 == area && _type < 0){
			photoList.setFocus();
		}
		if(2 == area && _type > 0){
			$("editOper_" + oper).focus();
		}
	}
	
	if(area > 0 && area < 3){
		$("editNum_" + area).blur();
	}
	
	area += _type;
	
	if(area < 0){
		area = 0;
	}else if(area > 3){
		area = 3;
	}
	
	if(area > 0 && area < 3){
		$("editNum_" + area).focus();
	}
}

function keyExist(){
	window.location.href = datas[8].menuPic[5].url;
}

function hideDelTip(){
	backTime = 5;
	isDel = false;
	clearTimeout(backTimeout);
	$('delContact').style.visibility = "hidden";
	$('tipCont').innerText = "";
}

function confirmEvent(evt) {
	var keyCode = evt.which || evt.keyCode;
	switch (keyCode) {
		case 13:
			isDel = false;
			hideDelTip();
			break;
	}
}

document.onkeypress = function(evt) {
	var keyCode = evt.which || evt.keyCode;
	evt.preventDefault();
	
	if (isDel) {
		confirmEvent(evt);
		return;
	}
	
	switch(keyCode) {
		case 38:
			upDown(-1);
			break;
		case 40:
			upDown(1);
			break;
		case 39:
			leftRight(1);
			break;
		case 37:
			leftRight(-1);
			break;
		case 13:
			doEnter();
			break;
		case 27: //退出键
		case 114:
			keyExist();
	}
}