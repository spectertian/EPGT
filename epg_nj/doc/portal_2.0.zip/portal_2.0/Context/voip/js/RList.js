/**
 * @fileOverview List控件
 * @description 带有显示、上下移动、上下翻页、焦点控制、滑动功能的List控件
 * @author
 * @version 1.00
 * @example var channelListView = new List(5, showChannel, onFocusMove, onFocus, onBlur, onNoChannel, "channel_focus", 168, 46);
 */
/**
 * @description 带有显示、上下移动、上下翻页、焦点控制、滑动功能的List控件
 * @constructor List
 * @param {Number} pageSize 一页能够显示的最大行数
 * @param {Function} iterator 遍历显示每行数据的函数
 * @param {Function} onFocusMove 焦点移动时调用的函数
 * @param {Function} onFocus 获取焦点函数
 * @param {Function} onBlur 失去焦点函数
 * @param {Function} onNoData 没有数据时处理方式
 * @param {String} focusId 焦点条的ID【滑动需要的参数,普通焦点移动时可为空】
 * @param {Number} focusTop 焦点条处于第一行时的top值【滑动需要的参数,普通焦点移动时可为空】
 * @param {Number} focusStep 焦点每移动一行的步长【滑动需要的参数,普通焦点移动时可为空】
 */
var RList = function(pageSize, iterator, onFocusMove, onFocus, onBlur, onNoData, focusId, focusTop, focusStep){
    this.pageSize = pageSize;
    this.iterator = iterator;
    this.onFocusMove = onFocusMove;
    this.onFocus = onFocus;
    this.onBlur = onBlur;
    this.onNoData = onNoData;
    this.focusId = focusId;
    this.focusTop = focusTop;
    this.focusStep = focusStep;
    this.moveFlag = Boolean(typeof(this.focusId) != 'undefined' && typeof(this.focusTop) != 'undefined' && typeof(this.focusStep) != 'undefined');
}

RList.prototype = {
    /**
     * @description 数量绑定函数
     * @param {Object} data 数组
     * @param {Object} index 当前焦点所处下标
     * @param {Object} type 数据类型【不传或值为0时：普通数组；1时：serviceList类型的数组，通过getAt()来获取数据】
     * @return null
     */
    bindData: function(data, index, type){
        this.type = type;
        this.data = data;
        this.currIndex = index;
        this.focusIndex = this.currIndex >= this.pageSize - 1 ? this.pageSize - 1 : this.currIndex;
        this.length = data.length;
        this.showList();
        this.pageUpdat = false;
        if (this.onNoData && this.length == 0) {
            this.onNoData();
        }
    },
    
    /**
     * @description 显示列表数据
     * @return null
     */
    showList: function(){
        var len = this.pageSize;
        this.start = this.currIndex - this.focusIndex <= 0 ? 0 : this.currIndex - this.focusIndex;
        if (this.start > this.length - 1) {
            this.start = 0;
            this.currIndex = 0;
            this.setBlur();
            this.focusIndex = 0;
        }
        for (var i = 0; i < len; i++) {
            var index = this.start + i;
            if (!this.type || this.type == 0) {
                this.iterator(index < this.length ? this.data[index] : null, index, i);
            }
            else {
                this.iterator(index < this.length ? this.data.getAt(index) : null, index, i);
            }
        }
    },
    
    /**
     * @description 向上移动一行焦点
     * @return null
     */
    up: function(){
        var isBelow = false;
        if (this.length == 0) {
            return;
        }
        var oldFocusIndex = this.focusIndex <= 0 ? 0 : this.focusIndex;
        if (oldFocusIndex == 0) {
            this.pageUpdat = true;
        }
        var oldIndex = this.currIndex;
        this.currIndex--;
        if (this.currIndex == this.start - this.focusIndex) {
            this.currIndex--;
        }
		
        if (this.currIndex < 0) {
            this.currIndex = this.length - 1;
			oldIndex = this.currIndex - (this.pageSize - this.focusIndex) + 1;
            isBelow = true;
        }
        
        var tempFocus = oldFocusIndex - 1, newIndex = this.currIndex;
        var newFocusIndex = tempFocus < 0 ? 0 : tempFocus;
        this.focusIndex = newFocusIndex;
        if (isBelow) {
            newFocusIndex = this.pageSize - 1;
            this.focusIndex = this.pageSize - 1;
        }
		
		/*
         * 当前业移动时不更新列表
         */
        if (this.pageUpdat) {
            this.showList();
            this.pageUpdat = false;
        }
        this.onFocusMove(oldFocusIndex, newFocusIndex, oldIndex, newIndex);
    },
    
    /**
     * @description 向下移动一行焦点
     * @return null
     */
    down: function(){
        if (this.length == 0) {
            return;
        }
        var oldFocusIndex = this.focusIndex > this.pageSize - 1 ? this.pageSize - 1 : this.focusIndex;
        /*
         * 焦点在尾页或当前页的末尾则更新列表
         */
        if (oldFocusIndex == this.pageSize - 1 || this.currIndex == this.length - 1) {
            this.pageUpdat = true;
        }
        var oldIndex = this.currIndex;
        
		this.currIndex++;
        
		var tempFocus = oldFocusIndex + 1;
        var newFocusIndex = tempFocus > this.pageSize - 1 ? this.pageSize - 1 : tempFocus;
        
		this.focusIndex = newFocusIndex;
        
		if (this.currIndex > this.length - 1) {
            this.currIndex = 0;
            this.focusIndex = 0;
            newFocusIndex = 0;
			oldIndex = this.pageSize - 1;
        }
        newIndex = this.currIndex;
        /*
         * 当前业移动时不更新列表
         */
        if (this.pageUpdat) {
            this.showList();
            this.pageUpdat = false;
        }
        this.onFocusMove(oldFocusIndex, newFocusIndex, oldIndex, newIndex);
    },
    
    /**
     * @description 向上翻页
     * @return null
     */
    pageUp: function(){
        var tempIdx = this.currIndex;
        this.currIndex -= this.pageSize;
        
        if (this.currIndex > -this.pageSize && this.currIndex < 0) {
            if (tempIdx == this.focusIndex) {
                this.currIndex = this.length - this.pageSize + this.focusIndex;
            }
            else {
                this.currIndex = 0;
            }
        }
        else {
            if (this.currIndex <= -this.pageSize) {
                this.currIndex = this.length - this.pageSize + this.focusIndex;
            }
        }
        
        this.showList();
        
        // 原焦点位置
        this.setBlur();
        this.focusIndex = 0;
        this.setFocus();
    },
    
    /**
     * @description 向下翻页
     * @return null
     */
    pageDown: function(){
        var isLast, tempIdx = this.currIndex;
        this.currIndex += this.pageSize;
        this.showList();
        
        // 原焦点位置
        this.setBlur();
        
        if (this.currIndex > this.length - 1) {
            this.currIndex = this.length - 1;
        }
        isLast = this.currIndex + (this.pageSize - this.focusIndex) > this.length - 1;
        if (isLast) {
            var right = this.length - tempIdx - 1;
            if (right != this.pageSize && right > 0) {
                if (this.focusIndex + 1 > right) 
                    this.focusIndex = right - 1;
            }
        }
        this.setFocus();
    },
    
    /**
     * @description 使某行获取焦点
     * @return null
     */
    setFocus: function(){
        this.onFocus(this.focusIndex);
    },
    
    /**
     * @description 使某行推动焦点
     * @return null
     */
    setBlur: function(){
        this.onBlur(this.focusIndex);
    }
    
}
/****************************************************************************/
var focusId, focusTop, preTop, slideTimer;
/**
 * @description 焦点滑动实现函数
 * @param {String} _divId 滑动的焦点层ID
 * @param {Number} _preTop 滑动前的top值
 * @param {Number} _top 滑动后的top值
 * @return null
 */
function slide(_divId, _preTop, _top){
    if (typeof(_divId) != 'undefined' && typeof(_preTop) != 'undefined' && typeof(_top) != 'undefined') {
        focusId = _divId;
        preTop = _preTop;
        focusTop = _top;
    }
    var moveStep = (focusTop - preTop) * 0.5;
    if (Math.abs(moveStep) > 1) {
        preTop += moveStep;
        $(focusId).style.top = preTop + "px";
        clearTimeout(slideTimer);
        slideTimer = setTimeout(slide, 30);
    }
    else {
        $(focusId).style.top = focusTop + "px";
    }
}
