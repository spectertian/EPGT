var record;
var pageList, pageListView;
var operListView;

var area = 0;
var oper = 2;
var opers = ["加为好友","视频通话","删除记录"];
var recodeData = [];

var focusId, focusTop, preTop, slideTimer;
function slide(_divId, _preTop, _top){
	if (typeof(_divId) != 'undefined' && typeof(_preTop) != 'undefined' && typeof(_top) != 'undefined') {
		focusId = _divId;
		preTop = _preTop;
		focusTop = _top;
	}
	var moveStep = (focusTop - preTop) * 0.5;
	if (Math.abs(moveStep) > 1) {
		preTop += moveStep;
		$(focusId).style.top = preTop + "px";
		clearTimeout(slideTimer);
		slideTimer = setTimeout(slide, 30);
	} else {
		$(focusId).style.top = focusTop + "px";
	}
}

function NJViopList(pageSize, iterator, onFocusMove, onFocus, onBlur, onNoData, focusId, focusTop, focusStep){
	List.call(this, pageSize, iterator, onFocusMove, onFocus, onBlur, onNoData, focusId, focusTop, focusStep);
}

NJViopList.prototype = new List();

NJViopList.prototype.up = function(){
	if (this.length == 0) return;
	var oldFocusIndex = this.currIndex % this.pageSize;
	var oldIndex = this.currIndex;
	this.currIndex--;
	this.pageUpdate = false;
	if (this.totalPage > 1 && oldFocusIndex == 0) {
		this.pageUpdate = true;
	}
	
	if (this.currIndex < 0) {
		this.currIndex = 0;
	}
	
	var newIndex = this.currIndex;
	var newFocusIndex = this.currIndex % this.pageSize;
	this.focusIndex = newFocusIndex;
	
	if (this.moveFlag) {
		slide(this.focusId, this.focusTop + (oldFocusIndex * this.focusStep), this.focusTop + (newFocusIndex * this.focusStep));
	}
	
	if (this.pageUpdate) {
		this.currPage = Math.ceil((this.currIndex + 1) / this.pageSize);
		this.showList();
	}
	this.onFocusMove(oldFocusIndex, newFocusIndex, oldIndex, newIndex);
}

/*
 * 继承和复写find方法
 */
function ContactRecord(filePath, vRMaxLen){
	VoipRecord.call(this, filePath, vRMaxLen);
}

ContactRecord.prototype = new VoipRecord();

ContactRecord.prototype.find = function(phoneNum){
    Utility.println("--phoneNum "+phoneNum);
    for (var index = 0; index < this.length; index++) {
        Utility.println("--index = "+index+"  phone "+this.data[index].cellPhone);
        if (phoneNumEqual(this.data[index].cellPhone, phoneNum)) { 
            return index; 
        }
    }
    Utility.println("-------index = "+index+"  length = "+this.length);
    return -1; 
}

function getNameFromPhonebook(num) {
	var index = contacts.find(num);
	var name = index >= 0 ? contacts.data[index].name : "陌生人";
	return name;
}

function showPage(item, index, focusIndex) {
    if (item) {
		pageList.rows[focusIndex].cells[0].innerHTML = record.getCode(0, item.type);
		pageList.rows[focusIndex].cells[1].innerHTML = getNameFromPhonebook(item.num);
		pageList.rows[focusIndex].cells[2].innerHTML = item.num;
		pageList.rows[focusIndex].cells[3].innerHTML = item.date;
		pageList.rows[focusIndex].cells[4].innerHTML = item.times;
	}else {
		for(var i = 0;i < 6;i++){
			pageList.rows[focusIndex].cells[i].innerHTML = "";
		}
	}
}

function onFocus(index) {
	$("pListFocus").style.top = 54 + 44 * index + "px";
}

function showOper(item, index, focusIndex) {
	$("uOper_" + focusIndex).innerText = item ? item  : "";
}

function onOperMove(oldPos, newPos) {
	$("uOper_" + newPos).className = "current";
	$("uOper_" + oldPos).className = "";
}

function onOperFocus(index) {
	$("uOper_" + index).className = "current";
}

function onOperBlur(index) {
	$("uOper_" + index).className = "";
}

var contacts = null;
function init(){
	var voipDa = new DataAccess("voipconfig.properties");
	var phoneStr = voipDa.get("login_phonenum");
	$("phone_num").innerText = phoneStr.length == 13 ? phoneStr.substr(5) : phoneStr.substr(3);
	
	var contactsFile = Utility.getEnv("STB.systemPath")+"/config/phonebook.txt";
	contacts = new ContactRecord(contactsFile);
	contacts.make();
	
	var filePath = Utility.getEnv("STB.systemPath")+"/config/VoipRecord.properties";
	record = new VoipRecord(filePath);
	record.make();
	record.reverse();
	recodeData = record.data;
	pageList = $("pageList");
	pageListView = new NJViopList(8, showPage,"",onFocus, "","","pListFocus",53,45);
	
	pageListView.bindData(recodeData,0);
	pageListView.setFocus();
	
	$("po_0").innerHTML = pageListView.currPage;
	$("po_1").innerHTML = pageListView.totalPage;
	
	operListView = new List(3, showOper, onOperMove, onOperFocus, onOperBlur);
	operListView.bindData(opers,0);
	showEffectOper();
}

function doEnter(){
	var index = operListView.currIndex;
	if (area == 1) {
		if(opers.length > 2){
			switch(index){
				case 0:
					if (pageListView.length > 0) {
						window.location.href = "contacts_edit.htm?type=add&phnNum=" + pageList.rows[pageListView.focusIndex].cells[2].innerHTML;
					}
				break;
				case 1:
				var num = pageList.rows[pageListView.focusIndex].cells[2].innerHTML;
					if (pageListView.length > 0 && num.length > 0) {
						window.location.href = "connect.htm?type=call&vedioType=vdCall&phnNum=" + num;
					}
				break;
				case 2:
					record.del(pageListView.currIndex);
					record.save();
					pageListView.bindData(record.data,0);
					$("po_0").innerHTML = pageListView.currPage;
					$("po_1").innerHTML = pageListView.totalPage;
				break;
			}
		}else {
			switch(index){
				case 0:
				var num = pageList.rows[pageListView.focusIndex].cells[2].innerHTML;
					if (pageListView.length > 0 && num.length > 0) {
						window.location.href = "connect.htm?type=call&vedioType=vdCall&phnNum=" + num;
					}
				break;
				case 1:
					record.del(pageListView.currIndex);
					record.save();
					pageListView.bindData(record.data,0);
					$("po_0").innerHTML = pageListView.currPage;
					$("po_1").innerHTML = pageListView.totalPage;
				break;
			}
		}
	}else if(area == 2){
		switch(oper){
			case 0:
				location.href = "connect.htm";
			break;
			case 1:
				location.href = "contacts.htm";
			break;
			case 2:
				location.reload();
			break;
		}
	}else if(area == 0){
		area = 1;
		showEffectOper();
	}
}

function showEffectOper(){
	pageListView.setBlur();
	$("operFull").style.visibility = "visible";
	var pIndex = pageListView.currIndex;
	
	var num = cutNumber(recodeData[pIndex].num);
	
	var index = contacts.find(num);
	if(-1 != index){
		if(opers.length > 2){
			var addFriend = opers.shift();
			var operElem = $("oper");
			var operList = operElem.getElementsByTagName("li");
			for(var i = 0, len = operList.length; i < len; i++){
				var idPre = operList[i].id.substr(0, operList[i].id.lastIndexOf("_"));
				operList[i].id = idPre + "_" + (i - 1);
			}
			operList[0].innertText = addFriend;
			operList[0].className = "enable";
			operListView.bindData(opers,0);
		}
	} else {
		opers = ["加为好友","视频通话","删除记录"];
		var operElem = $("oper");
		var operList = operElem.getElementsByTagName("li");
		for(var i = 0, len = operList.length; i < len; i++){
			var idPre = operList[i].id.substr(0, operList[i].id.lastIndexOf("_"));
			operList[i].id = idPre + "_" + i;
		}
		operList[0].className = "";
		operListView.bindData(opers,0);
		//operListView.setFocus();
	}
	$("operFull").style.top = 190 + 44 * pageListView.focusIndex + "px";
	if(area == 1){
		operListView.setFocus();
	}
}

function leftRight(_type){
	if(area != 2){
		area += _type;
		if(area < 0) area = 0;
		if(area > 1) area = 1;
		switch(area){
			case 0://left
				pageListView.setFocus();
				//$("operFull").style.visibility = "hidden";
				operListView.setBlur();
				showEffectOper();
				break;
			case 1://right
				if (recodeData.length > 0) {
					showEffectOper();
				}
				break;
		}
	}else{
		$('oper_' + oper).className = "oper_" + oper;
		oper += _type;
		if (oper > 2) {
			oper = 2;
		}else if(oper < 0){
			oper = 0;
		}
		
		$('oper_' + oper).className = "oper_" + oper + "_current";
	}
	
}

function UDChg(){
	if(area == 2){
		$('oper_' + oper).className = "oper_" + oper + "_current";
	}else {
		menuListView.setFocus();
	}
}

function keyExist(){
	switch(area){
		case 0:
		case 1:
			if ("visible" == $("operFull").style.visibility) {
				$("operFull").style.visibility = "hidden";
			}
			area = 2;
		break;
		case 2:
			$('oper_' + oper).className = "oper_" + oper;
			if(oper != 2){
				oper = 2;
			}
			$('oper_2').className = "oper_2_current1";
			menuListView.setFocus();
			area = 0;
			showEffectOper();
		break;
	}
	UDChg();
}

function eventHandler(evt){
	switch (evt.code) {
		case "KEY_LEFT":
		    leftRight(-1);
			break;
		case "KEY_RIGHT":
		    leftRight(1);
			break;
		case "KEY_UP":
			if (0 == area) {
				if (pageListView.currIndex != 0) {
					pageListView.up();
					$("po_0").innerHTML = pageListView.currPage;
					showEffectOper();
				}else{
					keyExist();
				}
				
			}else if (1 == area){
				operListView.up();
			}
			break;
		case "KEY_DOWN":
			if (0 == area) {
				pageListView.down();
				$("po_0").innerHTML = pageListView.currPage;
				showEffectOper();
			}else if (1 == area){
				operListView.down();
			}else if (2 == area){
				keyExist();
			}
			break;
		case "KEY_PAGE_UP":
			if (0 == area) {
				pageListView.pageUp();
				$("po_0").innerHTML = pageListView.currPage;
				showEffectOper();
			}
			break;
		case "KEY_PAGE_DOWN":
			if (0 == area) {
				pageListView.pageDown();
				$("po_0").innerHTML = pageListView.currPage;
				showEffectOper();
			}
			break;
		case "KEY_ENTER":
			doEnter();
			break;
		case "KEY_EXIT":
//			keyExist();
			window.location.href = datas[8].menuPic[5].url;
			break;
		case "KEY_BACK":
			window.location.href = "connect.htm";
			break;
	}
}