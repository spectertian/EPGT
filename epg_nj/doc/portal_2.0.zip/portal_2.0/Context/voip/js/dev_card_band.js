﻿var $ = function(id){
	var o = document.getElementById(id);
	return o;
};

function init() {
	showInfo();
}

function showInfo() {
	var voipCfg = new DataAccess("voipconfig.properties");
	var phoneNumbe = voipCfg.get("login_phonenum");// "+862525004442";//登陆电话号码
	$("userNum").innerText = phoneNumbe.substr(5, phoneNumbe.length);
	
	var STBNumber = SysInfo.STBSerialNumber;
	$("devNum").innerText = STBNumber;
	
	var CANumber = "";
	if (TFCA.pairedStatus != 2) {
		CANumber = CA.serialNumber;
	}
	$("cardNum").innerText = CANumber;
}

var suerPos = 0, isSuer = false;
function showConfirmDiv(_tips) {
	isSuer = true;
	$('delContact').style.visibility = "visible";
	$('tipCont').innerText = _tips;
}

function doEnter() {
	showConfirmDiv("确定进行配对吗？");
}

function keyExist(){
	
}

function getPairedStatus() {
	var pairedValue = TFCA.pairedStatus;
	switch (pairedValue) {
		case 1 :
			pairedInfo = "当前机卡已配对";
			break;
		case 2 :
			pairedInfo = "无智能卡或无效卡";
			break;
		case 3 :
			pairedInfo = "智能卡没有对应任何机顶盒";
			break;
		case 4 :
			pairedInfo = "智能卡已经和其他机顶盒配对";
			break;
		default :
			pairedInfo = "系统错误，暂时无法检测机卡绑定信息！";
			break;
	}
	$("tipCont").innerText = pairedInfo;
	setTimeout(function(){
		window.location.href = "connect.htm";
	},3000);
}

function confirmEvent(evt) {
	var keyCode = evt.which || evt.keyCode;
	switch (keyCode) {
		case 37:
		case 39:
			$('del_' + suerPos).className = "";
			suerPos = (suerPos + 1 )% 2;
			$('del_' + suerPos).className = "current";
			break;
		case 13:
			if (suerPos == 0) {
				getPairedStatus();
			} else {
				isSuer = false;
				$('del_' + suerPos).className = "";
				suerPos = 0;
				$('del_' + suerPos).className = "current";
				$('delContact').style.visibility = "hidden";
				$('tipCont').innerText = "";
			}
			break;
	}
}

document.onkeypress = function(evt) {
	var keyCode = evt.which || evt.keyCode;
	evt.preventDefault();
	
	if (isSuer) {
		confirmEvent(evt);
		return;
	}
	
	switch(keyCode) {
		case 13:
			doEnter();
			break;
		case 27: //退出键
		case 114:
			keyExist();
	}
}