var record;
var phoneData;

var menuListView,detailListView,editListView;
var detailText = [],editText = [];
var area = 0;
var operPos = 0;
var oper = 1;

function NJViopList(pageSize, iterator, onFocusMove, onFocus, onBlur, onNoData, focusId, focusTop, focusStep){
	List.call(this, pageSize, iterator, onFocusMove, onFocus, onBlur, onNoData, focusId, focusTop, focusStep);
}

NJViopList.prototype = new List();

NJViopList.prototype.up = function(){
	if (this.length == 0) return;
	var oldFocusIndex = this.currIndex % this.pageSize;
	var oldIndex = this.currIndex;
	this.currIndex--;
	this.pageUpdate = false;
	if (this.totalPage > 1 && oldFocusIndex == 0) {
		this.pageUpdate = true;
	}
	
	if (this.currIndex <= 0) {
		this.currIndex = 0;
	}
	
	var newIndex = this.currIndex;
	var newFocusIndex = this.currIndex % this.pageSize;
	this.focusIndex = newFocusIndex;
	
	if (this.pageUpdate) {
		this.currPage = Math.ceil((this.currIndex + 1) / this.pageSize);
		this.showList();
	}
	this.onFocusMove(oldFocusIndex, newFocusIndex, oldIndex, newIndex);
}

function hideDelTip(){
	$('del_' + delPos).className = "";
	delPos = 0;
	$('del_' + delPos).className = "current";
	$('delContact').style.visibility = "hidden";
	$('tipCont').innerText = "";
	
	area = 0;
	detailListView.setBlur();
	menuListView.setFocus();
}

function confirmEvent(evt) {
	switch (evt.code) {
		case "KEY_LEFT":
		case "KEY_RIGHT":
			$('del_' + delPos).className = "";
			delPos = (delPos + 1 )% 2;
			$('del_' + delPos).className = "current";
			break;
		case "KEY_ENTER":
			if (delPos == 0) {
				deleteRcd();
				hideDelTip();
			} else {
				isDel = false;
				hideDelTip();
			}
			break;
	}
}

function eventHandler(evt) {
	if (isDel) {
		confirmEvent(evt);
		return;
	}
	
	switch(evt.code) {
		case "KEY_UP":
			switch (area) {
				case 0:
					if(menuListView.currIndex != 0){
						menuListView.up();
					}else{
						$("list_" + menuListView.focusIndex).className = "blur";
						area = 3;
						UDChg();
					}
					$("po_0").innerHTML = menuListView.currPage;
					break;
				case 1:
					break;
				case 2:
					operPos--;
					if (operPos < 0) {
						operPos = 3;
					}
					operListFocus();
					break;
				case 4:
					area = 1;
					detailListView.setBlur();
					$("detailList_0").className = "more";
					break;
			}
			break;
		case "KEY_DOWN":
		    switch(area){
				case 0:
					menuListView.down();
					$("po_0").innerHTML = menuListView.currPage;
				break;
				case 1:
					$("detailList_0").className = "";
					detailListView.setFocus();
					area = 4;
				break;
				case 3:
					area = 0;
					$('oper_' + oper).className = "oper_" + oper;
					if(oper != 1){
						oper = 1;
					}
					$('oper_1').className = "oper_1_current1";
					UDChg();
				break;
			}
			break;
		case "KEY_LEFT":
			if (area != 4) {
				leftRight(-1);
			}else{
				detailListView.up();
			}
			break;
		case "KEY_RIGHT":
			if (area != 4) {
				leftRight(1);
			}else{
				detailListView.down();
			}
			break;
		case "KEY_ENTER":
			doEnter();
			break;
		case "KEY_PAGE_UP":
			menuListView.pageUp();
			$("po_0").innerHTML = menuListView.currPage;
			break;
		case "KEY_PAGE_DOWN":
			menuListView.pageDown();
			$("po_0").innerHTML = menuListView.currPage;
			break;
		case "KEY_EXIT":
			window.location.href = datas[8].menuPic[5].url;
		break;
		case "KEY_BACK":
			window.location.href = "connect.htm";
			break;
		default:
			break;
	}
}

var photos = [];
function initPhoto(){
	var voipCfg = new DataAccess("voipconfig.properties");
	var photoNums = voipCfg.get("USER_DEFAULT_PHOTOS") == "" ? 5 : voipCfg.get("USER_DEFAULT_PHOTOS");
	for(var i = 0; i < photoNums; i++){
		var userPt = {blr:"",fcs:""};
		userPt.blr = "images/photo/photo" + i + "_blur.png";
		userPt.fcs = "images/photo/photo" + i + "_focus.png";
		photos.push(userPt);
	}
}

function init() {
	var voipDa = new DataAccess("voipconfig.properties");
	var phoneStr = voipDa.get("login_phonenum");
	$("phone_num").innerText = phoneStr.length == 13 ? phoneStr.substr(5) : phoneStr.substr(3);
	
	var filePath = Utility.getEnv("STB.systemPath")+"/config/phonebook.txt";
	record = new VoipRecord(filePath);
	record.make();
	phoneData = record.data;
//	phoneData = [{name:"test1",cellPhone:"15112368468",photo:"0"},
//                  {name:"test2",cellPhone:"15112368469",photo:"1"},
//                  {name:"test3",cellPhone:"15112368461",photo:"2"},
//                  {name:"test4",cellPhone:"15112368462",photo:"3"},
//                  {name:"test5",cellPhone:"15112368463",photo:"4"},
//                  {name:"test6",cellPhone:"15112368464",photo:"0"},
//                  {name:"test7",cellPhone:"15112368465",photo:"1"},
//                  {name:"test8",cellPhone:"15112368466",photo:"2"}];
	initText();
	menuListView = new NJViopList(7, showMenu, onFocusMove, onFocus, onBlur);	
	menuListView.bindData(phoneData,0);
	menuListView.setFocus();
	
	$("po_0").innerHTML = menuListView.currPage;
	$("po_1").innerHTML = menuListView.totalPage;
	
	detailListView = new List(3, "", onFocusMoveDetail, onFocusDetail, onBlurDetail);	
	detailListView.bindData(detailText,0);
	detailListView.setBlur();
	
	initPhoto();
	
	showDetailName();
}

function initText() {
	detailText = [
		{name:"新增:"},
		{name:"编辑:"},
		{name:"删除:"}
	];
}

function showMenu(item, index, focusIndex) {
	$("list_" + focusIndex).innerText = item ? item.name : "";
}

function onFocusMove(oldPos, newPos) {
	if(menuListView.length <= 1) {
		$("list_" + oldPos).className = "current";
		$("list_" + newPos).className = "current";
	} else {
		$("list_" + oldPos).className = "";
		$("list_" + newPos).className = "current";
	}
	showDetailName();
}

function onFocus(index) {
	$("list_" + index).className = "current";
}

function onBlur(index) {
	$("list_" + index).className = "";
}

function showDetail(item, index, focusIndex) {
	showDetailName();
}

function showDetailName() {
	$("detailText_0").innerText = phoneData[menuListView.currIndex].name ? phoneData[menuListView.currIndex].name : "";
	$("detailText_1").innerText = phoneData[menuListView.currIndex].cellPhone ? phoneData[menuListView.currIndex].cellPhone : "";
	$("contacPic").src = photos[phoneData[menuListView.currIndex].photo - 0].fcs;
}

function onFocusMoveDetail(oldPos, newPos) {
	$("detailOper_" + newPos).className = "editFocus";
	$("detailOper_" + oldPos).className = "";	
}

function onFocusDetail(index) {
	$("detailOper_" + index).className = "editFocus";
}

function onBlurDetail(index) {
	$("detailOper_" + index).className = "";
}

function operListFocus(){
	var listTopN;
	listTopN = 152 + operPos * 71;
	$("listFocus").style.top = listTopN + "px";
}

function UDChg(){
	if(area == 3){
		$('oper_' + oper).className = "oper_" + oper + "_current";
	}else {
		menuListView.setFocus();
	}
}

function LRChg(){
	if(area == 0){
		menuListView.setFocus();
		$("detailList_0").className = "";
	}
	
	if(area == 1){
		menuListView.setBlur();
		if (phoneData.length > 0) {
			$("list_" + menuListView.focusIndex).className = "blur";
			$("detailList_0").className = "more";
		}else{
			area = 4;
			detailListView.setFocus();
		}
	}
	
	if(area == 2){
		if (phoneData.length > 0) {
			$("detailList_0").className = "";
			$("operFocus").style.visibility = "visible";
			$("operConFcs").style.color = "#000";
		}else{
			area = 1;
		}
	}else {
		$("operFocus").style.visibility = "hidden";
		$("operConFcs").style.color = "#fff";
	}
	
	if(area == 3){
		$('oper_' + oper).className = "oper_" + oper + "_current";
	}
}

function leftRight(type){
	if(area != 3){
		area += type;
		if(area < 0) area = 0;
		if (phoneData.length > 0) {
			if (area > 2) area = 2;
		} else {
			if (area > 1) {
				area = 1;
				return;
			}
		}
	}else {
		$('oper_' + oper).className = "oper_" + oper;
		oper += type;
		if (oper > 2) {
			oper = 2;
		}else if(oper < 0){
			oper = 0;
		}
	}
	LRChg();
}

Array.prototype.delArr = function(dx){
     if(isNaN(dx) || dx > this.length){
     	return false;
     }
     this.splice(dx,1);
}

function deleteRcd(){
	record.del(menuListView.currIndex,1);
	record.save();
	
	area = 0;
	
	menuListView.setBlur();
	menuListView.bindData(record.data,0);
	menuListView.setFocus();
	
	$("po_0").innerHTML = menuListView.currPage;
	$("po_1").innerHTML = menuListView.totalPage;
	
	detailListView.setBlur();
	
	showDetailName();
	
	isDel = false;
}

var delPos = 0, isDel = false, sec=6, secTimer=-1;
function showConfirmDiv(_tips) {
	isDel = true;
	$('delContact').style.visibility = "visible";
	$('tipCont').innerText = _tips;
}

function doEnter() {
	switch(area){
		case 2:
			var num = phoneData[menuListView.currIndex].cellPhone;
			if (menuListView.length > 0 && num.length > 0) {
				location.href = "connect.htm?type=call&vedioType=vdCall&phnNum=" + num;
			}
		break;
		case 3:
			switch(oper){
				case 0:
					location.href = "connect.htm";
				break;
				case 1:
					window.reload();
				break;
				case 2:
					location.href = "record.htm";
				break;
			}
		break;
		case 4:
			switch(detailListView.currIndex){
				case 0:
					window.location.href = "contacts_edit.htm?type=add&phnNum=+86";
				break;
				case 1:
					if (menuListView.length > 0) {
						location.href = "contacts_edit.htm?id=" + menuListView.currIndex + "&type=edit";
					}
				break;
				case 2:
					if (menuListView.length > 0) {
						showConfirmDiv("确定删除该联系人吗？");
					}
				break;
			}
			break;
	}
}

function keyBack() {
	if(area == 1) {
		area = 0;
		$("phoneBookId").style.visibility = "visible";
		$("phoneDetailId").style.visibility = "hidden";
		$("editPhoneId").style.visibility = "hidden";
	} else if(area == 2) {
		area = 1;
		$("phoneBookId").style.visibility = "hidden";
		$("phoneDetailId").style.visibility = "visible";
		$("editPhoneId").style.visibility = "hidden";	
	}
}

function exitPage() {
	record.save();
}