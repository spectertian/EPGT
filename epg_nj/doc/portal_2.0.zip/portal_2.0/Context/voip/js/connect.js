var pos = 0, p = null;

var locString = String(location.href);
function getParams(url){
	var queryString = url.substr(url.indexOf("?") + 1);
	if (queryString == "") return;
	var requests = [];
	var params = queryString.split("&");
	for (var i = 0; i < params.length; i++) {
		var temp = params[i].split("=");
		if (temp.length < 2) return;
		requests[temp[0]] = temp[1];
	}
	if (params.length == 0) {
		var temp = queryString.split("=");
		if (temp.length < 2) return;
		requests[temp[0]] = temp[1];
	}
	return requests;
}

var listid = parseInt(getParams(locString)["id"]);
var phoneID = getParams(locString)["phone"];
var homeID = getParams(locString)["home"];
var officeID = getParams(locString)["office"];

// call
var callTypeNum = false;
var from = true;
var callType = getParams(locString)["type"];

var vedioType = getParams(locString)["vedioType"];
var viopPhone = getParams(locString)["viopPhone"];
var pNumber = getParams(locString)["phnNum"];
var startTime = new Date();;
var myDate;
var endTime;
var isConnect = false;
var record;

// 焦点
var isLeft = false;
var vertical = 0;
var area = 0;
var isNum = false, num = 0;
var isFun = false, fun = 0;
var numEntC = 0, funEntC = 0;
oper = 0;

var voipCfg = new DataAccess("voipconfig.properties");
var isLogin = VideoPhone.getOnlineState() == 1 ? true : false;

if (!isLogin) {
	VideoPhone.login();
	startCheckLogin();
}

function startCheckLogin() {
	if (isLogin) {
		Utility.println("-------login success, so change user status to online-");
		$("userStatus").innerHTML = "在线";
		$("userStatus").className = "status";
		return;
	}
	isLogin = VideoPhone.getOnlineState() == 1 ? true : false;
	Utility.println("-------isLogin-"+isLogin);
	setTimeout("startCheckLogin()", 1000);
}

var isPhone = false;

var peakOrDailNum = "unknowned";

/*
 * 继承和复写find方法
 */
function ContactRecord(filePath, vRMaxLen){
	VoipRecord.call(this, filePath, vRMaxLen);
}

ContactRecord.prototype = new VoipRecord();

ContactRecord.prototype.find = function(phoneNum){
    for (var index = 0; index < this.length; index++) {
        if (phoneNumEqual(this.data[index].cellPhone, phoneNum)) { 
            return index; 
        }
    }
    return -1;
}
var mute = false;
var volume = 16;

function getTermInfo(reason) {
	var info = "";
	switch (reason) {
		case 24:
			info += "对方忙...";
			break;
		case 3:
			info += "被禁止呼叫此号码...";
			break;
		case 23:
			info += "没人接听...";
			break;
		case 4:
		case 11:
			info += "对方号码不存在...";
			break;
		case 1:
			info += "没有权限呼叫,本地号码或者登陆密码错误...";
			break;
		case 5:
			info += "呼叫被拒绝...";
			break;
		case 6:
			info += "呼叫参与者临时不可用...";
			break;
		case 7:
			info += "呼叫请求被中止...";
			break;
		case 8:
			info += "服务器内部错误...";
			break;
		case 9:
			info += "服务不可用...";
			break;
		case 10:
			info += "邀请超时...";
			break;
		case 11:
			info += "没有此用户...";
			break;
		case 12:
			info += "其他错误...";
			break;
		case 22:
			info += "取消通话...";
			break;
		case 23:
			info += "呼叫超时...";
			break;
		case 24:
			info += "对方忙...";
			break;
		case 25:
			info += "对方拒绝通话...";
			break;
		case 26:
			info += "通话转移...";
			break;
		case 27:
			info += "通话重定向...";
			break;
		case 21:
			info = "通话结束...";
			break;
		default:
			info += "("+reason+")"+"通话结束...";
			break;
	}
	
	return info;
}

function eventHandler(evt){
	switch (evt.code) {
		case "KEY_LEFT":
			movePos(2);
			break;
		case "KEY_RIGHT":
			movePos(3);
			break;
		case "KEY_UP":
			movePos(0);
			break;
		case "KEY_DOWN":
			movePos(1);
			break;
		case "KEY_ENTER":
			doEnter();
			break;
		case "KEY_EXIT":
		case "KEY_BACK":
			window.location.href = datas[8].menuPic[5].url;
			break;
		case "KEY_PAUSE":
            p.del();
			break;
		case "KEY_RED":// contacts
			window.location.href = "contacts.htm";
			break;
		case "KEY_YELLOW":// record.htm
			window.location.href = "record.htm";
			break;
		case "KEY_PAGE_UP":// CALL
			if (!p.callFlag && p.number.length > 0) {
				p.callFlag = true;
				from = false;
				setFocus();
				////initVideo();
				
				var index = contact.find(p.number);
				if(index >= 0){
					$("userPic").src = photos[contact.data[index].photo].blr;
				}
				peakOrDailNum = p.number;
				p.call();
			}
			break;
		case "KEY_PAGE_DOWN":// CALL
			if (p.callFlag) {
				setFocus();
				videoPhoneBye();
			}
			break;
		case "KEY_NUMERIC":
			keyNumeric(evt.param);
			break;
		case "KEY_#":
			bu();
			num = 14;
			fo();
			p.input('#');
			break;
		case "KEY_*":
			bu();
			num = 12;
			fo();
			p.input('*');
			break;
		case "KEY_GREEN":
			window.location.href = "login.htm";
			break;
		case "VOIP_CALLING":
			$('status').innerText = "拔号中...";
			startTime = new Date();
			break;
		case "VOIP_CALL_SUCCESS":
			$('status').innerText = "对方已响铃...";
			break;
		case "VOIP_CONNECT":
			startTime = new Date();
			isConnect = true;
			initVideo();
			break;
		case "VOIP_CALL_REFUSE":
			var evtstr = DVB.getEvent(40508, evt.messageId);
			Utility.println("-----evtstr = "+evtstr);
			var jsonObj = eval('(' + evtstr + ')');
			var reason = jsonObj.reason;
			var name = "", len = 0 ,temp, timers = "00:00:00";
			var recordData = {type:"",num:"",date:"",times:""};
			
			endTime = new Date();
			
			if (isConnect) {
				temp = Math.floor(parseInt(endTime - startTime) / 1000);
				timers = $G.leftPadStr(Math.floor(temp / 3600), '0', 2) + ":" + $G.leftPadStr(Math.floor(temp % 3600 / 60), '0', 2) + ":" + $G.leftPadStr(Math.floor(temp % 3600 % 60), '0', 2);
				recordData.date = $G.dateFormat(startTime, "yyyy-MM-dd hh:mm");
			}else {
				recordData.date = $G.dateFormat(endTime, "yyyy-MM-dd hh:mm");
			}
						
			recordData.type = from ? "0" : "1";

			var pdNum = cutNumber(peakOrDailNum);
			
			recordData.num = pdNum;
			
			recordData.times = timers;
			record.add(recordData);
			record.save();
			
			if (p.callFlag) {
				$('head').style.visibility = "visible";
	            $('localVedioPic').style.visibility = "visible";
				$('opposite_video').style.visibility = "visible";
				$('status').innerText = getTermInfo(reason);
				
				setTimeout("$('status').innerText = '';", 3000);
			}
			p.cancel();
		break;
		case "VOIP_ANSWER" :
			isPhone = true;
		break;
		case "VOIP_NUM":
			var evtstr = DVB.getEvent(40517, evt.messageId);	
			var jsonObj = eval('(' + evtstr + ')');
			if (isLogin) VideoPhone.tone(jsonObj.nKeyVal);
		break;
		case "KEY_MUTE":
			var mp = new MediaPlayer();
			mute = !mute;
			if (mute) {
				volume = mp.getVolume();
				mp.setVolume(0);
			} else {
				mp.setVolume(volume);
			}
		break;
}

function movePos(_pos){
	switch (_pos) {
		case 0://up
			bu();
			vertical--;
			if (vertical < -2) {
				vertical = -2;
			}
			if (vertical == -1) {
				if (isLogin) {
					vertical = -2;
				} else {
					area = 2;
					num = -3;
				}
			}
			
			if (vertical == -2) {
				area = 3;
				if(oper != 0){
					oper = 0;
				}
				$('oper_0').className = "oper_0_current";
				if(isLogin){
					$("userStatus").innerHTML = "在线";
				}else {
					$("userStatus").className = "login_blur";
				}
			}
			
			if (vertical < 5 && vertical > -1) {
				area = 0;
				num -= 3;
				if (num <= 0) num = 0;
			}
			fo();
			break;
		case 1://down
			bu();
			vertical++;
			if (vertical == -1) {
				if (isLogin) {
					vertical = 0;
					num = -3;
				} else {
					area = 2;
					num = -3;
				}
				if(oper != 0){
					oper = 0;
				}
				$('oper_0').className = "oper_0_current1";
			}
			if (vertical < 5 && vertical > -1) {
				area = 0;
				num += 3;
				if (num > 14) {
					num = 14;
				}
				if(isLogin){
					$("userStatus").innerHTML = "在线";
				}else {
					$("userStatus").className = "login_blur";
				}
			}
			fo();
			break;
		case 2://left
			bu();
			switch(area){
				case 0:
					if (num-- <= 0) {
					num = 14;
				}
				var numCurrentLine = Math.floor(num / 3);
				vertical = 0 + numCurrentLine;
				break;
				case 2:
				break;
				case 3:
					if (--oper < 0) 
					oper = 0;
				break;
			}
			fo();
			break;
		case 3://right
			bu();
			switch(area){
				case 0:
					if (++num > 14) 
					num = 0;
					var numCurrentLine = Math.floor(num / 3);
					vertical = 0 + numCurrentLine;
				break;
				case 2:
				break;
				case 3:
					if (++oper > 2) 
					oper = 2;
				break;
			}
			fo();
			break;
		}
	}
}

function keyNumeric(_num){
	var numCurrentLine = 0;
	isLeft = false;
	isNum = true;
	if(area == 1){
		bu();
		area = 0
		fun = 1;
	}
	if (_num == 0) {
		bu();
		num = 10;
		numCurrentLine = Math.floor(num / 3);
		vertical = 0 + numCurrentLine;
		fo();
	} else {
		bu();
		num = _num - 1;
		numCurrentLine = Math.floor(num / 3);
		vertical = 0 + numCurrentLine;
		fo();
	}
	p.input(_num);
	if (p.callFlag || callType == 'answer') {
		if (isLogin) VideoPhone.tone(_num+"");
	}
}

function videoPhoneBye() {
	Utility.println("---------------videoPhoneBye------------------");
	if (isLogin) VideoPhone.bye(callSessionID);
	callSessionID = -1;
	Utility.clearBrowserCache();
}

function doEnter(){
	switch(area){
		case 0:
			switch(num){
				case 9:
					p.input('*');
					if (p.callFlag){
						if (isLogin) VideoPhone.tone('*');
					}
				break;
				case 10:
					p.input(0);
					if (p.callFlag){
						if (isLogin) VideoPhone.tone("0");
					}
				break;
				case 11:
					p.input('#');
					if (p.callFlag){
						if (isLogin) VideoPhone.tone('#');
					}
				break;
				case 12:
				if (!p.callFlag && p.number.length > 0) {
					from = false;
					setFocus();
					peakOrDailNum = p.number;
					p.call();
					$('status').innerText = "正在呼叫对方...";
					var index = contact.find(p.number);
					if(index >= 0){
						$("userPic").src = photos[contact.data[index].photo].blr;
					}
				}
				break;
				case 13:
					p.del();
				break;
				case 14:
					if (p.callFlag) {
						videoPhoneBye();
					}
				break;
				default:
					p.input(num + 1);
					if (p.callFlag){
						if (isLogin) VideoPhone.tone(num + 1 + "");
					}
			}
		break;
		case 2:
			location.href = "login.htm";
		break;
		case 3:
			switch(oper){
				case 0:
					window.reload();
				break;
				case 1:
					location.href = "contacts.htm";
				break;
				case 2:
					location.href = "record.htm";
				break;
			}
		break;
	}
}

var Phone = function(_showId_0, _showId_1){
	this.number = getPhoneNum ? getPhoneNum : "";
	this.callFlag = false;
	this.showId_0 = _showId_0;
	this.showId_1 = _showId_1;
};

Phone.prototype = {
	call: function(){
		if (this.number.length > 0) {
			this.callFlag = true;
			var tempArr = this.number.split('\*');
			if (tempArr.length >= 4) { //IP
				var ip = '';
				for (var x in tempArr) {
					if (tempArr[x] != '') {
						ip += tempArr[x] + '.';
					}
				}
				this.number = ip.substring(0, ip.length - 1);
				this.show();
				if (isLogin) VideoPhone.callIP(this.number, 0);
			} else {
				if (isLogin) VideoPhone.call(this.number, 0);
			}
		}
	},
	del: function(){
		var num_len = this.number.length;
		if (num_len > 0) {
			this.number = this.number.substring(0, num_len - 1);
			this.show();
		}
	},
	cancel: function(){
		if (this.callFlag) {
			this.callFlag = false;
			videoPhoneBye();
		}
		this.number = '';
		this.show();
	},
	input: function(_num){
		this.number += _num.toString();
		this.show();
	},
	show: function(){
		var num_len = this.number.length;
		var showHtml = "";
		if (num_len > 12 && num_len <= 16) {
			showHtml = this.number.substring(0, 12) + '<br>' + this.number.substring(12, num_len);
		} else if (num_len > 16) {
			showHtml = '...' + this.number.substring(num_len - 15, num_len - 12) + '<br>' + this.number.substring(num_len - 12, num_len);
		} else {
			showHtml = this.number;
		}
		document.getElementById(this.showId_0).innerHTML = showHtml;
		if (this.showId_1 != undefined) {
			document.getElementById(this.showId_1).innerText = this.number;
		}
	}
};

function setFocus(){
	if(area != 0){
		area = 0;
	}
	bu();
	num = 14;
	vertical = 4;
	fo();
}

var phoneLength;
var getPhoneNum = "";
var filePath;

var contactPath;
var contact;

function initLgnStat(){
	if(!isLogin){
		$("userStatus").innerHTML = "";
		$("userStatus").className = "login_blur";
	}
}

var photos = [];
function initPhoto(){
	var voipCfg = new DataAccess("voipconfig.properties");
	var photoNums = voipCfg.get("USER_DEFAULT_PHOTOS") == "" ? 5 : voipCfg.get("USER_DEFAULT_PHOTOS");
	for(var i = 0; i < photoNums; i++){
		var userPt = {blr:"",fcs:""};
		userPt.blr = "images/photo/photo" + i + "_blur.png";
		userPt.fcs = "images/photo/photo" + i + "_focus.png";
		photos.push(userPt);
	}
}

function init(){
	var voipDa = new DataAccess("voipconfig.properties");
	var phoneStr = voipDa.get("login_phonenum");
	$("phone_num").innerText = phoneStr.length == 13 ? phoneStr.substr(5) : phoneStr.substr(3);
	
	Utility.setBrwMuteLogo(true);
	contactPath = Utility.getEnv("STB.systemPath")+"/config/phonebook.txt";
	contact = new ContactRecord(contactPath);
	contact.make();
	
	filePath = Utility.getEnv("STB.systemPath")+"/config/VoipRecord.properties";
	record = new VoipRecord(filePath);
	record.make();
	
	Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 101);
	
	initLgnStat();
	
	initPhoto();
	
	fo();
	
	if(listid == 0) {
		getPhoneNum = phoneID;
		phoneLength = phoneID.length; 
	} else if(listid == 1) {
		getPhoneNum = homeID;
		phoneLength = homeID.length;
	} else if(listid == 2) {
		getPhoneNum = officeID;
		phoneLength = officeID.length;
	} else if(listid == 5) {
		getPhoneNum = viopPhone;
		phoneLength = viopPhone.length;
	}
	var showHtml = "";
	if (phoneLength > 12 && phoneLength <= 16) {
		showHtml = getPhoneNum.substring(0, 12) + '<br>' + getPhoneNum.substring(12, phoneLength);
	} else if (phoneLength > 16) {
		showHtml = '...' + getPhoneNum.substring(phoneLength - 15, phoneLength - 12) + '<br>' + getPhoneNum.substring(phoneLength - 12, phoneLength);
	} else {
		showHtml = getPhoneNum;
	}
	$("input_number").innerHTML = showHtml;
	p = new Phone('input_number',"phoneNum");
	
	if (callType == 'answer') {
		p.number = pNumber;
		peakOrDailNum = p.number;
		
		var index = contact.find(p.number);
		if(index >= 0){
			$("userPic").src = photos[contact.data[index].photo].blr;
		}
		
		$("num_input_label").innerText = "来电号码";
		callSessionID = Number(getParams(locString)["callSessionID"]);
		VideoPhone.answer(callSessionID, 0);
		if("vcCall" == vedioType){
			p.show();
	    }
		setFocus();
	}
	if(callType == 'call'){
		from = false;
		p.number = pNumber;
		peakOrDailNum = p.number;
		
		var index = contact.find(p.number);
		if(index >= 0){
			$("userPic").src = photos[contact.data[index].photo].blr;
		}
		
//		initVideo();
		$('status').innerText = "拔号中...";
		if("vcCall" == vedioType){
			p.show();
	    }
		setFocus();
        p.call();
	}
	
	if(listid == 5) {
		$('status').innerText = "拔号中...";
		from = false;
		setFocus();
		peakOrDailNum = pNumber;
		p.call();
	}
}

function initVideo(){
	p.callFlag = true;
	Utility.println("++++++++++++++++vedioType = "+vedioType +"length = " + p.number+"callSessionID = "+callSessionID);
	if("vdCall" == vedioType || p.number.length < 11){
		$('head').style.visibility = "hidden";
		$('localVedioPic').style.visibility = "hidden";
		$('opposite_video').style.visibility = "hidden";
		if (isLogin) VideoPhone.setLocalVideoPos(callSessionID, 1145, 295, 440, 253);
		if (isLogin) VideoPhone.setRemoteVideoPos(callSessionID, 175, 295, 925, 692);
	}else{
		$('status').innerText = "正在通话中...";
	}
}

function exitPage(){
	if (p.callFlag && !isPhone) {
		videoPhoneBye();
	}
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 101);
}

function loginOrOper(_type){
	if (!isLogin) {
		$("userStatus").innerHTML = "";
		$("userStatus").className = "login";
	} else {
		switch (_type) {
			case 0:
				$("userStatus").innerHTML = "在线";
				$("userStatus").className = "status";
				break;
				
			case 1:
				$("userStatus").innerHTML = "";
				$("userStatus").className = "login";
				break;
		}
	}
}

function fo(){
	switch (area) {
		case 0:
			$('n_' + num).className = "current";
			break;
		case 1:
			$('f_' + fun).className = "current";
			break;
		case 2:
			loginOrOper(1);
			break;
		case 3:
			$('oper_' + oper).className = "oper_" + oper + "_current";
			break;
	}
}

function bu(){
	switch(area){
		case 0:
			$('n_' + num).className = "";
		break;
		case 1:
			$('f_' + fun).className = "";
		break;
		case 2:
			loginOrOper(0);
		break;
		case 3:
			$('oper_' + oper).className = "oper_" + oper;
		break;
	}
}
