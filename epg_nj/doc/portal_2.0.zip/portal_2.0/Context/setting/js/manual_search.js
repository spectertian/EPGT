﻿$L.init("setting");
var pos=0, numFlag=0, modulation=3, numId = ['freq_', 'sym_'], currFreq=0, currFreqSymbolRate=0, currFreqModulation=0, menuObj=new Object();
var searchTypePos = 0;
function eventHandler(evt){
	switch (evt.code) {
		case "KEY_ENTER":
			doEnter();
			break;
		case "KEY_UP":
			upDown(-1);
			break;
		case "KEY_DOWN":
			upDown(1);
			break;
		case "KEY_LEFT":
			leftRigth(-1);
			break;
		case "KEY_RIGHT":
			leftRigth(1);
			break;
		case "KEY_NUMERIC":
			input(evt.param);
			break;
		case "KEY_BACK":
			SysSetting.panelDisplayText("");
			window.location.href = 'channelSearch.htm?pos=1';
			break;
		case "KEY_EXIT":
			$G.exitToPlay();
			break;
	}
}
function init(){
	initTxt();
	SysSetting.panelDisplayText("SCAN");
	currFreq = Number($G.sysDa.get("SEARCH.frequency_0"))*1000;
	currFreqSymbolRate = Number($G.sysDa.get("SEARCH.symbol_0"));
	modulation = Number($G.sysDa.get("SEARCH.modulation_0"));
	currFreqModulation = modulation;
	initDelivery();
	Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 57);
	
}
function initTxt(){
	var textArr = {
		menuTitle:($L.SYS_SET + "—" + $L.LIST_NAME_1 + "—" + $L.Manual_search),
		tips:$L.SEARCH_TIPS,
		btn:$GL.OK
	};
	for(var id in textArr){
		$(id).innerText = textArr[id];
	}
	
	var menu = [$L.s_0,$L.s_1,$L.s_2];	
	menuObj = new List(3, onShow, onFocusMove, onFocus, onBlur);
	menuObj.bindData(menu, pos);
	menuObj.setFocus();
	$(numId[pos]+numFlag).style.textDecoration = "underline";
}
function initDelivery(){
	var deliveryArr = [{val:$G.leftPadStr(currFreq, "0", 6), pre:"freq_"}, {val:$G.leftPadStr(currFreqSymbolRate, "0", 4), pre:"sym_"}];
	for(var i=0,j=deliveryArr.length; i<j; i++){
		for(var x=0,y=deliveryArr[i].val.length; x<y; x++){
			$(deliveryArr[i].pre+x).innerText = deliveryArr[i].val[x];
		}
	}
	$('modual').innerText = (16*Math.pow(2,modulation-1));
}
function doEnter(){
	if(pos==3){
		var fre = $('freq_0').innerText +  $('freq_1').innerText +  $('freq_2').innerText + "." + $("freq_3").innerText + $("freq_4").innerText + $("freq_5").innerText;
		var sym = $('sym_0').innerText +  $('sym_1').innerText +  $('sym_2').innerText +  $('sym_3').innerText;
		window.location.href = "auto_search.htm?searchType=0&frequency=" + fre + "000&symbolRate=" + sym + "&modulation=" + modulation + "&searchTypePos=" + searchTypePos;
	}
}
function upDown(_type){
	if(pos == 3){
		$("btn").className = "";
	} else {
		$(numId[pos]+numFlag).style.textDecoration = "";
		$("list_" + pos).className = "";
	}
	pos = (pos+_type+4)%4;
	numFlag=0;
	if (pos == 3) {
		$('btn').className = "focus";
	} else {
		$("list_" + pos).className = "current";
		$(numId[pos] + numFlag).style.textDecoration = "underline";
	}
}
function leftRigth(_type){
	switch(pos){
		case 0:
		case 1:
			$(numId[pos]+numFlag).style.textDecoration = "";
			numFlag=(numFlag+_type+pos + 6)%(pos + 6);
			$(numId[pos]+numFlag).style.textDecoration = "underline";
			break;
		case 2:
			modulation += _type;
			if(modulation > 5){
				modulation=3;
			}else if(modulation < 3){
				modulation = 5;
			}
			$('modual').innerText = (16*Math.pow(2,modulation-1));
			break;
	}
}
function input(_num){
	if (pos < 2) {
		$(numId[pos] + numFlag).innerText = _num;
		$(numId[pos] + numFlag).style.textDecoration = "";
		numFlag = (numFlag + 1) % (pos + 6);
		$(numId[pos] + numFlag).style.textDecoration = "underline";
	}
}

function onShow(_item, _index, _focusIndex) {
	if(_item){
		$('listTitle_' + _focusIndex).innerText = _item;
	}else{
		$('listTitle_' + _focusIndex).innerText = "";
	}
}
function onFocusMove(_oldFocusIndex, _newFocusIndex){
	$('list_' + _newFocusIndex).className = "current";
}
function onFocus(_focusIndex) {
	$('list_' + _focusIndex).className = "current";
}
function onBlur(_focusIndex) {
	$('list_' + _focusIndex).className = "";
}
function exitPage(){
	Utility.setEnv("recoverUpdate", "stopUpdate");
	SysSetting.panelDisplayText("");
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 57);
}