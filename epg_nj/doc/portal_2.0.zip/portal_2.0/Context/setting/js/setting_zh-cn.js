/**
 * 有线搜索(menu_set.htm、menu.htm.htm、search_manual.htm)
 */
var manual_search = "手动搜索";
$L.extend({
	
	HOME_0:"开机设置：",
	HOME_1:"彩色电视制式：",
	
    PROG_NAME: "节目指南",
    INFO_TITLE: "内容简介",
    INFO_TIPS: "【后退】键返回",
    CURR_TIP: "【↑↓】键移动，【1】键取消当前预约，【2】取消所有预约",
    //当前预告
    PROG_NAME_0: "当前预告",
    PROG_NAME_1: "一周预告",
    PROG_NAME_2: "分类预告",
    PROG_NAME_3: "所有频道",
    PROG_NAME_4: "喜爱频道",
    PROG_NAME_5: "预约管理",
    
    TV_NUM: "电视号：",
    TV_ATTR: "归属地：",
    
    PROG_CHOICE: "供选频道",
    
    FAV_0: "【确认】键切添加频道，方向键切换，【1】键删除一个频道",
    FAV_1: "【2】键删除所有频道，【上下页】键翻页，【返回】键退出",
    
    TIP_0: "F1   当天预告",
    TIP_1: "F2   一周预告",
    TIP_2: "F3   分类预告",
    TIP_3: "F4   预约管理",
    
    DATE: "日期",
    PLAY_TIME: "播出时间",
    
    CHANNEL: "频道",
    PROGRAM: "节目",
    TIME: "时间",
    STATUS: "状态",
    
    PROG_TIPS_0: "【↑↓】键 移动，【←→】 键进入单频道浏览，",
    PROG_TIPS_1: "表示节目已预约",
    PROG_TIPS_2: "【信息】键查看内容简介，【确认】键预约",
    PROG_TIPS_3: "表示节目有内容简介",
    PROG_TIPS_4: "数字键1-7选星期，",
    
    SEARCH_TIPS: "【0~9】键输入，【确认】键搜索，【后退】键返回",
    
    AV_0: "视频输出格式：",
    AV_1: "视频输出制式：",
    AV_3: "样式比例：",
    AV_4: "声道控制方式：",
    AV_5: "声音控制方式：",
    AV_6: "声音设置：",
    AV_7: "声道设置：",
    
    SIGNAL_TXT_0: "信号电平等级：",
    SIGNAL_TXT_1: "误码率：",
    SIGNAL_TXT_2: "信号质量：",
 	   
    SOFTWARE_TIP_0: "未检测到OTA升级信息",
    SOFTWARE_TIP_1: "已检测到新版本信息，是否进行升级 ？",
    SOFTWARE_TIP_2: "升级成功^_^",
    SOFTWARE_TIP_3: "升级失败-_-",
    SOFTWARE_TIP_4: "检测升级中,请稍后……",
    BTN_TITLE: "开始升级",
    
    SYS_TIPS: '【↑↓】键移动，【确认】键进入，【后退】键返回',
    
    LIST_NAME_0: "父母控制",
    LIST_NAME_1: "节目搜索",
    LIST_NAME_2: "条件接收",
    LIST_NAME_3: "系统配置",
    LIST_NAME_4: "系统信息",
    LIST_NAME_5: "系统更新",
    LIST_NAME_6: "节目管理",
    LIST_NAME_7: "预约管理",
	LIST_NAME_8: "待机选择",
    
    SET_0: "通道设置",
    SET_1: "视音频设置",
    SET_2: "显示设置",
    SET_3: "双向设置",
    SET_4: "信号检测",
    
    GWNAME_0: "数据广播通道设置",
    GWNAME_1: "应用下载通道设置",
    GWNAME_2: "股海淘金通道设置",
    GWNAME_3: "点播剧院通道设置",
    GWNAME_4: "系统更新通道设置",
    GWNAME_5: "自动搜索通道设置",
    
    DISPLAY_0: "语言设置：",
    DISPLAY_1: "菜单透明度：",
    DISPLAY_2: "菜单亮度：",
    DISPLAY_3: "信息条显示时间：",
    
    CARD_MONEY: "智能卡授权信息",
    OPERATOR_NAME: "运营商名称",
    WALLET_ID: "钱包ID号",
    AMOUNT: "消费金额",
    REMAIN_SUM: "剩余金额",
    MONEY_TIPS: "【确认】键查看IPPV节目信息",
    PIN_TIPS: "按数字键输入本机PIN码完成机顶盒绑定",
    GW_Pro_0: "频率(MHz)：",
    GW_Pro_1: "符号率(KS/s)：",
    ENTITLE_ID:"产品ID",
	ENTITLE_STATUS:"产品状态",
	ENTITLE_TIME:"授权结束时间",
	SLEEP_OPEN:"开启",
	SLEEP_CLOSE:"关闭",
    
    //-- menu_set.htm、menu.htm、search_manual.htm --
    SYS_SET: "系统设置",
    MENU_PROPERTY: "菜单属性",
    //-- menu_set.htm --
    LAN_SET: "语言设置",
    TRANSPARENCY_SET: "透明度设置",
    SYS_SETTING: "系统配置",
    EPG_TITLE: "节目指南",
    //-- menu.htm --
    PRO_MANAGE: "节目管理",
    LOCAL_SETUP: "本机设置",
    NETWORK_SET: "网络设置",
    SYS_INFO: "系统信息",
    CA_INFO: "CA信息",
    PROGRAM_SEARCH: "节目搜索",
    HD_EDIT: "高清节目编辑",
    SD_EDIT: "标清节目编辑",
    RADIO_EDIT: "广播频道编辑",
    ORDER_MANAGE: "预定管理",
    AV_SET: "音视频设置",
    PARENTS_LOCK: "父母锁",
    PSW_SET: "密码设置",
    FACTORY_SET: "恢复出厂设置",
    SOFT_UPGRADE: "软件升级",
    IP_SET: "IP设置",
    GATEWAYTEST_SET: "网关测试",
    SERVER_SET: "服务器设置",
    STB_INFO: "机顶盒信息",
    ADULT_SET: "成人级设置",
    CARD_INFO: "智能卡信息",
    LOCAL_PSW: "本机密码",
    INPUT_PSW: "请输入本机密码:",
    RESET_CONFIRM: "系统参数恢复到初始状态，设置将会全部清空，是否继续？",
    RESETTING: "正在恢复初始设置，请注意不要断电！",
    TO_SEARCH: "系统已恢复完成,是否进行自动搜索，按确定进行自动搜索，否则按取消返回！",
    OP_INFORMATION: "运营商信息",
    Mailing_list: "邮件列表",
    
    //-- search_menu.htm、search_manual.htm --
    AUTO_SEARCH: "自动搜索",
    MANUAL_SEARCH: manual_search,
    
    //-- search_menu.htm --
    ALL_SEARCH: "全频道搜索",
    FREQUERCY_SET: "频点设置",
    PRO_SEARCH: "节目搜索",
    TIPS_CONTENT: "如果改动此设置，请联系广电网络！",
    UP_DOWN: "上/下一个菜单",
    
    //-- search_manual.htm --
    START_SEARCH: "开始搜索",
    SIGNAL_LEVEL: "信号等级",
    SIGNAL_QUALITY: "信号质量",
    s_0: "频率(MHz)：",
    s_1: "符号率(KS/s)：",
    s_2: "调制方式(QAM)：",
    
    //-- search_all.htm --
    START: "起始",
    END: "结束",
    ALL_SEARCH_1: "全频道搜索",
    
    CA_BT_0: "设置配对",
    CA_BT_1: "退出界面",
    
    //-- search.htm --
    CURR_SEARCH: "当前搜索到：",
    PER: "个",
    BROADCAST: "数据广播",
    SEARCH_PROGRESS: "搜索进度",
    SEARCHING: "正在搜索中...",
    CURR_DELIVERY: "当前频点信息为：",
    STOP_SEARCH: "搜索完成",
    
    //-- hd_program_edit.htm、program_edit.htm --
    PRO_NUM: "节目号",
    PRO_NAME: "节目名称",
    
    //-- av_set.htm --
    ASPRCT_RATIO: "外观比例",
    RATE: "场频",
    RESOLUTION: "分辨率",
    DEF_TRACK: "默认声道",
    SPDIF: "SPDIF",
    
    //-- pg_level.htm --
    SET_PARENTS: "设置父母锁级别",
    CURR_PARENTS: "当前父母锁级别",
    
    //-- password_edit.htm --
    PSW_CONTROL: "密码控制",
    PSW_INPUT: "请输入新密码",
    PSW_CONFIRM: "请确认新密码",
    VALID: "有效",
    INVALID: "无效",
    MOFIDY_SUCCESS: "两次输入密码一致,修改成功",
    RE_INPUT: "两次输入密码不一致,请重新输入!",
    
    //-- ip_config.htm --
    NETWORK_MODE: "网络模式:",
    IP_ADDR: "IP地址:",
    SUBNET_MASK: "子网掩码:",
    GATEWAY: "默认网关:",
    MASTER_DNS: "主DNS:",
    BACKUP_DNS: "备用DNS:",
    DYNAMIC: "动态获取",
    MANUAL: "手动设置",
    INPUT_NUM: "【0~9】键输入",
    IP_TITLE: "IP设置",
    APP_DETAIL:"应用信息",
    APP_DEPLOY_BACKDOOR:"单向应用部署后门",
    
    MAC: "MAC地址",
    IP_GETMETHOD: "IP获取方式",
    
    
    
    //-- server_config.htm --
    EPG_SERVER: "EPG服务器:",
    AUTH_SERVER: "认证服务器:",
    VOD_SERVER: "VOD服务器:",
    BACK_VOD_SERVER: "备份VOD服务器:",
    DOWNLOAD_HTTP: "HTTP服务器:",
    DOWNLOAD_UDP: "下载服务器(UDP):",
    
    //-- info_stb.htm --
    STB_MODE: "机顶盒型号:",
    HARDWARE_VER: "硬件版本:",
    FLASH_SIZE: "内存大小: ",
    LOADER_VERSION: "Loader版本: ",
    SOFTWARE_VER: "软件版本:",
    BROWSER_VER: "浏览器版本号: ",
    SOFTWARE_ISSUE: "软件发布日期:",
    STB_SN: "机顶盒内部序列号: ",
    
    //-- search_center_delivery.htm --
    CENTER_DELIVERY: "中心频点",
    
    //--info_stb.htm---
    ca_baseInfo: "智能卡基本信息",
    ca_ratingSet: "成人级别设置",
    ca_pin: "PIN码设置",
    ca_timeSet: "时间段设置",
    ca_cardPaire: "机卡配对",
    ca_update: "智能卡升级状态",
    
    //ca_rating.htm --
    pinCode_successTip: "密码正确！修改成功。",
    pinCode_failTip: "本机密码输入错误！",
    adultLevel: "成人级别",
    rating_adultLevel: "设置新成人级别",
    rating_currLevel: "当前成人级别",
    rating_localPassword: "本机密码",
    rating_save: "保存",
    rating_change: "修改",
    
    //card_paire.htm--
    paire_title: "机卡绑定设置",
    card_index: "索引号",
    card_numList: "机顶盒序列号",
    
    //--ca_mail_conter.htm--
    ca_mail_recipient: "发件人:",
    ca_mail_name: "系统",
    ca_mail_timeName: "时间:",
    
    //--ca_mail_list.htm--
    mail_list_num: "序号",
    mail_list_status: "状态",
    mail_list_title: "标题",
    mail_list_sendTime: "发送时间",
    mail_list_switch: "切换",
    mail_list_read: "已读",
    mail_list_read: "未读",
    
    //--gatewayTest.htm--
    gatewayTest_title: "网关测试",
    gatewayTest_subTitle: "默认网关",
    gatewayTest_test: "网关测试",
    gatewayTest_boxTitle: "温馨提示",
    gatewayTest_pinOk: "Ping成功",
    gatewayTest_pinfail: "Ping失败",
    
    //hd_program_edit.htm--
    hd_title: "高清节目编辑",
    hd_proNum: "节目号",
    hd_proName: "节目名称",
    hd_fav: "喜爱",
    hd_lock: "加锁",
    hd_del: "删除",
    hd_move: "移动",
    
    //operator_ChildInfo.htm--
    childInfo_tittle: "子母卡信息",
    childInfo_subTitle: "子母卡",
    childInfo_cardInfo: "智能卡信息",
    childInfo_feedTime: "喂养周期",
    childInfo_lastTime: "上次喂养时间",
    
    //operator_detitleInfo.htm--
    DETITLEINFO_TITLE: "运营商信息",
    DETITLEINFO_ID: "反授权号",
    DETITLEINFO_NUM: "反授权码",
    DETITLEINFO_STATUS: "状态",
    
    //ca_info.htm--
    CARD_TITLE: "智能卡类型：",
    CARD_NUM: "智能卡号：",
    CARD_ID: "运营商ID：",
    CARD_DETITLE: "是否授权：",
    CARD_RATING: "当前成人级别：",
    CARD_CURRTIME: "观看时间段：",
    CARD_VERSION: "CA版本号：",
    CARD_PAIRE: "机卡配对：",
    
    //--ca_mail_list.htm--
    MAIL_ALL: "所有信件：",
    MAIL_PER: "封",
    MAIL_UNREAD: "未读信件：",
    MAIL_READ: "已读信件：",
    OCDEPLOY_BACKDOOR: "应用后门",
    
    //---------------------------
    
    s_3: "搜索方式:",
    s_4: "开始搜索",
    s_5: "频道设置",
    s_6: "/" + manual_search,
    NUMBER: "序号",
    BANDWIDTH: "带宽",
    SINGAL_FREQ: "单频搜索",
    NETWORK: "网络搜索",
    Manual_search: "手动搜索",
    Manual_Frequency: "频率(MHz):",
    Manual_SymbolRate: "符号率(KS/s):",
    Manual_Modulation: "调制方式(QAM):",
    Manual_SearchMode: "搜索方式",
    PSW_TXT0: "原密码",
    PSW_TXT1: "新密码",
    PSW_TXT2: "确认新密码",
    PSW_TIP3: "请按数字键输入6位密码",
    //ca_info.htm
    CARD_INFO_PAIR: "当前机卡已配对",
    CARD_INFO_NOCARD: "无智能卡或无效卡",
    CARD_INFO_FAIL: "智能卡没有对应任何机顶盒",
    CARD_INFO_SUCCESS: "智能卡已经和其他机顶盒配对",
    PIN_TITLE: "PIN码设置",
    
    //-- auto_search.htm --
    //START_SEARCH: "正在搜索freqMHz，请稍候...",
    
    BACK_TIPS: '【后退】键返回',
    SEARCH_INFO: "搜索到tvCount个电视频道，radioCount个广播频道",
    SAVE_OR_NOT: "是否保存搜索结果",
    PROCESS: "搜索进度：",
    PROCESS2: "进度",
    
    SIGNAL_STRENGTH: "信号强度：",
    SIGNAL_QUALITY2: "质量",
    SIGNAL_STRENGTH2: "强度",
    NETWORKLAN:"网络环境选择",
    
    IP_TITLE: "IP设置",
    CM_TITLE: "CM信息",
    IP_TIP: "【0~9】键输入，【↑↓】键选择，【后退】键保存",
    
    IMAGE_TITLE: "USB应用",
    SUB_TITLE: "图片浏览",
    IMAGE_TIP: "【↑↓】键移动；【确认】键进入。",
    UPGRADE: "自动更新",
	UPGRADE_TIPS:"您确定要进行自动更新吗？",
	UPGRADE_TIP_0:"【0~9】键输入，【确认】键更新，【后退】键返回左列表",
    
    TWO_0: "首页设置",
    TWO_1: "网关测试",
    TWO_2: "无线配置",
    TV_NUM: "电视号",
    
    STB_0: "厂商名称：",
    STB_1: "品牌名称：",
    STB_2: "类型：",
    STB_3: "型号：",
    STB_4: "序列号：",
    STB_5: "硬件版本号：",
    STB_6: "软件版本号：",
    
    GANGWAY: "网关"

});
