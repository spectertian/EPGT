$L.extend({
	IPPV_TITLE:"IPPV信息查看",
	IPPV_TIPS:"【↑↓】键移动，【返回】键退出",
	ALL_TIPS:"【后退】键返回",
	CA_TITLE : "CA信息浏览",
	CA_INFO_0:"CA内核版本号：",
	CA_INFO_1:"智能卡号：",
	CA_INFO_2:"PIN码锁定状态：",
	CA_INFO_3:"机卡绑定状态：",
	CA_INFO_4:"观看级别设置：",
	CA_INFO_5:"卡工作时间段设置：",
	CA_INFO_6:"区域码：",
	INPUT_NUM: "【0~9】键输入",
	
	AUTO_SEARCH: "自动搜索",
	ALL_SEARCH: "全频道搜索",
	Manual_search: "手动搜索",
	
	REVERT_TIPS:"您确定要恢复出厂设置吗？这样会让你失去之前的所有资料和信息！",
	
	LV_CHOICE : "级别控制",
	LV_TIPS : "【←→】键更改，数字键输入，【后退】键返回",
	
	LOCK_NAME:"节目锁",
	CTROL_NAME:"修改控制级别",
	PWD_MODIFY:"修改密码",
	
	SEARCH_TITLE:"系统设置—频道搜索",
	SEARCH_TITLE_0:"系统设置—频道搜索—自动搜索",
	//ippv.js
	SYS_SET: "系统设置",
	OPERA_IPPV : "IPPV购买信息",
	SUB_0 : "节目ID",
	SUB_1 : "节目状态",
	SUB_2 : "价格",
	SUB_3 : "开始时间",
	SUB_4 : "过期时间",
	SUB_5 : "可录像",
	
	//operator_entitle.js
	CC_0 : "产品ID",
	CC_1 : "产品状态",
	CC_2 : "授权结束时间",
	
	//operator_wallet.js
	OPERA_INFO : "运营商信息",
	OPERA_LOGO:"运营商标识:",
	OPERA : "运营商:",
	WALLET : "钱包号",
	CREDIT : "信用额",
	PAYED : "已花费点数",
	OPEAR_TIPS:'【确认】键查看钱包信息，【F3】键查看授权',
	CA_LIST_0:"卡中存在{0}个运营商",
	
	//operator_info.js
	OPERA_0 : "运营商授权信息",
	OPERA_1 : "运营商钱包信息",
	OPERA_2 : "反授权信息",
	OPERA_3 : "子母卡",
	
	//OPERATOR.JS
	OPERA_ID : "运营商ID",
	OPERA_NAME : "运营商名称",
	
	//password_edit.js,pin.js
	PSW_TITLE : "密码设置",
	PSW_NATIVE : "本机密码",
	PSW_APP : "应用密码",
	PSW_PARENT : "父母锁密码",
	STATUS_0 : "有效",
	STATUS_1 : "无效",
	MENU_0 : "密码类型",
	MENU_1 : "密码控制",
	MENU_2 : "请输入新密码",
	MENU_3 : "请确认新密码",
	PSW_TIP0 : "两次输入密码一致,修改成功!",
	PSW_TIP1 : "两次输入密码不一致,请重新输入!",
	PSW_TIP3:"请按数字键输入4位密码",
	PSW_TXT0:"原密码",
	PSW_TXT1:"新密码",
	PSW_TXT2:"确认新密码",
	
	//pg_level.js
	LIST_TITLE : "父母控制",
	LIST_TITLE0 : "设置父母锁级别",
	LIST_TITLE1 : "当前父母锁级别",
	
	//pin.js
	PIN_TITLE : "PIN码设置",
	PIN_MENU0 : "输入CA PIN码",
	PIN_MENU1 : "输入新CA PIN码",
	PIN_MENU2 : "确认新CA PIN码",
	PIN_ERROR : "原始pin码输入错误！",
	
	//program_search.js
	S_MENU0 : "自动搜索",
	S_MENU1 : "手动搜索",
	S_MENU2 : "列表搜索",
	
	//program_edit.js
	PRO_TITLE : "标清节目编辑",
	RADIO_TITLE : "广播节目编辑",
	PRO_ID : "节目号",
	PRO_NAME : "节目名称",
	LIKE : "喜爱",
	LOCK : "加锁",
	DELETE : "删除",
	
		//-- search_manual.htm --
	START_SEARCH: "开始搜索",
	SIGNAL_STREN: "信号强度",
	SIGNAL_QUALITY: "信号质量",
	s_0: "频率(MHz)：",
	s_1: "符号率(KS/s)：",
	s_2: "调制方式(QAM)：",
	END_TIPS:"节目搜索完毕！",
	
	//-- search_all.htm --
	START: "起始",
	END: "结束",
	ALL_SEARCH_1: "全频道搜索",
	
	//-- search.htm --
	CURR_SEARCH: "当前搜索到：",
	PER: "个",
	BROADCAST: "数据广播",
	SEARCH_PROGRESS: "搜索进度",
	SEARCHING: "正在搜索中...",
	CURR_DELIVERY: "当前频点信息为：",
	STOP_SEARCH: "搜索完成",
	
	//program_search.js
	ALL_S_TITLE : "全频道搜索",
	START_S : "开始搜索",
	PS_TITLE : "节目搜索",
	SX_MENU : "上/下一个菜单",
	
	//search_all.js
	START_FRE : "起始频率(MHz)：",
	END_FRE : "结束频率(KHz)：",
	SYMBOL_FRE : "符号率(KS/s)：",
	MODUL : "调制方式(QAM)：",
	
	//search.js
	S_RESULT : "当前搜索到：{0}个电视节目",
	
	//timeSet.js
	TIME_TITLE : "时间段设置",
	TIME_SET : "设置工作时段",
	TIME_VALUE0 : "全天观看",
	TIME_VALUE1 : "时间段观看",
	SET_TITLE : "设置工作时段",
	SET_START : "开始时间",
	SET_END : "结束时间",
	SAVE : "保存",
	INPUT_PSW: "请输入密码:",
	TIME_SET_TIPS : "设置时间段无效,修改不成功！",
	TIME_TIPS:"【0~9】键输入"
	
});
