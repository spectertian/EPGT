﻿/**
 * Cable Search(menu_set.htm、menu.htm.htm、.htm)
 */
var manual_search = "Manual Search";
$L.extend({
	
	HOME_0:"Power setting:",
	HOME_1:"Page Definition:",
	
	
	PROG_NAME:"Program Guide",
	INFO_TITLE:"brief introduction",
	INFO_TIPS:"Press Exit key to return",
	CURR_TIP:'↑ ↓ View; "1" key to cancel the current appointment, "2" to cancel all appointments.',
	PIN_TITLE:"PIN code setting",
	PSW_TIP3:"Press the number keys enter the 6 digit password",
	
	TV_NUM:"TV number:",
	TV_ATTR:"Attribution:",
	
	SEARCH_TIPS:"【0-9】input data 【confirmed】search 【back】 out",
	//当前预告
	PROG_NAME_0:"The current notice",
	PROG_NAME_1:"Week notice",
	PROG_NAME_2:"Classification notice",
	PROG_NAME_3:"All Channels",
	PROG_NAME_4:"Favorite Channels",
	PROG_NAME_5:"Reservation Management",
	PROG_CHOICE:"For selected channel",
	PROG_TIPS_0:"↑ ↓ browsing, ← → to enter the single channel view,",
	PROG_TIPS_1:"That programs have an appointment",
	PROG_TIPS_2:"Information key to view the content of profiles, confirm the key appointment.",
	PROG_TIPS_3:"Description of programs that have",
	PSW_TXT0:"Original PSW",
	PSW_TXT1:"New PSW",
	PSW_TXT2:"Confirm new PSW",
	PROG_TIPS_4:"Select the number keys 1-7 weeks",
	IP_GETMETHOD:"IP Access",
	FAV_0:'Enter key cut to add channels, the arrow keys to switch, "1" key to delete a channel',
	FAV_1:'"2" key to delete all the channels, flip key page, exit key to exit',
	PIN_TIPS:"Press the number keys enter the PIN code to complete set-top box binding",
	DATE:"Date",
	PLAY_TIME:"Broadcast time",
	LIST_NAME_7:"Appoint Manager",
	
	CHANNEL:"Channel",
	PROGRAM:"Program",
	TIME:"Time",
	STATUS:"Status",
	MAC:"MAC Addr",
	OPERATOR_NAME:"The residual amount",
	WALLET_ID:"Wallet ID No.",
	AMOUNT:"The amount of consumption",
	REMAIN_SUM:"The residual amount",
	MONEY_TIPS:"Press OK key to view the development of an operator in the IPPV program information wallet",
	
	CA_BT_0:"Set the binding",
	CA_BT_1:"Exit Interface",
	
	CARD_MONEY:"智能卡钱包信息",
	AV_0 : "Video output format:",
	AV_1 : "Video output format:",
	AV_2 : "Change the channel mode:",
	AV_3 : "Style ratio:",
	AV_4 : "Channel Control:",
	AV_5 : "Sound Control:",
	AV_6 : "Sound settings:",
	AV_7 : "Channel settings:",
	
	TIP_0:"F1 Day notice",
	TIP_1:"F2 Week notice",
	TIP_2:"F3 Classification notice",
	TIP_3:"F4 Reservation Management",
	
	SIGNAL_TXT_0:"Signal level rating:",
	SIGNAL_TXT_1:"BER:",
	SIGNAL_TXT_2:"Signal quality:",
	
	SOFTWARE_TIP_0:"OTA upgrade info is not detected",
	SOFTWARE_TIP_1:"Software upgrade, please wait...",
	SOFTWARE_TIP_2:"Upgrade success^_^",
	SOFTWARE_TIP_3:"Upgrade failed-_-",
	SOFTWARE_TIP_4:"Upgrading,wait...",
	BTN_TITLE:"Starting upgrading",
	LIST_NAME_6:"Program Manager",
	
	SYS_TIPS:'"↑ ↓" key to select "OK" button to enter, "Exit" key to return',
	
	LIST_NAME_0:"Parental Control",
	LIST_NAME_1:"Program search",
	LIST_NAME_2:"Conditional Access",
	LIST_NAME_3:"System Configuration",
	LIST_NAME_4:"System Information",
	LIST_NAME_5:"System Update",
	
	SET_0:"",
	SET_1:"",
	SET_2:"",
	SET_3:"",
	
	GANGNAME_0:"",
	GANGNAME_1:"",
	GANGNAME_2:"",
	GANGNAME_3:"",
	GANGNAME_4:"",
	GANGNAME_5:"",
	
	DISPLAY_0:"Language Settings：",
	DISPLAY_1:"Menu transparency：",
	DISPLAY_2:"Brightness menu：",
	DISPLAY_3:"Information bar displays the time：",
	
	
	GW_Pro_0:"Frequency:",
	GW_Pro_1:"SymbolRate:",
	
	//-- menu_set.htm、menu.htm --
	SYS_SET: "Sys Setting",
	MENU_PROPERTY: "Menu Property",
	//-- menu_set.htm --
	LAN_SET: "Language Set",
	TRANSPARENCY_SET: "Transparency Set",
	EPG_TITLE:"Program Guide",
	//-- menu.htm --
	PRO_MANAGE: "Pro manage",
	LOCAL_SETUP: "Local Setup",
	NETWORK_SET: "Network Set",
	SYS_INFO: "System Info",
	CA_INFO: "CA Info",
	PROGRAM_SEARCH: "Program Search",
	HD_EDIT: "HD Program Edit",
	SD_EDIT: "SD Program Edit",
	RADIO_EDIT: "Radio Program Edit",
	ORDER_MANAGE: "Order Management",
	AV_SET: "A/V Settings",
	PARENTS_LOCK: "Parents Lock",
	PSW_SET: "Password Set",
	FACTORY_SET: "Recovery Factory Set",
	SOFT_UPGRADE: "Software Upgrade",
	IP_SET: "IP Settings",
	GATEWAYTEST_SET: "Gateway Test",
	SERVER_SET: "Server Settings",
	STB_INFO: "STB Information",
	ADULT_SET: "Adult Level Set",
	CARD_INFO: "Card Information",
	LOCAL_PSW: "Local password",
	INPUT_PSW: "Password:",
	RESET_CONFIRM: "This operation will be restored to its original state system parameters, before you do Settings will all empty, do you wish to continue?",
	RESETTING: "Is restoring the initial Settings, please don't power!",
	TO_SEARCH: "System has returned to finish, whether for automatic search, according to defined for automatic search, otherwise the revocation of return!",
	OP_INFORMATION: "Operator Information",
	Mailing_list: "Mailing List",
	
	//-- search_menu.htm、search_manual.htm --
	AUTO_SEARCH: "Auto Search",
	MANUAL_SEARCH: manual_search,
	
	//-- search_menu.htm --
	ALL_SEARCH: "Full Frequency Search",
	FREQUERCY_SET: "Frequency Set",
	PRO_SEARCH: "Program Search",
	TIPS_CONTENT: "If modify the Settings, please contact b&t group.",
	UP_DOWN: "Previous/Next Menu",
	
	//-- search_manual.htm --
	START_SEARCH: "Start Search",
	SIGNAL_LEVEL: "Level",
	SIGNAL_QUALITY: "Quality",
	s_0: "Frequency(MHz)",
	s_1: "SymbolRate(KS/s)",
	s_2: "QAM",
	
	//-- search_all.htm --
	START: "Start ",
	END: "End ",
	ALL_SEARCH_1: "Full Fre Search",
	NETWORKLAN:"NetworkLan",
	
	//-- search.htm --
	CURR_SEARCH: "Current Searched：",
	PER: " ",
	BROADCAST: "data broadcast",
	SEARCH_PROGRESS: "Progress",
	SEARCHING: "Searching...",
	CURR_DELIVERY: "Current Delivery：",
	STOP_SEARCH: "Search completed",
	S_RESULT : "Current search: {0}TV programs",
	
	//-- hd_program_edit.htm、program_edit.htm --
	PRO_NUM: "Nmuber",
	PRO_NAME: "Program Name",
	SYS_SETTING:"System Configuration",
	
	//-- av_set.htm --
	ASPRCT_RATIO: "Aspect Ratio",
	RATE: "Rate",
	RESOLUTION: "Resolution",
	DEF_TRACK: "Default track",
	SPDIF:"SPDIF",
	
	//-- pg_level.htm --
	SET_PARENTS: "Setting parents lock level",
	CURR_PARENTS: "The current parents lock level",
	
	//-- password_edit.htm --
	PSW_CONTROL: "Password Control",
	PSW_INPUT: "Input New Passwrod",
	PSW_CONFIRM: "Confirm New Password",
	VALID: "Valid",
	INVALID: "Invalid",
	MOFIDY_SUCCESS: "Modified password successfully!",
	RE_INPUT: "Two passwords aren't consistent!",
	
	//-- ip_config.htm --
	NETWORK_MODE: "Network Mode:",
	IP_ADDR: "IP Address:",
	SUBNET_MASK: "Subnet Mask:",
	GATEWAY: "Gateway:",
	MASTER_DNS: "Master DNS:",
	BACKUP_DNS: "Backup DNS:",
	DYNAMIC: "Dynamic",
	MANUAL: "Manual",
	INPUT_NUM:"[0、1...9]Input Numeric",
	IP_TITLE:"IP Seting",
	
	//-- server_config.htm --
	EPG_SERVER: "EPG Server:",
	AUTH_SERVER: "Authentication Server:",
	VOD_SERVER: "VOD Server:",
	BACK_VOD_SERVER: "Backup VOD Server:",
	DOWNLOAD_HTTP: "Download Server(HTTP):",
	DOWNLOAD_UDP: "Download Server(UDP):",
	
	//-- info_stb.htm --
	STB_MODE: "STB Model:",
	HARDWARE_VER: "Hardware Version:",
	FLASH_SIZE: "Flash Size: ",
	LOADER_VERSION: "Loader Version: ",
	SOFTWARE_VER: "Software Version:",
	BROWSER_VER: "Browser Version: ",
	SOFTWARE_ISSUE: "Software Issue Date:",
	STB_SN: "STB Number: ",
	
	//-- search_center_delivery.htm --
	CENTER_DELIVERY: "Center Delivery",
	Manual_search:"Manual Search",
	Manual_Frequency:"Frequency(MHz)",
	Manual_SymbolRate:"SymbolRate(KS/s)",
	Manual_Modulation:"Modulation",
	Manual_SearchMode:"SearchMode",
	
	//--info_stb.htm---
	ca_baseInfo:"Smart Card Basics",
	ca_ratingSet:"Adult-level Setting",
	ca_pin:"PIN Cod Setting",
	ca_timeSet:"Time set",
	ca_cardPaire:"Machine card pairing",
	ca_update:"Smart card upgrade status",
	
	//operator_ChildInfo.htm--
	childInfo_tittle:"Child Information",
	childInfo_subTitle:"Child Card",
	childInfo_cardInfo:"Smart Card Info",
	childInfo_feedTime:"Feeding Period",
	childInfo_lastTime:"Last Feeding Time",
	
	//operator_detitleInfo.htm--
	DETITLEINFO_TITLE:"Operator Of Info",
	DETITLEINFO_ID:"Anti-Autho Number",
	DETITLEINFO_NUM:"Anti-Author code",
	DETITLEINFO_STATUS:"STATUS",
	
	//ca_rating.htm --
	pinCode_successTip:"The correct password code!",
	pinCode_failTip:"The native password error!",
	adultLevel:"Adult Level",
	rating_adultLevel:"Set a new adult-LV",
	rating_currLevel:"Current adult level",
	rating_save:"Save",
	rating_change:"Modify",
	
	//--gatewayTest.htm--
	gatewayTest_title:"Gateway Test",
	gatewayTest_subTitle:"Default Gateway",
	gatewayTest_test:"Gateway Test",
	gatewayTest_boxTitle:"Tip",
	gatewayTest_pinOk:"Ping OK",
	gatewayTest_pinfail:"Ping FAIL",
	
	//hd_program_edit.htm--
	hd_title:"HD porgram edit",
	hd_proNum:"Pro_Number",
	hd_proName:"Pro_Name",
	hd_fav:"FAV",
	hd_lock:"LOCK",
	hd_del:"DELETE",
	hd_move:"MOVE",
	
	//card_paire.htm--
	paire_title:"Card Pairing",
	card_index:"Card Index",
	card_numList:"STB serial number",
	
	//--ca_mail_conter.htm--
	ca_mail_recipient:"Recipient:",
	ca_mail_name:"System",
	ca_mail_timeName:"Time:",
	
	//--ca_mail_list.htm--
	MAIL_ALL:"All Mail:",
	MAIL_PER:"  ",
	MAIL_UNREAD:"UnRead:",
	MAIL_READ:"Read:",
	
	//--ca_mail_list.htm--
	mail_list_num:"Num",
	mail_list_status:"Status",
	mail_list_title:"Title",
	mail_list_sendTime:"Time",
	mail_list_switch:"Switch",
	
	//ca_info.htm--
	CARD_TITLE:"Smart Card:",
	CARD_NUM:"SMART CARD NUMBER:",
	CARD_ID:"Operator ID:",
	CARD_DETITLE:"Authorize:",
	CARD_RATING:"Current Adult Level:",
	CARD_CURRTIME:"Time:",
	CARD_VERSION:"CA Version:",
	CARD_PAIRE:"Machine Card Pair:",
	
	
	BACK_TIPS:"",
	
	//---------------------------
	
	s_3: "Search Method:",
	s_4: "Start Scan",
	s_5: "Channel Setting",
	s_6: "/" + manual_search,
	NUMBER: "No.",
	BANDWIDTH: "Bandwidth",
	SINGAL_FREQ: "Singal Freq",
	NETWORK: "Network",
	
	//ca_info.htm
	CARD_INFO_PAIR:"The current machine card is paired",
	CARD_INFO_NOCARD:"No smart card or an invalid card",
	CARD_INFO_FAIL:"Smart card does not correspond to any set-top boxes",
	CARD_INFO_SUCCESS:"Smart cards have been paired with other set-top box",
	
	//-- auto_search.htm --
	//START_SEARCH: "Searching freq(MHz), please wait...",
	
	SEARCH_INFO: "Search tvCount TV，radioCount radio",
	SAVE_OR_NOT: "Do you want to save search result?",
	PROCESS2: "Process",
	PROCESS: "Process",
	
	SIGNAL_STRENGTH: "strength",
	SIGNAL_QUALITY2: "Quality",
	SIGNAL_STRENGTH2: "Strength",
	
	
	IP_TITLE:"IP Set",
	CM_TITLE:"CM Info",
	IP_TIP:'Left and right keys to select the address of Access, "on the page, next page" key to switch to set classification, number keys to enter',
	
	
	IMAGE_TITLE:"USB Applications",
	SUB_TITLE:"Photo browser",
	IMAGE_TIP:"↑ ↓ key; 'confirm' key to enter.",
	UPGRADE:"Automatic Updates",
	UPGRADE_TIPS:"Are you sure you want to automatically update?",
	UPGRADE_TIP_0:'Number keys to enter, press the Enter key to update!"Back" key to return to list on the left',
	
	TWO_0:"Home Set",
	TWO_1:"Gateway Test",
	TWO_2:"Wireless Configuration",
	
	TV_NUM:"TV number",
	
	
	STB_0:"Set-top box manufacturer name:",
	STB_1:"Set-top box Brand Name:",
	STB_2:"Set-top box type:",
	STB_3:"STB Model:",
	STB_4:"STB serial number:",
	STB_5:"Set-top box hardware version number:",
	STB_6:"Set-top box software version number:",
	
	GANGWAY:"Gateway"
	
});
