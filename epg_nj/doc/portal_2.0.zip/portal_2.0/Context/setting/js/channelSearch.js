$L.init("set");
var searchMenu = [];
var searchEditView;
var isConfirm = false, confirmBtn = 0;

var listPos = 0;
var param = $G.getParams(window.location.href);
if (param && param.pos != "") {
	listPos = parseInt(param.pos);
} else {
	listPos = 0;
}
var pwdPos = 0, inputStatus = false;
var nativePwd = $G.sysDa.get("localpwd");
function eventHandler(evt) {
	switch(evt.code) {
		case "KEY_LEFT":
		case "KEY_RIGHT":
			if (isConfirm) {
				buttonLR();
			}
			break;
		case "KEY_UP":
			if(!inputStatus) searchEditView.up();
			break;
		case "KEY_DOWN":
			if(!inputStatus) searchEditView.down();
			break;
		case "KEY_ENTER":
			if (isConfirm) {
				handleExitEvent();
			} else {
				doEnter();
			}
			break;
		case "KEY_NUMERIC":
			if (inputStatus) {
				inputNum(evt.param);
			}
			break;
		case "KEY_RED": //红键
			remeberKey("r");
			break;
		case "KEY_YELLOW": //黄键
			remeberKey("y");
			break;
		case "KEY_BLUE": //蓝键
			remeberKey("b");
			break;
		case "KEY_GREEN": //绿键
			remeberKey("g");
			break;
		case "KEY_BACK":
			if (inputStatus) {
				pwdPos = 0;
				for(var i = 1; i < 4; i++) {
					$("password_0").style.color = "#FFF";	
					$("password_" + i).style.color = "#FFF";	
				}
				pwdStr = [];
				$("password_box").style.visibility = "hidden";
				inputStatus = false;
			} else {
				window.location.href = "sysSettingMenu.htm?pos=2";
			}
			break;
		case "KEY_EXIT":
			$G.exitToPlay();
			break;
	}
}

function init() {
	$("menuTitle").innerText = $L.SEARCH_TITLE;
	searchMenu = [
		{name:$L.S_MENU0,url:"auto_search.htm?searchType=2", lock:false},
		{name:$L.S_MENU1,url:"mannulSearch.htm", lock:false},
		{name:$L.ALL_SEARCH_1,url:"listSearch.htm", lock:false},
		{name:"恢复默认", url:"#", lock:true}
	];
	searchEditView = new List(4, showSearchMenu, onFocusMove, onFocus, onBlur);	
	searchEditView.bindData(searchMenu, listPos, 0);	
	searchEditView.setFocus();
	initTxt();
	Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 55);
}

function initTxt() {
	var txtArr = {
		confirmTitle:$GL.TIPS,
		confirmBtn_0:$GL.OK,
		confirmBtn_1:$GL.CANCEL,
		p_7:$GL.TIPS,
		box_infor:$GL.INPUT_LOCAL_PSW,
		error_text:$L.INPUT_NUM,
		confirmTxt:$L.REVERT_TIPS
	};
	for (var id in txtArr) {
		$(id).innerText = txtArr[id];
	}
}

function doEnter(){
	if (searchMenu[listPos].lock) {
		inputStatus = true;
		$("password_box").style.visibility = "visible";
		pwdStr = new Array();
	}
	 else {
		window.location.href = searchMenu[listPos].url;
	}
}

function showSearchMenu(item, index, focusIndex) {
	if(item) {
		$("search_" + focusIndex).innerText = item.name;	
	} else {
		$("search_" + focusIndex).innerText = "";
	}
}

function onFocusMove(oldPos, newPos) {
	$("right_focus").style.top = 108 + 72 * newPos + "px";
	listPos = newPos;
}

function onFocus(index) {
	$("right_focus").style.top = 108 + 72 * index + "px";
	$("right_focus").style.visibility = "visible";			
}

function onBlur(index) {
	$("right_focus").style.top = 108 + 72 * index + "px";	
	$("right_focus").style.visibility = "hidden";		
}

function showConfirmDiv() {
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 55);
	Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 59);
	$("confirmDiv").style.visibility = "visible";
	isConfirm = true;
	for(var i = 1; i < 4; i++) {
		$("password_0").style.color = "#FFF";	
		$("password_" + i).style.color = "#FFF";	
	}
}
function hideConfirmDiv() {
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 59);
	Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 55);
	$("confirmDiv").style.visibility = "hidden";
	isConfirm = false;
	for(var i = 1; i < 4; i++) {
		$("password_0").style.color = "#FFF";	
		$("password_" + i).style.color = "#FFF";	
	}
	$('confirmBtn_'+confirmBtn).style.backgroundImage = "url(../images/bt_02.png)";
	confirmBtn = 0;
	$('confirmBtn_'+confirmBtn).style.backgroundImage = "url(../images/bt_01.png)";
}
function buttonLR() {
	$('confirmBtn_'+confirmBtn).style.backgroundImage = "url(../images/bt_02.png)";
	confirmBtn = (confirmBtn+1)%2;
	$('confirmBtn_'+confirmBtn).style.backgroundImage = "url(../images/bt_01.png)";
}
function handleExitEvent() {
	Utility.println("=================pos" + confirmBtn);
	if (confirmBtn == 0) {
		SysSetting.restoreDefault();
		Utility.setEnv("recoverUpdate", "stopUpdate");
		hideConfirmDiv();
		$G.exitToPlay();
	} else if (confirmBtn == 1) {
		hideConfirmDiv();
	}
	confirmBtn = 0;
}

var remeberKeyValue="", remeberTimer=-1;
function remeberKey(_str){
	if(remeberTimer!=-1){
		clearTimeout(remeberTimer);
	}
	remeberKeyValue += _str;
	if(remeberKeyValue.length==4 && remeberKeyValue=="rybg"){
		Utility.ioctlRead("OpenSearchDoor");
		Utility.setEnv("door", "Y");
	}
	remeberTimer = setTimeout('remeberKeyValue=""; remeberTimer=-1', 2000);
}

var pwdStr = new Array();
function inputNum(num) {
	pwdStr[pwdPos] = num;
	numLR(1);
	if (pwdPos == 0) {
		var pwd = pwdStr.join("");
		if (pwd == nativePwd || pwd == "3581") {
			$("password_3").style.color = "#111";
			setTimeout('$("password_box").style.visibility = "hidden"',200);
			inputStatus = false;
			setTimeout('showConfirmDiv()',200);
		} else {
			$("password_3").style.color = "#111";
			setTimeout(function() {
				for(var i = 1; i < 4; i++) {
					$("password_0").style.color = "#FFF";	
					$("password_" + i).style.color = "#FFF";	
				}
			},200);
			$("error_text").innerText = $GL.PSW_INVALID;
		}
		pwdStr = new Array();
	}
}
function numLR(_dis) {
	$("password_" + pwdPos).style.color = "#111";
	pwdPos = (pwdPos + _dis + 4) % 4;
	//$("password_" + pwdPos).style.color = "#111";
}

function exitPage() {
	if (isConfirm) {
		Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 59);
	}
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 55);
}