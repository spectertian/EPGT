$L.init("setting");

var leftPos = 0, area = 0, pwdInputStatus = false;
var data0, data1, currFreq=0, currFreqSymbolRate=0, currFreqModulation=0, modulation=3;
var nativePwd = $G.sysDa.get("localpwd");
var caListView = new List(6, initList, onFocusMove, onFocus, onBlur);
var realStandby = $G.sysDa.get("RealStandbyFlag") == "" ? 1 : $G.sysDa.get("RealStandbyFlag");

var rightPos;
var param = $G.getParams(window.location.href);
if (param && param.pos != "") {
	rightPos = parseInt(param.pos);
	area = 1;
} else {
	rightPos = 0;
}

var sleepItem;

function initList(item, index, focusIndex) {
	$("caName_" + focusIndex).innerText = item ? item.name : "";
}
function onFocusMove(oldPos, newPos) {
	$("caName_" + oldPos).className = "";
	$("caName_" + newPos).className = "listFocus";
}
function onFocus(index) {
	$("caName_" + index).className = "listFocus";
}
function onBlur(index) {
	$("caName_" + index).className = "";
}
function init() {
	data0 = [{name:$L.ca_pin, url:"pin.htm"}, {name:$L.ca_baseInfo, url:"CA_info.htm"}, {name:$L.DETITLEINFO_TITLE, url:"operatorInfo.htm"},
		{name:$L.CARD_MONEY, url:"ca_Money.htm"}, {name:$L.ca_timeSet, url:"timeSet.htm"}, {name:$L.paire_title, url:"ca_Paired.htm"},];
	
	var sleepItemArry = [{displayValue: $L.SLEEP_OPEN, sysValue: 0}, {displayValue: $L.SLEEP_CLOSE, sysValue: 1}]
	
	caListView.bindData(data0, 0, 0);
	currFreq = Number($G.sysDa.get("upgradeFreq"));
	currFreqSymbolRate = Number($G.sysDa.get("upgradeSymb"));
	modulation = Number($G.sysDa.get("SEARCH.modulation_0"));
	currFreqModulation = modulation;
	
	sleepItem = new LRButton("sleepValue_0", itemOnFocus, itemOnBlur, showItem, itemOnChange);
	sleepItem.bindData(sleepItemArry);
	sleepItem.setValue(realStandby);
	//$("tvValue0").innerText = Utility.getEnv("MIS_TVCode") != "" ? Utility.getEnv("MIS_TVCode") : "00000000";
	
	var sdpTvNum = CITV.getParamInfo("TVCode") != "" ? CITV.getParamInfo("TVCode") : "00000000";
	$("tvValue0").innerText = sdpTvNum;
	
	initTxt();
	$("CA_content").style.visibility = "visible";
	if (area == 1) {
		caListView.bindData(data0, rightPos, 0);
		caListView.setFocus();
		leftOnBlur();
	} else {
		leftOnFocus();
	}
	getSTBInfo();
	initDelivery();
	Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 76);
}

function itemOnFocus() {}

function itemOnBlur() {}

function showItem(id, value) {
	$(id).innerText = value;
}

function itemOnChange() {
	var value = sleepItem.getValue();
	$G.sysDa.set("RealStandbyFlag", value);
	
}

function initTxt() {
	var txtArr = {
		menuTitle:$L.SYS_SET + "—" + $L.LIST_NAME_4,
		tips:$L.SYS_TIPS,
		list_0:$L.CARD_INFO,
		list_1:$L.TV_NUM,
		list_2:$L.STB_INFO,
		list_3:$L.LIST_NAME_5,
		list_4:$L.LIST_NAME_8,
		stbName_0:$L.STB_0,
		stbName_1:$L.STB_3,
		stbName_2:$L.STB_4,
		stbName_3:$L.STB_5,
		stbName_4:$L.STB_6,
		stbName_5:$L.SOFTWARE_ISSUE,
		upgrade_0:$L.s_0,
		upgrade_1:$L.s_1,
		upgrade_2:"PID:",
		upgrade_3:$L.s_2,
		tvName0:"电视号：",
		tvName1:$L.TV_ATTR,
		pwdTitle:$GL.TIPS,
		box_infor:$L.INPUT_PSW,
		confirmTitle:$GL.TIPS,
		confirmTxt:$L.UPGRADE_TIPS,
		confirmBtn_0:$GL.OK,
		confirmBtn_1:$GL.CANCEL,
		error_text:$L.INPUT_NUM,
		upgarde_0:$L.s_0,
		upgarde_1:$L.s_1,
		upgarde_2:"PID：",
		upgarde_3:$L.s_2,
		p_7:$GL.TIPS
	};
	for (var id in txtArr) {
		$(id).innerText = txtArr[id];
	}
}

function eventHandler(evt) {
	if (leftPos == 3 && area == 1) {
		upgradeEvent(evt);
		return;
	}
	if (pwdInputStatus) {
		pwdEventHandler(evt);
		return;
	}
	switch (evt.code) {
		case "KEY_UP":
			if (area == 0) {
				leftUpDown(-1);
			} else {
				rightUpDown(-1);
			}
			break;
		case "KEY_DOWN":
			if (area == 0) {
				leftUpDown(1);
			} else {
				rightUpDown(1);
			}
			break;
		case "KEY_LEFT":
			if (area == 1) { 
				if (leftPos == 0) {
					area = 0;
					leftOnFocus();
					caListView.setBlur();
				}
				if (leftPos == 4) {
					//sleepItem.left();
					area = 0;
					leftOnFocus();
					caListView.setBlur();
				}
			}
			break;
		case "KEY_RIGHT":
			if (area == 0) {
				if (leftPos == 0) {
					area = 1;
					leftOnBlur();
					caListView.setFocus();
				}
				if (leftPos == 4) {
					area = 1;
					leftOnBlur();
				}
			}else{
				if (leftPos == 4) {
					sleepItem.right();
				}
			}
			break;
		case "DVB_SMARTCARD_INSERTED":
			//$("tvValue0").innerText = Utility.getEnv("MIS_TVCode") != "" ? Utility.getEnv("MIS_TVCode") : "00000000";
			var sdpTvNum = CITV.getParamInfo("TVCode") != "" ? CITV.getParamInfo("TVCode") : "00000000";
			$("tvValue0").innerText = sdpTvNum;
			break;
		case "DVB_SMARTCARD_EVULSION":
			$("tvValue0").innerText = "00000000";
			break;
			break;
		case "KEY_ENTER":
			doEnter();
			break;
		case "KEY_BACK":
			window.location.href = "sysSettingMenu.htm?pos=3";
			break;
		case "KEY_EXIT":
			$G.exitToPlay();
			break;
	}
}
var pwdPos = 0, pwdStr = new Array();
function pwdEventHandler(evt) {
	switch (evt.code) {
		case "KEY_NUMERIC":
			pwdInput(evt.param);
			break;
		case "KEY_EXIT":
			pwdInputStatus = false;
			$("password_box").style.visibility = "hidden";
			break;
	}
}
function pwdLR(_type) {
	$("password_" + pwdPos).style.color = "#111";
	pwdPos = (pwdPos + _type + 4) % 4;
	//$("password_" + pwdPos).style.color = "#111";
}
var pwdStr;
function pwdInput(num) {
	pwdStr[pwdPos] = num;
	pwdLR(1);
	if (pwdPos == 0) {
		if (pwdStr.join("") == nativePwd) {
			$("password_3").style.color = "#111";
			area = 1;
			setTimeout(function() {
				$("password_box").style.visibility = "hidden";
				for(var i = 1; i < 4; i++) {
					$("password_0").style.color = "#FFF";	
					$("password_" + i).style.color = "#FFF";	
				}
			},200);
			Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 85);
			pwdInputStatus = false;
			$("upgrade").style.visibility = "visible";
			leftOnBlur();
			$(numId[upgradeListPos]+numPos).style.textDecoration = "underline";
			$("upgradeList_" + upgradeListPos).style.background = "url(../images/upFocus.png) no-repeat";
			$("tips").innerText = $L.UPGRADE_TIP_0;
		} else {
			$("password_3").style.color = "#111";
			setTimeout(function() {
				for(var i = 1; i < 4; i++) {
					$("password_0").style.color = "#FFF";	
					$("password_" + i).style.color = "#FFF";	
				}
			},200);
			$("error_text").innerText = "密码输入错误，请重新输入！";
		}
		pwdStr = new Array();
	}
}
function rightUpDown(_type) {
	switch (leftPos) {
		case 0:
			if (_type < 0) {
				caListView.up();
			} else {
				caListView.down();
			}
			break;
	}
}
function doEnter() {
	switch (area) {
		case 0 :
			if (leftPos == 3) {
				pwdInputStatus = true;
				pwdStr = new Array();
				$("password_box").style.visibility = "visible";
			}
			break;
		case 1 :
			if (leftPos == 0) {
				window.location.href = data0[caListView.currIndex].url;
			}
			break;
	}
}
function leftUpDown(_type) {
	$("list_" + leftPos).className = "";
	switch (leftPos) {
		case 0:
			Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 76);
			break;
		case 1:
			Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 83);
			break;
		case 2:
			Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 84);
			break;
		case 3:
			//Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 85);
			break;
		case 4:
			Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 106);
			break;			
	}
	leftPos = (leftPos + _type + 5) % 5;
	leftOnFocus();
	switch (leftPos) {
		case 0:
			Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 76);
			break;
		case 1:
			Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 83);
			break;
		case 2:
			Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 84);
			break;
		case 3:
			//Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 85);
			break;
		case 4:
			Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 106);
			break;	
	}
	rightChange();
}
function leftOnFocus() {
	$("list_" + leftPos).className = "listFocus";	
}
function leftOnBlur() {
	$("list_" + leftPos).className = "listFocus_2";
}
function getSTBInfo() {
	$("stbValue_0").innerText = SysInfo.STBBrand;
	$("stbValue_1").innerText = SysInfo.STBType;
	$("stbValue_2").innerText = SysInfo.STBSerialNumber;
	$("stbValue_3").innerText = SysInfo.hardwareVersion;
	$("stbValue_4").innerText = SysInfo.softwareVersion + "("+$G.sysDa.get("Sys.stbTypeCode") + ")";
	var date = new Date(SysInfo.softwareReleaseDate);
	$("stbValue_5").innerHTML = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate() + "&nbsp;&nbsp;" + 
							$G.leftPadStr(date.getHours(), "0", 2) + ":" + $G.leftPadStr(date.getMinutes(), "0", 2);
}
function rightChange() {
	switch (leftPos) {
		case 0:
			$("CA_content").style.visibility = "visible";
			$("STB_info").style.visibility = "hidden";
			$("tvNumInfo").style.visibility = "hidden";
			$("sleepSet").style.visibility = "hidden";
			break;
		case 1:
			$("CA_content").style.visibility = "hidden";
			$("tvNumInfo").style.visibility = "visible";
			$("STB_info").style.visibility = "hidden";
			$("sleepSet").style.visibility = "hidden";
			break;
		case 2:
			$("STB_info").style.visibility = "visible";
			$("tvNumInfo").style.visibility = "hidden";
			$("sleepSet").style.visibility = "hidden";
			break;
		case 3:
			$("STB_info").style.visibility = "hidden";
			$("CA_content").style.visibility = "hidden";
			$("sleepSet").style.visibility = "hidden";
			break;
		case 4:
		    $("STB_info").style.visibility = "hidden";
			$("CA_content").style.visibility = "hidden";
			$("tvNumInfo").style.visibility = "hidden";
			$("sleepSet").style.visibility = "visible";
			break;
	}
}
var numId = ['freq_', 'sym_', 'PID_'], upgradeListPos = 0, numPos = 0;
var confirmFlag = false;
function upgradeEvent(evt) {
	switch (evt.code) {
		case "KEY_LEFT":
			if (confirmFlag) {
				confirmBtLR();
			} else {
				leftRight(-1);
			}
			break;
		case "KEY_RIGHT":
			if (confirmFlag) {
				confirmBtLR();
			} else {
				leftRight(1);
			}
			break;
		case "KEY_UP":
			upUpDown(-1);
			break;
		case "KEY_DOWN":
			upUpDown(1);
			break;
		case "KEY_NUMERIC":
			var numParam = parseInt(evt.param);
			if (upgradeListPos < 3) {
				$(numId[upgradeListPos] + numPos).innerText = numParam;
				numLR(1);
			}
			break;
		case "KEY_ENTER":
			if (!confirmFlag) {
				$("confirmDiv").style.visibility = "visible";
				confirmFlag = true;
			} else {
				if (confirmBtPos == 0) {
					goUpgrade();
				} else {
					$("confirmDiv").style.visibility = "hidden";
					confirmFlag = false;
					confirmBtLR();
				}
			}
			break;
		case "KEY_BACK":
			Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 85);
			$("upgrade").style.visibility = "hidden";
			$("upgradeList_" + upgradeListPos).className = "";
			$("list_" + leftPos).className = "listFocus";
			area = 0;
			$("tips").innerText = $L.SYS_TIPS;
			break;
		case "KEY_EXIT":
			if (confirmFlag) {
				$("confirmDiv").style.visibility = "hidden";
				confirmFlag = false;
			} else {
				$G.exitToPlay();
			}
			break;
	}
}
var confirmBtPos = 0;
function confirmBtLR() {
	$("confirmBtn_" + confirmBtPos).style.background = "url(../images/bt_02.png) no-repeat";
	confirmBtPos = (confirmBtPos + 1) % 2;
	$("confirmBtn_" + confirmBtPos).style.background = "url(../images/bt_01.png) no-repeat";
}
function upUpDown(_dis) {
	if (upgradeListPos == 3) {
		$("arrow").style.background = "url(../images/ipArrow2.png) no-repeat";
	}
	$(numId[upgradeListPos]+numPos).style.textDecoration = "";
	$("upgradeList_" + upgradeListPos).style.background = "url(../images/upBlur.png) no-repeat";
	upgradeListPos = (upgradeListPos + _dis + 4) % 4;
	if (upgradeListPos == 3) {
		$("arrow").style.background = "url(../images/ipArrow.png) no-repeat";
	}
	numPos = 0;
	$(numId[upgradeListPos]+numPos).style.textDecoration = "underline";
	$("upgradeList_" + upgradeListPos).style.background = "url(../images/upFocus.png) no-repeat";
}
function numLR(_dis) {
	switch (upgradeListPos) {
		case 0:
			$(numId[upgradeListPos]+numPos).style.textDecoration = "";
			numPos=(numPos+_dis+3)%3;
			$(numId[upgradeListPos]+numPos).style.textDecoration = "underline";
			break;
		case 1:
		case 2:
			$(numId[upgradeListPos]+numPos).style.textDecoration = "";
			numPos=(numPos+_dis+4)%4;
			$(numId[upgradeListPos]+numPos).style.textDecoration = "underline";
			break;
	}
}
function leftRight(_type){
	switch(upgradeListPos){
		case 0:
		case 1:
			numLR(_type);
			break;
		case 3:
			modulation += _type;
			if(modulation>5){
				modulation=1;
			}else if(modulation<1){
				modulation=5;
			}
			$('modual').innerText = (16*Math.pow(2,modulation-1))+"QAM";
			break;
	}
}
function initDelivery(){
	var deliveryArr = [{val:$G.leftPadStr(currFreq, "0", 3), pre:"freq_"}, {val:$G.leftPadStr(currFreqSymbolRate, "0", 4), pre:"sym_"}];
	for(var i=0,j=deliveryArr.length; i<j; i++){
		for(var x=0,y=deliveryArr[i].val.length; x<y; x++){
			$(deliveryArr[i].pre+x).innerText = deliveryArr[i].val[x];
		}
	}
	$('modual').innerText = (16*Math.pow(2,modulation-1))+"QAM";
}
function goUpgrade() {
	var freq = $("freq_0").innerText + $("freq_1").innerText + $("freq_2").innerText;
	var sym = $("sym_0").innerText + $("sym_1").innerText + $("sym_2").innerText + $("sym_3").innerText;
	var pid = $("PID_0").innerText + $("PID_1").innerText + $("PID_2").innerText + $("PID_3").innerText;
	window.location.href = "softUpgrade.htm?frequency=" + freq + "&symbolRate=" + sym + "&modulation=" + modulation;
}
function exitPage() {
	$G.sysDa.submit();
	switch (leftPos) {
		case 0:
			Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 76);
			break;
		case 1:
			Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 83);
			break;
		case 2:
			Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 84);
			break;
		case 3:
			if(area == 1){
			Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 85);
			}
			break;
	}
}
