$L.extend({
	IPPV_TITLE:"IPPV information see",
	IPPV_TIPS:'"↑ ↓" key to flip key here, exit key to exit',
	ALL_TIPS:'Press "Exit" key to return',
	CA_TITLE : "CA Information Browsing",
	
	CA_INFO_0:"CA kernel version:",
	CA_INFO_1:"Smart Card Number:",
	CA_INFO_2:"PIN code lock status:",
	CA_INFO_3:"Binding state machine cards:",
	CA_INFO_4:"Watch level setting:",
	CA_INFO_5:"Working time card set:",
	CA_INFO_6:"Region:",
	
	REVERT_TIPS:"Are you sure you want to restore factory settings? This will make you lose all data and information before!",
	
	LV_CHOICE : "Level control",
	LV_TIPS : '"← →" key to select the view level',
	
	LOCK_NAME:"",
	CTROL_NAME:"",
	PWD_MODIFY:"",
	OPERA_LOGO:"Operator Logo:",
	SEARCH_TITLE:"System Settings - Channel Search",
	SEARCH_TITLE_0:"System Settings - Channel Search - Auto Search",
	//ippv.js
	SYS_SET: "Sys Setting",
	OPERA_IPPV : "IPPV Purchase Info",
	SUB_0 : "Pro Num",
	SUB_1 : "Pro status",
	SUB_2 : "Price",
	SUB_3 : "Start Time",
	SUB_4 : "Expiration",
	SUB_5 : "For video",
	
	//operator_entitle.js
	CC_0 : "Product ID",
	CC_1 : "Product Status",
	CC_2 : "Authorized end time",
	
	//operator_wallet.js
	OPERA_INFO : "Operator Info",
	OPERA : "Operator:",
	WALLET : "Number of purse",
	CREDIT : "Credit card limit",
	PAYED : "Have spent point",
	OPEAR_TIPS:'"OK button" View wallet information, F3 key to view the license',
	CA_LIST_0:"Card there are '{0}' operators",
	
	//operator_info.js
	OPERA_0 : "Authorization information",
	OPERA_1 : "Wallet information carriers",
	OPERA_2 : "Anti-authorization information",
	OPERA_3 : "Mother and child cards",
	
	//OPERATOR.JS
	OPERA_ID : "Operator ID",
	OPERA_NAME : "Operator Name",
	
	//password_edit.js
	PSW_TITLE : "Password Settings",
	PSW_NATIVE : "Local Password",
	TIP_00 : "Modify",
	PSW_APP : "Applied Cryptography",
	PSW_PARENT : "Parental lock code",
	STATUS_0 : "Effective",
	STATUS_1 : "Invalid",
	MENU_0 : "Password Type",
	MENU_1 : "Password control",
	MENU_2 : "Please enter a new password",
	MENU_3 : "Confirm the new PWD",
	PSW_TIP0 : "The same password twice, has been changed successfully!",
	PSW_TIP1 : "Enter the password twice inconsistent, please try again!",
	SW_TIP3:"请按数字键输入4位密码",
	PSW_TXT0:"原密码",
	PSW_TXT1:"新密码",
	PSW_TXT2:"确认新密码",
	
	//pg_level.js
	LIST_TITLE : "Parental control",
	LIST_TITLE0 : "Set the parental lock level",
	LIST_TITLE1 : "Curr level of parental lock",
	
	//pin.js
	PIN_TITLE : "PIN code setting",
	PIN_MENU0 : "Input the CA PIN code",
	PIN_MENU1 : "Input a new CA PIN code",
	PIN_MENU2 : "Confirm the new CA PIN code",
	PIN_ERROR : "The original pin code input error!",
	
	//program_search.js
	S_MENU0 : "Auto Search",
	S_MENU1 : "Manual search",
	S_MENU2 : "List Search",
	
	//search_all.js
	START_FRE : "Starting frequency(KHz)",
	END_FRE : "End of the frequency(MHz)",
	SYMBOL_FRE : "Symbol Rate(MHz)",
	MODUL : "Modulation",
	
	//program_edit.js
	PRO_TITLE : "SD PRO Editing",
	RADIO_TITLE : "Radio editing",
	PRO_ID : "Pro num",
	PRO_NAME : "Program Name",
	LIKE : "Fav",
	LOCK : "Lock",
	DELETE : "Delete",
	MOVE : "Move",
	
	//-- search_manual.htm --
	START_SEARCH: "Start Search",
	SIGNAL_STREN: "Strength",
	SIGNAL_QUALITY: "Quality",
	s_0: "Frequency(MHz)",
	s_1: "SymbolRate(KS/s)",
	s_2: "QAM",
	END_TIPS:"Program search is completed!",
	
	//-- search_all.htm --
	START: "Start ",
	END: "End ",
	ALL_SEARCH_1: "Full Fre Search",
	
	//-- search.htm --
	CURR_SEARCH: "Current Searched",
	PER: " ",
	BROADCAST: "data broadcast",
	SEARCH_PROGRESS: "Progress",
	SEARCHING: "Searching...",
	CURR_DELIVERY: "Current Delivery",
	STOP_SEARCH: "Search completed",
	
	//search.js
	S_RESULT : "Current search: {0}TV programs",
	
	//program_search.js
	ALL_S_TITLE : "All Channel Search",
	START_S : "Start Search",
	PS_TITLE : "Program search",
	SX_MENU : "Up/down a menu",
	
	//timeSet.js
	TIME_TITLE : "Time set",
	TIME_SET : "Set working hours",
	TIME_VALUE0 : "Day Watch",
	TIME_VALUE1 : "Time watch",
	SET_TITLE : "Set working hours",
	SET_START : "Start Time",
	SET_END : "End Time",
	SAVE : "Save",
	INPUT_PSW: "Password:",
	TIME_SET_TIPS : "Set time is invalid, change is not successful!",
	TIME_TIPS:"Please press the number keys to enter"
	
});
