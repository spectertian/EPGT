$L.init("set");
var area = 0, searchFlag = false, searchType = -1, currDelieveryCount = 0, serviceArr = [], totalDelieveries = 0, tempDeliverCount = 0, currServiceList = [], timeoutFlag = -1, signalStrength = 0, signalQuality = 0, signalCN=0, tvNum = 0, radioNum = 0, dataNum = 0;
var lineSize = 7; //显示行数
var requests = $G.getParams(window.location.href);

stopMediaPlayer();

function eventHandler(evt){
	switch (evt.code) {
		case "KEY_ENTER":
			if (area == 1) {
				$("alert").style.visibility = "hidden";
				goBack();
			}
			break;
		case "DVB_DELIVERY_SEARCH_START":
			if (searchFlag) {
				currDelieveryCount++;
				var currDelivery = Search.currentDelivery;
				if (currDelivery) {
					$("MHz_NUM").innerText = currDelivery.frequency / 1000;
					$("KS_speed").innerText = currDelivery.symbolRate;
					$("AM_NUM").innerText = 16 * Math.pow(2, currDelivery.modulation - 1);
				}
				//refreshSignalInfo();
			}
			break;
		case "DVB_DELIVERY_SEARCH_FINISHED":
			/*这里处理不精确，放到cfg中处理*/
			var curFre = Search.currentDelivery.frequency;	
			var curSymb = Search.currentDelivery.symbolRate;
			var curModu = Search.currentDelivery.modulation;	
			if(curFre != undefined)	
			{
				Utility.println("------------ one frequency search end ------------");
				Utility.ioctlWrite("NM_Freq", "nParam1:"+curFre+",nParam2:"+curSymb+",nParam3:"+curModu+",nParam4:"+signalStrength+",nParam5:"+signalQuality+",nParam6:"+signalCN);	
			}	
			if (searchFlag) {
				serviceArr = Search.currentDeliverServices;//获取当前频点搜索到的Service对象数组。
				if (searchType == 1) {
					totalDelieveries = Search.getDeliverCount() * 2;
				} 
				if (serviceArr.length > 0) {
					getCurrDelieveryServices();
				}
				var percent = currDelieveryCount / totalDelieveries;
				if (percent > 1) percent = 1;
				$("p_value_2").innerText = parseInt(percent * 100, 10) + "%";
				$("progress_2").width = percent * 265;
				//refreshSignalInfo();	
			}
			break;
		case "DVB_NIT_SEARCH_SUCCESS":
			totalDelieveries = Search.getDeliverCount();
			break;
		case "DVB_NIT_SEARCH_FAILED":
			Utility.println("------------------------ search failed ------------------");		
			Utility.ioctlWrite("NM_Search","nAction:"+2+",nParam1:"+0+",nParam2:"+0+",nParam3:"+0+",nParam4:"+0+",nParam5:"+0);
			searchEnd();
			break;
		case "DVB_SERVICE_READY":
			break;
		case "DVB_SEARCH_FINISHED":
			if (Utility.getEnv("Search_Break") == "YES") //如果是中断搜索了
			{
				totalDelieveries = tempDeliverCount;
			}
			else
			{
				totalDelieveries = Search.getDeliverCount();
			}
			
			searchEnd();
			
			Utility.println("---------totalDelieveries-----------" + totalDelieveries);				

			Utility.ioctlWrite("NM_Search","nAction:"+0+",nParam1:"+totalDelieveries+",nParam2:"+tvNum+",nParam3:"+radioNum+",nParam4:"+dataNum);
			Utility.setEnv("Search_Break", "NO");//设置是否搜索中断了。
			break;
		case "DVB_SEARCH_EXIT":
			break;
		case "KEY_MENU":
			doMenu();
			break;
		case "KEY_BACK":
			Utility.setEnv("Search_Break", "YES");//设置是否搜索中断了。
			totalDelieveries = Search.getDeliverCount();
			tempDeliverCount = totalDelieveries;
			searchEnd();
			break;
		case "KEY_EXIT":
			Utility.setEnv("Search_Break", "YES");//设置是否搜索中断了。
			totalDelieveries = Search.getDeliverCount();
			tempDeliverCount = totalDelieveries;
			searchEnd();
			break;
	}
}

function doRepairPropertyFile() {
	var propertyFile = "Systemsetting.properties";
	
	var sysData = new DataAccess(propertyFile);
	
	//先检测此文件是否有效
	var mainFre = sysData.get("SEARCH.frequency_0");
	var mainSym = sysData.get("SEARCH.symbol_0");
	var mainMod = sysData.get("SEARCH.modulation_0");
	var pwd = sysData.get("localpwd");
	
	if (!mainFre || !mainSym || !mainMod || !pwd) {
		//配置文件内容不正常，需要修复
		Utility.println(propertyFile+" is in dangerous!! need repair");
		var defaultSysDataPath = Utility.getEnv("STB.innerPath")+"/config/"+propertyFile;//存储在默认区的配置文件
	
		Utility.println("defaultSysDataPath = "+defaultSysDataPath);
		
		var defaultSysData = new DataAccess(defaultSysDataPath);
		
		var keyCount = defaultSysData.getCount();
		Utility.println("keyCount = "+keyCount);
		var key = null;
		var value = null;
		for (var i = 0; i < keyCount; i++) {
			key = defaultSysData.getKeyAt(i);
			value = defaultSysData.get(key);
			if (key && value) {
				Utility.println("set "+key+"="+value);
				sysData.set(key, value);
			}
			if (i >= 200) {//已知的最大key值不会超过200个
				break;
			}
		}
		
		sysData.submit();
	} else {
		//配置文件内容正常，不需要修复
		Utility.println(propertyFile+" is safe. Do not need repair!");
	}
}

function init(){
	$("mainTitle").innerText = $L.SEARCH_TITLE_0;
	doRepairPropertyFile();
	startSearch();
	var txtArr = {
		Se_tv: $GL.TV,
		Se_radio: $GL.RADIO,
		alert_title: $GL.TIPS,
		alert_ok: $GL.OK,
		signalStr: $L.SIGNAL_STREN,
		signalQual: $L.SIGNAL_QUALITY,
		search_pro: $L.SEARCH_PROGRESS,
		freq : $L.s_0,
		symbol : $L.s_1,
		AM : $L.s_2,
		endTip : $L.END_TIPS
	};
	for (var id in txtArr) {
		$(id).innerText = txtArr[id];
	}
	Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 56);
	
	//关闭开机避免黑屏的iframe
	if (Utility.getEnv("CLOSE_START_VIDEO_IFRAME") != "true") {
		setTimeout(function () {
				Utility.ioctlWrite("CLOSE_START_VIDEO_IFRAME", '');
			}, 2000);
		Utility.setEnv("CLOSE_START_VIDEO_IFRAME", "true");
	}
		
}
var sysData = new DataAccess("Systemsetting.properties");
function startSearch(){
	SysSetting.panelDisplayText("SCAN");
	if (requests.searchType == "0") { //手动搜索
		$("mainTitle").innerText = $L.PS_TITLE + "—" + $L.Manual_search;
		searchTypePos = parseInt(requests["searchTypePos"], 10);
		fre = requests["frequency"] * 1000;
		symRate = parseInt(requests["symbolRate"], 10);
		modul = parseInt(requests["modulation"], 10);
		$("MHz_NUM").innerText = fre / 1000;
		$("KS_speed").innerText = symRate;
		$("AM_NUM").innerText = 16 * Math.pow(2, modul - 1);
		if(searchTypePos == 0) {
			searchType = 0;	
			var delivery = new Delivery();
			delivery.type = 1;
			delivery.frequency = fre;
			delivery.symbolRate = symRate;
			delivery.modulation = modul;
			Search.startCableSearch(0, [delivery]);
			searchFlag = true;
			Utility.ioctlWrite("NM_Search", "nAction:"+1+",nParam1:"+0+",nParam2:"+fre+",nParam3:"+symRate+",nParam4:"+modul);	
		} else if(searchTypePos == 1) {
			searchType = 2;
			SysSetting.deleteAllService();//删除所有节目
			var delivery = new Delivery();
			delivery.type = 1;
			delivery.frequency = fre;
			delivery.symbolRate = symRate;
			delivery.modulation = modul;
			Search.startCableSearch(1, [delivery]);
			searchFlag = true;	
			Utility.ioctlWrite("NM_Search", "nAction:"+1+",nParam1:"+0+",nParam2:"+fre+",nParam3:"+symRate+",nParam4:"+modul);	
		}
	} else if (requests.searchType == "1") { //全频搜索	
		$("mainTitle").innerText = $L.PS_TITLE + "—" + $L.ALL_SEARCH_1;
		Utility.println("================================dddddd"+parseInt(requests["modulation"], 10));	
		searchType = 1;
		SysSetting.deleteAllService();//删除所有节目
		var startMHz = parseInt(requests["startMHz"], 10);
		var endMHz = parseInt(requests["endMHz"], 10);
		symRate = parseInt(requests["symbolRate"], 10);
		modul = parseInt(requests["modulation"], 10);
		
		$("MHz_NUM").innerText = startMHz / 1000;
		$("KS_speed").innerText = symRate;
		$("AM_NUM").innerText = 16 * Math.pow(2, modul - 1);
		
		var deliveryArray = new Array(2);
		deliveryArray[0] = new Delivery();
		deliveryArray[0].type = 1;
		deliveryArray[0].frequency = startMHz;
		deliveryArray[0].symbolRate = symRate;
		deliveryArray[0].modulation = modul;
		deliveryArray[1] = new Delivery();
		deliveryArray[1].type = 1;
		deliveryArray[1].frequency = endMHz;
		deliveryArray[1].symbolRate = symRate;
		deliveryArray[1].modulation = modul;
		
		Search.startCableSearch(2, deliveryArray);
		searchFlag = true;
		Utility.ioctlWrite("NM_Search", "nAction:"+1+",nParam1:"+1+",nParam2:"+startMHz+",nParam3:"+symRate+",nParam4:"+modul+",nParam5:"+endMHz);	
	} else if (requests.searchType == "2") { //自动搜索
		$("mainTitle").innerText = $L.PS_TITLE + "—" + $L.AUTO_SEARCH;
		// 自动搜索前将区域码设置为默认值1
		sysData.set("NanjingAreacode", "1");
		Utility.setEnv("autoSearch", "Y");
		Utility.setEnv("isNeedUpdate", "0");
		searchType = 2;
		SysSetting.deleteAllService();//删除所有节目
		var currFreq = Number($G.sysDa.get("SEARCH.frequency_0"))*1000;
		var currFreqSymbolRate = Number($G.sysDa.get("SEARCH.symbol_0"));
		var currFreqModulation = Number($G.sysDa.get("SEARCH.modulation_0"));
		$("MHz_NUM").innerText = currFreq / 1000;
		$("KS_speed").innerText = currFreqSymbolRate;
		$("AM_NUM").innerText = 16 * Math.pow(2, currFreqModulation - 1);
		
		var delivery = new Delivery();
		delivery.type = 1;
		delivery.frequency = currFreq;
		delivery.symbolRate = currFreqSymbolRate;
		delivery.modulation = currFreqModulation;
		Search.startCableSearch(1, [delivery]);
		searchFlag = true;
		Utility.ioctlWrite("NM_Search", "nAction:"+1+",nParam1:"+2+",nParam2:"+currFreq+",nParam3:"+currFreqSymbolRate+",nParam4:"+currFreqModulation);	
	}
	refreshSignalInfo();
}

function searchEnd(){
	searchFlag = false;
	$("tvNum").innerText = tvNum;
	$("radioNum").innerText = radioNum;
	Utility.println("tvNum:"+tvNum+",radioNum:"+radioNum+",dataNum:"+dataNum);
	Search.stopSearch();
	ServiceDB.save();
	sysData.submit();		// 保存区域码
	//弹出框 
	area = 1;
	$("alert").style.visibility = "visible";
	clearTimeout(timeoutFlag);
	Utility.ioctlRead("ReadFile");
	DVB.clearShowEvent();
}

function getCurrDelieveryServices(){
	for (var i = 0; i < serviceArr.length; i++) {
		var service = serviceArr[i];
		if (service.type == DVB.SERVICE_TYPE_TV) {
			tvNum++;
			currServiceList.push(service);
		} else if (service.type == DVB.SERVICE_TYPE_RADIO) {
			radioNum++;
			currServiceList.push(service);
		} else if (service.type == DVB.SERVICE_TYPE_DATA_BROADCAST) {
			dataNum++;
		} else if (requests.searchType == "0" && Utility.getEnv("door") == "Y") {
			tvNum++;
			currServiceList.push(service);
		}
	}
	showServices();
}
function showServices(){
	if (currServiceList.length > 0) {
		var tvStartPos = 0;
		if (currServiceList.length > lineSize) {
			tvStartPos = currServiceList.length - lineSize;
		}
		for (var i = tvStartPos, j = 0; j < 7 && i < currServiceList.length; i++, j++) {
			$("channelNum_" + j).innerText = $G.leftPadStr(i + 1, "0", 3);
			$("channelName_" + j).innerText = currServiceList[i].name != "" ? currServiceList[i].name.sub(12) : "";
		}
	}
}

function refreshSignalInfo(){
	if (timeoutFlag != -1) {
		clearTimeout(timeoutFlag);
		timeoutFlag = -1;
	}
	signalStrength = DVB.signalStrength; //信号强度
	signalQuality = DVB.signalQuality; //信息质量
	signalCN = DVB.signalCN; // 信号误码率
	$('progress_0').width = signalStrength / 100 * 265;
	$('progress_1').width = signalQuality / 100 * 265;
	$('p_value_0').innerText = signalStrength + "dBuv";
	$('p_value_1').innerText = signalQuality + "dB";
	
	timeoutFlag = setTimeout("refreshSignalInfo()", 800);
}

function searchExit(){
	if (searchFlag) {
		searchFlag = false;
		Search.stopSearch();
		ServiceDB.revert();
		ServiceDB.save();
	}
}

function goBack(){
	$G.exitToPlay();
}

function doMenu() {
	return;
}

function exitPage() {
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 56);
	Utility.setEnv("autoSearch", "N");
}