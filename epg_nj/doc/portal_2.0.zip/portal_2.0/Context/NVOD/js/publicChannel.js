
var serviceList = ServiceDB.getServiceList();

var tvList = serviceList.filterService(ServiceDB.LIST_TYPE_SERVICE, "TV");
var centralChannels = serviceList.filterService(ServiceDB.LIST_TYPE_BAT, 11);
var nativeChannels = serviceList.filterService(ServiceDB.LIST_TYPE_BAT, 12);
var provincialChannels = serviceList.filterService(ServiceDB.LIST_TYPE_BAT, 13);
//var infoSrvChannels = serviceList.filterService(ServiceDB.LIST_TYPE_BAT, 14);
var hdChannels = serviceList.filterService(ServiceDB.LIST_TYPE_BAT, 22);
var payChannels = serviceList.filterService(ServiceDB.LIST_TYPE_BAT, 21);
//var allChannels = serviceList.filterService(ServiceDB.LIST_TYPE_BAT, 15);
var allChannels = serviceList.filterService(ServiceDB.LIST_TYPE_SERVICE, "TV");
var volumeBar, audioChannelOptions = [], audioChannelText,scrollbar;
var timerManager = new TimerManager();
var publicChannel, groupNum = 0;
var area = 1, currService, showTipsFlag = false;
var groupIndex = 0, channelIndex = 0;		//将来可能要记录或者从全局变量中更改
var params = $G.getParams(window.location.href);
var mp = new MediaPlayer();
mp.setVideoDisplayMode(0);
mp.setVideoDisplayArea(735, 140, 448, 227);
mp.refreshVideoDisplay();
var nativePwd = $G.sysDa.get("localpwd");

var groupListView;
function initGroup(item, index, focusIndex) {
	$("group_" + focusIndex).innerText = item ? item.name : "";
}
function onFocusMove_0(oldPos, newPos) {
	for (var i = 0; i < 4; i++) {
		$("password_" + i).style.color = "#FFF";
		$("error_text").innerText = $GL.INPUT_NUM;	
	}
	$("group_focus").style.top = 55*newPos + "px";
}
function onFocus_0(index) {
	$("group_focus").style.top = 55*index + "px";
	$("group_focus").style.backgroundImage = "url(../images/nvod_list_focus_2.png)";
	$("group_focus").style.visibility = "visible";
}
function onBlur_0(index) {
	$("group_focus").style.top = 55*index + "px";
	$("group_focus").style.backgroundImage = "url(../images/nvod_list_focus.png)";
	$("group_focus").style.visibility = "visible";
}

var channelListView = new List(10, showList, onFocusMove, onFocus, onBlur);

function showList(item, index, focusIndex){
	$("channelName_" + focusIndex).innerText = item ? item.name : "";
}
function onFocusMove(oldPos, newPos) {
	for (var i = 0; i < 4; i++) {
		$("password_" + i).style.color = "#FFF";
		$("error_text").innerText = $GL.INPUT_NUM;		
	}
	$("channelName_" + oldPos).style.color = "#fff";
	$("listFocus_0").style.top = 31 + 45*newPos + "px";
	$("channelName_" + newPos).style.color = "#111";
}
function onFocus(index) {
	$("listFocus_0").style.backgroundImage = "url(../images/nvod_lt_focus.png)";
	$("listFocus_0").style.top = 31 + 45*index + "px";
	$("listFocus_0").style.visibility = "visible";
	$("channelName_" + index).style.color = "#111";
}
function onBlur(index) {
	$("listFocus_0").style.backgroundImage = "url(../images/nvod_lt_focus_2.jpg)";
	$("listFocus_0").style.top = 31 + 45*index + "px";
	$("listFocus_0").style.visibility = "visible";
}
var playTimer = -1;
function init() {
	if (hdChannels.length > 0) {
		publicChannel = [
			{name:$GL.GROUP_0, value:centralChannels},
			{name:$GL.GROUP_1, value:nativeChannels},
			{name:$GL.GROUP_2, value:provincialChannels},
			{name:$GL.GROUP_5, value:hdChannels},
			{name:$GL.GROUP_6, value:payChannels},
			{name:$GL.GROUP_4, value:allChannels}
		];
		groupNum = 6;
	} else {
		publicChannel = [
			{name:$GL.GROUP_0, value:centralChannels},
			{name:$GL.GROUP_1, value:nativeChannels},
			{name:$GL.GROUP_2, value:provincialChannels},
			{name:$GL.GROUP_6, value:payChannels},
			{name:$GL.GROUP_4, value:allChannels}
		];
		groupNum = 5;
	}
	
	
	if (params && params.index != "") {
		groupIndex = parseInt(params.index);
		if (hdChannels.length <= 0 && groupIndex == 3) {
			groupIndex = 0;
		} else if (hdChannels.length <= 0 && groupIndex == 4) {
			groupIndex = 3;
		}
		groupFilter();
	} else {
		groupIndex = 0;
	}
	
	initText();
	volumeBar = new Con($("volume_bar"), false, 3000, "volumeBar");
	// 获取如加广告。
	$("ad").src = "misads://typeIndex=18";
	Utility.println("=========================groupNum"+groupNum);
	groupListView = new List(groupNum, initGroup, onFocusMove_0, onFocus_0, onBlur_0);
	groupListView.bindData(publicChannel, groupIndex, 0);
	groupListView.setBlur();
	scrollbar = new Scrollbar({
		objId: "scroll_bar", 
		pageSize: 10, 
		totalBarHeight: 240
	});
	if (publicChannel[groupIndex].value.length != 0) {
		channelListView.bindData(publicChannel[groupIndex].value, channelIndex, 1);
		scrollbar.bindData(publicChannel[groupIndex].value, channelIndex);
		channelListView.setFocus();
		$("channelName_" + channelListView.focusIndex).style.color = "#111";
		playTimer = setTimeout(playVideo, 800);
	}
	audioChannelOptions = [{displayValue: $GL.TRACK_LEFT, sysValue: 'Left'},{displayValue: $GL.TRACK_RIGHT, sysValue: 'Right'},{displayValue: $GL.TRACK_STEREO, sysValue: 'Stereo'}];
	audioChannelText = new LRButton("audio_channel_text", function(){}, function(){}, showAudioChannel, function(){});
	audioChannelText.bindData(audioChannelOptions);
	onDisplayMessageEvent(DVB.getShowEvents());	
}
function groupFilter() {
	var startList = publicChannel[groupIndex].value;
	var tempService = tvList.currentService;
	var tempIndex = startList.findIndex(tempService);
	if (tempIndex != -1) {
		channelIndex = tempIndex;
	} else {
		channelIndex = 0;
	}
}

var audioFlag = false, audioTimer = -1;
function changeAudioChannel() {
	clearTimeout(audioTimer);
	$("audio_channel_text").style.visibility = "visible";
	var currAudioChannel = mp.player.getCurrentAudioChannel();
	if (!audioFlag) {
		audioChannelText.setValue(currAudioChannel);
		audioFlag = true;
	} else {
		audioChannelText.right();
		mp.player.setCurrentAudioChannel(audioChannelText.getValue());
	}
	audioTimer = setTimeout(function() {
		$("audio_channel_text").style.visibility = "hidden";
		$G.sysDa.set("AudioTrack",audioChannelText.getValue());
		$G.sysDa.submit();
		audioFlag = false;
	}, 3000);
}

function showAudioChannel(id, value) {
	$(id).innerText = value;
}
function initText() {
	var txtArr = {
		menuTitle : $GL.GROUP_NAME,
		tips : $GL.GROUP_TIPS,
		soundTitle : $GL.SOUND,
		p_7:$GL.TIPS, 
		error_text:$GL.INPUT_NUM,
		box_infor:$GL.INPUT_LOCAL_PSW,
	};
	for (var id in txtArr) {
		$(id).innerText = txtArr[id];
	}
}

function changeVolume(offset) {
	var volume;
	if (volumeMode == 0) {
		volume = currService ? currService.volume : mp.getVolume();
	} else {
		volume = mp.getVolume();
	}
	volume += offset;
	if (volume < 0) volume = 0;
	if (volume > 31) volume = 31;
	currService.volume = volume;
	mp.setVolume(volume);
	$("volume_value").innerText = volume;
	$("volume_progress").style.width = 375 / 31 * volume + "px";
	volumeBar.show();
	if (channelBar.isVisible) channelBar.hide();
	if (mp.getMuteFlag() == 1) {
		setMuteFlag(0);
	}
}

function setMute() {
	var muteFlag = mp.getMuteFlag();
	muteFlag = muteFlag == 0 ? 1 : 0;
	setMuteFlag(muteFlag);
}

function setMuteFlag(flag) {
	mp.setMuteFlag(flag);
	volumeBar.hide();
	if (flag == 0) {//有声
		$('mutePic').style.visibility = "hidden";
	} else {
		$('mutePic').style.visibility = "visible";
		$("muteTxt").innerText = $GL.MUTE_TXT;
	}
}

// 更新广告
var misTimer;
function misUpdateAd() {
	$("ad").src = "misads://typeIndex=18";
	Utility.println("-----pub: get ad-------");
}
function misChangeAd() {
	Utility.println("-----pub: clear ad, new ad-------");
	clearTimeout(misTimer);
	misTimer = setTimeout(misUpdateAd, 600);
}

var inputStatus = false;
function eventHandler(evt) {
	Utility.ioctlWrite("motoKey2Dvb", "");
	switch (evt.code) {
		case "KEY_UP":
			if (area == 0) {
				groupListView.up();
				$("channelName_" + channelListView.focusIndex).style.color = "#fff";
				groupIndex = groupListView.currIndex;
				channelListView.bindData(publicChannel[groupIndex].value, 0, 1);
				scrollbar.bindData(publicChannel[groupIndex].value, 0);
				channelListView.setBlur();
				$("channelName_" + channelListView.focusIndex).style.color = "#111";
				hidePwdBox();
			} else if (area == 1) {
				channelListView.up();
				scrollbar.setPosition(channelListView.currIndex);
				DVB.clearShowEvent();
				hidePwdBox();
			}
			//misChangeAd();		// 更新广告
			clearTimeout(playTimer);
			playTimer = setTimeout(playVideo, 800);
			break;
		case "KEY_DOWN":
			if (area == 0) {
				groupListView.down();
				$("channelName_" + channelListView.focusIndex).style.color = "#fff";
				groupIndex = groupListView.currIndex;
				channelListView.bindData(publicChannel[groupIndex].value, 0, 1);
				scrollbar.bindData(publicChannel[groupIndex].value, 0);
				channelListView.setBlur();
				$("channelName_" + channelListView.focusIndex).style.color = "#111";
				hidePwdBox();
			} else if (area == 1) {
				//misChangeAd();		// 更新广告
				channelListView.down();
				scrollbar.setPosition(channelListView.currIndex);
				DVB.clearShowEvent();
				hidePwdBox();
			}
			//misChangeAd();		// 更新广告
			clearTimeout(playTimer);
			playTimer = setTimeout(playVideo, 800);
			break;
		case "KEY_PAGE_UP":
			if (area == 0) {
				return;
			} else if (area == 1) {
				if (channelListView.totalPage > 1) {
					//misChangeAd();		// 更新广告
					$("channelName_" + channelListView.focusIndex).style.color = "#fff";
					channelListView.pageUp();
					scrollbar.setPosition(channelListView.currIndex);
					DVB.clearShowEvent();
					hidePwdBox();
					clearTimeout(playTimer);
					playTimer = setTimeout(playVideo, 800);
				}
			}
			break;
		case "KEY_PAGE_DOWN":
			if (area == 0) {
				return;
			} else if (area == 1) {
				if (channelListView.totalPage > 1) {
					//misChangeAd();		// 更新广告
					$("channelName_" + channelListView.focusIndex).style.color = "#fff";
					channelListView.pageDown();
					scrollbar.setPosition(channelListView.currIndex);
					DVB.clearShowEvent();
					hidePwdBox();
					clearTimeout(playTimer);
					playTimer = setTimeout(playVideo, 800);
				}
			}
			break;
		case "KEY_LEFT":
			if (area == 0) {
				return;
			} else if (area == 1) {
				area = 0;
				channelListView.setBlur();
				$("channelName_" + channelListView.focusIndex).style.color = "#111";
				groupListView.setFocus();
			}
			break;
		case "KEY_RIGHT":
			if (area == 0) {
				area = 1;
				groupListView.setBlur();
				channelListView.setFocus();
			} else if (area == 1) {
				return;
			}
			break;
		case "KEY_ENTER":
			doEnter();
			break;
		case "DVB_SHOW_INFO":
			onDisplayMessageEvent(DVB.getShowEvents());
			break;
		case "DVB_HIDE_INFO":
			hiddenTips();
			break;
		case "KEY_VOLUME_UP":
			changeVolume(1);
			break;
		case "KEY_VOLUME_DOWN":
			changeVolume(-1);
			break;
		case "KEY_MUTE":
			setMute();
			break;
		case "KEY_AUDIO":
			changeAudioChannel();
			break;
		case "KEY_BACK":
			//$G.exitToMenu();
			history.back();
			break;
		case "KEY_EXIT":
			$G.exitToMenu();
			break;
		case "KEY_NUMERIC":
			if (inputStatus) {
				inputNum(evt.param);
			} else {
				helpTo(evt.param);
			}
			break;
		case "DVB_PRESENT_EVENT_REFRESH":
		case "DVB_FOLLOWING_EVENT_REFRESH":
			clearTimeout(pfTimer);
			pfTimer = setTimeout(refreshPFInfo, 1000);
			return;
		case "MIS_GETEPG_STATUS":
			var misStr = DVB.getEvent(45783, event.userInt);
			if (misStr == "success") {
				$("adDiv").style.visibility = "visible";
			} else {
				$("adDiv").style.visibility = "hidden";
			}
			Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 00);
			break;
	}
}
var showTipsType = 0;
function onDisplayMessageEvent(events) {
	Utility.println("=======================================HD hiddenTips============");
	var info = "";
	Utility.println("onDisplayMessageEvent evt length = "+events.length);
	if (events.length > 0) {
		var maxId = 0;//events.length-1;
		Utility.println("evt type = "+events[maxId].type+" sub type = "+events[maxId].msgSubType);
		switch (events[maxId].type) {
			case 40021:
				inputStatus = true;
				$("password_box").style.visibility = "visible";
				showTips("加锁节目");
				break;
			case 40023:
				showTipsType = 0;
				if (serviceList.length == 0) {
					info = $GL.NO_SERVICE;
				} else {
					info = "无信号";
				}
				showTips(info);
				break;
			case 40081:
				var tipsArr = ['',$GL.CA_1, $GL.CA_2, $GL.CA_3, $GL.CA_4, $GL.CA_5, $GL.CA_6, $GL.CA_7, $GL.CA_8, $GL.CA_23, $GL.CA_10, $GL.CA_11, $GL.CA_12, $GL.CA_13, $GL.CA_14, $GL.CA_15, $GL.CA_16, $GL.CA_17, $GL.CA_18, $GL.CA_19, $GL.CA_20, $GL.CA_21,$GL.CA_22];
				var type = Number(events[maxId].msgSubType);
				showTipsType = 0;
				
				if(type == 1 || type == 2 || type == 10)
				{
					Utility.ioctlWrite("NM_Error","nAction:"+1+",code:"+40081+",subcode:"+type);
				}
				
				if (type < 23) {
					info = tipsArr[type];
					if(type == 9) {	
						Utility.setEnv("NM_CaStatus", "failed");
						showTips("未订购,按确认键了解详情");
						var displayStr = Utility.ioctlRead("channelDescription");
						showTipsType = 1;
					} else {
						showTipsType = 0;
						showTips(info);
					}
				} else if (type == 23) {//在屏幕上消除alarm消息-23
					hiddenTips();
				}
				break;
			case 40083:
				var tipsArr = ['',$GL.CA_MSG_0,'','',$GL.CA_MSG_1];
				var type = Number(events[maxId].msgSubType);
				if(type == 1){
					showTipsType = 0;
					var info = $GL.NO_CARD;
					showTips(info);
				}else{
					showTipsType = 0;
					info = tipsArr[type];
					showTips(info);
				}
				break;
		}
	}
}
function helpTo(num) {
	if (num == 0) {
		var ethenets = Network.ethenets[0];
		var ipAddr = ethenets.IPs[0];
		var currIp = ipAddr.IPAddres;
		Utility.println("======portal========currIp===" + currIp);
		var caSerialNum = CA.serialNumber;
		Utility.println("======portal========caSerialNum===" + caSerialNum);
		var stbSerialNum = SysInfo.STBSerialNumber;
		Utility.println("======portal========stbSerialNum===" + stbSerialNum);
		var codeStr = "Y-coship-coship" + currIp + "-etc";
		
		var helpTailAddr = "cardid=" + caSerialNum + "&clientid=" + stbSerialNum + "&method=&channel=0000:000:00:0000&code=" + codeStr;
		Utility.setEnv("zeroChannel", "NM_Help");
		Utility.ioctlWrite("NM_Help", "nAction:"+1);
		window.location.href = "http://hdzchannel.jsamtv.com/epg/show.do?app=zchannel&hd=y&content=help&detail=50009&" + helpTailAddr;
	}
}
var pwdStr = new Array(), pwdPos = 0;
function inputNum(num) {
	pwdStr[pwdPos] = num;
	numLR(1);
	if (pwdPos == 0) {
		if (pwdStr.join("") == nativePwd) {
			$("password_3").style.color = "#111";
			setTimeout('$("password_box").style.visibility = "hidden"',200);
			inputStatus = false;
			mp.unlockPlay();
		} else {
			$("password_3").style.color = "#111";
			setTimeout(function() {
				for(var i = 1; i < 4; i++) {
					$("password_0").style.color = "#FFF";	
					$("password_" + i).style.color = "#FFF";	
				}
			},200);
			$("error_text").innerText = $GL.PSW_INVALID;
		}
		pwdStr = new Array();
	}
}
function numLR(_dis) {
	$("password_" + pwdPos).style.color = "#111";
	pwdPos = (pwdPos + _dis + 4) % 4;
	//$("password_" + pwdPos).style.color = "#111";
}
function hidePwdBox() {
	if (inputStatus) {
		$("password_box").style.visibility = "hidden";
		inputStatus = false;
		DVB.clearShowEvent();
	}
	hiddenTips();
}

function showTips(_tips){
	if(showTipsType==0){
		$('alert').innerText = _tips;
		$('alert').style.visibility = "visible";
		
	}else{
		if($("alert").style.visibility == "visible"){
			$("alert").style.visibility = "hidden";
		}
	}
	if(!showTipsFlag){
		showTipsFlag=true;
	}
}
function hiddenTips(){
	$('alert').style.visibility = "hidden";
	showTipsFlag = false;
	Utility.setEnv("NM_CaStatus", "success");
	var events = DVB.getShowEvents();
	if (events.length > 0) {
		onDisplayMessageEvent(events);
	}
}
var volumeMode = $G.sysDa.get("VolumeSaveMode") != "" ? parseInt($G.sysDa.get("VolumeSaveMode")) : 0;
function initSound(){
	//var volume = currService ? currService.volume : mp.getVolume();
	var volume;
	if (volumeMode == 0) {
		volume = currService ? currService.volume : mp.getVolume();
	} else {
		volume = $G.sysDa.get("UniformVolume") != "" ? parseInt($G.sysDa.get("UniformVolume")) : 16;
	}
	mp.setVolume(volume);
	Utility.println("==============currService.volume==============="+volume);
	$("volume_value").innerText = volume;
	$("volume_progress").style.width = 375 / 31 * volume + "px";
	if (mp.getMuteFlag() == 1) {
		$('mutePic').style.visibility = "visible";
		$("muteTxt").innerText = $GL.MUTE_TXT;
	}
}

function showChannelBar() {
	clearChannelBar();
	$("time").innerText = $G.dateFormat((new Date()), "hh:mm");
	$("num").innerText = $G.leftPadStr(currService.logicNumber, "0", 3);
	$("channelName").innerText = currService.name != "" ? currService.name.sub(14) : "";
	$("p_time").innerText = $G.dateFormat(currService.presentProgram.startTime, "hh:mm");
	$("p_name").innerHTML = $G.txtMarquee(currService.presentProgram.name, 17, 400);
	$("f_time").innerText = $G.dateFormat(currService.followingProgram.startTime, "hh:mm");
	$("f_name").innerHTML = $G.txtMarquee(currService.followingProgram.name, 17, 400);
	var leftSeconds = timeDiff((new Date()), currService.presentProgram.endTime);
	var totalSeconds = timeDiff(currService.presentProgram.startTime, currService.presentProgram.endTime);
	var progressLen = (leftSeconds / totalSeconds) * 89;
	if (progressLen > 89) {
		progressLen = 89;
	}
	$("progress").style.width = progressLen + "px";
}
var pfTimer = -1;
function refreshPFInfo() {
	$("p_time").innerText = $G.dateFormat(currService.presentProgram.startTime, "hh:mm");
	$("p_name").innerHTML = $G.txtMarquee(currService.presentProgram.name, 17, 400);
	$("f_time").innerText = $G.dateFormat(currService.followingProgram.startTime, "hh:mm");
	$("f_name").innerHTML = $G.txtMarquee(currService.followingProgram.name, 17, 400);
	var leftSeconds = timeDiff((new Date()), currService.presentProgram.endTime);
	var totalSeconds = timeDiff(currService.presentProgram.startTime, currService.presentProgram.endTime);
	var progressLen = (leftSeconds / totalSeconds) * 89;
	if (progressLen > 89) {
		progressLen = 89;
	}
	$("progress").style.width = progressLen + "px";
}

function clearChannelBar() {
	$("p_time").innerText = "";
	$("p_name").innerHTML = "";
	$("f_name").innerText = "";
	$("f_time").innerHTML = "";
	$("progress").style.width = "0px";
}

/*
 * 将Date对象转换为妙
 */
function dateToSecond(date) {
	return date.getHours()*3600 + date.getMinutes()*60 + date.getSeconds();
}
/*
 * 计算Date对象的时间差,返回值为秒
 */
function timeDiff(nowTime, endTime) {
	return (dateToSecond(endTime) - dateToSecond(nowTime));
}
function playVideo() {
	var currList = publicChannel[groupListView.currIndex].value;
	currService = currList.getAt(channelListView.currIndex);
	$G.setFrontPanelDisplay(currService.logicNumber, 0);
	mp.setSingleMedia(currService.getLocation());
	mp.playFromStart();	
	initSound();
	showChannelBar();
}
function Con(obj, isVisible, delayTime, name){
	var self = this;
	self.isVisible = isVisible;
	self.obj = obj;
	self.name = name;
	self.delayTime = delayTime;
	var timer = new Timer(name);
	timerManager.add(timer);
	
	self.show = function(){
		self.obj.style.visibility = "visible";
		self.isVisible = true;
		if (self.delayTime != -1) {
			var timer = timerManager.get(self.name);
			timer.exec(self.hide, self.delayTime);
		}
	};
	
	self.hide = function(){
		self.obj.style.visibility = "hidden";
		self.isVisible = false;
		self.clearTimer();
		if (self.name == "volumeBar") {
			ServiceDB.save();
		}
	};
	/**
	 * 重设Timer
	 * @param {Number} _delayTime 不传时，则按默认。否则按此新值执行隐藏
	 */
	self.resetTimer = function(_delayTime){
		if (self.delayTime != -1) {
			var timer = timerManager.get(self.name);
			var delay = self.delayTime;
			if(typeof(_delayTime)!="undefined"){
				delay = _delayTime;
			}
			timer.exec(self.hide, delay);
		}
	};
	
	self.clearTimer = function(){
		var timer = timerManager.get(self.name);
		timer.clear();
	}
}

function doEnter() {
	if(area == 1) {
		var index = 0;
		index = tvList.findIndex(currService);
		tvList.moveTo(index);
		window.location.href = "../play/play.htm";
	}
}

function exitPage() {
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 00);
	stopMediaPlayer();
	ServiceDB.save();
}

