$L.init("NVOD");	//语言设置

SysSetting.panelDisplayText("NuoD");
var bouquetArea = true;	//参考业务显示区
var eventArea = false;		//参考事件显示区
var timeShiftArea = false;	//时移事件显示区 
var descFlag = false;	//是否由描述信息
var orderInfoFlag = false;
//构造事件列表对象
var eventListView = new List(8, showEvents, onListFocusMove_0, eventsOnFocus, eventsOnBlur, noEvents);
//构造时间列表对象
var timeShiftListView = new List(5, showTs, onListFocusMove_1, tsOnFocus, tsOnBlur, noTss);
// 定义一个列表对象以及时移事件对象
var refEvents, tsEvents;

var nvodLocation;
var volumeBar;
var timerManager = new TimerManager();
var count;	//从内置对象NVOD中获取有几个参考业务分组
//业务
var currPage = 1;	//业务分组的页数
var totalPage = 1;	//计算总共分为几页
var currBat = 0;	//初始化业务位置为第一个

var currEventPos = 0;
var currTfPos = 0;
var lastPage = 1;
var lastGroupPos = 0;
var lastEventPos = 0;
var lastTfPos = 0;
var leftSeconds;

//var flag = false;	//用来描述是否在添加预定提示框区域
var conflictFlag = false, showTipsFlag = false;

var eventIndex;
var currEvent;
var isSearchEnd = false;

var mp = new MediaPlayer();
mp.setStopMode(0);
mp.stop();
var backFromProOrder = Utility.getEnv("backFromProOrder");
$G.debug("============================backFromProOrder", backFromProOrder);
var backFromNVODPlay = Utility.getEnv("backFromNVODPlay");
$G.debug("============================backFromNVODPlay", backFromNVODPlay);

function nvod_searchComplete() {
	count = NVOD.groupCount;
	totalPage = Math.ceil(count/6);
	showBats();
	refEvents = NVOD.getRefEvents(currBat);
	$G.debug("===========================播放顺序测试：", "下面开始画出节目分组列表");
	eventListView.bindData(refEvents, 0, 0);
	eventListView.setBlur();
	$("realTip").innerText = $L.REAL_TIPS;
	tsEvents = refEvents[0].getTimeshiftEvents();
	timeShiftListView.bindData(tsEvents, 0, 0);
	timeShiftListView.setBlur();
	mp.setVideoDisplayMode(0);
	mp.setVideoDisplayArea(738, 142, 435, 225);
	mp.refreshVideoDisplay();
	playVideo();
	refreshTSEvent();
}

//初始化函数
function init() {
	initText();
	
	// 获取如加广告
	$("ad").src = "misads://typeIndex=20";
		
	$("tip_3").style.display = "none";	
	volumeBar = new Con($("volume_bar"), false, 3000, "volumeBar");
	if (backFromNVODPlay == "OK" || backFromProOrder == "YES") {
		isSearchEnd = true;
		rePaint();
		Utility.setEnv("backFromNVODPlay", "");
		Utility.setEnv("backFromProOrder", "");
		mp.setVideoDisplayMode(0);
		mp.setVideoDisplayArea(738, 142, 435, 225);
		mp.refreshVideoDisplay();
	} else {
		setTimeout("NVOD.enter()", 800);
		$("realTip").innerText = $L.NVOD_INFO;
	}
	setTimeout(function() {
		if (!isSearchEnd) {
			NVOD.exit();
			$("realTip").innerText = "搜索NVOD信息失败，退出后请重新搜索！";
			window.location.href = "../play/play.htm";
		}
	}, 15000);
}
//从NVOD播放页面回来之后重新按照保存的焦点位置重绘界面

function rePaint() {
	count = NVOD.groupCount;
	totalPage = Math.ceil(count/6);
	$G.debug("======从可恢复页面返回重新写入=============分组数目为：", count);
	currBat = parseInt(Utility.getEnv("lastGroupPos"));
	currPage = parseInt(Utility.getEnv("lastPage"));
	lastEventPos = parseInt(Utility.getEnv("lastEventPos"));
	lastTfPos = parseInt(Utility.getEnv("lastTfPos"));
	showBats();
	refEvents = NVOD.getRefEvents((currPage - 1)*6 + currBat);
	eventListView.bindData(refEvents, lastEventPos, 0);
	$("realTip").innerText = $L.REAL_TIPS;
	tsEvents = refEvents[lastEventPos].getTimeshiftEvents();
	timeShiftListView.bindData(tsEvents, lastTfPos, 0);
	revertFocus();
	playVideo();
	refreshTSEvent();
	clearEnv();
}
function revertFocus() {
	var currArea = Utility.getEnv("currArea");
	switch (currArea) {
		case "bouquetArea":
			timeShiftArea = false;
			bouquetArea = true;
			eventArea = false;
			$("groupName_" + currBat).className = "focus";
			eventListView.setBlur();
			timeShiftListView.setBlur();
			break;
		case "eventArea":
			timeShiftArea = false;
			bouquetArea = false;
			eventArea = true;
			$("groupName_" + currBat).className = "blur";
			eventListView.setFocus();
			timeShiftListView.setBlur();
			break;
		case "timeShiftArea":
			timeShiftArea = true;
			bouquetArea = false;
			eventArea = false;
			$("groupName_" + currBat).className = "blur";
			eventListView.setBlur();
			timeShiftListView.setFocus();
			break;
	}
}
function clearEnv() {
	Utility.setEnv("currArea", "");
	Utility.setEnv("lastPage", 0);
	Utility.setEnv("lastGroupPos", 0);
	Utility.setEnv("lastEventPos", 0);
	Utility.setEnv("lastTfPos", 0);
	Utility.setEnv("leftSeconds", 0);
	Utility.setEnv("startTime", "");
	Utility.setEnv("endTime", "");
	Utility.setEnv("eventName", "");
	Utility.setEnv("enventPrice", "");
}

function initText() {
	var textArr = {"menuTitle":$L.HEAD_TITLE,"realTip" : $L.REAL_TIPS,"fixTip":$L.FIXED_TIPS,"infoBotom":$GL.OK,
					"confirmBtn_0":$GL.OK, "confirmBtn_1":$GL.CANCEL, "confirmTitle":$L.TIP_TITLE,"soundTitle" : $GL.SOUND};
	for (var id in textArr) {
		$(id).innerText = textArr[id];
	}
}

// 更新广告
var misTimer;
function misUpdateAd() {
	$("ad").src = "misads://typeIndex=20";
	Utility.println("-----nvod: get ad-------");
}
function misChangeAd() {
	Utility.println("-----nvod: clear ad, new ad-------");
	clearTimeout(misTimer);
	misTimer = setTimeout(misUpdateAd, 600);
}

//事件响应函数
function eventHandler(evt) {
	switch (evt.code) {
		case "KEY_UP" :
			if (!isSearchEnd) return;
			if (descFlag || conflictFlag || orderInfoFlag) return;
			if (bouquetArea) {
				upDown(-1);
			} else if (eventArea) {
				misChangeAd();		// 更新广告
				eventListView.up();
				updateEventName();
				refreshNVOD_TIMESHIFT();
			} else if (timeShiftArea) {
				timeShiftListView.up();
			}
			break;
		case "KEY_DOWN" :
			if (!isSearchEnd) return;
			if (descFlag || conflictFlag || orderInfoFlag) return;
			if (bouquetArea) {
				upDown(1);
			} else if (eventArea) {
				misChangeAd();		// 更新广告
				eventListView.down();
				updateEventName();
				refreshNVOD_TIMESHIFT();
			} else if (timeShiftArea) {
				timeShiftListView.down();
			}
			break;
		case "KEY_LEFT" :
			if (!isSearchEnd) return;
			if (descFlag || orderInfoFlag) return;
			if (conflictFlag) {
				conflictButton();
			} else if (bouquetArea) {
					return;
				} else if (eventArea) {
					bouquetArea = true;
					eventArea = false;
					$("realTip").innerText = $L.REAL_TIPS;
					currEventPos = eventListView.currIndex;
					$("groupName_" + currBat).className = "focus";
					eventListView.setBlur();
				} else if (timeShiftArea) {
					timeShiftArea = false;
					eventArea = true;
					timeShiftListView.setBlur();
					eventListView.setFocus();
					updateEventName();
				}
			break;
		case "KEY_RIGHT" :
			if (!isSearchEnd) return;
			if (descFlag || orderInfoFlag) return;
			if(conflictFlag) {
				conflictButton();
			} else if (bouquetArea) {
					bouquetArea = false;
					eventArea = true;
					$("groupName_" + currBat).className = "blur";
					eventListView.setFocus();
					updateEventName();
				} else if (eventArea) {
					eventArea = false;
					timeShiftArea = true;
					currEventPos = eventListView.currIndex;
					eventListView.setBlur();
					timeShiftListView.setFocus();
					$("realTip").innerText = $L.REAL_TIPS;
				} else if (timeShiftArea) {
					return;
				}
			break;
		case "KEY_PAGE_UP" :
			if (!isSearchEnd) return;
			if (descFlag || conflictFlag || orderInfoFlag) return;
			if (eventArea) {
				misChangeAd();		// 更新广告
				eventListView.pageUp();
				updateEventName();
			} else if (timeShiftArea) {
				timeShiftListView.pageUp();
			}
			break;
		case "KEY_PAGE_DOWN" :
			if (!isSearchEnd) return;
			if (descFlag || conflictFlag || orderInfoFlag) return;
			if (eventArea) {
				misChangeAd();		// 更新广告
				eventListView.pageDown();
				updateEventName();
			} else if (timeShiftArea) {
				timeShiftListView.pageDown();
			}
			break;
		case "KEY_INFO" :
			if (!isSearchEnd) return;
			if (conflictFlag || orderInfoFlag) return;
			if ((bouquetArea || timeShiftArea) && !descFlag) {
				showInfo();
			}
			break;
		case "KEY_ENTER" :
			if (!isSearchEnd) return;
			if (descFlag) {
				hideInfo();
			} else if (orderInfoFlag) {
				hideOrderInfo();
			} else if (conflictFlag) {
				programConflict();
			} else if (timeShiftArea && tsEvents[timeShiftListView.currIndex].timeStatus == 0) {
				nvodLocation = tsEvents[timeShiftListView.currIndex].getLocation(); 
				Utility.setEnv("currNVOD", nvodLocation);
				$G.debug("=================================nvodLocation", nvodLocation);
				currTfPos = timeShiftListView.currIndex;
				startTime = tsEvents[timeShiftListView.currIndex].startTime;
				endTime = tsEvents[timeShiftListView.currIndex].endTime;
				leftSeconds = timeDiff((new Date()), tsEvents[timeShiftListView.currIndex].endTime);
				eventName = refEvents[eventListView.currIndex].eventName;
				eventPrice = refEvents[eventListView.currIndex].price;
				saveInfo();
				var groupName = NVOD.getGroupName(currBat);
				Utility.ioctlWrite("NM_Nvod", "nAction:"+2+",NvodName:"+groupName);						
				window.location.href="NVOD_play.htm";
			} else if (timeShiftArea && tsEvents[timeShiftListView.currIndex].timeStatus == 1) {
				doOrder();
			}
			break;
		case "KEY_EXIT" :
			backToPlay();
			break;
		case "KEY_BACK" :
			if (conflictFlag || orderInfoFlag || descFlag) return;
			backToMenu();
			break;
		case "DVB_NVOD_EIT_REFRESH":
			break;
		case "DVB_NVOD_SORT_UPDATED"://NVOD分组列表个数改变	
			refreshNVOD_GROUP();
			break;
		case "DVB_NVOD_REF_EVENT_UPDATED"://NVOD参考事件列表个数改变	
			if (isSearchEnd) {
				refreshNVOD_EVENT();
			}
			break;
		case "DVB_NVOD_TS_EVENT_UPDATED"://NVOD时移事件列表个数改变
			if (isSearchEnd) {
				refreshNVOD_TIMESHIFT();
			}
			break;
		case "DVB_NVOD_TS_EVENT_COUNTER_UPDATED":
			break;
		case "DVB_NVOD_EIT_READY":////nvod搜索完成
			if (!isSearchEnd) {
				isSearchEnd = true;
				nvod_searchComplete();
			}
			break;
		case "EVT_AD_UPDATE":
			break;
		case "KEY_BLUE":	//查看预约情况
			saveInfo();
			mp.setStopMode(0);
			mp.stop();
			Utility.setEnv("backFromProOrder", "NVOD");
			window.location.href = "../epg/appointNotice.htm";
			break;
		case "DVB_SHOW_INFO":
			onDisplayMessageEvent(DVB.getShowEvents());
			break;
		case "DVB_HIDE_INFO":
			hiddenTips();
			break;
		case "KEY_VOLUME_UP":
			changeVolume(1);
			break;
		case "KEY_VOLUME_DOWN":
			changeVolume(-1);
			break;
		case "KEY_MUTE":
			setMute();
			break;
		case "MIS_GETEPG_STATUS":
			var misStr = DVB.getEvent(45783, event.userInt);
			if (misStr == "success") {
				$("adDiv").style.visibility = "visible";
			} else {
				$("adDiv").style.visibility = "hidden";
			}
			Utility.println("############################################## NVOD");
			Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 30);
			break;
		case "KEY_NUMERIC":
			if (evt.param == 0) {
				mp.player.setStopMode(0);
				mp.player.stop();
				helpTo(0);
			}
			break;			
	}
}
function helpTo(num) {
	Utility.ioctlWrite("NM_Help", "nAction:"+1);
	var ethenets = Network.ethenets[0];
	var ipAddr = ethenets.IPs[0];
	var currIp = ipAddr.IPAddres;
	Utility.println("======portal========currIp===" + currIp);
	var caSerialNum = CA.serialNumber;
	Utility.println("======portal========caSerialNum===" + caSerialNum);
	var stbSerialNum = SysInfo.STBSerialNumber;
	Utility.println("======portal========stbSerialNum===" + stbSerialNum);
	var codeStr = "Y-coship-coship" + currIp + "-etc";
	
	var helpTailAddr = "cardid=" + caSerialNum + "&clientid=" + stbSerialNum + "&method=&channel=0000:000:00:0000&code=" + codeStr;
	
	window.location.href = "http://hdzchannel.jsamtv.com/epg/show.do?app=zchannel&hd=y&content=help&detail=50009&" + helpTailAddr;
}
var startTime, endTime, eventName, eventPrice;
function saveInfo() {
	if (bouquetArea) {
		Utility.setEnv("currArea", "bouquetArea");
	} else if (eventArea) {
		Utility.setEnv("currArea", "eventArea");
	} else if (timeShiftArea) {
		Utility.setEnv("currArea", "timeShiftArea");
	}
	Utility.setEnv("lastPage", currPage);
	Utility.setEnv("lastGroupPos", currBat);
	Utility.setEnv("lastEventPos", currEventPos);
	Utility.setEnv("lastTfPos", currTfPos);
	Utility.setEnv("startTime", startTime);
	Utility.setEnv("endTime", endTime);
	Utility.setEnv("leftSeconds", leftSeconds);
	Utility.setEnv("eventName", eventName);
	Utility.setEnv("enventPrice", eventPrice);
}

function refreshNVOD_GROUP() {
	count = NVOD.groupCount;
	totalPage = Math.ceil(count/6);
	eventIndex = 0;
	nvod_searchComplete();
}
function refreshNVOD_EVENT() {
	refEvents = NVOD.getRefEvents((currPage - 1)*6 + currBat);
	eventListView.bindData(refEvents, 0, 0);
	eventListView.setBlur();
	refreshNVOD_TIMESHIFT();
}

function refreshNVOD_TIMESHIFT() {
	eventIndex = eventListView.currIndex ? eventListView.currIndex : 0;
	tsEvents = refEvents[eventListView.currIndex].getTimeshiftEvents();
	timeShiftListView.bindData(tsEvents, 0, 0);
	timeShiftListView.setBlur();
	playVideo();
}

var tsRefreshTimer = -1;
function refreshTSEvent() {
	clearTimeout(tsRefreshTimer);
	tsEvents = refEvents[eventListView.currIndex].getTimeshiftEvents();
	timeShiftListView.bindData(tsEvents, timeShiftListView.currIndex, 0);
	Utility.println("=============隔一分钟重新刷新一下时移事件列表==============");
	tsRefreshTimer = setTimeout("refreshTSEvent();", 30000);
}

function showBats() {
	var firstIndex = (currPage - 1)*6;
	for (var i=0; i<6; i++) {
		$("groupName_" + i).innerText = NVOD.getGroupName(firstIndex) ? NVOD.getGroupName(firstIndex) : "";
		firstIndex++;
	} 
	batsOnFocus();
}

function batsOnFocus() {
	$("groupName_" + currBat).className = "focus";
}

function batsOnBlur() {
	$("groupName_" + currBat).className = "";
}
function upDown(dis) {
	batsOnBlur();
	$("eventName_" + eventListView.currIndex).style.color = "#fff";
	currBat += dis;
	if (currBat > (count % 6 - 1) && currPage == totalPage) {
		currBat = 0;
		currPage = 1;
	} else if (currBat > 5) {
		currBat = 0;
		currPage++;
	}
	if (currBat < 0 && currPage == 1) {
		currBat = count % 6 - 1;
		currPage = totalPage;
		showBats();
	} else if (currBat < 0) {
		clearTimeout(timer_1);
		currPage--;
		currBat = 5;
	}
	showBats();
	batsOnFocus();
	refreshNVOD_EVENT();
}

//指定业务事件显示
function showEvents(item, index, focusIndex) {
	$("eventName_" + focusIndex).innerText = item ? item.eventName.sub(14) : "";
}

function onListFocusMove_0(oldPos, newPos) {
	$("eventName_" + oldPos).style.color = "#fff";
	$("eventName_" + oldPos).style.color = "#fff";
	$("listFocus_0").style.top = 31 + 44*newPos + "px";
	$("eventName_" + newPos).style.color = "#111";
}

function eventsOnFocus(index) {
	$("listFocus_0").style.background = "url(../images/nvod_lt_focus.png) no-repeat left top";
	$("listFocus_0").style.top = 31 + 44*index + "px"
	$("listFocus_0").style.visibility = "visible";
	$("eventName_" + index).style.color = "#111";
}

function eventsOnBlur(index) {
	$("listFocus_0").style.background = "url(../images/nvod_lt_focus_2.jpg) no-repeat left top";
	$("listFocus_0").style.top = 31 + 44*index + "px"
	$("listFocus_0").style.visibility = "visible";
	$("eventName_" + index).style.color = "#111";
}

function noEvents() {
	$("eventName_" + index).innerText = "";
}

function diffMinute(startTime) {
	var currDate = new Date();
	var rtMinutes = Math.floor(timeDiff(startTime, currDate) / 60); 
	return rtMinutes;
}
/*
 * 将Date对象转换为妙
 */
function dateToSecond(date) {
	return date.getHours()*3600 + date.getMinutes()*60 + date.getSeconds();
}
/*
 * 计算Date对象的时间差,返回值为秒
 */
function timeDiff(nowTime, endTime) {
	return (dateToSecond(endTime) - dateToSecond(nowTime));
}

//某时间的时移事件显示
function showTs(item, index, focusIndex) {
	if (item) {
		$("ts_Time_" + focusIndex).innerText = item ? $G.dateFormat(item.startTime, "hh:mm") : "";
		switch (item.timeStatus) {
			case -1 :
				$("status_" + focusIndex).innerText = "";
				break;
			case 0 :
				$("status_" + focusIndex).innerText = $L.TIP_PLAY + diffMinute(item.startTime) + $L.MINUTES;
				break;
			case 1 :
				if (Orders.isOrdered(item)) {
					$("status_" + focusIndex).innerText = $L.PLAYED;
				} else {
					$("status_" + focusIndex).innerText = $L.NOT_PALY;
				}
				break;
		}	
	} else {
		$("ts_Time_" + focusIndex).innerHTML = "";
		$("status_" + focusIndex).innerText = "";
	}
}

function onListFocusMove_1(oldPos, newPos) {
	$("listFocus_1").style.top = 44*newPos + "px";
}

function tsOnFocus(index) {
	$("listFocus_1").style.background = "url(../images/tsBg_1.jpg) no-repeat left top";
	$("listFocus_1").style.top = 44*index + "px";
	$("listFocus_1").style.visibility = "visible";
}

function tsOnBlur(index) {
	$("listFocus_1").style.background = "url(../images/tsBg_2.jpg) no-repeat left top";
	$("listFocus_1").style.top = 44*index + "px";
	$("listFocus_1").style.visibility = "visible";
}

function noTss(index) {
	$("ts_Time_" + index).innerText = "";
	$("status_" + index).innerText = "";
}

function showInfo() {
	descFlag = true;
	$("infoDiv").style.visibility = "visible";
	$("infoTitle").innerText = $L.PRO_INFO;
	eventIndex = eventListView.currIndex ? eventListView.currIndex : 0;
	currEvent = refEvents[eventIndex] ? refEvents[eventIndex] : undefined;	//当前事件对象
	$("infoText").innerText = currEvent.description;
	if (bouquetArea) {
		Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 31);
	} else if (timeShiftArea) {
		Utility.ioctlWrite("NM_Menu", "nAction:" + 1 + ",code:" + 32);
	}
}

function hideInfo() {
	descFlag = false;
	$("infoDiv").style.visibility = "hidden";
	if (bouquetArea) {
		Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 31);
	} else {
		Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 32);
	}
}

function updateEventName() {
	eventIndex = eventListView.currIndex ? eventListView.currIndex : 0;
	currEvent = refEvents[eventIndex] ? refEvents[eventIndex] : undefined;	//当前事件对象
	$("realTip").innerText = currEvent.eventName;
}

function doOrder() {
	var order = new Order(tsEvents[timeShiftListView.currIndex].getLocation());
	$G.debug("=========================order.name:", order.name);
	$G.debug("=========================order.name:", order.location);
	if (Orders.isOrdered(tsEvents[timeShiftListView.currIndex])) {
		var deleteResult = Orders.deleteOrder(order);
		$("status_" + timeShiftListView.currIndex % 5).innerText = $L.NOT_PALY;
	}
	else {
		var orderFlag = Orders.add(order);
		$G.debug("===================orderFlag", orderFlag);
		switch(orderFlag) {
			case Orders.OK: //预定成功:0
				$("status_" + timeShiftListView.currIndex % 5).innerText = $L.PLAYED;
				Orders.save();
				break;	
			case Orders.ERROR_TIME: //已经过期:-1
				showOrderInfo($L.ORDER_0);
				break;
			case Orders.ERROR_SERVICE: //预定非法:-2
				showOrderInfo($L.ORDER_1);
				break;
			case Orders.ERROR_MAXCOUNT:
				showOrderInfo($L.ORDER_2);
				break;
			case Orders.ERROR_CONFLICT: //预定冲突:-3
				var cOrders = Orders.getConflictOrders(order);
				var orderType = Orders.getAt(0);
				var content = "";
				if (orderType.type == 2) {
					content = $L.ORDER_3.param("NVOD", cOrders[0].name);
				} else {
					content = $L.ORDER_3.param(cOrders[0].serviceName, cOrders[0].name);
				}
				showConflictDiv(content);
				break;
		}
	}
}
function showConflictDiv(_content) {
	conflictFlag = true;
	$("confirmDiv").style.visibility = "visible";
	$("confirmTxt").innerText = _content;
}
function hideConflictDiv() {
	conflictFlag = false;
	$("confirmDiv").style.visibility = "hidden";
	$("confirmTxt").innerText = "";
}
var conflictBtPos = 0;
function conflictButton() {
	$("confirmBtn_"+conflictBtPos).style.backgroundImage = "url(../images/bt_02.png)";
	conflictBtPos = (conflictBtPos + 1) % 2;
	$("confirmBtn_"+conflictBtPos).style.backgroundImage = "url(../images/bt_01.png)";
}

function programConflict() {
	$G.debug("============解决冲突进入此函数=================conflictPos", conflictPos);
	if(conflictBtPos == 0) {
		var order = new Order(tsEvents[timeShiftListView.currIndex].getLocation());
		Orders.deleteConflicts(order);
		Orders.add(order);
		$("status_" + timeShiftListView.currIndex % 5).innerText = $L.PLAYED;
	} else {
		$G.debug("=============解决冲突进入此函数================", "按取消键取消预定节目");
		conflictButton();
	}
	hideConflictDiv();
}
function showOrderInfo(_tip) {
	orderInfoFlag = true;
	$("infoDiv").style.visibility = "visible";
	$("infoTitle").innerText = $L.TIP_TITLE;
	$("infoText").innerText = _tip;
}
function hideOrderInfo() {
	orderInfoFlag = false;
	$("infoDiv").style.visibility = "hidden";
	$("infoTitle").innerText = "";
	$("infoText").innerText = "";
}
function backToPlay() {
	clearEnv();
	isSearchEnd = false;
	mp.setStopMode(0);
	mp.stop();
	clearEnv();
	NVOD.exit();	
	$G.exitToPlay();
}
function backToMenu() {
	clearEnv();
	isSearchEnd = false;
	mp.setStopMode(0);
	mp.stop();
	clearEnv();
	NVOD.exit();	
	window.location.href = "../index.htm";
}
function playVideo() {
	var currLocation = tsEvents[timeShiftListView.currIndex].getLocation();
	initSound();
	mp.setSingleMedia(currLocation);
	mp.playFromStart();
}
function onDisplayMessageEvent(events) {
	var info = "";
	Utility.println("onDisplayMessageEvent evt length = "+events.length);
	if (events.length > 0) {
		var maxId = 0;//events.length-1;
		Utility.println("evt type = "+events[maxId].type+" sub type = "+events[maxId].msgSubType);
		switch (events[maxId].type) {
			case 40021:
//				passwordBox.show();
				showTips("加密节目");
				break;
			case 40023:
				if (serviceList.length == 0) {
					info = $GL.NO_SERVICE;
				} else {
					info = $GL.NO_SIGNAL;
				}
				showTips(info);
				break;
			case 40081:
				var tipsArr = ['',$GL.CA_1, $GL.CA_2, $GL.CA_3, $GL.CA_4, $GL.CA_5, $GL.CA_6, $GL.CA_7, $GL.CA_8, $GL.CA_9, $GL.CA_10, $GL.CA_11, $GL.CA_12, $GL.CA_13, $GL.CA_14, $GL.CA_15, $GL.CA_16, $GL.CA_17, $GL.CA_18, $GL.CA_19, $GL.CA_20, $GL.CA_21,$GL.CA_22];
				var type = Number(events[maxId].msgSubType);			
				showTipsType = 0;
				if (type < 23) {
					info = tipsArr[type];
					if(type == 9) {	
						showTips("未授权节目");
						Utility.setEnv("NM_CaStatus", "failed");
						var displayStr = Utility.ioctlRead("channelDescription");
					} else {
						showTips(info);
					}
				} else if (type == 23) {//在屏幕上消除alarm消息-23
					hiddenTips();
				}
				break;
			case 40083:
				var tipsArr = ['',$GL.CA_MSG_0,'','',$GL.CA_MSG_1];
				var type = Number(events[maxId].msgSubType);
				if(type == 1){
					var info = $GL.NO_CARD;
					showTips(info);
				}else{
					info = tipsArr[type];
					showTips(info);
				}
				break;
		}
	}
}

function showTips(_tips){
	if($("alert").style.visibility == "visible"){
		$("alert").style.visibility = "hidden";
	} else {
		$("alert").style.visibility = "visible"
		$("alert").innerText = _tips;
	}
	if(!showTipsFlag){
		showTipsFlag=true;
	}
}
function hiddenTips(){
	Utility.setEnv("NM_CaStatus", "success");
	var events = DVB.getShowEvents();
	if (events.length > 0) {
		onDisplayMessageEvent(events);
	}else{
		$('alert').style.visibility = "hidden";
		showTipsFlag = false;
	}
}
//声音的设置
var defaultVolume = Utility.getEnv("NVOD_volume") != "" ? Number(Utility.getEnv("NVOD_volume")) : 16;
$G.debug("=================刚进入页面的时候的音量值为==============", defaultVolume);

function initSound(){
	var volume = defaultVolume;
	$("volume_value").innerText = volume;
	$("volume_progress").style.width = 375 / 31 * volume + "px";
	if (mp.getMuteFlag() == 1) {
		$('mutePic').style.visibility = "visible";
		$("muteTxt").innerText = $GL.MUTE_TXT;
	}
}
function changeVolume(offset) {
	volumeBar.show();
	$("volume_value").innerText = defaultVolume;
	var volume = mp.getVolume();
	volume += offset;
	if (offset < 0) {
		if (volume < 0) {
			volume = 0;	
		}
	} else if (offset > 0) {
		if (volume > 31) {
			volume = 31;
		}
	}
	$("volume_value").innerText = volume;
	$("volume_progress").style.width = 375 / 31 * volume + "px";
	Utility.setEnv("NVOD_volume", volume);
	mp.setVolume(volume);
	if (mp.getMuteFlag() == 1) {
		setMuteFlag(0);
	}
}


function setMute() {
	var muteFlag = mp.getMuteFlag();
	muteFlag = muteFlag == 0 ? 1 : 0;
	setMuteFlag(muteFlag);
}

function setMuteFlag(flag) {
	mp.setMuteFlag(flag);
	volumeBar.hide();
	if (flag == 0) {//有声
		$('mutePic').style.visibility = "hidden";
	} else {
		$('mutePic').style.visibility = "visible";
		$("muteTxt").innerText = $GL.MUTE_TXT;
	}
}

function Con(obj, isVisible, delayTime, name){
	var self = this;
	self.isVisible = isVisible;
	self.obj = obj;
	self.name = name;
	self.delayTime = delayTime;
	var timer = new Timer(name);
	timerManager.add(timer);
	
	self.show = function(){
		self.obj.style.visibility = "visible";
		self.isVisible = true;
		if (self.delayTime != -1) {
			var timer = timerManager.get(self.name);
			timer.exec(self.hide, self.delayTime);
		}
	};
	
	self.hide = function(){
		self.obj.style.visibility = "hidden";
		self.isVisible = false;
		self.clearTimer();
		if (self.name == "volumeBar") {
			ServiceDB.save();
		}
	};
	/**
	 * 重设Timer
	 * @param {Number} _delayTime 不传时，则按默认。否则按此新值执行隐藏
	 */
	self.resetTimer = function(_delayTime){
		if (self.delayTime != -1) {
			var timer = timerManager.get(self.name);
			var delay = self.delayTime;
			if(typeof(_delayTime)!="undefined"){
				delay = _delayTime;
			}
			timer.exec(self.hide, delay);
		}
	};
	
	self.clearTimer = function(){
		var timer = timerManager.get(self.name);
		timer.clear();
	}
}

function exitPage() {
	DVB.clearShowEvent();
	Utility.ioctlWrite("NM_Menu", "nAction:" + 0 + ",code:" + 30);
	Orders.save();
}

