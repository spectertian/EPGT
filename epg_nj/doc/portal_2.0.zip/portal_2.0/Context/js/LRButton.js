/**
 *  LRButton(左右选择框) 功能:设置系统参数
 * 属性
 * 1.可设定正文内容变化范围(如：English、简体中文);
 * 2.可设定当前选择的内容（如上图中的简体中文;
 * 3.可接受左右按键消息;
 * @param {function} focus 获得焦点
 * @param {function} blur 失去焦点
 * @param {function} initContents 填充内容
 * 注意:这里所传参数全是外部定义的全局函数
 */
function LRButton(pageId, focus, blur, initContent, onChange){
	this.pageId = pageId;
    this.index = 0;//初始的索引
    this.focus = focus;//把外部函数当做属性即回调函数
    this.blur = blur;
    this.initContent = initContent;
	this.onChange = onChange;
}

/**
 * bindData 绑定数据,把外部定义的函数当参数传进去
 * @param {Object} data 需要设置的值，格式：[{displayValue:"", sysValue: ""}, {displayValue:"", sysValue: ""}]
 * @param {Object} initialValue 需要设置的系统参数
 */
LRButton.prototype.bindData = function(data){
    this.data = data;
    this.length = this.data.length;
}

/**
 * left 向左选择值
 */
LRButton.prototype.left = function(){
    this.index -= 1;
    if (this.index < 0) 
        this.index = this.length - 1;
    this.initContent(this.pageId, this.data[this.index].displayValue);
	if (this.onChange) this.onChange();
}
/**
 * right 向右选择值
 */
LRButton.prototype.right = function(){
    this.index += 1;
    if (this.index > this.length - 1) 
        this.index = 0;
    this.initContent(this.pageId, this.data[this.index].displayValue);
	if (this.onChange) this.onChange();
}

LRButton.prototype.setValue = function(initialValue){
    for (var i = 0, len = this.data.length; i < len; i++) {//根据设置的初值找到初始的索引
        if (initialValue == this.data[i].sysValue) {
            this.index = i;
			break;
        }
    }
	this.initContent(this.pageId, this.data[this.index].displayValue);
}

/**
 * getValueIndex 获取选择的值
 */
LRButton.prototype.getValue = function(){
    return this.data[this.index].sysValue;
}