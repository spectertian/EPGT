/**
 * IP控件
 * @param {Function} lineFocus IP框聚焦函数-->【必须】
 * @param {Function} lineBlur IP框失焦函数-->【必须】
 * @param {Function} keyFocus IP单一数字格聚焦函数-->【必须】
 * @param {Function} keyBlur IP单一数字格失焦函数-->【必须】
 * @param {Function} lineEnable IP行允许编辑时函数-->【非必须】
 * @param {Function} lineDisable IP行不允许编辑时函数-->【非必须】
 */
function InputIP(lineFocus, lineBlur, keyFocus, keyBlur, lineEnable, lineDisable){
	this.lineFocus = lineFocus;
	this.lineBlur = lineBlur;
	this.keyFocus = keyFocus;
	this.keyBlur = keyBlur;
	this.lineEnable = lineEnable;
	this.lineDisable = lineDisable;
	
	this.isActive = true; //默认可编辑
	this.defaultIp = "0.0.0.0";
	this.xPos = 0; //第几个网段,行
	this.yPos = 0; //网段三位数第几个,列
	this.strArr = [0, 0, 0, 0]; //4个网段
	this.tdNums = [[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]];
	this.preId = [new Array(), new Array(), new Array(), new Array()];
}

/**
 * IP数据绑定
 * @param {String} bgId IP行ID-->【必须】
 * @param {String} ipValue IP值-->【必须】
 * @param {String} tdId ID数字ID-->【必须】
 */
InputIP.prototype.bindData = function(bgId, ipValue, tdId){
	this.bgId = bgId;
	this.tdId = tdId;
	for (var j = 0; j < 12; j++) {
		var xPos = Math.floor(j / 3);
		var yPos = j % 3;
		this.preId[xPos][yPos] = document.getElementById(tdId + j);
	}
	this.initIp(ipValue);
	this.showContent();
}
/**
 * 用字符串设置ip
 * @param {String} str
 */
InputIP.prototype.initIp = function(str){
	if (typeof(str) == 'undefined' || str == '' || str.split(".").length != 4) {//过滤错误
		str = this.defaultIp;
	}
	this.strArr = str.split(".");
	for (var i = 0; i < 4; i++) {
		var paddedStr = this.padString(this.strArr[i], 3, '0');
		this.tdNums[i][0] = paddedStr.charAt(0);
		this.tdNums[i][1] = paddedStr.charAt(1);
		this.tdNums[i][2] = paddedStr.charAt(2);
	}
}
/**
 * IP行聚焦
 */
InputIP.prototype.focus = function(){
	this.lineFocus();
	this.keyFocus(this.tdId + this.yPos);
}
/**
 * IP行失焦
 */
InputIP.prototype.blur = function(){
	this.lineBlur();
	this.keyBlur(this.tdId + this.yPos);
	this.yPos = 0;
}
/**
 * 单一格向左移动
 */
InputIP.prototype.left = function(){
	this.keyBlur(this.tdId + this.yPos);
	this.yPos = (this.yPos + 11) % 12;
	this.keyFocus(this.tdId + this.yPos);
}
/**
 * 单一格向右移动
 */
InputIP.prototype.right = function(){
	this.keyBlur(this.tdId + this.yPos);
	this.yPos = (this.yPos + 1) % 12;
	this.keyFocus(this.tdId + this.yPos);
}
/**
 * 显示IP值
 */
InputIP.prototype.showContent = function(){
	for (var i = 0; i < 4; i++) {
		this.preId[i][0].innerText = this.tdNums[i][0];
		this.preId[i][1].innerText = this.tdNums[i][1];
		this.preId[i][2].innerText = this.tdNums[i][2];
	}
}
/**
 * 重新显示
 * @param {String} _ip 需要显示的IP值
 */
InputIP.prototype.reShow = function(_ip){
	this.initIp(_ip);
	this.showContent();
}
/**
 *  输入IP
 * @param {Number} num 单一数字IP值
 * @param {Boolean} isMoveFocus 是否输入数字后焦点向下移动一位（true或不传：向下移动；false:不向下移动）
 */
InputIP.prototype.inputNum = function(num, isMoveFocus){
	var x = parseInt(this.yPos / 3, 10);
	var y = this.yPos % 3;
	var temp = "";
	for (var ii = 0; ii < 3; ii++) {
		if (ii != y) {
			temp += this.tdNums[x][ii];
		} else {
			temp += num;
		}
	}
	if (parseInt(temp, 10) <= 255) {
		document.getElementById(this.tdId + this.yPos).innerText = num;
		this.tdNums[x][y] = num;
	} else {//大于255时,重置为255
		document.getElementById(this.tdId + (this.yPos - y)).innerText = 2;
		document.getElementById(this.tdId + (this.yPos - y + 1)).innerText = 5;
		document.getElementById(this.tdId + (this.yPos - y + 2)).innerText = 5;
		this.tdNums[x][0] = 2;
		this.tdNums[x][1] = 5;
		this.tdNums[x][2] = 5;
	}
	if(typeof(isMoveFocus)=='undefined' || isMoveFocus) this.right();
}
/**
 * 获取到IP值
 * @return {String} IP值
 */
InputIP.prototype.getIp = function(){
	var ip = "";
	for (var i = 0; i < 4; i++) {
		for (var j = 0; j < 3; j++) {
			ip += this.tdNums[i][j];
		}
		if (i < 3) ip += '.';
	}
	return ip;
}
/**
 * IP行不允许编辑时
 */
InputIP.prototype.disable = function(){//逻辑不能放在外面
	this.lineDisable(this.bgId);
	this.isActive = false;
}
/**
 * IP行允许编辑时
 */
InputIP.prototype.enable = function(){
	this.lineEnable(this.bgId);
	this.isActive = true;
}
InputIP.prototype.padString = function(input, width, addStr){
	var str = input.toString();
	while (str.length < width) {
		str = addStr + str;
	}
	return str;
}
