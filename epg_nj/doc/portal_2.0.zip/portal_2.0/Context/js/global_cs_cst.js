﻿Utility.setBrwMuteLogo(false);
Utility.setEnv("isInHDPage", "y");
Utility.ioctlWrite("motoKey2Dvb", "");
Utility.setEnv("TVRadio", "TVRadio_global");
//Utility.setEnv("reloadFlag", "true");
var TVRadioLink = Utility.getEnv("TVRadio");
var voipCfg = new DataAccess("voipconfig.properties");
var DevType = voipCfg.get("AudioDev_Type");
var OTANum = 0;
var voipNum = [];
var viopPhone,vedioType;
var viopFlag = false;
var callerTelNum, callSessionID = -1, callType = 1;
var voip_num_timer = -1;
var isVoipConnect = false;

/**
 * @fileOverview 全局函数
 */
var $ = function(id){
	var o = document.getElementById(id);
	return o;
};

var $G = {};

(function(){
	/**
	 * DataAccess对象
	 * @type Object
	 */
	var sysDa = new DataAccess("Systemsetting.properties");
	var netDa = new DataAccess("NetworkConfig.properties");
	var envDa = new DataAccess("env.properties");
	var voipDa = new DataAccess("voipconfig.properties");
	var adsDa = null;
	
	/**
	 * 当前系统语言
	 * @type String
	 */
	var lang = sysDa.get("languangeString"); //language_chi:简体中文、language_eng:英文
	/**
	 * 是否开启打印
	 * @type Boolean
	 */
	var DEBUG_MODE = true;
	
	/**
	 * 是否阻止当前按键的默认处理
	 * @type Boolean
	 */
	var isKeyPrevent = true;
	
	/**
	 * 根目录路径
	 * @type String
	 */
	var root = Utility.getEnv("ROOT_PATH");
	
	/**
	 * 调试函数，受DEBUG_MODE调试开关控制，以便全局关闭js页面打印，提升运行速度，建议使用，代替Utility.println
	 * 可传一个参数或两个参数，当传一个参数时，直接打印该对象的值，打印格式为：[JS_DEBUG]value
	 * 当传两个参数时，每一个参数为在打印中需要显示的名称标识，第二个参数为要打印的对象的值，打印的格式为：
	 * [JS_DEBUG]name:value
	 */
	function debug(){
		if (!DEBUG_MODE) { return; }
		
		if (arguments.length == 1) {
			var value = arguments[0];
			Utility.println("[JS_DEBUG]" + value);
		} else {
			var name = arguments[0];
			var value = arguments[1];
			Utility.println("[JS_DEBUG]" + name + " : " + value);
		}
	}
	
	/**
	 * 对象扩展，在目标对象上添加源对象的方法及属性
	 * @param {Object} destination 目标对象
	 * @param {Object} source 源对象
	 */
	function extend(destination, source){
		for (var property in source) {
			destination[property] = source[property];
		}
		return destination;
	}
	
	/**
	 * 对象复制，返回一个新对象，包含被复制对象的所有属性和方法
	 * @param {Object} object 被复制的对象
	 */
	function clone(object){
		return extend({}, object);
	}
	
	/**
	 * 按键、系统事件转换及处理
	 */
	function eventListener(){
		var keyCode = event.which || event.keyCode;
		
		var powsered = Utility.getEnv("STB.powered");
		if (powsered == "true") {
			return;
		}
		
		// 在如加的广告的mis应用中时，除了mis事件和待机事件之外，不应响应其它任何事件
		if (
			Utility.getEnv("MIS_APP_STATUS") == "TRUE"
			&& (keyCode < 45778 || keyCode > 45783)	// 不是mis事件
			) {
			return;
		}
		
		isKeyPrevent = true;
		var messageId = event.userInt;
		debug("keyCode", keyCode);
		debug("messageId", messageId);
		if (isShowCAGlobalTips && keyCode < 40000) { //弹出全局提示信息时，不处理非系统消息
			event.preventDefault();
			if (isShowGlobalConfirm) {//isShowCAGlobalConfirm || isShowOTAGlobalConfirm
				switch (keyCode) {
					case 38: //上键
					case 40: //下键
					case 37: //左键
					case 39: //右键
						$('globalCAConfirmBtn_' + globalCAConfirmBtn).style.background = 'url(../images/bt_02.png) no-repeat';
						globalCAConfirmBtn = (globalCAConfirmBtn + 1) % 2;
						$('globalCAConfirmBtn_' + globalCAConfirmBtn).style.background = 'url(../images/bt_01.png) no-repeat';
						break;
					case 640://返回键
					case 27:
					case 13: //确定键
						if (keyCode == 13) {//key enter
							if (globalCAConfirmBtn == 1) { //select cancel
								if (isShowCAGlobalConfirm) {
									//DVNCA.tokenConfirmChange(true, globalCAOperationID);
								} else if (isShowOTAGlobalConfirm) {
									OTANum++;
									if(OTANum > 2) {
										OTANum = 0;
										Upgrade.startOTA();
									} else {
										Upgrade.wait();
									}
								}
								Utility.setEnv("recoverUpdate", "stopUpdate");
							} else if (globalCAConfirmBtn == 0) { //select ok
								if (isShowCAGlobalConfirm) {
									//DVNCA.tokenConfirmChange(false, globalCAOperationID);
								} else if (isShowOTAGlobalConfirm) {
									Upgrade.startOTA();
								} else if (isShowNITGlobalConfirm) {
									$G.sysDa.set("NIT_update", 0);
									$G.sysDa.submit();
									stopAitManager();
									Utility.setEnv("isNeedUpdate", "0");
									window.location.href = $G.root + "setting/auto_search.htm?searchType=2";
								}
							}
						} else {//exit || back
							if (isShowOTAGlobalConfirm) {
								OTANum++;
								if(OTANum > 2) {
									OTANum = 0;
									Upgrade.startOTA();
								} else {
									Upgrade.wait();
								}
							}
						}
						hiddenGlobalCAConfirm();
						break;
				}
			} else {
				switch (keyCode) {
					case 640://返回键
					case 27:
					case 13: //确定键
						if (globalCATipsTimeout != -1) {
							clearTimeout(globalCATipsTimeout);
							globalCATipsTimeout = -1;
						}
						document.getElementById('globalCATipsDiv').style.visibility = 'hidden';
						isShowCAGlobalTips = false;
						break;
				}
			}
			return;
		}
		var code = ""; //转换后的按键字符串
		var param = 0; //按键事件所带参数
		if (keyCode >= 48 && keyCode <= 57) {
			code = "KEY_NUMERIC";
			param = keyCode - 48;
		} else {
			Utility.println("=======keyCode=" + keyCode);
			switch (keyCode) {
				case 38: //上键
					code = "KEY_UP";
					break;
				case 40: //下键
					code = "KEY_DOWN";
					break;
				case 37: //左键
					code = "KEY_LEFT";
					break;
				case 39: //右键
					code = "KEY_RIGHT";
					break;
				case 33: //上翻页
				case 120:
					code = "KEY_PAGE_UP";
					break;
				case 34: //下翻页
				case 121:
					code = "KEY_PAGE_DOWN";
					break;
				case 447: //音量加
					code = "KEY_VOLUME_UP";
					isKeyPrevent = false;
					break;
				case 448: //音量减
					code = "KEY_VOLUME_DOWN";
					isKeyPrevent = false;
					break;
				case 85://key U
				case 449: //静音
					code = "KEY_MUTE";
					isKeyPrevent = false;
					break;
				case 65://key A
					break;
				case 407: //声道键
					code = "KEY_AUDIO";
					break;
				case 0x0282: //电视/音频广播键
					code = "KEY_TV_RADIO";
					//Utility.setEnv("reloadFlag", "true");
					if(TVRadioLink == "TVRadio_global") {
						window.location.href = "../play/play.htm";
					} 
					break;
				case 640://返回键
					code = "KEY_BACK";
					break;
				case 27: //退出键
				case 114:
					code = "KEY_EXIT";
					break;
				case 13: //确定键
					code = "KEY_ENTER";
					break;
				case 403: //红键
				case 96:
					code = "KEY_RED";
					break;
				case 405: //黄键
				case 97:
					code = "KEY_YELLOW";
					break;
				case 406: //蓝键
				case 98:
					code = "KEY_BLUE";
					break;
				case 404: //绿键
				case 99:
					code = "KEY_GREEN";
					break;
				case 480:
					code = "KEY_LOVE";
					Utility.ioctlWrite("NM_Love","nAction:"+1); 
					break;
				case 468://菜单键
				case 113:
					code = "KEY_MENU";
					if(location.href.indexOf("NVOD_play.htm") == -1) { // 不是NVOD页面到portal事件					
						doMenu();									
					}
					break;
				case 464:
					code = "KEY_OC";
					break;
				case 0x84: //132, CSUDI_VK_INPUT
					code = "KEY_VOD";
					break;
				case 2731:
					code = "KEY_TIMESHIFT";
					break;
				case 112:
					code = "KEY_INFO";
					break;
				case 122:
					code = "KEY_CHANNEL_UP";
					break;
				case 123:
					code = "KEY_CHANNEL_DOWN";
					break;
				case 116: //键盘上F5键，作用是页面刷新，用于开发
					window.location.reload();
					break;
				case 427: //频道加
					code = "KEY_CHANNEL_UP";
					break;
				case 428: //频道减
					code = "KEY_CHANNEL_DOWN";
					break;
				case 457: //信息键
					code = "KEY_INFO";
					break;
				case 69://key E
				case 458: //节目指南键
					code = "KEY_EPG";
					break;
				case 3883:
					code = "KEY_DIANBO"
					break;
				case 3864: //暂停/播放
					code = "KEY_PAUSE";
					break;
				case 2732:
					code = "KEY_AUTO_SEARCH";
					break;
				case 83: //Key S
				case 644: //暂定为‘搜索键’
					code = "KEY_SEARCH";
					break;
				/*********搜索部分*************/
				case 40001: //开始搜索
					code = "DVB_SEARCH_START";
					break;
				case 40002: //开始搜索某个频点
					code = "DVB_DELIVERY_SEARCH_START";
					break;
				case 40003: //某个频点搜索结束
					code = "DVB_DELIVERY_SEARCH_FINISHED";
					break;
				case 40004: //开始搜索nit表
					code = "DVB_NIT_SEARCH_START";
					break;
				case 40005: //nit表搜索成功
					code = "DVB_NIT_SEARCH_SUCCESS";
					break;
				case 40006: //nit表搜索失败
					code = "DVB_NIT_SEARCH_FAILED";
					Utility.ioctlWrite("NM_Error","nAction:"+1+",code:"+40006+",subcode:"+0); 					
					break;
				case 40007: //搜索到service
					code = "DVB_SERVICE_READY";
					break;
				case 40008: //搜索全部结束
					code = "DVB_SEARCH_FINISHED";
					break;
				case 40009: //搜索任务退出
					code = "DVB_SEARCH_EXIT";
					break;
				/******************/
				case 45900:
					code = "CLOUD_GAME_HIDDEN";
					break;
				case 45901:
				code = "CLOUD_GAME_START";
					break;
				case 45902:
					code = "CLOUD_GAME_ECEIVE";
					break;
				case 45903:
					code = "CLOUD_GAME_START_APPLICATION";
					break;
				case 45904:
					code = "CLOUD_GAME_ConnectionTimeout";
					break;
				case 45905:
					code = "CLOUD_GAME_StartCloudServiceFailed";
					break;
				case 45906:
					code = "CLOUD_GAME_InvalidUserID";
					break;
				case 45907:
					code = "CLOUD_GAME_InvalidPassword";
					break;
				case 45908:
					code = "CLOUD_GAME_UserHasLogined";
					break;
				case 45909:
					code = "CLOUD_GAME_BadNetworkConnection";
					break;
				case 45910:
					code = "CLOUD_GAME_ApplicationNotOrdered";
					break;
				case 45911:
					code = "CLOUD_GAME_ApplicationCannotMatchTerminal";
					break;
				case 45912:
					code = "CLOUD_GAME_SeverIsBusy";
					break;
				case 45913:
					code = "CLOUD_GAME_ServiceInterrupt";
					break;
				case 45914:
					code = "CLOUD_GAME_UserLoginInOtherPlace";
					break;
				case 45915:
					code = "CLOUD_GAME_UnknownErrort";
					break;
				case 45918:
					code = "CLOUD_GAME_HIDDENINFO";
					break;
				case 45919:
					code = "CLOUD_EXIT_CALLBACK";
					Utility.ioctlRead("ExitCloud");
					break;
				/*********EPG部分*************/
				case 40011: //当前event需要刷新
					code = "DVB_PRESENT_EVENT_REFRESH";
					break;
				case 40012: //下一个event需要刷新
					code = "DVB_FOLLOWING_EVENT_REFRESH";
					break;
				case 40013: //详细epg可能需要刷新
					code = "DVB_EIT_REFRESH";
					break;
				case 40014: //所有的详细epg搜索成功
					code = "DVB_EIT_SEARCH_FINISHED";
					break;
					
				/*********播放部分*************/
				case 40021: //频道加锁/解锁
					code = "DVB_CHANNEL_LOCK";
					break;
				case 40022: //频道父母锁/解锁
					code = "DVB_CHANNEL_PARENT_LOCK";
					break;
				case 40023: //播放信号丢失
					code = "DVB_TUNE_FAILED";
					SysSetting.panelClear("signal");
					break;
				case 40024: //播放信号锁定
					code = "DVB_TUNE_SUCCESS";
					SysSetting.panelDisplayCtrlLight("signal");
					break;
				case 40025: //播放成功
					code = "DVB_PLAY_SUCCESS";
					break;
				case 40026: //SI更新
					code = "DVB_SI_UPDATED";
					break;
				
				case 40044: //媒体格式不支持
					code = "MEDIA_NOT_SUPPORT";
					break;
				case 40204: //前端码流停播。
					code = "DVB_STREAM_STOP";
					if (typeof onDisplayMessageEvent != "undefined") {
						showTipsType = 0;
						showTips("前端码流停播");
						Utility.ioctlWrite("NM_Error","nAction:"+1+",code:"+40204+",subcode:"+0); 
					}			
					break;
				case 40205: //前端码流恢复播放。
					code = "DVB_STREAM_RESUME";
					if (typeof hiddenTips != "undefined") {
						hiddenTips();
						Utility.ioctlWrite("NM_Error","nAction:"+0+",code:"+40205+",subcode:"+0); 
					}
					break;
				case 45889: // 处理网管恢复出厂设置消息
					code = "NM_RESET";
					break;
				/*********NVOD部分*************/
				case 40033: //nvod时移事件播放结束
					code = "DVB_NVOD_PLAY_FINISHED";
					break;
				case 40034: //nvod搜索进度
					code = "DVB_NVOD_EIT_REFRESH";
					break;
				case 40035: //nvod分组列表个数改变
					code = "DVB_NVOD_SORT_UPDATED";
					break;
				case 40036: //nvod参考事件列表个数改变
					code = "DVB_NVOD_REF_EVENT_UPDATED";
					break;
				case 40037: //nvod时移事件列表个数改变
					code = "DVB_NVOD_TS_EVENT_UPDATED";
					break;
				case 40038: //nvod时称事件倒计时时间改变
					code = "DVB_NVOD_TS_EVENT_COUNTER_UPDATED";
					break;
				case 40039: //nvod搜索完成
					code = "DVB_NVOD_EIT_READY";
					break;
					
				/*********节目预定部分*************/
				case 40051: //预定提前提醒
					code = "DVB_ORDER_PRE_REMIND";
					/**
					 * 是否弹出节目预定信息
					 * @trye Boolean ：默认为true
					 */
					var isEnterCloud = Utility.getEnv("enter_cloud");
					if(isEnterCloud == null || isEnterCloud == "" || isEnterCloud == undefined) {
						isEnterCloud = false;
					}
					if (!isEnterCloud) {
						showOrderReminder();
					}else {
						var order = Orders.getAt(0);
						isEnterCloud = false;
						Orders.deleteOrder(order);
						Orders.save();
					}
					break;
				case 40052: //预定节目到期
					code = "DVB_ORDER_REMIND";
					openOrderedProgram();
					break;
				case 40053: //预定节目播放完毕
					code = "DVB_ORDER_PLAY_END";
					break;
				case 40054: //预定节目已经过期
					code = "DVB_ORDER_EXPIRE";
					break;
				case 40055: //预定节目数据改变
					code = "DVB_ORDER_UPDATED";
					break;
					
				/*********开关机部分*************/
				case 40061: //定时开机
					code = "DVB_POWER_ON_NOTIFY";
					break;
				case 40062: //定时待机
					code = "DVB_POWER_OFF_NOTIFY";
					break;
				case 40063: //定时开关机数据改变
					code = "DVB_POWER_EVENT_UPDATED";
					break;
					
				/*********PMT部分*************/
				case 40064: //PMT搜索完成
					code = "DVB_PMT_SEARCH_FINISHED";
					break;
					
				/*********智能卡部分*************/
				case 40070: //智能卡已插入
					code = "DVB_SMARTCARD_INSERTED";
					Utility.ioctlRead("CACardInsert");
					Utility.ioctlWrite("NM_Error","nAction:"+0+",code:"+40070+",subcode:"+0);
					
					//tvcode发生变化过，则用新的，否则重置为"00000000"
					var caSerialNumNew = CA.serialNumber;
					var sysData = new DataAccess("Systemsetting.properties");
					var caSerialNumOld = sysData.get("System.CardIDOld");
					if (caSerialNumNew != caSerialNumOld ) {
						Utility.setEnv("MIS_TVCode", "00000000");
						Utility.setEnv("TVCodeChange", "false");	
					} else {
						Utility.setEnv("MIS_TVCode", Utility.getEnv("TVCode"));	
					}		
					break;
				case 40071: //智能卡已拔出
					code = "DVB_SMARTCARD_EVULSION";					
					Utility.ioctlWrite("NM_Error","nAction:"+1+",code:"+40071+",subcode:"+0);	
					
					Utility.setEnv("MIS_TVCode", "00000000");
					//Utility.setEnv("CACardInsert", "false");
					break;
					
				/*********CA部分*************/
				case 40080: //CA提示信息
					code = "CA_INFO";
					break;
				case 40081: //CA警告信息
					code = "CA_ALARM";
					break;
				case 40082: //CA命令信息
					code = "CA_COMMAND";
					var evtstr = DVB.getEvent(40082, messageId);
					var jsonObj = eval('(' + evtstr + ')');
					handleCaCommand(jsonObj);
					break;
				case 40083: //CA状态信息
					code = "CA_STATUS";
					break;
					
				/*********网络部分*************/
				case 40090: //IP地址更新
					code = "DVB_IP_UPDATED";
					break;
				case 40091: //网络链接成功
					code = "DVB_IP_CONNECT_SUCCESS";
					break;
				case 40092: //网络断开
					code = "DVB_IP_CONNECT_FAILED";
					Utility.ioctlWrite("NM_Error","nAction:"+1+",code:"+40092+",subcode:"+0); 					
					break;
				case 40093: //cm在线
					code = "DVB_CM_ON_LINE";
					break;
				case 40094: //cm离线
					code = "DVB_CM_OFF_LINE";
					Utility.ioctlWrite("NM_Error","nAction:"+1+",code:"+40094+",subcode:"+0); 					
					break;
					
				/*********提示信息部分*************/
				case 41000: //提示信息显示
					code = "DVB_SHOW_INFO";
					break;
				case 41001: //提示信息隐藏
					code = "DVB_HIDE_INFO";
					break;
					
				/*********自定义部分**********/
				case 40123: //未检测到OTA升级信息
					code = "OTA_NO_UPGRADE_INFO";
					Utility.ioctlWrite("NM_Error","nAction:"+1+",code:"+40123+",subcode:"+0);
					if (window.location.href.indexOf("softUpgrade") == -1) {
						showCAGlobalTips($GL.OTA_NO_UPGRADE_INFO, 0);
					}
					break;
				case 40110: //OTA强制升级信息
					code = "OTA_FORCE_UPGRADE";
					showCAGlobalTips($GL.OTA_FORCE_UPGRADE, 0);
					setTimeout('Upgrade.startOTA()', 3000);
					break;
				case 40111: //OTA手动升级提示
					code = "OTA_MANUAL_UPGRADE";
					if (window.location.href.indexOf("softUpgrade") == -1) {
						showCAGlobalTips($GL.OTA_MANUAL_UPGRADE, 1, 'ota');
					}
					break;
				case 40150: //NIT表自动更新
					code = "DVB_NIT_AUTO_UPDATE";
					var hasProcessed = Utility.getEnv("hasProcessed");
					if (hasProcessed && hasProcessed == 1) {
					break;
					}
					$G.sysDa.set("NIT_update", 1);
					$G.sysDa.submit();
					showCAGlobalTips($GL.DVB_NIT_AUTO_UPDATE, 1, 'nit');
					Utility.setEnv("hasProcessed", "1");
					break;
				case 40160:
					code = "EVT_AD_UPDATE";
					break;
				case 40220:
					code = "USB_DEVICE_INSERTED";
					showCAGlobalTips($GL.USB_DEVICE_INSERTED, 0);
					break;
				case 40221:
					code = "USB_DEVICE_EVULSION";
					showCAGlobalTips($GL.USB_DEVICE_EVULSION, 0);
					break;
				case 768:
					code = "MEDIA_EVENT";
					break;
				/****************** VoIP *****************/
				case 40500: //登录成功
					code = "VOIP_LOGIN_SUCCESS";
					voipDa.set("ISVOIPLOGIN", "loged");
					break;
				case 40501: //登录失败
					code = "VOIP_LOGIN_FAILED";
					voipDa.set("ISVOIPLOGIN", "failed");
					break;
				case 40502: //本地注销成功
					code = "VOIP_LOCAL_LOGOUT_SUCCESS";
					break;
				case 40503: //服务器注销成功
					code = "VOIP_SERVER_LOGOUT_SUCCESS";
					break;
				case 40504: //收到远端的一个呼叫请求
					code = "VOIP_RECEIVE_CALL";	
					var evtstr = DVB.getEvent(40504, messageId);
					$G.debug('--------------evtstr=',evtstr);
					var phoneRecordObj = eval('(' + evtstr + ')');
					callSessionID = Number(phoneRecordObj.sessionId);
					Utility.println("-----40504-----callSessionID = "+callSessionID);
					callType = Number(phoneRecordObj.type);
					var str = phoneRecordObj.phoneNumber;
					var reg = /[\+][\d]{4}([\d]+)/gi;
					callerTelNum = reg.exec(str)[1];
					if ('0' == callType) {
						vedioType = "vdCall";
					}else {
						vedioType = "vcCall";
					}
					viopPhone = callerTelNum;
					isVoipConnect = true;
					break;
				case 40505: //会话正在呼出中
					code = "VOIP_CALLING";
					break;
				case 40506: //对方已经收到呼叫，处于振铃中
					code = "VOIP_CALL_SUCCESS";
					var evtstr = DVB.getEvent(40506, messageId);
					$G.debug('--------------evtstr=',evtstr);
					var phoneRecordObj = eval('(' + evtstr + ')');
					callSessionID = Number(phoneRecordObj.sessionId);
					Utility.println("-----40506-----callSessionID = "+callSessionID);
					break;
				case 40507: //对方已经接受了呼叫请求，进入通话状态
					code = "VOIP_CONNECT";
					var evtstr = DVB.getEvent(40507, messageId);
					$G.debug('--------------evtstr=',evtstr);
					var phoneRecordObj = eval('(' + evtstr + ')');
					callSessionID = Number(phoneRecordObj.sessionId);
					Utility.println("-----40507-----callSessionID = "+callSessionID);
					if(DevType == 3)
					{
						Utility.ioctlWrite("NM_MulMedia","nAction:" + 1);
					} else {
						Utility.ioctlWrite("NM_UsbPhone","nAction:" + 1);
					}
					break;
				case 40508: //对方拒绝或者终止了呼叫请求
					code = "VOIP_CALL_REFUSE";
					if(DevType == 3)
					{
						Utility.ioctlWrite("NM_MulMedia","nAction:" + 0);
					} else {
						Utility.ioctlWrite("NM_UsbPhone","nAction:" + 0);
					}
					break;
				case 40509: //保持呼叫成功
					code = "VOIP_KEEP_SUCCESS";
					break;
				case 40510: //解除呼叫保持操作成功
					code = "VOIP_KEEP_CANCEL";
					break;
				case 40511:	     //对方正在通话中
					code = "VOIP_CALLCONFLICT";
					break;
				case 40512:     //对方无人接听超时关闭
					code = "VOIP_CALLTIMEOUT";
					break;
				case 40513:
					code = "VOIP_ANSWER";
					if (isVoipConnect) {
						stopMediaPlayer();
						if (callSessionID != -1) {//接电话
							window.location.href = Utility.getEnv("ROOT_PATH") + "voip/connect.htm?type=answer&vedioType=" + vedioType + "&phnNum=" + callerTelNum + '&callSessionID=' + callSessionID;
						//window.location.href = Utility.getEnv("ROOT_PATH") + "voip/connect.htm?id=5&vedioType=" + vedioType +"&phnNum=" + viopPhone;
						}
					}
					break;
				case 40514:
					$G.debug('-----------------VoIP--------------','挂机!');
					code = "VOIP_BYE";
					voipNum = [];
					if (viopFlag || isAnswer) {
						VideoPhone.bye(callSessionID);
						callSessionID = -1;
						setTimeout(function(){
							window.location.href = Utility.getEnv("ROOT_PATH") + "play/play.htm";
						}, 2000);
					}
					break;
				case 40517:
					$G.debug('-----------------VoIP--------------','num');
					code = "VOIP_NUM";
					var evtstr = DVB.getEvent(40517, messageId);	
					var jsonObj = eval('('+evtstr+')');
					voipNum.push(jsonObj.nKeyVal);
					viopFlag = true;
					viopPhone = voipNum.join("");
					clearTimeout(voip_num_timer);
					if(viopPhone.length > 0) voip_num_timer = setTimeout(function(){window.location.href = Utility.getEnv("ROOT_PATH") + "voip/connect.htm?id=" + 5 + "&viopPhone=" + viopPhone;}, 3500);	
					break;
				case 319: //#键
					event.preventDefault();
					code = "KEY_#";
					break;
				case 318: //*键
					event.preventDefault();
					code = "KEY_*";
					break;
				case 45002:
					code = "GETEVENT_CHANNEL_DESCRIPTION";
					break;
				//case 40032:
				//	code = "ENCRYPT_CHANNEL_DESCRIPTION";
				//	break;
				case 45003:
					code = "EVT_GAME_READY";
					break;
				case 45004:
					code = "MIS_TVCODE_CHANGE";
					Utility.println("-------------huhuatao------MIS_TVCODE_CHANGE-----------TVCode = " + Utility.getEnv("TVCode"));
					Utility.setEnv("MIS_TVCode", Utility.getEnv("TVCode"));
					$G.sysDa.set("System.CardIDOld", CA.serialNumber);	
					$G.sysDa.submit();				
					break;
				case 45778:
					code = "MIS_ENTER_APP";					// 进入mis应用消息
					break;
				case 45779:				
					code = "MIS_QUIT_APP";					// 退出mis应用消息
					break;
				case 45780:
					code = "MIS_SWITCH_PROGRAM";		// 如加切台消息
					break;
				case 45781:
					code = "MIS_ENTER_BROADCAST";		// 如加进入数据广播消息
					break;
				case 45782:
					code = "MIS_REQUEST_USSTATUS";	// 请求当前UI显示状态消息
					break;
				case 45783:
					code = "MIS_GETEPG_STATUS";		// 获取旗帜广告成功消息
					break;
				case 40173:
					code = "UPDATE_MOSAIC";
					break;
				case 44001:
					code = "Application_Note";
					break;
				case 41002:
					code = "XLET_ACTIVE";
					break;
				case 41003:
					code = "XLET_STOP";
					break;
				case 45900: // add by xy
					SysSetting.restoreDefault();
					break;	
				/*******************/
				case 45888: // 
					code = "NM_UPGRADE";
					break;
				case 40341:
					window.location.reload();
					break;
				/********************/
				default:
					debug("Unkown key " + keyCode);
					this.isKeyPrevent = false;
					break;
			}
			param = keyCode;
			debug("eventStr", code);
		}
		if (isKeyPrevent) {
			event.preventDefault();
		}
		if (orderReminder && orderReminder.isVisible) {
			var returnFlag = window.order_reminder.eventHandler({
				"code": code,
				"param": param,
				"messageId": messageId
			});
			if (!returnFlag) return;
		}
		
		if (typeof eventHandler != "undefined") {
			eventHandler({
				"code": code,
				"param": param,
				"messageId": messageId
			});
		}
	}
	
	/**
	 * 日期对象格式化
	 * y或Y：表示年份，当y为两位时，输出年份后两位，为四位时，输出完整的年份
	 * M：表示月份
	 * d：表示日期
	 * h：表示小时
	 * m：表示分钟
	 * s：表示秒钟
	 * w：表示星期
	 * @param {Object} d 要进行格式化的Date对象
	 * @param {String} formatter 格式字符串，形如“yyyy-MM-dd hh:mm:ss w”
	 * @return {String} dateStr 格式化后的日期字符串
	 */
	function dateFormat(d, formatter){
		if (!formatter || formatter == "") {
			formatter = "yyyy-MM-dd";
		}
		
		var weekdays = [["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"], ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]];
		
		var year = (d.getFullYear()).toString();
		var month = (d.getMonth() + 1).toString();
		var date = d.getDate().toString();
		var day = d.getDay();
		var hour = d.getHours().toString();
		var minute = d.getMinutes().toString();
		var second = d.getSeconds().toString();
		
		var yearMarker = formatter.replace(/[^y|Y]/g, '');
		if (yearMarker.length == 2) {
			year = year.substring(2, 4);
		} else if (yearMarker.length == 0) {
			year = "";
		}
		
		var monthMarker = formatter.replace(/[^M]/g, '');
		if (monthMarker.length > 1) {
			if (month.length == 1) {
				month = "0" + month;
			}
		} else if (monthMarker.length == 0) {
			month = "";
		}
		
		var dateMarker = formatter.replace(/[^d]/g, '');
		if (dateMarker.length > 1) {
			if (date.length == 1) {
				date = "0" + date;
			}
		} else if (dateMarker.length == 0) {
			date = "";
		}
		
		var hourMarker = formatter.replace(/[^h]/g, '');
		if (hourMarker.length > 1) {
			if (hour.length == 1) {
				hour = "0" + hour;
			}
		} else if (hourMarker.length == 0) {
			hour = "";
		}
		
		var minuteMarker = formatter.replace(/[^m]/g, '');
		if (minuteMarker.length > 1) {
			if (minute.length == 1) {
				minute = "0" + minute;
			}
		} else if (minuteMarker.length == 0) {
			minute = "";
		}
		
		var secondMarker = formatter.replace(/[^s]/g, '');
		if (secondMarker.length > 1) {
			if (second.length == 1) {
				second = "0" + second;
			}
		} else if (secondMarker.length == 0) {
			second = "";
		}
		
		var dayMarker = formatter.replace(/[^w]/g, '');
		var weekDay = "";
		if (dayMarker.length > 0) weekDay = weekdays[0][day];
		var dateStr = formatter.replace(yearMarker, year).replace(monthMarker, month).replace(dateMarker, date).replace(hourMarker, hour).replace(minuteMarker, minute).replace(secondMarker, second).replace(dayMarker, weekDay);
		return dateStr;
	}
	
	/**
	 * getDate方法，得到几天之后的时间对象
	 * @param {number} offset 时间间隔，如:当天－0,明天－1，后天－2，依此类推，也可为负数表示以前的日期
	 * @return {Date} 隔offset天之后的时间对象
	 */
	function getDate(offset){
		var d = new Date();
		d.setDate(d.getDate() + offset);
		return d;
	}
	
	/**
	 * 当字符串不足length位时，自动在左侧填充padding指定的字符串
	 * @param {String} str 需要处理的字符串
	 * @param {String} padding 用于填充的字符
	 * @param {Number} length 字符串填充后的总长度
	 * @return {String} s 进行填充处理后的结果
	 */
	function leftPadStr(str, padding, length){
		str = str.toString();
		var s = str;
		
		for (var i = 0; i < length - str.length; i++) {
			s = padding + s;
		}
		return s;
	}
	
	/**
	 * 设置机顶盒前面板字符串显示
	 * @param {Number} num 频道号
	 * @param {Number} serviceType Service类型，0为电视，1为广播
	 */
	function setFrontPanelDisplay(num, serviceType){
		if (serviceType == 0) {//电视
			SysSetting.panelDisplayText("C" + leftPadStr(num, "0", 3));
			SysSetting.panelClear("audio");
		} else if (serviceType == 1) {//广播
			SysSetting.panelDisplayText("A" + leftPadStr(num, "0", 3));
			SysSetting.panelDisplayCtrlLight("audio");
		}
	}
	
	function each(array, iterator, start, end){
		if (start > end) {
			var temp = start;
			start = end;
			end = temp;
		}
		
		for (var i = 0, len = end - start; i < len; i++) {
			var index = start + i;
			var item = index < array.length ? array[index] : null;
			iterator(item, index, i);
		}
	}
	
	/**
	 * 从URL里获取参数
	 * @param {String} url URL地址
	 * @return JSON
	 */
	function getParams(url){
		var queryString = url.substr(url.indexOf("?") + 1);
		if (queryString == "") return;
		var requests = [];
		var params = queryString.split("&");
		for (var i = 0; i < params.length; i++) {
			var temp = params[i].split("=");
			if (temp.length < 2) return;
			requests[temp[0]] = temp[1];
		}
		if (params.length == 0) {
			var temp = queryString.split("=");
			if (temp.length < 2) return;
			requests[temp[0]] = temp[1];
		}
		return requests;
	}
	
	function exitToPlay(){
		window.location.href = $G.root + "play/play.htm";
	}
	
	function exitToMenu(){
		if (window.location.href.indexOf("play.htm") == -1) {
			stopMediaPlayer();
		}
		window.location.href = Utility.getEnv("ROOT_PATH")+"index.htm";
	}
	
	function txtMarquee(str, wordSize, width) {
		if (str.length > wordSize) {
			return '<marquee direction=left width=' + width +' scrollamount=25 behavior=scroll scrolldelay=500>' + str + '</marquee>';
		} else {
			return str;
		}
	}
	
	extend($G, {
		extend: extend,
		clone: clone,
		sysDa: sysDa,
		netDa: netDa,
		envDa: envDa,
		adsDa: adsDa,
		each: each,
		lang: lang,
		root: root,
		isKeyPrevent: isKeyPrevent,
		eventListener: eventListener,
		dateFormat: dateFormat,
		getDate: getDate,
		debug: debug,
		leftPadStr: leftPadStr,
		setFrontPanelDisplay: setFrontPanelDisplay,
		getParams: getParams,
		exitToMenu: exitToMenu,
		exitToPlay: exitToPlay,
		txtMarquee: txtMarquee
	});
})();

(function(){
	document.onkeypress = $G.eventListener;
	window.addEventListener("load", function(){
		if (typeof init != "undefined") {
			init();
		}
	}, false);
	
	window.addEventListener("unload", function(){
		if (typeof exitPage != "undefined") {
			exitPage();
		}
	}, false);
})();
/**************************************************** Multi Language Code Begin ******************************************************/
/**
 * 多语言资源调用函数
 */
var $L = function(){
}

$L.extend = $L.prototype.extend = function(){
	for (var xx in arguments[0]) {
		this[xx] = arguments[0][xx];
	}
}
$L.extend({
	/**
	 * 多语言资源文件初始化
	 * @param {String} _moduleId 模块名称（注：与语言资源文件的前缀名称相同，不传则默认为'i18n'）
	 */
	init: function(_moduleId){
		if (!Boolean(_moduleId)) {
			_moduleId = 'i18n';//default value
		}
		this.moduleId = _moduleId;
		this.createScriptTag("js/" + _moduleId + "_" + this.getAreaCode() + ".js", "__moduleLanguageResources");//加载模块语言资源文件
	},
	/**
	 * UI模块ID(即模块文件夹名称)，如epg
	 */
	moduleId: "",
	/**
	 * 切换语言
	 * @param {String} _areaCode 语系和地区码的组合（注，该参数必须存在有相应的语言资源文件）
	 * @param {Number} _changeType 变更语言方式（注：该参数为0时，设置语言后，重新加载页面；为1时，设置语言后，调用initLanguage()重新初始化页面，不重新加载页面；为其它值时，只设置语言，不做其它动作）
	 */
	change: function(_areaCode, _changeType){
		if (typeof(_areaCode) != 'undefined') this.setAreaCode(_areaCode);
		else return;
		if (_changeType == 0) {
			window.location.reload();
		} else if (_changeType == 1) {
			var resourcesNode, globalResourcesNode;
			if (globalResourcesNode = document.getElementById('__globalLanguageResources')) {
				globalResourcesNode.parentNode.removeChild(globalResourcesNode);
				this.createScriptTag(Utility.getEnv("ROOT_PATH") + "js/global_" + _areaCode + ".js", "__globalLanguageResources"); //重新加载全局语言资源文件
			}
			if (resourcesNode = document.getElementById('__moduleLanguageResources')) {
				resourcesNode.parentNode.removeChild(resourcesNode);
			}
			this.createScriptTag("js/" + this.moduleId + "_" + _areaCode + ".js", "__moduleLanguageResources", this.initLanguage);//重新加载模块语言资源文件
		}
	},
	/**
	 * 初始化页面所有与语言有关的函数
	 */
	initLanguage: function(){
	
	},
	/**
	 * 情况一：所以参数不为空时。对同一前缀名为_prev的ID、并且在语言资源文件里存在同名的Key，从_begin至_end逐一执行innerText。
	 * 情况二：当_end参数为空时。则仅为ID为_prev+_begin的单个元素执行innerText。
	 * 注：该函数必须要求页面ID与语言资源文件里的KEY相对应。
	 * @param {String} _prev ID前缀
	 * @param {Number} _begin 起始Index
	 * @param {Number} _end 终止Index （注：该参数可为空）
	 */
	inner: function(_prev, _begin, _end){
		if (typeof(_end) == 'undefined') _end = _begin;
		for (var ii = _begin; ii <= _end; ii++) {
			try {
				document.getElementById(_prev + ii).innerText = $L[_prev + ii];
			} catch (e) {
				Utility.println("[MultiLanguage Error] - " + e.message);
			}
		}
	},
	/**
	 * 获取多语言标识，语系和地区码的组合
	 * 注：与sys.ini文件中的languangeString参数值相关
	 */
	getAreaCode: function(){
		var areaCode = (new DataAccess("Systemsetting.properties")).get("languangeString");
		var languageMapping = {
			language_chi: "zh-cn",
			language_eng: "en-us"
		};//languangeString参数值映射数组
		if (!Boolean(areaCode) || !(areaCode = languageMapping[areaCode])) {
			areaCode = 'zh-cn';
		}
		return areaCode;
	},
	/**
	 * 设置多语言标识
	 * @param {String} _areaCode 语系和地区码的组合
	 * 注：与sys.ini文件中的languangeString参数值相关
	 */
	setAreaCode: function(_areaCode){
		if (_areaCode != '') {
			var da = new DataAccess("Systemsetting.properties");
			da.set("languangeString", _areaCode);
			da.submit();
		}
	},
	/**
	 * 载入一个JavaScript文件到当前页面在<HEAD>标签下
	 * @param {String} _filePath 如：'js/i18n.js'(相对路径)
	 * @param {String} _elementId 生成的script标签的ID
	 * @param {Function} _callback JS文件加载完后反调函数
	 */
	createScriptTag: function(_filePath, _elementId, _callback){
		var headObj = document.getElementsByTagName('HEAD').item(0);
		var scriptObj = document.createElement("script");
		scriptObj.type = "text/javascript";
		scriptObj.charset = "utf-8";//编码
		scriptObj.id = _elementId;
		scriptObj.src = _filePath;
		scriptObj.onload = _callback;
		headObj.appendChild(scriptObj);
	}
});

/**
 * 替换有带参'｛Number｝'字符串中的符号为文字信息
 */
String.prototype.param = function(){
	var formated = this;
	for (var i = 0; i < arguments.length; i++) {
		formated = formated.replace("\{" + i + "\}", arguments[i]);
	}
	return formated;
}
/**
 * 加载全局语言资源文件
 */
$L.createScriptTag(Utility.getEnv("ROOT_PATH") + "js/global_" + $L.getAreaCode() + ".js", "__globalLanguageResources");
/**
 * 加载全局CA语言资源文件
 */
//$L.createScriptTag(Utility.getEnv("ROOT_PATH") + "js/global_ca_" + $L.getAreaCode() + ".js", "__globalCALanguageResources");

/**************************************************** Multi Language Code End ******************************************************/

function MPlayer(){
	this.player = new MediaPlayer();
	//this.player.setStopMode(1);
}

MPlayer.prototype.setPosition = function(x, y, w, h){
	this.player.setVideoDisplayMode(0);
	this.player.setVideoDisplayArea(x, y, w, h);
	this.player.refreshVideoDisplay();
};

MPlayer.prototype.fullScreen = function(){
	this.player.setVideoDisplayMode(1);
	this.player.refreshVideoDisplay();
};

//manage page timers
function Timer(name){
	this.name = name;
}

Timer.prototype.exec = function(fun, time){
	this.clear();
	this.timer = window.setTimeout(fun, time);
};

Timer.prototype.clear = function(name){
	if (this.timer) {
		window.clearTimeout(this.timer);
	}
};

function TimerManager(){
	this.timerPool = [];
};

TimerManager.prototype.add = function(timer){
	this.timerPool[timer.name] = timer;
};

TimerManager.prototype.get = function(name){
	var timer = this.timerPool[name];
	return timer;
};

TimerManager.prototype.clearAll = function(){
	for (var i in this.timerPool) {
		this.timerPool[i].clear();
	}
};

/**
 * 全局"KEY_EXIT"键处理函数【注：如果页面中需要个性化处理此键值，请重写此函数。】
 * @return null
 */
function doExit(){
	$G.exitToPlay();
}

/**
 * 全局"KEY_MENU"键处理函数【注：如果页面中需要个性化处理此键值，请重写此函数。】
 * @return null
 */
function doMenu(){
	stopAitManager();
	var mp = new MediaPlayer();
	mp.setStopMode(1);
	mp.stop();
	$G.exitToMenu();
}

/**
 * 全局"KEY_EPG"键处理函数【注：如果页面中需要个性化处理此键值，请重写此函数。】
 * @return null
 */
function doEpg(){
	stopAitManager();
	window.location.href = Utility.getEnv("ROOT_PATH") + "epg/currDayNotice.htm";
}

/**
 * 将整个字符串中的中文替换成双字节,判断总长度是否大于需要截取的长度,如果大于则截取
 * @param {Number} n 截取长度
 */
String.prototype.sub = function(n){//中英文混合截取子字符串     
	var r = /[^\x00-\xff]/g;
	if (this.replace(r, "mm").length <= n) return this;
	var m = Math.floor(n / 2);
	for (var i = m; i < this.length; i++) {
		if (this.substr(0, i).replace(r, "mm").length >= n) { return this.substr(0, i) + "..."; }
	}
	return this;
}
/**
 * 中英文字符长度统一用英文长度计算
 */
String.prototype.len = function(){
	return this.replace(/[^\x00-\xff]/g, "rr").length;
}
/**
 * 处理40082消息
 * @param {Json} _json JOSN消息格式
 */
function handleCaCommand(_json){
	switch(_json.msgSubType){
		case 1: //1表示-应用锁定STB  //游戏搜索中，请稍候……
			showCAGlobalTips($GL.CA_INFO_0, 0);
			break;
		case 2: //搜索失败，退回游戏主页面 
			globalCAOperationID = _json.operationID;
			showCAGlobalTips($GL.CA_INFO_1.param(_json.tokenChangeValue), 1, 'ca');
			break;
		case 4:
			showCAGlobalTips(_json.msgContent, 0);
			break;
		case 5:
			showCAGlobalTips(+_json.smcId, 0);
			break;
		case 6:
			showCAGlobalTips($GL.CA_INFO_2 + _json.smcId, 0);
			break;
		case 7:
			var currYear = _json.parentRate;
			if (DVNCA.rating < _json.parentRate) {
				showCAGlobalTips($GL.CA_INFO_3, 0);
			}
			break;
	}
}

/**
 * 显示CA提示消息
 * @param {String} _tips 提示显示内容
 * @param {String} _type 显示提示框类别（0:普通;1:带确认取消按钮）
 */
var isInnerTipsHTML = isInnerConfirmHTML = isShowCAGlobalTips = isShowCAGlobalConfirm = isShowOTAGlobalConfirm = isShowGlobalConfirm = isShowNITGlobalConfirm = false, globalCATipsTimeout = -1, globalCAConfirmBtn = 0, globalCAOperationID;
function showCAGlobalTips(_tips, _type, _flag){
	// 在全局显示框显示之前，应把如加广告中的泡泡广告隐藏
	Utility.setEnv("Mis_AdvCallback", "hide_bubble_adv");
	
	var globalCreateDiv = function(_html){
		var bodyObj = document.getElementsByTagName('BODY').item(0);
		var divObj = document.createElement("div");
		bodyObj.appendChild(divObj);
		divObj.innerHTML = _html;
	}
	if (!isInnerTipsHTML && _type == 0) {
		var html = '<div id="globalCATipsDiv" style="position:absolute; font-size:30px; left:360px; top:180px; width:557px; height:293px;background:url(' + encodeURI($G.root) + 'images/alert_s.png) no-repeat left top;z-index:20;visibility:visible;">';
		html += '<div style="position:absolute; left:10px; top:12px; color:#fff;  width:530px; text-align:center; height:45px;">' + $GL.TIPS + '</div>';
		html += '<div id="globalCATipsTxt" style="position:absolute; left:10px; top:72px; width:538px; height:136px; line-height:136px; font-size:24px; text-align:center; color:#111;">' + _tips + '</div></div>';
		isInnerTipsHTML = true;
		globalCreateDiv(html);
	} else if (_type == 1 && !isInnerConfirmHTML) {
		var html = '<div style="position:absolute; font-size:30px; left:360px; top:180px; width:557px; height:293px;background:url(' + encodeURI($G.root) + 'images/alert_s.png) no-repeat left top;z-index:20;visibility:visible;" id="globalCAConfirmDiv">';
		html += '<div style="position:absolute; left:10px; top:12px; width:530px; color:#fff; text-align:center; height:45px; ">' + $GL.TIPS + '</div>';
		html += '<div style="position:absolute; left:10px; top:72px; width:538px; height:136px; line-height:136px; font-size:24px; text-align:center; color:#111;" id="globalCAConfirmTxt">' + _tips + '</div>';
		html += '<span style="position:absolute; top:233px; left:77px; width:182px;height:48px;text-align:center;line-height:48px; color:#eee; background:url(../images/bt_01.png) no-repeat left top;" id="globalCAConfirmBtn_0">' + $GL.OK + '</span>';
		html += '<span style="position:absolute; top:233px; left:290px; width:182px;height:48px;text-align:center;line-height:48px; color:#eee; background:url(../images/bt_02.png) no-repeat left top;" id="globalCAConfirmBtn_1">' + $GL.CANCEL + '</span>';
		html += '</div>';
		isInnerConfirmHTML = true;
		globalCreateDiv(html);
	} else {
		document.getElementById(['globalCATipsTxt', 'globalCAConfirmTxt'][_type]).innerText = _tips;
		document.getElementById(['globalCATipsDiv', 'globalCAConfirmDiv'][_type]).style.visibility = 'visible';
	}
	isShowCAGlobalTips = true;
	if (_type == 0) {
		if (globalCATipsTimeout != -1) {
			clearTimeout(globalCATipsTimeout);
		}
		globalCATipsTimeout = setTimeout("document.getElementById('globalCATipsDiv').style.visibility='hidden';isShowCAGlobalTips=false;globalCATipsTimeout=-1;", 3000);
	} else if (_type == 1) {
		isShowGlobalConfirm = true;
		if (_flag == 'ca') {
			isShowCAGlobalConfirm = true;
		} else if (_flag == 'ota') {
			isShowOTAGlobalConfirm = true;
		} else if (_flag == 'nit') {
			isShowNITGlobalConfirm = true;
		}
	}
}
function hideStreamDiv() {
	$('globalCAConfirmDiv').style.visibility='hidden';
	isShowCAGlobalTips=false;
}
/**
 * 隐藏全局confirm框
 */
function hiddenGlobalCAConfirm(){
	$('globalCAConfirmDiv').style.visibility='hidden';
	isShowCAGlobalTips=false;
	isShowCAGlobalConfirm=false;
	if(globalCAConfirmBtn==0){
		globalCAConfirmBtn=1;
		$('globalCAConfirmBtn_0').style.backgroundImage = 'url(../images/bt_01.png)';
		$('globalCAConfirmBtn_1').style.backgroundImage = 'url(../images/bt_02.png)';
	}
}

function Dialog(name, src, zIndex, x, y, w, h){
	this.iframe = document.createElement("iframe");
	this.iframe.name = name;
	document.body.appendChild(this.iframe);
	this.x = x || 0;
	this.y = y || 0;
	this.src = src;
	this.width = w || 1280;
	this.height = h || 720;
	this.zIndex = zIndex || 30;
	this.iframe.style.position = "absolute";
	this.iframe.style.left = this.x + "px";
	this.iframe.style.top = this.y + "px";
	this.iframe.style.width = this.width + "px";
	this.iframe.style.height = this.height + "px";
	this.iframe.style.zIndex = this.zIndex;
	this.isVisible = false;
	
	this.show = function(){
		this.iframe.src = this.src;
		this.isVisible = true;
	};
	
	this.hide = function(){
		this.iframe.src = Utility.getEnv("ROOT_PATH") + "blank.htm";
		this.isVisible = false;
	};
}

var misIsShowOrder = false;
var orderReminder;
function showOrderReminder(){
	if (!orderReminder) {
		orderReminder = new Dialog("order_reminder", Utility.getEnv("ROOT_PATH") + "epg/order_reminder.htm", 30);
	}
		
	// 在预定提前提醒框显示之前，应把如加广告中的泡泡广告隐藏
	Utility.setEnv("Mis_AdvCallback", "hide_bubble_adv");
	misIsShowOrder = true;
	
	orderReminder.show();
}

function hideOrderReminder(){
	misIsShowOrder = false;
	
	orderReminder.hide();
}

function diffMinute(date) {
	var currDate = new Date();
	var rtMinutes = Math.floor(timeDiff(currDate, date) / 60); 
	return rtMinutes;
}
/*
 * 将Date对象转换为妙
 */
function dateToSecond(date) {
	return date.getHours()*3600 + date.getMinutes()*60 + date.getSeconds();
}
/*
 * 计算Date对象的时间差,返回值为秒
 */
function timeDiff(nowTime, endTime) {
	return (dateToSecond(endTime) - dateToSecond(nowTime));
}

function openOrderedProgram(){
	var order = Orders.getAt(0);
	$G.debug("=========================", "预定跳转开始");
	var service = new Service(order.location);
	$G.debug("service.name", service.name);
	$G.debug("service.type", service.type);
	if (order.type == 2) {
		$G.debug("=========================", "此时预定跳转往NVOD播放页面");
		stopAitManager();
		Utility.setEnv("backToPlay", "backToPlay");
		Utility.setEnv("currNVOD", order.location);
		Utility.setEnv("eventName", order.name);
		Utility.setEnv("startTime", order.startTime);
		Utility.setEnv("endTime", order.endTime);
		var leftSeconds = timeDiff(order.startTime, order.endTime);
		Utility.setEnv("leftSeconds", leftSeconds);
		Utility.setEnv("fromGlobalOrder_event", order.name);
		Utility.setEnv("fromGlobalOrder_group", order.serviceName);
	  window.location.href = Utility.getEnv("ROOT_PATH") + "NVOD/NVOD_play.htm";
	} else if (order.type == 3){
		if (service && service.type == DVB.SERVICE_TYPE_TV) {
			var serviceList = ServiceDB.getServiceList().filterService(ServiceDB.LIST_TYPE_SERVICE, "TV");
			var serviceIndex = serviceList.findIndex(service);
			$G.debug("serviceIndex", serviceIndex);
			serviceList.moveTo(serviceIndex);
			$G.sysDa.set("Mediaplayer.groupIndex", 0);
			$G.sysDa.submit();
			stopAitManager();
			window.location.href = Utility.getEnv("ROOT_PATH") + "play/play.htm?" + Math.random();
		} else if (service && service.type == DVB.SERVICE_TYPE_RADIO) {
			var serviceList = ServiceDB.getServiceList().filterService(ServiceDB.LIST_TYPE_SERVICE, "RADIO");
			var serviceIndex = serviceList.findIndex(service);
			$G.debug("serviceIndex", serviceIndex);
			serviceList.moveTo(serviceIndex);
			$G.sysDa.set("Mediaplayer.groupIndex", 1);
			$G.sysDa.submit();
			stopAitManager();
			window.location.href = Utility.getEnv("ROOT_PATH") + "radio/radio.htm?" + Math.random();
		}
	}	
}

function stopMediaPlayer() {
	var mp = new MediaPlayer();
	mp.setStopMode(0);
	mp.stop();
	DVB.clearShowEvent();
}
var volumeMode = $G.sysDa.get("VolumeSaveMode") != "" ? parseInt($G.sysDa.get("VolumeSaveMode")) : 0;
var uniformVolume = $G.sysDa.get("UniformVolume") != "" ? parseInt($G.sysDa.get("UniformVolume")) : 16;
function playCurrService() {
	var allChannelsList = ServiceDB.getServiceList();
	var tvList = allChannelsList.filterService(ServiceDB.LIST_TYPE_SERVICE, "TV");
	var currService = tvList.currentService;
	
	var mp = new MediaPlayer();
	if (volumeMode == 0) {
		mp.setVolume(currService.volume);
	} else {
		mp.setVolume(uniformVolume);
	}
	if (currService.lock) {
		mp.setStopMode(0);
		mp.stop();
	} else {
		//var volume = currService.volume;
		mp.setSingleMedia(currService.getLocation());
		//mp.setVolume(volume);
		mp.setVideoDisplayMode(1);
		mp.refreshVideoDisplay();
		mp.playFromStart();
	}

}
