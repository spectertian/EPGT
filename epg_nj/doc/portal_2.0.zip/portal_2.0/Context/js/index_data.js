﻿var ethenets;
var ipAddr;
var currIp;
var caSerialNum;
var stbSerialNum;
var codeStr;

var helpTailAddr;
var userId = "";
var datas;
getDatas();
function getDatas() {
	ethenets = Network.ethernets[0];
	ipAddr = ethenets.IPs[0];
	currIp = ipAddr.IPAddres;
	caSerialNum = CA.serialNumber;
	stbSerialNum = SysInfo.STBSerialNumber;
	codeStr = "Y-coship-coship" + currIp + "-etc";
	
	helpTailAddr = "cardid=" + caSerialNum + "&clientid=" + stbSerialNum + "&method=&channel=0000:000:00:0000&code=" + codeStr + "&uitype=" + 1;
	userId=Utility.getSystemInfo("UID");
	
	datas = [
			{
				"menuTitle": "阅读",
				menuPic: [
						{pic:"images/zxtj_blur.gif",focusPic:"images/zxtj_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=09-001&userCode="+userId},
						{pic:"images/dszz_blur.gif",focusPic:"images/dszz_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=09-002&userCode="+userId},
						{pic:"images/qgbz_blur.gif",focusPic:"images/qgbz_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=09-003&userCode="+userId},
						{pic:"images/nrss_blur.gif",focusPic:"images/nrss_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=09-004&userCode="+userId},
						{pic:"images/yjjc_blur.gif",focusPic:"images/yjjc_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=09-005&userCode="+userId},
						{pic:"images/tv_book_blur.gif",focusPic:"images/tv_book_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=09-006&userCode="+userId},
						{pic:"images/read_help_blur.gif",focusPic:"images/read_help_focus.gif",url:"http://hdzchannel.jsamtv.com/epg/show.do?app=zchannel&hd=y&content=help&detail=50006&"+helpTailAddr}					
						],
				homePage : ""
				},
			{
				"menuTitle": "频道",
				menuPic: [
						{pic:"images/zypd_blur.gif",focusPic:"images/zypd_focus.gif",url:"http://10.20.88.48:8080/hlstest/hls.html"},
						{pic:"images/bdpd_blur.gif",focusPic:"images/bdpd_focus.gif",url:"NVOD/publicChannel.htm?index=1"},
						{pic:"images/wdpd_blur.gif",focusPic:"images/wdpd_focus.gif",url:"NVOD/publicChannel.htm?index=2"},
						{pic:"images/ffpd_blur.gif",focusPic:"images/ffpd_focus.gif",url:"NVOD/publicChannel.htm?index=4"},
						{pic:"images/gbpd_blur.gif",focusPic:"images/gbpd_focus.gif",url:"radio/radio_index.htm"},
						{pic:"images/channel_help_blur.gif",focusPic:"images/channel_help_focus.gif",url:"http://hdzchannel.jsamtv.com/epg/show.do?app=zchannel&hd=y&content=help&detail=50009&" + helpTailAddr},				
						{pic:"images/xtsz_blur.gif",focusPic:"images/xtsz_focus.gif",url:"setting/sysSettingMenu.htm"}
						],
				homePage : ""
				},
			{
				"menuTitle": "点播",
				menuPic: [
						{pic:"images/hotmovice_blur.gif",focusPic:"images/hotmovice_focus.gif",url:"http://hditv.jsamtv.com/epg/show.do?app=vpg&hd=y&content=hot&" + helpTailAddr},
						{pic:"images/movice_blur.gif",focusPic:"images/movice_focus.gif",url:"http://hditv.jsamtv.com/epg/show.do?app=vpg&hd=y&content=movies&" + helpTailAddr},
						{pic:"images/tv_blur.gif",focusPic:"images/tv_focus.gif",url:"http://hditv.jsamtv.com/epg/show.do?app=vpg&hd=y&content=teleplay&" + helpTailAddr},
						{pic:"images/cartoon_blur.gif",focusPic:"images/cartoon_focus.gif",url:"http://hditv.jsamtv.com/epg/show.do?app=vpg&hd=y&content=animation&" + helpTailAddr},
						{pic:"images/entertaiment_blur.gif",focusPic:"images/entertaiment_focus.gif",url:"http://hditv.jsamtv.com/epg/show.do?app=vpg&hd=y&content=arts&" + helpTailAddr},
						{pic:"images/sport_blur.gif",focusPic:"images/sport_focus.gif",url:"http://hditv.jsamtv.com/epg/show.do?app=vpg&hd=y&content=sports&" + helpTailAddr},
						{pic:"images/culture_blur.gif",focusPic:"images/culture_focus.gif",url:"http://hditv.jsamtv.com/epg/show.do?app=vpg&hd=y&content=culture&" + helpTailAddr},
						{pic:"images/news_blur.gif",focusPic:"images/news_focus.gif",url:"http://hditv.jsamtv.com/epg/show.do?app=vpg&hd=y&content=news&" + helpTailAddr},
						{pic:"images/vod_help_blur.gif",focusPic:"images/vod_help_focus.gif",url:"http://hdzchannel.jsamtv.com/epg/show.do?app=zchannel&hd=y&content=help&detail=50001&" + helpTailAddr},
						{pic:"images/vod_home_blur.gif",focusPic:"images/vod_home_focus.gif",url:"http://hditv.jsamtv.com/epg/show.do?app=vpg&hd=y&content=vodhome&" + helpTailAddr}
						],
				homePage : ""
				},
			{
				"menuTitle": "高清",
				menuPic: [
						{pic:"images/HD_promote_blur.gif",focusPic:"images/HD_promote_focus.gif",url:"http://hditv.jsamtv.com/epg/show.do?app=vpg&hd=y&content=hdhome&" + helpTailAddr},
						{pic:"images/HD_movice_blur.gif",focusPic:"images/HD_movice_focus.gif",url:"http://hditv.jsamtv.com/epg/show.do?app=vpg&hd=y&content=hdperfect&" + helpTailAddr},
						{pic:"images/HD_tv_blur.gif",focusPic:"images/HD_tv_focus.gif",url:"http://hditv.jsamtv.com/epg/show.do?app=vpg&hd=y&content=hdchinatv&" + helpTailAddr},
						{pic:"images/HD_all_blur.gif",focusPic:"images/HD_all_focus.gif",url:"http://hditv.jsamtv.com/epg/show.do?app=vpg&hd=y&content=hddocumentary&" + helpTailAddr},
						{pic:"images/HDChannel_blur.gif",focusPic:"images/HDChannel_focus.gif",url:"NVOD/publicChannel.htm?index=3"},
						{pic:"images/HD_help_blur.gif",focusPic:"images/HD_help_focus.gif",url:"http://hdzchannel.jsamtv.com/epg/show.do?app=zchannel&hd=y&content=help&detail=50002&" + helpTailAddr}
						],
				homePage : ""
				},
			{
				"menuTitle": "万事通",
				menuPic: [
						{pic:"images/Livelihood_blur.gif",focusPic:"images/Livelihood_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-001&userCode="+userId},
						{pic:"images/stock_blur.gif",focusPic:"images/stock_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-002&userCode="+userId},
						{pic:"images/Customers_blur.gif",focusPic:"images/Customers_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-003&userCode="+userId},
						{pic:"images/love_blur.gif",focusPic:"images/love_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-004&userCode="+userId},
						{pic:"images/TVBank_service_blur.gif",focusPic:"images/TVBank_service_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-005&userCode="+userId},
						{pic:"images/car_blur.gif",focusPic:"images/car_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-006&userCode="+userId},
						{pic:"images/food_blur.gif",focusPic:"images/food_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-007&userCode="+userId},
						{pic:"images/market_blur.gif",focusPic:"images/market_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-008&userCode="+userId},
						{pic:"images/tqzx_blur.gif",focusPic:"images/tqzx_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-009&userCode="+userId},
						{pic:"images/love_service_blur.gif",focusPic:"images/love_service_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-010&userCode="+userId},
						{pic:"images/Chief_blur.gif",focusPic:"images/Chief_focus.gif",url:"oc_play_quick.htm?index=0"},
						{pic:"images/price_blur.gif",focusPic:"images/price_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-012&userCode="+userId},
						{pic:"images/rent_blur.gif",focusPic:"images/rent_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-013&userCode="+userId},
						{pic:"images/wst_help_blur.gif",focusPic:"images/wst_help_focus.gif",url:"http://hdzchannel.jsamtv.com/epg/show.do?app=zchannel&hd=y&content=help&detail=50003&"+helpTailAddr},
						{pic:"images/wst_view_blur.gif",focusPic:"images/wst_view_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-015&userCode="+userId}
						],
				homePage : ""
				},
			{
				"menuTitle": "商城",
				menuPic: [
						{pic:"http://hdtvmall.jsamtv.com/HD/hengtongFamily.gif",focusPic:"http://hdtvmall.jsamtv.com/HD/hengtongFamily_selected.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=05-001&userCode="+userId},
						{pic:"http://hdtvmall.jsamtv.com/HD/shoppingMall.gif",focusPic:"http://hdtvmall.jsamtv.com/HD/shoppingMall_selected.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=05-002&userCode="+userId},
						{pic:"http://hdtvmall.jsamtv.com/HD/famousStreet.gif",focusPic:"http://hdtvmall.jsamtv.com/HD/famousStreet_selected.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=05-003&userCode="+userId},						
						{pic:"http://hdtvmall.jsamtv.com/HD/lifeShow.gif",focusPic:"http://hdtvmall.jsamtv.com/HD/lifeShow_selected.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=05-004&userCode="+userId},
						{pic:"http://hdtvmall.jsamtv.com/HD/babyShow.gif",focusPic:"http://hdtvmall.jsamtv.com/HD/babyShow_selected.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=05-005&userCode="+userId},
						{pic:"http://hdtvmall.jsamtv.com/HD/beautyShow.gif",focusPic:"http://hdtvmall.jsamtv.com/HD/beautyShow_selected.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=05-006&userCode="+userId},				
						{pic:"http://hdtvmall.jsamtv.com/HD/memberCenter.gif",focusPic:"http://hdtvmall.jsamtv.com/HD/memberCenter_selected.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=05-009&userCode="+userId},
						{pic:"http://hdtvmall.jsamtv.com/HD/search.gif",focusPic:"http://hdtvmall.jsamtv.com/HD/search_selected.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=05-010&userCode="+userId},
						{pic:"http://hdtvmall.jsamtv.com/HD/help.gif",focusPic:"http://hdtvmall.jsamtv.com/HD/help_selected.gif",url:"http://hdzchannel.jsamtv.com/epg/show.do?app=zchannel&hd=y&content=help&detail=50004&"+helpTailAddr},
						{pic:"http://hdtvmall.jsamtv.com/HD/navigate.gif",focusPic:"http://hdtvmall.jsamtv.com/HD/navigate_selected.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=05-008&userCode="+userId}
						],
				homePage : ""
				},
			{
				"menuTitle": "互联网",
				menuPic: [
						{pic:"images/media_blur.gif",focusPic:"images/media_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=06-001&userCode="+userId},
						{pic:"images/sina_blur.gif",focusPic:"images/sina_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=06-002&userCode="+userId},
						{pic:"images/baidu_blur.gif",focusPic:"images/baidu_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=06-003&userCode="+userId},
						{pic:"images/zjw_blur.gif",focusPic:"images/zjw_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=06-004&userCode="+userId},
						{pic:"images/ChinaJS_blur.gif",focusPic:"images/ChinaJS_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=06-005&userCode="+userId},
						{pic:"images/longhu_blur.gif",focusPic:"images/longhu_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=06-006&userCode="+userId},
						{pic:"images/hxw_blur.gif",focusPic:"images/hxw_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=06-007&userCode="+userId},
						{pic:"images/365_blur.gif",focusPic:"images/365_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=06-008&userCode="+userId},
						{pic:"images/traffic_blur.gif",focusPic:"images/traffic_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=06-009&userCode="+userId},
						{pic:"images/movice_blur_1.gif",focusPic:"images/movice_focus_1.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=06-010&userCode="+userId},						
						{pic:"images/speed_blur.gif",focusPic:"images/speed_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=06-011&userCode="+userId},
						{pic:"images/web_help_blur.gif",focusPic:"images/web_help_focus.gif",url:"http://hdzchannel.jsamtv.com/epg/show.do?app=zchannel&hd=y&content=help&detail=50007&"+helpTailAddr},						
						{pic:"images/nav_blur.gif",focusPic:"images/nav_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=06-013&userCode="+userId},
						],
				homePage : ""
				},
			{
				"menuTitle": "营业厅",
				menuPic: [
						{pic:"images/myCount_blur.gif",focusPic:"images/myCount_focus.gif",url:"http://hdcsc.jsamtv.com/csc/show.do?app=csc&hd=y&content=cschome&cardid=" + caSerialNum + "&clientid=" + stbSerialNum + "&uitype=" + 1},
						{pic:"images/cmenu92.gif",focusPic:"images/smenu92.gif",url:"http://hdcsc.jsamtv.com/csc/show.do?app=csc&hd=y&content=order&cardid=" + caSerialNum + "&clientid=" + stbSerialNum},
						{pic:"images/cmenu91.gif",focusPic:"images/smenu91.gif",url:"http://hdcsc.jsamtv.com/csc/show.do?app=csc&hd=y&content=charge&cardid=" + caSerialNum + "&clientid=" + stbSerialNum},
					    {pic:"images/cmenu95.gif",focusPic:"images/smenu95.gif",url:"http://hdcsc.jsamtv.com/csc/show.do?app=csc&hd=y&content=faq&cardid=" + caSerialNum + "&clientid=" + stbSerialNum},
						{pic:"images/back_service_blur.gif",focusPic:"images/back_service_focus.gif",url:"http://hdcsc.jsamtv.com/csc/show.do?app=csc&hd=y&content=online&cardid=" + caSerialNum + "&clientid=" + stbSerialNum + "&uitype=" + 1},
						{pic:"images/jf_service_blur.gif",focusPic:"images/jf_service_focus.gif",url:"http://hdcsc.jsamtv.com/csc/show.do?app=csc&hd=y&content=cumulation&cardid=" + caSerialNum + "&clientid=" + stbSerialNum + "&uitype=" + 1},
						{pic:"images/yyt_help_blur.gif",focusPic:"images/yyt_help_focus.gif",url:"http://hdzchannel.jsamtv.com/epg/show.do?app=zchannel&hd=y&content=help&detail=50008&" + helpTailAddr}
						],
				homePage : ""
				},
			{
				"menuTitle": "娱乐",
				menuPic: [
						{pic:"images/game_blur.gif",focusPic:"images/game_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=08-001&userCode="+userId},
						{pic:"images/kalaok_blur.gif",focusPic:"images/kalaok_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=08-002&userCode="+userId},
						{pic:"images/yybh_blur.gif",focusPic:"images/yybh_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=08-004&userCode=" + userId},
						{pic:"images/dsxc_blur.gif",focusPic:"images/dsxc_focus.gif",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=08-006&userCode=" + userId},
						{pic:"images/entermian_help_blur.gif",focusPic:"images/entermian_help_focus.gif",url:"http://hdzchannel.jsamtv.com/epg/show.do?app=zchannel&hd=y&content=help&detail=50005&"+ helpTailAddr},
						{pic:"images/navigation_blur.png",focusPic:"images/navigation_focus.png",url:"http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=08-008&userCode=" + userId}
						],
				homePage : ""
				}
		];
}

var weather = [
		{image:"images/weather_0.png",city:"南京",high:"30",low:"14",des:"多云"},
		{image:"images/weather_1.png",city:"苏州",high:"29",low:"15",des:"多云间晴"},
		{image:"images/weather_2.png",city:"无锡",high:"29",low:"18",des:"晴转小雨"},
		{image:"images/weather_3.png",city:"常州",high:"29",low:"17",des:"小雨"},
		{image:"images/weather_4.png",city:"镇江",high:"30",low:"17",des:"大雨"},
		{image:"images/weather_5.png",city:"徐州",high:"30",low:"14",des:"中雨"},
		{image:"images/weather_6.png",city:"扬州",high:"29",low:"15",des:"雾"},
		{image:"images/weather_7.png",city:"宿迁",high:"29",low:"18",des:"晴"},
		{image:"images/weather_8.png",city:"盐城",high:"29",low:"17",des:"雷电"},
		{image:"images/weather_9.png",city:"泰州",high:"30",low:"17",des:"多云"},
		{image:"images/weather_5.png",city:"南通",high:"30",low:"14",des:"中雨"},
		{image:"images/weather_2.png",city:"连云港",high:"29",low:"15",des:"晴转小雨"},
		{image:"images/weather_8.png",city:"淮安",high:"29",low:"18",des:"雷电"}
	];
