/**
 * @fileoverview 滚动条模块(JS HTML版)
 * <pre>
 * 使用方法：
 * 创建：
 * var scrollbar = new Scrollbar({
 *     objId: "obj_id", 
 *     barId: "bar_id",
 *     pageSize: 8, 
 *     totalBarHeight: 400
 * });
 *
 * 
 * 绑定数据：
 * var data = ['item1','item2','item3','item4'];
 * var currIndex = 0;
 * scrollbar.bindData(data, currIndex);
 * 
 * 定位：
 * scrollbar.setPosition(currIndex);
 * </pre>
 */

/**
 * 滚动条模块
 * @initParams {Object} initParams 格式为：{objId: "", barId: "", pageSize: 8, totalBarHeight: 400}
 * objId：当前滚动条对象id，主要用于操作滚动条的位置
 * barId：滚动条中部可伸缩部分的id，主要用于根据数据的长度控制滚动条伸缩
 * pageSize：每页的数据条数
 * totalBarHeight：滚动条中部的最大长度
 * 注意：该对象的创建一定放在页面onload里
 */
var Scrollbar = function (initProps) {
	this.obj = document.getElementById(initProps.objId);
	if (!this.obj) {
		return null;
	}
	this.pageSize = initProps.pageSize;
	this.totalBarHeight = initProps.totalBarHeight;
};

Scrollbar.prototype = {
	/**
	 * 为滚动条绑定数据
	 * @param {Array} data 数据数组
	 * @param {Number} index 列表当前索引
	 */
	bindData : function (data, index) {
		var dataCount = data.length;
		this.scrollStep = dataCount > this.pageSize ? this.totalBarHeight / (dataCount - 1) : 0;
		this.setPosition(index);
	},
	
	/**
	 * 设置当前滚动位置的index，滚动条自动定位到相应的位置
	 * @param {Number} currIndex 列表当前索引
	 */
	setPosition : function (currIndex) {
		var position = this.scrollStep * currIndex;
		this.obj.style.top = Math.floor(position) + "px";
	}
}