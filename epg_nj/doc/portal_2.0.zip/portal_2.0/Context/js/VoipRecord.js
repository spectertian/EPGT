function objArrayToJSON(objArray){
    var ret = "[";
    var len = objArray.length;
    var obj;
    var key;
    for (var i = 0; i < len; i++) {
        obj = objArray[i];
        ret += "{";
        for (key in obj) {
            if (obj[key]) {
                ret += key + ':"' + obj[key] + '",';
            }
        }
        ret += "}";
        if (i < len - 1) {
            ret += ",";
        }
    }
    ret += "]";
    return ret;
}

function printObjAttr(obj) {
	var key;
	for (key in obj) {
		if (obj[key]) {
			Utility.println("--"+key+"="+obj[key]);
		}
	}
}

function checkPhoneNumberValid(phoneNumber) {
	if (!phoneNumber || phoneNumber == "undefined") {
		return false;
	}
	if (phoneNumber[0] != "+" && isNaN(phoneNumber[0])) {
		return false;
	}
	return true;
}
function isShotNumberOrMobile(number) {
	if (number.length <= 5) {
		return true;
	}
	if (number.length == 11 && number[0] == '1' && number[1] != '0') {
		return true;
	}
	
	return false;
}

//此函数返回值如下：
//如果输入的号码前有+86，会自动去除
//如果输入的号码是短号或手机号码，则返回短号或手机号.比如直接返回96296或186********
//如果输入的号码是电话号码，则会返回带区号的电话号码，并且区号前的0会被保留.比如会返回02525009660
function cutNumber(number) {
	var str = number;
	if (number.length > 8 || number[0] == '+') {
		var reg = /([\+])?(86)?0*([\d]+)/gi;
		str = reg.exec(number)[3];
	}
	
	if (!isShotNumberOrMobile(str)) {
		if (str.length == 8 || str.length == 7) {
			str = "025"+str;
		} else {
			str = "0"+str;
		}
	}
	
	return str;
}

function phoneNumEqual(left, right) {
	return (cutNumber(left) == cutNumber(right))
}

// 构造函数
var VoipRecord = function(filePath, vRMaxLen){
	this.recordFile = new File(filePath);
	if (typeof(vRMaxLen) == "number") {
		this.maxLen = vRMaxLen;
	}
	else {
		this.maxLen = 30;
	}
}

VoipRecord.prototype = {
    make: function(){
        var recordStr = "", size = this.recordFile.getSize();
        this.recordFile.open("r+", 1);
        recordStr = this.recordFile.readFile(0, size);
        this.recordFile.close();
        if (recordStr && recordStr != "" && recordStr != undefined) {
            this.data = eval(recordStr);
        }
        else {
            this.data = new Array(0);
        }
        this.length = this.data.length == undefined ? 0 : this.data.length;
    },
    
    getCode: function(_type, code){
        var msg = [["来电", "去电", "未接"],["在线","离线"]];
        code -= 0;
        _type -= 0;
        return msg[_type][code];
    },
    
    save: function(){
        var saveStr = objArrayToJSON(this.data);
        this.recordFile.open("w+", 1);
        this.recordFile.writeFile(0, saveStr);
        this.recordFile.close();
    },
    
    add: function(obj){
        Utility.println("add obj:");
        printObjAttr(obj);
        this.data.push(obj);
        this.length++;
		if(this.length > this.maxLen){
			this.data.shift();
		}
    },
    
    modify: function(_index, obj){
        this.data.splice(_index, 1, obj);
    },
    
    del: function(_id){
        this.data.splice(_id, 1);
        this.length--;
    },
    
    find: function(phoneNum){
        for (var index = 0; index < this.length; index++) {
            if (this.data[index].num == phoneNum) 
                return index;
        }
        if (index >= this.length) 
            return -1;
    },
    
    reverse: function(){
        this.data.reverse();
    }
}