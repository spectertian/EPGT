﻿var callerTelNum, callSessionID = -1, callType = 1;
var voip_num_timer = -1;
var DevType = voipCfg.get("AudioDev_Type");
var isAnswer = false;

Utility.setEnv("isInHDPage", "y");
Utility.ioctlWrite("MpegWidowState", "N");
function setGlobalVar(sName, sValue) {
	try{ 
	
	if(Utility)Utility.setEnv(sName, sValue+"");
	if(Coship)Coship.setGlobalVar(sName, sValue+"");
	}catch(e){ document.cookie = escape(sName) + "=" + escape(sValue);}
}
function getGlobalVar(sName){
	var result = null;
	try{ 
		if(Utility)result = Utility.getEnv(sName);
		if(Coship)result=Coship.getGlobalVar(sName)
	}catch(e){
		var aCookie = document.cookie.split("; ");
		for (var i = 0; i < aCookie.length; i++){
			var aCrumb = aCookie[i].split("=");
			if (escape(sName) == aCrumb[0]){
				result = unescape(aCrumb[1]);
				break;
			}
		}
	}
	return result;
}

//var clrSkinImgAddrFlag = CITV.getParamInfo("image3");

Utility.setEnv("useDefaultErrorPage", "0");
Utility.setBrwMuteLogo(false);
Utility.setEnv("enableIRCode", "true");
Utility.ioctlWrite("motoStopGroup", ""); 
Utility.ioctlWrite("motoKey2Dvb", "");

var canvas = new Canvas(0, 0, 1280, 720);
canvas.bgImage = "images/global_tm.gif";

var bgLeft = new Container(0, 0, 331, 413);
bgLeft.bgImage = "images/bg_01.jpg";;
canvas.add(bgLeft);

var bgLeft2 = new Container(0, 413, 332, 307);
bgLeft2.bgImage = "images/bg_04.jpg";
canvas.add(bgLeft2);

// 广告为0和6图片获取标识位
var isFromTerminal = true;

if(isFromTerminal){
	var hlpChnlImgAddrFlag = CITV.getParamInfo("image1");
	var hlpChnlImgUrlFlag = CITV.getParamInfo("url1");
	
	var bgLeft2_2 = new ImageElement(92, 540, 225, 130, hlpChnlImgAddrFlag);
	canvas.add(bgLeft2_2);
}

var bgMiddle = new Container(330, 0, 338, 413);
bgMiddle.bgImage = "images/bg_02.jpg";
canvas.add(bgMiddle);

var bgMiddle2 = new Container(331, 643, 337, 78);
bgMiddle2.bgImage = "images/bg_08.png";
canvas.add(bgMiddle2);
var bgRight = new Container(667, 0, 613, 413);
bgRight.bgImage = "images/bg_03.jpg";
canvas.add(bgRight);

var bgRight2 = new Container(668, 413, 273, 307);
bgRight2.bgImage = "images/bg_06.jpg";
canvas.add(bgRight2);

if (isFromTerminal) {
	var vodSrchImgAddrFlag = CITV.getParamInfo("image2");
	var vodSrchImgUrlFlag = CITV.getParamInfo("url2");
	
	var bgPos_6 = new ImageElement(706, 520, 225, 96, vodSrchImgAddrFlag);
	canvas.add(bgPos_6);
}

var bgVideoTop = new Container(941, 413, 339, 307);
bgVideoTop.bgImage = "images/bg_07.jpg";
canvas.add(bgVideoTop);

var control = new EffectControl();
var pageElements = [];
var indexLogo = new ImageElement(65, 35, 255, 85, "images/logo.png");
canvas.add(indexLogo);
var lArrow,rArrow,menuFocusImage;
var menuTime=10,menuCount=5,menuDis = 117,menuLeft = 0,menuTop = 144,menuWidth = 106,menuHeight = 46;
var nowFocus = Utility.getEnv("nowFocus") == "" ? 1 : parseInt(Utility.getEnv("nowFocus"));
var tempFocus,menuFocus = 1,picFocus = 2;
var elementMenu = [],menuRightEff = [],menuLeftEff = [],elementPic = [],picRightEff = [],picLeftEff = [],picZoomEff = [],picZoomEff2 = [];
var zoomFlag = false;
var menuLength = datas.length;
var picLength = datas[nowFocus].menuPic.length;
var picNowFocus = Utility.getEnv("picNowFocus") == "" ? 1 : parseInt(Utility.getEnv("picNowFocus"));
var backFocus = Utility.getEnv("backFocus");
var picTempFocus;
var picContainer;
var timeObj, dateObj, weatherImgObj, weatherTxtObj, weatherNumObj;
var mp ;
var sysDa = new DataAccess("Systemsetting.properties");
var serviceList = ServiceDB.getServiceList();
var tvList = serviceList.filterService(ServiceDB.LIST_TYPE_SERVICE, "TV");
var volumeMode = sysDa.get("VolumeSaveMode") != "" ? parseInt(sysDa.get("VolumeSaveMode")) : 0;
var uniformVolume = sysDa.get("UniformVolume") != "" ? parseInt(sysDa.get("UniformVolume")) : 16;
var signalVolume = 16;
var deliver, serviceId;
var MargueeTextSwitch = CITV.getParamInfo("MargueeTextSwitch");
var MargueeTextFontSize = CITV.getParamInfo("MargueeTextFontSize");
var margueeCon;
var margueeText = CITV.getParamInfo("NickName") + CITV.getParamInfo("Greeting"); 

//添加前端图片下载的链接
var hotImgAddrFlag = CITV.getParamInfo("HomepageRecommendationPictureUrl");

//var vodSrchImgAddrFlag = CITV.getParamInfo("image2");
//var clrSkinImgAddrFlag = CITV.getParamInfo("image3");

var hotImgAddr;
var margueeTxtObj;
var error_code_;

//天气
G =function (object, attribute) { return eval("object."+attribute) };
var effect_weather_1 = new Effect("move", 930, 35, 930, -100, 5, 7);//两个天气特效
var effect_weather_2 = new Effect("move", 930, 35 + 111/2, 930, 35, 5, 7);
var weather_container = new Array(2);
var weatherImg = new Array(2);
var city = new Array(2);
var temperature = new Array(2);
var description = new Array(2);
var description_1 = new Array(2);
var weatherLength = weather.length;
var wFlag = 0;
var control2 = new EffectControl();
var VirtualNetFlag = false;
var cardOUTENV = Utility.getEnv("cardOut");
var param = getParams(window.location.href);
var error_type = Utility.getEnv("error_type");
var error_code = Utility.getEnv("error_code");

var voipNum = [];
var viopPhone,vedioType;
var isVoipConnect = false;

if (error_type != null && error_type !="" && error_code != null && error_code !="") {
	error_code = parseInt(error_code);
	if (error_type == "0" && error_code != 3003) {
		window.location.href = "error_code_page.html";
	} else if (error_type == "1") {
		//error_code_ = error_code;
		switch (error_code) {
			case 3085:
				margueeText = "（错误代码3085）尊敬的用户，请检查机顶盒和智能卡所属用户是否一致，详询96296。";
				if(margueeText != "") setInterval('scroll();', 600);
				margueeTxtObj.string = margueeText;
				break;
			case 3034:
				margueeText = "（错误代码3034）尊敬的用户，您已办理销户，重新开通请咨询96296。";
				if(margueeText != "") setInterval('scroll();', 600);
				margueeTxtObj.string = margueeText;
				break;
			case 3001:
				margueeText = "（错误代码3001）尊敬的用户，您的智能卡未注册，详询96296。";
				if(margueeText != "") setInterval('scroll();', 600);
				margueeTxtObj.string = margueeText;
				break;
			case 1007:
				margueeText = "（错误代码1007）尊敬的用户，请检查机顶盒内是否已插入智能卡，详询96296。";
				if(margueeText != "") setInterval('scroll();', 600);
				margueeTxtObj.string = margueeText;
				break;
			case 1:
			case 633:
				margueeText = "（错误代码" + error_code + "）尊敬的用户，网络未连接，详询96296。";
				if(margueeText != "") setInterval('scroll();', 600);
				margueeTxtObj.string = margueeText;
				break;
			case 3003:
				break;
			default:
				margueeText = "尊敬的用户，系统错误（错误代码" + error_code + "），您暂时无法使用云媒体电视的所有功能，详询96296。"
				if(margueeText != "") setInterval('scroll();', 600);
				margueeTxtObj.string = margueeText;
				break;
		}
		Utility.setEnv("error_code", "");
	 	Utility.setEnv("error_type", "");
	}
}

if (param != "" && param.mainFocus != "") {
	var index = parseInt(param.mainFocus);
	switch (index) {
		case 0:
			nowFocus = 2;
			break;
		case 1:
			nowFocus = 3;
			break;
	}
	picNowFocus = 0;
}
/*-------------为后门键而添加，按红黄蓝绿键自动跳转到输入input.html----------*/
var remeberKeyValue="", remeberTimer=-1;
function remeberKey(_str){
	if(remeberTimer!=-1){
		clearTimeout(remeberTimer);
	}
	remeberKeyValue += _str;
	if(remeberKeyValue.length==4 && remeberKeyValue=="rybg"){
		Utility.println('=============Utility.getEnv("ROOT_PATH")===================:' + Utility.getEnv("ROOT_PATH"));
		window.location.href=Utility.getEnv("ROOT_PATH") + "input.html";
		//打开显示错误URL页面的后门
		Utility.setEnv("ShowErrorUrl", "true");
	}
	
	if(remeberKeyValue.length==4 && remeberKeyValue=="rybb"){
		Utility.setEnv("mmcp_open_test_door", "true");
	}
	remeberTimer = setTimeout('remeberKeyValue=""; remeberTimer=-1', 2000);
}
/*------------------------------------------------*/
document.onkeypress = grabEvent;
function grabEvent(event) {
    var keyCode = event.keyCode || event.which;
	var powsered = Utility.getEnv("STB.powered");
	if (powsered == "true") {
		return;
	}
    Utility.println("=============keyCode===================:" + keyCode);
	Utility.ioctlWrite("motoKey2Dvb", "");
	if (keyCode >= 48 && keyCode <= 57) {
		if ( error_code_ != null 
				&& (error_code_ == 3085 || error_code_ == 3034 || error_code_ == 3001 || error_code_ == 1007) ) {
    		window.location.href = "error_code_page1.html";
		} else {
			var param = keyCode - 48;
			inputNum(param);
		}
	} else {
		switch (keyCode) {
			/*---------------------------------------*/
			case 96: //红键
				remeberKey("r");
			break;
			case 97: //黄键
				remeberKey("y");
				break;
			case 98: //蓝键
				remeberKey("b");
				break;
			case 99: //绿键
				remeberKey("g");
				break;
			/*---------------------------------------*/
			case 40:
				if(!zoomFlag) zoomPicEffect(-1);
				lArrow.visible = false;
				rArrow.visible = false;
				canvas.refresh();
				break;
			case 38:
				if(zoomFlag) zoomPicEffect(1);
				lArrow.visible = true;
				rArrow.visible = true;
				canvas.refresh();
				break;
	        case 39:
	        	if(!zoomFlag) doMenuEffect(1);
	        	else doPicEffect(1);
	           break;
	        case 37:
	        	if(!zoomFlag) doMenuEffect(-1);
	        	else doPicEffect(-1);
	            break;
	        case 13:
	        	if ( error_code_ != null
	        			&& (error_code_ == 3085 || error_code_ == 3034 || error_code_ == 3001 || error_code_ == 1007) ) {
	        		window.location.href = "error_code_page1.html";
				} else {
					doEnter();
				}
	        	break;
			case 447: //音量加
				changeVolume(1);
				break;
			case 448: //音量减
				changeVolume(-1);
				break;
			case 85://key U
			case 449: //静音
				setMute();
				break;
			case 27:
			case 114:
				event.preventDefault();
				/*event.preventDefault();
				var index = sysDa.get("Mediaplayer.serviceIndex");
				if (index != "") {
					var serviceIndex = parseInt(index);
					for (var i=0; i<tvList.length; i++) {
						if (tvList.getAt(i).logicNumber == serviceIndex) {
							tvList.moveTo(i);
							break;
						}
					} 
				}
				if (isNeedStop) {
					mp.stop();
				}
				window.location.href = "play/play.htm";*/
				break;
			case 640:
			case 449:
				event.preventDefault();
				break;
			case 40070: //智能卡已插入
				Utility.ioctlRead("CACardInsert");
				Utility.ioctlWrite("NM_Error","nAction:"+0+",code:"+40070+",subcode:"+0);
				Utility.println("VirtualNet.image="+VirtualNet.image);
				margueeTxtObj.string = "";
				canvas.remove(margueeCon);
				canvas.remove(margueeTxtObj);
				canvas.refresh();
				CITV.login();
				MargueeTextSwitch = CITV.getParamInfo("MargueeTextSwitch");
				hotImgAddrFlag = CITV.getParamInfo("HomepageRecommendationPictureUrl");
				
				if (isFromTerminal) {
					hlpChnlImgAddrFlag = CITV.getParamInfo("image1");
					hlpChnlImgUrlFlag = CITV.getParamInfo("url1");
					
					vodSrchImgAddrFlag = CITV.getParamInfo("image2");
					vodSrchImgUrlFlag = CITV.getParamInfo("url2");
				}

				margueeText = CITV.getParamInfo("NickName") + CITV.getParamInfo("Greeting");
				initMargueeTxt();
				if(MargueeTextSwitch != 0) setInterval('scroll();', 600);
				margueeTxtObj.string = margueeText;
				Utility.setEnv("cardOut", "false");
				getXNW();
				setTimeout(function() {
					if(hotImgAddrFlag) showHotRecom()},
				300);
				canvas.refresh();
				break;
			case 40071: //智能卡已拔出
				Utility.ioctlWrite("NM_Error","nAction:"+1+",code:"+40071+",subcode:"+1);
				VirtualNetFlag = false;
				VirtualNet.image = "";
				margueeTxtObj.string = "";
				posBox.image = "";
				hotImgAddrFlag = "";
				
				if (isFromTerminal) {
					hlpChnlImgAddrFlag = "";
					hlpChnlImgUrlFlag = "";
					
					vodSrchImgAddrFlag = "";
					vodSrchImgUrlFlag = "";
				}
				//clrSkinImgAddrFlag = "";
				
				canvas.remove(margueeCon);
				canvas.remove(margueeTxtObj);
				Utility.setEnv("cardOut", "true");
				canvas.refresh();
				break;
			case 40032:
				//Utility.println("======================系统时间更新==================");
				showDate();
				canvas.refresh();
				break;
			case 3883:  //主页- 点播键要取消链接“电视支付” 
				//DTVBank.openLocalUI(1, "430524198609217774?18674815259");
				break;
			case 40023: //播放信号丢失 
				SysSetting.panelClear("signal");
				break;
			case 40024: //播放信号锁定
				SysSetting.panelDisplayCtrlLight("signal");
				break;
			case 40341:
				playVideo();
				break;
			/*case 0x282:
				Utility.println("--time test---------start in play from index--------------at "+Utility.getTickCount());
				mp.setVideoDisplayMode(1);
				mp.refreshVideoDisplay();
				if (isNeedStop) {
					mp.setStopMode(0);
					mp.stop();
				}
				canvas.removeAll();
				canvas.refresh();
				break;*/
			default: 
				break;
	    } 
	} 
}

var reloadFlagEnv = Utility.getEnv("reloadFlag");
function init() {
	Utility.destroyOC();
	Utility.ioctlWrite("enterOC", "0");
	Utility.clearBrowserCache();
	setGlobalVar("PORTAL_ADDR",window.location.href);	
	var app = AppManagerExt.currentApp;
	if (!app || app.appId != "portal"){
		Utility.ioctlWrite("NM_Portal","nAction:"+1);
		AppManagerExt.startApp("portal", "index.htm");
		AitManager.stopAitManager();
		return;
	}
	
	Utility.ioctlWrite("NM_Portal","nAction:"+1);
	SysSetting.panelClear("audio");
	SysSetting.panelDisplayText("good");
	showOtherInfo();
	initMargueeTxt();
	margueeTxtObj.string = margueeText;
	showPic();
	showPicEffect();
	showArrow();
	showMenu();
	showMenuEffect();
	if(backFocus == "picFocus") {
		zoomPicEffect(-1);	
	} else {
		zoomPicEffect(1);	
	}
	showZoomEffect();
	getXNW();
	setTimeout("getWeatherData()",3000);
	getDeliverInfo();
	
	setInterval( function() {
		switchWeather();
	}, 6000);
	setInterval( function() {
		showDate();
	}, 3000);
	if(MargueeTextSwitch != 0) setInterval('scroll();', 600);
	
	if (Utility.getEnv("VIDEO_IFRAME_CLOSED") == "") {
		Utility.ioctlWrite("CLOSE_START_VIDEO_IFRAME", ''); //关闭开机视频层iframe
		Utility.setEnv("VIDEO_IFRAME_CLOSED", "true");
	}
	
	mp = new MediaPlayer();
	mp.setVideoDisplayMode(0);
	
	//mp.setVideoFormat(18);	
	mp.setVideoDisplayArea(331, 413, 337, 251);
	mp.refreshVideoDisplay();
	setTimeout('playVideo()',300);
	//if(reloadFlagEnv == "true") doRefresh();
	canvas.refresh();
	//setTimeout("doRefresh()", 5000);
	//Utility.ioctlRead("reboot");
}

function doRefresh() {
	Utility.ioctlRead("refreshBrowser");
	Utility.setEnv("reloadFlag", "false");
	//window.location.reload();
	//canvas.refresh();
}

function getDeliverInfo() {
	var freq = sysDa.get("freq_0");
	var modul = sysDa.get("modu_0");
	var symb = sysDa.get("sysmbol_0");
	var serviceID = sysDa.get("serviceid_0");
	
	Utility.println("get from properties  "+freq+" "+modul+" "+symb+" "+serviceID);
	if (freq != "" && modul != "" && symb != "" && serviceID != "" && freq != "0" && modul != "0" && symb != "0" && serviceID != "0") {
		freq = parseInt(freq);
		freq *= 1000000;
		modul = parseInt(modul);
		switch (modul) {
		case 1:
			modul = 16;
			break;
		case 2:
			modul = 32;
			break;
		case 3:
			modul = 64;
			break;
		case 4:
			modul = 128;
			break;
		case 5:
			modul = 256;
			break;
		default :
			modul = 64;
			break;
		}
		serviceId = parseInt(serviceID);
		deliver = "deliver://" + freq + "." + symb + "." + modul + "." + serviceID;
		isNeedStop = true;
	} else {
		var curSer = ServiceDB.getServiceList().filterService(0, "TV").currentService;
		if (curSer && !curSer.lock) {
			var modulation = 16 * Math.pow(2, curSer.modulation - 1);
			deliver = "deliver://"+curSer.frequency+"000."+curSer.symbolRate+"."+modulation+"."+curSer.serviceId;
		} else {
			deliver = "deliver://443000000.6875.64.289";
			isNeedStop = true;
		}
		
		serviceId = deliver.substring(deliver.lastIndexOf(".") + 1, deliver.length);
	}
	
	Utility.println("--------------"+deliver);
	Utility.ioctlWrite("portaldeliver",deliver);

}

function inputNum(num) {
	Utility.setEnv("reloadFlag", "true");
	switch (num) {
		case 0:
			mp.setStopMode(0);
			mp.stop();
			Utility.ioctlWrite("NM_SubLevel","menuPic:"+0+",menuTitle:"+"KeyPress");
			Utility.ioctlWrite("NM_Help", "nAction:"+1);
			Utility.ioctlWrite("JsAddKeyState","N");
			window.location.href = "http://hdzchannel.jsamtv.com/epg/show.do?app=zchannel&hd=y&content=home&detail=10000&" + helpTailAddr;	
			break;
		case 1:
			var tvListLen = tvList.length;
			for (var i=0; i<tvListLen; i++) {
				if (tvList.getAt(i).serviceId == serviceId) {
					tvList.moveTo(i);
					Utility.ioctlWrite("NM_SubLevel","menuPic:"+1+",menuTitle:"+"KeyPress");
					/*mp.setVideoDisplayMode(1);
					mp.refreshVideoDisplay();
					canvas.removeAll();
					canvas.refresh();*/
					window.location.href = "play/play.htm";
				}
			}
			break;
		case 2:
			
			Utility.setEnv("picNowFocus",picNowFocus);
			Utility.setEnv("nowFocus",nowFocus);
			Utility.ioctlWrite("NM_SubLevel","menuPic:"+2+",menuTitle:"+"KeyPress");
			mp.setStopMode(0);
			mp.stop();
			window.location.href="http://hdsearch.jsamtv.com:8088/indexHD.action";
			break;
		case 3:
			if(hotImgAddrFlag) {
				Utility.setEnv("picNowFocus",picNowFocus);
				Utility.setEnv("nowFocus",nowFocus);
				Utility.ioctlWrite("NM_SubLevel","menuPic:"+3+",menuTitle:"+"KeyPress");
				mp.setStopMode(0);
				mp.stop();
		   		location.href ="http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=10-004&userCode="+userId;
		   	}
			break;
		case 5:
			if(vodSrchImgAddrFlag && isFromTerminal) {
				Utility.ioctlWrite("NM_SubLevel","menuPic:"+5+",menuTitle:"+"KeyPress");
				mp.setStopMode(0);
				mp.stop();
				location.href = vodSrchImgUrlFlag;
			}
			break;
		case 6:
			Utility.ioctlWrite("NM_SubLevel","menuPic:"+6+",menuTitle:"+"KeyPress");
			mp.setStopMode(0);
			mp.stop();
			location.href="http://hdamsp.jsamtv.com/colorskins.do";
			break;
		case 7:
			Utility.ioctlWrite("NM_SubLevel","menuPic:"+7+",menuTitle:"+"KeyPress");
			mp.setStopMode(0);
			mp.stop();
			location.href="http://hdamsp.jsamtv.com/redirect/Redirect.do?splinkid=04-009&userCode="+userId;
			break;
		case 8:
			if(VirtualNetFlag) {
				//Utility.ioctlWrite("NM_Key"," KeyName:"+ 56);
				Utility.ioctlWrite("NM_SubLevel","menuPic:"+8+",menuTitle:"+"KeyPress");
				mp.setStopMode(0);
				mp.stop();
				location.href = xnwData[0].url;
			}
			break;
			
		case 9:
			if(hlpChnlImgAddrFlag && isFromTerminal) {
				Utility.ioctlWrite("NM_SubLevel","menuPic:"+9+",menuTitle:"+"KeyPress");
				mp.setStopMode(0);
				mp.stop();
				location.href = hlpChnlImgUrlFlag;
			}
			break;
			
		default:
			break;
	}
	return;
}

function showMenu() {
	for(var i = 0; i < menuLength + 2; i++) {
		tempFocus = nowFocus - menuFocus + i;
		if(tempFocus < 0) tempFocus += menuLength;
		if(tempFocus > menuLength - 1) tempFocus -= menuLength;
		elementMenu[i] = new TextElement(menuLeft + i * menuDis, menuTop, menuWidth, menuHeight, datas[tempFocus].menuTitle);
		elementMenu[i].size = 30;
		elementMenu[0].string = "";
		if(i == menuLength + 1) elementMenu[menuLength + 1].string = "";
		if(i == menuFocus) elementMenu[i].color = 0x000000;
		else elementMenu[i].color = 0xFFFFFF;
		canvas.add(elementMenu[i]);
	}
	
	setTimeout(function(){
		if(menuLength < 10) {
			elementMenu[0].x = 58;
			elementMenu[menuLength + 1].x = 131 * (menuLength + 1);
			elementMenu[0].visible = false;
			elementMenu[menuLength + 1].string = "";
			elementMenu[menuLength + 1].visible = false;
		}
		else {
			for(var i = 9; i < menuLength + 1; i++) {
				elementMenu[0].x = 58;
				elementMenu[0].visible = false;
				elementMenu[i + 1].x = 131 * (i + 1);
				elementMenu[i + 1].visible = false;			
			}
		}
	},1);
}

function showArrow() {
	lArrow = new ImageElement(60, 151, 38, 38, "images/larrow.png");
	canvas.add(lArrow);
	if(menuLength < 10) {
		rArrow = new ImageElement(111 * (menuLength + 1) + 62, 151, 38, 38, "images/rarrow.png");
		canvas.add(rArrow);	
	} else {
		rArrow = new ImageElement(1188, 151, 38, 38, "images/rarrow.png");
		canvas.add(rArrow);	
	}
	menuFocusImage = new ImageElement(117, 145, 106, 46, "images/menuFocus.png");
	canvas.add(menuFocusImage);
}

function showMenuEffect() {
	for(var i = 1; i < menuLength + 2; i++) {
		 menuRightEff[i] = new Effect("move",elementMenu[i-1].x,elementMenu[i-1].y,elementMenu[i].x,elementMenu[i].y,menuTime,menuCount);
	}
	
	for(var i = 0;i < menuLength + 1; i++) {
		 menuLeftEff[i] = new Effect("move",elementMenu[i+1].x,elementMenu[i+1].y,elementMenu[i].x,elementMenu[i].y,menuTime,menuCount);	
	}
}

var mainMenuTimer = -1;
function refreshMenu() {
	clearTimeout(mainMenuTimer);
	mainMenuTimer = setTimeout(function () {
		for(i = 0; i < picLength + 2; i++) {
			canvas.remove(elementPic[i]);
		}
		picLength = datas[nowFocus].menuPic.length;
		picNowFocus = 1;
		picTempFocus = 0;
		showPic();
		showPicEffect();
		canvas.refresh();
	}, 800);
	var tempFocus;
	for(var i = 0; i < menuLength + 2; i++) {
		tempFocus = nowFocus - menuFocus + i;
		if(tempFocus < 0) tempFocus += menuLength;
		if(tempFocus > menuLength - 1) tempFocus -= menuLength;
		if(i == menuFocus) elementMenu[i].color = 0x000000;
		else elementMenu[i].color = 0xFFFFFF;
		elementMenu[i].string = datas[tempFocus].menuTitle;
		elementMenu[0].string = "";
		if(i > 8) {
			elementMenu[i + 1].string = "";
			elementMenu[i + 1].visible = false;
		}
	}

	if(menuLength < 10) {
		elementMenu[0].x = 58;
		elementMenu[menuLength + 1].x = 111 * (menuLength + 1);
		elementMenu[0].visible = false;
		elementMenu[menuLength + 1].string = "";
		elementMenu[menuLength + 1].visible = false;
	}
	else {
		for(var i = 9; i < menuLength + 1; i++) {
			elementMenu[0].x = 58;
			elementMenu[0].visible = false;
			elementMenu[i + 1].x = 131 * (i + 1);
			elementMenu[i + 1].visible = false;			
		}
	}
}

var subMenuTimer = -1;
function doMenuEffect(type) {
	picNowFocus = 1;
	nowFocus += type;
	if(nowFocus > menuLength - 1) nowFocus = 0;
	else if(nowFocus < 0) nowFocus = menuLength - 1;
	refreshMenu();
	if(type == -1) {
		control.beginParallel();
		for(var i = 1; i < menuLength + 2; i++) {
			elementMenu[i].setEffect(menuRightEff[i]);	
			elementMenu[i].doEffect();
			clearTimeout(subMenuTimer);
			subMenuTimer = setTimeout(function () {
				elementPic[i].setEffect(picRightEff[i]);	
				elementPic[i].doEffect();
			}, 800);
		}
		control.endParallel();
	}
	else if(type == 1) {
		control.beginParallel();
		for(var i = 0; i < menuLength + 1; i++) {
			elementMenu[i].setEffect(menuLeftEff[i]);
			elementMenu[i].doEffect();
			clearTimeout(subMenuTimer);
			subMenuTimer = setTimeout(function () {
				elementPic[i].setEffect(picLeftEff[i]);	
				elementPic[i].doEffect();
			}, 800);
		}
		control.endParallel();
	}
	canvas.refresh();
}

function showPic() {
	for(var i = 0; i < picLength + 2; i++) {
		picTempFocus = picNowFocus - picFocus + i;
		if(picTempFocus < 0) picTempFocus += picLength;
		if(picTempFocus > picLength - 1) picTempFocus -= picLength;
		if (zoomFlag && i == 1) {
			picTempFocus++;
		} else {
			elementPic[i] = new ImageElement(-100 + i * 200, 230, 195,140, datas[nowFocus].menuPic[picTempFocus].pic);
		}
		canvas.add(elementPic[i]);
	}
	if(picLength < 6) {
		elementPic[0].x = -200;
		elementPic[picLength + 1].x = (picLength + 1)* 200;
		elementPic[0].visible = false;
		elementPic[picLength + 1].visible = false;
	} else {
		for(var i = 6; i < picLength + 1; i++) {
			elementPic[0].x = -200;	
			elementPic[0].visible = false;
			elementPic[i + 1].x = 1280 * (i + 1);
			elementPic[i + 1].visible = false;
		}
	}
}

function showPicEffect() {
	for(var i = 1; i < picLength + 2; i++) {
		if(i == 1) picRightEff[i] = new Effect("zoom", -200, 230, 195, 140, 40, 213, 244, 175, menuTime,menuCount);
		else if(i == 2) picRightEff[i] = new Effect("zoom", 40, 213, 244, 175, 299, 230, 195, 140, menuTime,menuCount);
		else picRightEff[i] = new Effect("move",elementPic[i-1].x,elementPic[i-1].y,elementPic[i].x,elementPic[i].y, menuTime,menuCount);
	}
	
	for(var i = 0; i < picLength + 1; i++) {
		if(i == 1) picLeftEff[i] = new Effect("zoom",299, 230, 195, 140, 40, 213, 244, 175, menuTime,menuCount);
		else if(i == 0) picLeftEff[i] = new Effect("zoom", 40, 213, 244, 175, -200, 230, 195, 140, menuTime,menuCount);
		else picLeftEff[i] = new Effect("move",elementPic[i+1].x,elementPic[i+1].y,elementPic[i].x,elementPic[i].y, menuTime,menuCount);
	}
}

function doPicEffect(type) {
	picNowFocus += type;
	if(picNowFocus > picLength - 1) picNowFocus = 0;
	else if(picNowFocus < 0) picNowFocus = picLength - 1;
	refreshPic();
	if(type == -1) {
		control.beginParallel();
		for(var i = 0; i < picLength + 1; i++) {
			elementPic[i].setEffect(picRightEff[i]);
			elementPic[i].doEffect();
		}
		control.endParallel();
	}
	else if(type == 1) {
		control.beginParallel();
		for(var i = 0; i < picLength + 1; i++) {
			elementPic[i].setEffect(picLeftEff[i]);
			elementPic[i].doEffect();
		}
		control.endParallel();	
	}
	canvas.refresh();
}

function refreshPic() {
	for(var i = 0; i < picLength + 2; i++) {
		picTempFocus = picNowFocus - picFocus + i;
		if(picTempFocus < 0) picTempFocus += picLength;
		if(picTempFocus > picLength - 1) picTempFocus -= picLength;
		if(i==1) elementPic[i].image = datas[nowFocus].menuPic[picTempFocus].focusPic;
		else elementPic[i].image = datas[nowFocus].menuPic[picTempFocus].pic;
	}
	if(picLength < 6) {
		elementPic[0].x = -200;
		elementPic[picLength + 1].x = (picLength + 1)* 200;
		elementPic[0].visible = false;
		elementPic[picLength + 1].visible = false;
	} else {
		for(var i = 6; i < picLength + 1; i++) {
			elementPic[0].x = -200;	
			elementPic[0].visible = false;
			elementPic[i + 1].x = 1280 * (i + 1);
			elementPic[i + 1].visible = false;
		}	
	}
}

function showZoomEffect() {
	picZoomEff[1] = new Effect("zoom", 100, 230, 195, 140, 40, 213, 244, 175, menuTime,menuCount);
	
	picZoomEff2[1] = new Effect("zoom", 40, 213, 244, 175, 100, 230, 195, 140, menuTime,menuCount);	
}

function zoomPicEffect(type) {
	if(type == -1) {
		zoomFlag = true;
		menuFocusImage.image = "images/menuBlur.png";
		setTimeout(function(){
			lArrow.visible = false;
			rArrow.visible = false;
		},1);
		elementMenu[1].color = 0xf1e800;
		elementPic[1].image = datas[nowFocus].menuPic[picTempFocus].focusPic;
		elementPic[1].setEffect(picZoomEff[1]);
		elementPic[1].x = 40;
		elementPic[1].y = 213;
		elementPic[1].width = 244;
		elementPic[1].height = 175;
	}
	else if(type == 1) {
		zoomFlag = false;
		menuFocusImage.image = "images/menuFocus.png";
		setTimeout(function(){
			lArrow.visible = true;
			rArrow.visible = true;
		},1);
		elementMenu[1].color = 0x000000;
		elementPic[1].image = datas[nowFocus].menuPic[picTempFocus].pic;
		elementPic[1].setEffect(picZoomEff2[1]);
		elementPic[1].x = 100;
		elementPic[1].y = 230;
		elementPic[1].width = 195;
		elementPic[1].height = 140;
	}
	//canvas.refresh();
}

function backToPortal() {
	zoomFlag = true;
	menuFocusImage.image = "images/menuBlur.png";
	lArrow.visible = false;
	rArrow.visible = false;
	elementMenu[2].color = 0xf1e800;
	elementPic[1].image = datas[nowFocus].menuPic[picTempFocus].focusPic;
	elementPic[1].x = 40;
	elementPic[1].y = 213;
	elementPic[1].width = 244;
	elementPic[1].height = 175;
}

var urlPos = 0;
function doEnter() {
	if(nowFocus != 1) {
		Utility.setEnv("reloadFlag", "true");
	}
	urlPos = picNowFocus - 1;
	if(urlPos < 0) urlPos = picLength - 1;
	else if(urlPos > picLength - 1) urlPos = 0;
	if (!zoomFlag) return;

	if (userId == "") {
		getDatas();
	}
	var forwardUrl = datas[nowFocus].menuPic[urlPos].url;
	Utility.setEnv("backFocus","picFocus");
	if (forwardUrl != "") {
		Utility.setEnv("picNowFocus",picNowFocus);
		Utility.setEnv("nowFocus",nowFocus);
		mp.setStopMode(0);
		mp.setVideoDisplayMode(1);
		mp.refreshVideoDisplay();
		mp.stop();
		var mainMenuTitle = datas[nowFocus].menuTitle;
		var subMenuNum = urlPos + 1;
		if(nowFocus != 1)
		{
			Utility.ioctlWrite("NM_SubLevel","menuPic:"+subMenuNum+",menuTitle:"+mainMenuTitle);
		}
		else
		{
			if(subMenuNum == 6 )
			{
				Utility.ioctlWrite("NM_SubLevel","menuPic:"+subMenuNum+",menuTitle:"+mainMenuTitle);
			}			
		}
		
		if (nowFocus != 2 && nowFocus != 1) {
			SysSetting.panelDisplayText(" IP ");
		}
		if (nowFocus == 2) {
			Utility.ioctlWrite("JsAddKeyState","N");
			SysSetting.panelDisplayText(" Vod");
		} else if (nowFocus == 0) {
		}
		Utility.setBrwMuteLogo(true);
		
		window.location.href = forwardUrl;
		canvas.refresh();
	}
}

function leftPadStr(str, padding, length){
	str = str.toString();
	var s = str;
	
	for (var i = 0; i < length - str.length; i++) {
		s = padding + s;
	}
	return s;
}

function showDate() {
	var tempDate = new Date();
	var displayTime = leftPadStr(tempDate.getHours(), "0", 2) + ":" + leftPadStr(tempDate.getMinutes(), "0", 2);
	var displayDate = tempDate.getFullYear() + "-" + leftPadStr((tempDate.getMonth() + 1), "0", 2) + "-" + leftPadStr(tempDate.getDate(), "0", 2);

	timeObj.string = displayTime;
	dateObj.string = displayDate;
}

var posBox;


function showOtherInfo() {
	var tempDate = new Date();
	var displayTime = leftPadStr(tempDate.getHours(), "0", 2) + ":" + leftPadStr(tempDate.getMinutes(), "0", 2);
	var displayDate = tempDate.getFullYear() + "-" + leftPadStr((tempDate.getMonth() + 1), "0", 2) + "-" + leftPadStr(tempDate.getDate(), "0", 2);

	timeObj = new TextElement(795, 55, 135, 30, displayTime);
	timeObj.color = 0x000000;
	timeObj.size = 26;
	timeObj.type = "right";
	canvas.add(timeObj);
	
	posBox = new ImageElement(957, 541, 220, 130, "");
	canvas.add(posBox);
	
	dateObj = new TextElement(795, 84, 135, 30, displayDate);
	dateObj.color = 0x000000;
	dateObj.size = 26;
	dateObj.type = "right";
	canvas.add(dateObj);
}
var isNeedStop = false;
function playVideo(){
	if (volumeMode == 0) {
		var curSer = ServiceDB.getServiceList().filterService(0, "TV").currentService;
		if (curSer) {
			mp.setVolume(curSer.volume);
		} else {
			mp.setVolume(16);
		}
	} else {
		mp.setVolume(uniformVolume);
	}
	
	Utility.println('=============currentService.volume===================:' + curSer.volume);
	
	var isAuthorized = sysDa.get("Mediaplayer.isAuthorized") != "" ? parseInt(sysDa.get("Mediaplayer.isAuthorized")) : 1;
	if (isAuthorized == 0) {
		deliver = "deliver://443000000.6875.64.289";
		serviceId = 289;
		isNeedStop = true;
	}
	mp.setSingleMedia(deliver);
	mp.playFromStart();
}

function getParams(url){
	var queryString = url.substr(url.indexOf("?") + 1);
	if (queryString == "") return;
	var requests = [];
	var params = queryString.split("&");
	for (var i = 0; i < params.length; i++) {
		var temp = params[i].split("=");
		if (temp.length < 2) return;
		requests[temp[0]] = temp[1];
	}
	if (params.length == 0) {
		var temp = queryString.split("=");
		if (temp.length < 2) return;
		requests[temp[0]] = temp[1];
	}
	return requests;
}

//音量
function changeVolume(_type) {
	var volume = mp.getVolume();
	volume += _type;
	if (volume > 31) {
		volume = 31;
	} else if (volume < 0) {
		volume = 0;
	}
	if (volumeMode == 1) {
		sysDa.set("UniformVolume", volume);
	}else {
		var curSer = ServiceDB.getServiceList().filterService(0, "TV").currentService;
		curSer.volume = volume;
	}
	mp.setVolume(volume);
	if (mp.getMuteFlag() == 1) {
		mp.setMuteFlag(0);
	}
}

function setMute() {
	var muteStatus = mp.getMuteFlag();
	muteStatus = muteStatus == 0 ? 1 : 0;
	mp.setMuteFlag(muteStatus);
}

function exitPage() {
	Utility.ioctlWrite("NM_Portal", "nAction:" + 0);
	DVB.clearShowEvent();
}

//对接SDP数据
function ajaxUrl(url, handler) {
	var xmlhttp;
	if (window.XMLHttpRequest) {
		xmlHttp = new XMLHttpRequest();
		if (xmlHttp.overrideMimeType) {
			xmlHttp.overrideMimeType("text/xml");
		}
	} else {
		if (window.ActiveXObject) {
			xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}
	xmlHttp.onreadystatechange = function () {
		if (xmlHttp.readyState == 4) {
		   if (xmlHttp.status == 200) {
				eval(handler+"(xmlHttp)");
			}else{
			//alert("请求超时")
				if(handler == 'setMenuData'){
					VirtualNetFlag = false;
				}
			}
		}
	};
	xmlHttp.open("GET", url, true);
	xmlHttp.send(null);
}

//虚拟网
function getXNW(){
	if (cardOUTENV != "true") {
		var userId=Utility.getSystemInfo("UID");
		var url ="http://hdamsp.jsamtv.com/T-nsp/Virtual.do?svstype=getVirtualNetwork&serviceCode=hl_xnw&userId=" + userId;
		ajaxUrl(url,'setMenuData');
	}
}

var xnwData;
var VirtualNet = new ImageElement(707, 616, 225, 55, "");
canvas.add(VirtualNet);
function setMenuData(xmlHttp){
	var resText = xmlHttp.responseText;
	//resText = resText.replace(/name:/g,"menuTitle:").replace(/generalLogo:/g,"pic:").replace(/focusLogo:/g,"focusPic:").replace(/list:/g,"menuPic:"); 
	xnwData = eval(resText);
	
	if(xnwData.length > 0){
		VirtualNetFlag = true;
		VirtualNet.image = xnwData[0].imageList[0].imageUrl;
	} else {
		VirtualNet.image = "";
	}
}

//天气
var weatherData;
function getWeatherData(){
	var url ="http://hdamsp.jsamtv.com/weather/weatherAction!getWeather.do";
	ajaxUrl(url,'showWeather');
 }

function showWeather(xmlHttp){
	var resText = xmlHttp.responseText;
	weatherData =eval(resText);
	if(weatherData){
		initWeather();
	}
	
	if(hotImgAddrFlag) showHotRecom();

}

function showHotRecom() {
	var url ='http://hdamsp.jsamtv.com/businessrecommend/businessRecommendAction!getRecommend.do';
	ajaxUrl(url,'showRecommend');		
}

function showZeroTwoSix() {
	var chnlHlpUrl = 'url1';
	ajaxUrl(chnlHlpUrl,'enterZero');	
}

var recomData;

function enterZero(xmlHttp){
	var resText = xmlHttp.responseText;
	recomData =eval('['+resText+']');
	if(recomData){
		posBox.image='http://hdamsp.jsamtv.com'+recomData[0].logo;
		canvas.refresh();
	}
}

function showRecommend(xmlHttp){
	var resText = xmlHttp.responseText;
	recomData =eval('['+resText+']');
	if(recomData){
		posBox.image='http://hdamsp.jsamtv.com'+recomData[0].logo;
		canvas.refresh();
	}
}

function initWeather(){
	for (var i=0;i<weatherData.length;i++){
		weather_container[i] = new Container(930,41,280,100);
		weatherImg[i] = new ImageElement(10,0,85,85,"");
		city[i] = new TextElement(80,36,80,35,"");
		city[i].color="0x00000000";
		city[i].size=26;
		temperature[i] = new TextElement(140,20,120,35,"");
		temperature[i].color="0x00000000";
		temperature[i].size=22;
		description[i] = new TextElement(140,52,120,20,"");
		description[i].color="0x00000000";
		description[i].size=18;
		description_1[i] = new TextElement(140,72,120,20,"");
		description_1[i].color="0x00000000";
		description_1[i].size=18;
		weather_container[i].add(weatherImg[i]);
		weather_container[i].add(city[i]);
		weather_container[i].add(temperature[i]);
		weather_container[i].add(description[i]);
		weather_container[i].add(description_1[i]);
	}
	for (var i=0;i<weatherData.length;i++){
		weather_container[i].visible = false;
		canvas.add(weather_container[i]);
		weatherImg[i].image = weatherData[i].image;
		city[i].string=weatherData[i].city;
		description[i].string = weatherData[i].des.substring(0,5);
		description_1[i].string = weatherData[i].des.substring(5,10);
		temperature[i].string = weatherData[i].temperature;
	}
	weather_container[0].visible = true;
}


function switchWeather(){ 
	if(wFlag == weatherLength -1){
		weather_container[wFlag].setEffect(effect_weather_1);
		weather_container[0].setEffect(effect_weather_2);
		control2.beginParallel();
		weather_container[wFlag].doEffect();
		weather_container[0].doEffect();
		control2.endParallel();
		wFlag = 0;
		return;
	}else{
		weather_container[wFlag].setEffect(effect_weather_1);
		weather_container[wFlag+1].setEffect(effect_weather_2);
		control2.beginParallel();
		weather_container[wFlag].doEffect();
		weather_container[wFlag+1].doEffect();
		control2.endParallel();
	}
	wFlag++;
}

//跑马灯
var width;
function initMargueeTxt() {
	margueeCon = new Container(330, 70, 450, 48);

	if(MargueeTextFontSize == "") MargueeTextFontSize = 24;
	else MargueeTextFontSize = CITV.getParamInfo("MargueeTextFontSize"); 
	width = margueeText.length * MargueeTextFontSize; //24是经验值，每个字所占的最大宽度
	if(width <= 450) {
		width = 450;	
	}
	else {
		width = width > 7200 ? 7200 : width;
	}
	margueeTxtObj = new TextElement(0, 0, width, 48, "");
	margueeTxtObj.color = 0xffffffff;
	margueeTxtObj.size = MargueeTextFontSize;
	margueeTxtObj.type = "center";
	margueeCon.add(margueeTxtObj);
	canvas.add(margueeCon);
}

function scroll() {
	if ((margueeTxtObj.x + width) < 80) {
		margueeTxtObj.x = 440;
	} else {
		margueeTxtObj.x -= 30;
	}
	canvas.refresh();
}