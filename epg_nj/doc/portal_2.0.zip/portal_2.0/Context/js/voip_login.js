
var voipDa = new DataAccess("voipconfig.properties");

function voipAjaxUrl(url, handler) {
	var xmlhttp;
	if (window.XMLHttpRequest) {
		xmlHttp = new XMLHttpRequest();
		if (xmlHttp.overrideMimeType) {
			xmlHttp.overrideMimeType("text/xml");
		}
	}
	xmlHttp.onreadystatechange = function () {
		if (xmlHttp.readyState == 4) {
			if (xmlHttp.status == 200) {
				eval(handler+"(xmlHttp)");
			}
		}
	};
	xmlHttp.open("GET", url, true);
	xmlHttp.send(null);
}
function getVoipLoginInfo(){
	var scId = CA.serialNumber;
	var stbId = SysInfo.STBSerialNumber;
	var stbType = SysInfo.STBType;
	var url ="http://172.31.178.6:18080/aaa/imsAuth?setTopBoxId="+stbId+"&smartCardId="+scId+"&stbType="+stbType;
	voipAjaxUrl(url,'setVoipLoginInfo');
}

function setVoipLoginInfo(xmlHttp){
	var resText = xmlHttp.responseText;
	var loginInfo = eval("("+resText+")");
	Utility.println("ajax data come");
	Utility.println("voip login info resText = "+resText);
	if(loginInfo){
		phoneNumbe = loginInfo.iMSNumber;
		phoneNumbe += "";
		Utility.println("phoneNumbe = "+phoneNumbe);
		if (phoneNumbe && phoneNumbe.length >= 11 && phoneNumbe[0] == '8' && phoneNumbe[1] == '6') {
			phoneNumbe = '+' + phoneNumbe;
		}
		Utility.println("phoneNumbe after = "+phoneNumbe);
		password = loginInfo.userPassword;
		voipResultCode = loginInfo.resultCode;
	}
	clearTimeout(getVoipLoginInfoTimer);
	doVoipLogin();
}
var getVoipLoginInfoTimer;
function voipLogin() {
	getVoipLoginInfo();
	getVoipLoginInfoTimer = setTimeout("doVoipLogin()", 5000);
}
var phoneNumbe = "";
var password = "";
var voipResultCode = 0;
var jumpPageTimer;
function doVoipLogin() {
	var loginType = voipDa.get("login_type"); //0:使用电话号码登陆; 1:使用IP地址登陆
	var ipAddress = voipDa.get("login_ip");//登陆IP地址
	
	if (phoneNumbe) {
		voipDa.set("login_phonenum", phoneNumbe);
		voipDa.set("login_pwd", password);
	}
k
	Utility.println("voip login infos: "+loginType+":"+phoneNumbe+":"+password+":"+ipAddress);
	Utility.println("voipResultCode = "+voipResultCode);
	
	if (loginType == 0 && phoneNumbe && phoneNumbe != "") {
		VideoPhone.login(phoneNumbe, password);
		jumpPageTimer = setTimeout("jumpPage()", 3000);
	} else if (loginType == 1 && ipAddress && ipAddress != "") {
		VideoPhone.loginip(ipAddress);
		jumpPageTimer = setTimeout("jumpPage()", 3000);
	} else {
		jumpPage();
	}
}