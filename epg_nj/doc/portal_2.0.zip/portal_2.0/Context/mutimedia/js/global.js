
var $ = function(id){
	var o = document.getElementById(id);
	return o;
};
var $G = {};
(function(){
	/**
	 * DataAccess对象
	 * @type Object
	 */
	var sysDa = new DataAccess("Systemsetting.properties");
	var netDa = new DataAccess("NetworkConfig.properties");
	var envDa = new DataAccess("env.properties");
	
	var DEBUG_MODE = true;
	
	/**
	 * 是否阻止当前按键的默认处理
	 * @type Boolean
	 */
	var isKeyPrevent = true;
	var root = Utility.getEnv("ROOT_PATH");
	function debug(){
		if (!DEBUG_MODE) {
			return;
		}
		
		if (arguments.length == 1) {
			var value = arguments[0];
			Utility.println("[JS_DEBUG]" + value);
		} else {
			var name = arguments[0];
			var value = arguments[1];
			Utility.println("[JS_DEBUG]" + name + " : " + value);
		}
	}
	
	function extend(destination, source){
		for (var property in source) {
			destination[property] = source[property];
		}
		return destination;
	}
	function eventListener(){
		var keyCode = event.which || event.keyCode;
		isKeyPrevent = true;
		var messageId = event.userInt;
		Utility.println("keyCode = "+keyCode);
		if (65535 == keyCode) DVB.standbyMode(1);
		var code = ""; //转换后的按键字符串
		var param = 0; //按键事件所带参数
		if (keyCode >= 48 && keyCode <= 57) {
			code = "KEY_NUMERIC";
			param = keyCode - 48;
		} else {
			switch (keyCode) {
				case 1:
				case 38: //上键
					code = "KEY_UP";
					break;
				case 2:
				case 40: //下键
					code = "KEY_DOWN";
					break;
				case 3:
				case 37: //左键
					code = "KEY_LEFT";
					break;
				case 4:
				case 39: //右键
					code = "KEY_RIGHT";
					break;
				case 120://江苏翻页键
				case 372:
				case 33: //上翻页
					code = "KEY_PAGE_UP";
					break;
				case 121://江苏翻页键
				case 373:
				case 34: //下翻页
					code = "KEY_PAGE_DOWN";
					break;
				case 447: //音量加
				case 595:
					code = "KEY_VOLUME_UP";
					break;
				case 448: //音量减
				case 596:
					code = "KEY_VOLUME_DOWN";
					break;
				case 449: //静音
				case 597:
					code = "KEY_MUTE";
					event.preventDefault();
					break;
				case 427:
					code = "KEY_CHANNEL_UP";
					break;
				case 428:
					code = "KEY_CHANNEL_DOWN";
					break;
				case 407://声道键
				case 598:
					code = "KEY_AUDIO";
					break;
				case 564:
					code = "KEY_TV_RADIO";
					break;
				case 340:
				case 640://返回键
					code = "KEY_BACK";
					break;
				case 339: //退出键
				case 27:
				case 114:
					code = "KEY_EXIT";
					break;
				case 13: //确定键
					code = "KEY_ENTER";
					break;
				case 403: //红键
				case 832:
				case 96:
					code = "KEY_RED";
					break;
				case 405: //黄键
				case 834:
				case 97:
					code = "KEY_YELLOW";
					break;
				case 406: //蓝键
				case 835:
				case 98:
					code = "KEY_BLUE";
					break;
				case 404: //绿键
				case 833:
				case 99:
					code = "KEY_GREEN";
					break;
				case 514:
					code = "TV_GUIDE"//导视键
					break;
				case 113:
				case 468://菜单键
				case 513:
					code = "KEY_MENU";
					window.location.href = Utility.getEnv("ROOT_PATH") + "index.htm";
					break;
				case 116: //键盘上F5键，作用是页面刷新，用于开发
					window.location.reload();
					break;
				case 427: //频道加
					code = "KEY_CHANNEL_UP";
					break;
				case 428: //频道减
					code = "KEY_CHANNEL_DOWN";
					break;
				//case 457: //信息键
				case 42:
					code = "KEY_INFO";
					break;
				case 458: //节目指南键
					code = "KEY_EPG";
					doEpg();
					break;
				case 3873://快退
					code = "KEY_RW";
					break;
				case 3874://快进
					code = "KEY_FF";
					break;
				case 3864: //暂停/播放
					code = "KEY_ENTER_PAUSE";
					break;
				case 40200:
					code = "MP3_PLAY_END";
					break;
				/*********节目预定部分*************/
				case 40051: //预定提前提醒
					code = "DVB_ORDER_PRE_REMIND";
					showOrderReminder();
					break;
				case 40052: //预定节目到期
					code = "DVB_ORDER_REMIND";
					openOrderedProgram();
					break;
				case 40053: //预定节目播放完毕
					code = "DVB_ORDER_PLAY_END";
					break;
				case 40054: //预定节目已经过期
					code = "DVB_ORDER_EXPIRE";
					break;
				case 40055: //预定节目数据改变
					code = "DVB_ORDER_UPDATED";
					break;
					
				/*********网络部分*************/
				case 40090: //IP地址更新
					code = "DVB_IP_UPDATED";
					break;
				case 40091: //网络链接成功
					code = "DVB_IP_CONNECT_SUCCESS";
					break;
				case 40092: //网络断开
					code = "DVB_IP_CONNECT_FAILED";
					break;
				case 40093: //cm在线
					code = "DVB_CM_ON_LINE";
					break;
				case 40094: //cm离线
					code = "DVB_CM_OFF_LINE";
					break;
					
				/*********提示信息部分*************/
				case 41000: //提示信息显示
					code = "DVB_SHOW_INFO";
					break;
				case 41001: //提示信息隐藏
					code = "DVB_HIDE_INFO";
				case 40220:
					code = "USB_DEVICE_INSERTED";
					showCAGlobalTips($GL.USB_DEVICE_INSERTED, 0);
					break;
				case 40221:
					code = "USB_DEVICE_EVULSION";
					showCAGlobalTips($GL.USB_DEVICE_EVULSION, 0);
					break;
				case 40209:
					code = "MEDIA_SHOW_SUBTITLE";
					break;
				case 40210:
					code = "MEDIA_CLEAR_SUBTITLE";
					break;
				case 482://"电视/广播"键
					code = "TV_RADIO";
					break;
				case 457://"频道"键
				case 573:
					code = "CHANNEL";
					break;
				default:
					debug("Unkown key " + keyCode);
					this.isKeyPrevent = false;
					break;
			}
			param = keyCode;
			debug("eventStr", code);
		}
		if (isKeyPrevent) {
			event.preventDefault();
		}
		if (orderReminder && orderReminder.isVisible) {
			var returnFlag = window.order_reminder.eventHandler({
				"code": code,
				"param": param,
				"messageId": messageId
			});
			if (!returnFlag) return;
		}
		
		if (typeof eventHandler != "undefined") {
			eventHandler({
				"code": code,
				"param": param,
				"messageId": messageId
			});
		}
	}
	function dateFormat(d, formatter){
		if (!formatter || formatter == "") {
			formatter = "yyyy-MM-dd";
		}
		
		var weekdays = [["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"], ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]];
		
		var year = (d.getFullYear()).toString();
		var month = (d.getMonth() + 1).toString();
		var date = d.getDate().toString();
		var day = d.getDay();
		var hour = d.getHours().toString();
		var minute = d.getMinutes().toString();
		var second = d.getSeconds().toString();
		
		var yearMarker = formatter.replace(/[^y|Y]/g, '');
		if (yearMarker.length == 2) {
			year = year.substring(2, 4);
		} else if (yearMarker.length == 0) {
			year = "";
		}
		
		var monthMarker = formatter.replace(/[^M]/g, '');
		if (monthMarker.length > 1) {
			if (month.length == 1) {
				month = "0" + month;
			}
		} else if (monthMarker.length == 0) {
			month = "";
		}
		
		var dateMarker = formatter.replace(/[^d]/g, '');
		if (dateMarker.length > 1) {
			if (date.length == 1) {
				date = "0" + date;
			}
		} else if (dateMarker.length == 0) {
			date = "";
		}
		
		var hourMarker = formatter.replace(/[^h]/g, '');
		if (hourMarker.length > 1) {
			if (hour.length == 1) {
				hour = "0" + hour;
			}
		} else if (hourMarker.length == 0) {
			hour = "";
		}
		
		var minuteMarker = formatter.replace(/[^m]/g, '');
		if (minuteMarker.length > 1) {
			if (minute.length == 1) {
				minute = "0" + minute;
			}
		} else if (minuteMarker.length == 0) {
			minute = "";
		}
		
		var secondMarker = formatter.replace(/[^s]/g, '');
		if (secondMarker.length > 1) {
			if (second.length == 1) {
				second = "0" + second;
			}
		} else if (secondMarker.length == 0) {
			second = "";
		}
		
		var dayMarker = formatter.replace(/[^w]/g, '');
		var weekDay = "";
		if (dayMarker.length > 0) weekDay = weekdays[0][day];
		var dateStr = formatter.replace(yearMarker, year).replace(monthMarker, month).replace(dateMarker, date).replace(hourMarker, hour).replace(minuteMarker, minute).replace(secondMarker, second).replace(dayMarker, weekDay);
		return dateStr;
	}
	
	function getDate(offset){
		var d = new Date();
		d.setDate(d.getDate() + offset);
		return d;
	}
	function leftPadStr(str, padding, length){
		str = str.toString();
		var s = str;
		
		for (var i = 0; i < length - str.length; i++) {
			s = padding + s;
		}
		return s;
	}
	
	function exitToPlay(){
		var serviceList = ServiceDB.getServiceList().filterService(4, false);
		var service = serviceList.currentService;
		if (service && service.type == DVB.SERVICE_TYPE_RADIO) {
			window.location.href = Utility.getEnv("ROOT_PATH") + "play/radio.htm";
		} else {
			window.location.href = Utility.getEnv("ROOT_PATH") + "play/play.htm";
		}
	}
	
	function exitToMenu(){
		if (typeof mp != "undefined") {
			var player = new MediaPlayer();
			player.stop();
		}
		window.location.href = Utility.getEnv("ROOT_PATH") + "index.htm";
	}
	
	extend($G, {
		extend: extend,
		sysDa: sysDa,
		netDa: netDa,
		envDa: envDa,
		root: root,
		isKeyPrevent: isKeyPrevent,
		eventListener: eventListener,
		dateFormat: dateFormat,
		getDate: getDate,
		debug: debug,
		leftPadStr: leftPadStr,
		exitToMenu: exitToMenu,
		exitToPlay: exitToPlay
	});
})();

(function(){
	document.onkeypress = $G.eventListener;
	window.addEventListener("load", function(){
		if (typeof init != "undefined") {
			init();
		}
	}, false);
	
	window.addEventListener("unload", function(){
		if (typeof exitPage != "undefined") {
			exitPage();
		}
	}, false);
})();
var $L = function(){
}

$L.extend = $L.prototype.extend = function(){
	for (var xx in arguments[0]) {
		this[xx] = arguments[0][xx];
	}
}
$L.extend({
	/**
	 * 多语言资源文件初始化
	 * @param {String} _moduleId 模块名称（注：与语言资源文件的前缀名称相同，不传则默认为'i18n'）
	 */
	init: function(_moduleId){
		if (!Boolean(_moduleId)) {
			_moduleId = 'i18n';//default value
		}
		this.moduleId = _moduleId;
		this.createScriptTag("js/" + _moduleId + "_" + this.getAreaCode() + ".js", "__moduleLanguageResources");//加载模块语言资源文件
	},
	/**
	 * UI模块ID(即模块文件夹名称)，如epg
	 */
	moduleId: "",
	/**
	 * 切换语言
	 * @param {String} _areaCode 语系和地区码的组合（注，该参数必须存在有相应的语言资源文件）
	 * @param {Number} _changeType 变更语言方式（注：该参数为0时，设置语言后，重新加载页面；为1时，设置语言后，调用initLanguage()重新初始化页面，不重新加载页面；为其它值时，只设置语言，不做其它动作）
	 */
	change: function(_areaCode, _changeType){
		if (typeof(_areaCode) != 'undefined') this.setAreaCode(_areaCode);
		else 			
			return;
		if (_changeType == 0) {
			window.location.reload();
		} else if (_changeType == 1) {
			var resourcesNode, globalResourcesNode;
			if (globalResourcesNode = document.getElementById('__globalLanguageResources')) {
				globalResourcesNode.parentNode.removeChild(globalResourcesNode);
				this.createScriptTag(Utility.getEnv("ROOT_PATH") + "js/global_" + _areaCode + ".js", "__globalLanguageResources"); //重新加载全局语言资源文件
			}
			if (resourcesNode = document.getElementById('__moduleLanguageResources')) {
				resourcesNode.parentNode.removeChild(resourcesNode);
			}
			this.createScriptTag("js/" + this.moduleId + "_" + _areaCode + ".js", "__moduleLanguageResources", this.initLanguage);//重新加载模块语言资源文件
		}
	},
	/**
	 * 初始化页面所有与语言有关的函数
	 */
	initLanguage: function(){
	
	},
	/**
	 * 情况一：所以参数不为空时。对同一前缀名为_prev的ID、并且在语言资源文件里存在同名的Key，从_begin至_end逐一执行innerText。
	 * 情况二：当_end参数为空时。则仅为ID为_prev+_begin的单个元素执行innerText。
	 * 注：该函数必须要求页面ID与语言资源文件里的KEY相对应。
	 * @param {String} _prev ID前缀
	 * @param {Number} _begin 起始Index
	 * @param {Number} _end 终止Index （注：该参数可为空）
	 */
	inner: function(_prev, _begin, _end){
		if (typeof(_end) == 'undefined') _end = _begin;
		for (var ii = _begin; ii <= _end; ii++) {
			try {
				document.getElementById(_prev + ii).innerText = $L[_prev + ii];
			} 
			catch (e) {
				Utility.println("[MultiLanguage Error] - " + e.message);
			}
		}
	},
	/**
	 * 获取多语言标识，语系和地区码的组合
	 * 注：与sys.ini文件中的languangeString参数值相关
	 */
	getAreaCode: function(){
		var areaCode = (new DataAccess("Systemsetting.properties")).get("languangeString");
		var languageMapping = {
			language_chi: "zh-cn",
			language_eng: "en-us"
		};//languangeString参数值映射数组
		if (!Boolean(areaCode) || !(areaCode = languageMapping[areaCode])) {
			areaCode = 'zh-cn';
		}
		return areaCode;
	},
	/**
	 * 设置多语言标识
	 * @param {String} _areaCode 语系和地区码的组合
	 * 注：与sys.ini文件中的languangeString参数值相关
	 */
	setAreaCode: function(_areaCode){
		if (_areaCode != '') {
			var da = new DataAccess("Systemsetting.properties");
			da.set("languangeString", _areaCode);
			da.submit();
		}
	},
	/**
	 * 载入一个JavaScript文件到当前页面在<HEAD>标签下
	 * @param {String} _filePath 如：'js/i18n.js'(相对路径)
	 * @param {String} _elementId 生成的script标签的ID
	 * @param {Function} _callback JS文件加载完后反调函数
	 */
	createScriptTag: function(_filePath, _elementId, _callback){
		var headObj = document.getElementsByTagName('HEAD').item(0);
		var scriptObj = document.createElement("script");
		scriptObj.type = "text/javascript";
		scriptObj.charset = "utf-8";//编码
		scriptObj.id = _elementId;
		scriptObj.src = _filePath;
		scriptObj.onload = _callback;
		headObj.appendChild(scriptObj);
	}
});

/**
 * 替换有带参'｛Number｝'字符串中的符号为文字信息
 */
String.prototype.param = function(){
	var formated = this;
	for (var i = 0; i < arguments.length; i++) {
		formated = formated.replace("\{" + i + "\}", arguments[i]);
	}
	return formated;
}
/**
 * 加载全局语言资源文件
 */
$L.createScriptTag(Utility.getEnv("ROOT_PATH") + "js/global_" + $L.getAreaCode() + ".js", "__globalLanguageResources");
/**
 * 将整个字符串中的中文替换成双字节,判断总长度是否大于需要截取的长度,如果大于则截取
 * @param {Number} n 截取长度
 */
String.prototype.sub = function(n){//中英文混合截取子字符串     
	var r = /[^\x00-\xff]/g;
	if (this.replace(r, "mm").length <= n) return this;
	var m = Math.floor(n / 2);
	for (var i = m; i < this.length; i++) {
		if (this.substr(0, i).replace(r, "mm").length >= n) {
			return this.substr(0, i) + "...";
		}
	}
	return this;
}
/**
 * 中英文字符长度统一用英文长度计算
 */
String.prototype.len = function(){
	return this.replace(/[^\x00-\xff]/g, "rr").length;
}

function Dialog(name, src, zIndex, x, y, w, h){
	this.iframe = document.createElement("iframe");
	this.iframe.name = name;
	document.body.appendChild(this.iframe);
	this.x = x || 0;
	this.y = y || 0;
	this.src = src;
	this.width = w || 1280;
	this.height = h || 720;
	this.zIndex = zIndex || 10;
	this.iframe.style.position = "absolute";
	this.iframe.style.left = this.x + "px";
	this.iframe.style.top = this.y + "px";
	this.iframe.style.width = this.width + "px";
	this.iframe.style.height = this.height + "px";
	this.iframe.style.zIndex = this.zIndex;
	this.isVisible = false;
	
	this.show = function(){
		this.iframe.src = this.src;
		this.isVisible = true;
	};
	
	this.hide = function(){
		this.iframe.src = Utility.getEnv("ROOT_PATH") + "blank.htm";
		this.isVisible = false;
	};
}

var orderReminder;
function showOrderReminder(){
	if (!orderReminder) {
		orderReminder = new Dialog("order_reminder", Utility.getEnv("ROOT_PATH") + "epg/order_reminder.htm", 10);
	}
	orderReminder.show();
}

function hideOrderReminder(){
	orderReminder.hide();
}

function openOrderedProgram(){
	var order = Orders.getAt(0);
	$G.debug("=========================", "预定跳转开始");
	var service = new Service(order.location);
	$G.debug("service.name", service.name);
	$G.debug("service.type", service.type);
	if (order.type == 2) {
		$G.debug("=========================", "此时预定跳转往NVOD播放页面");
		Utility.setEnv("currNVOD", order.location);
		window.location.href = Utility.getEnv("ROOT_PATH") + "NVOD/NVOD_play.htm";
	} else if (order.type == 3) {
		var allService = ServiceDB.getServiceList().filterService(4, false);
		var serIndex = allService.findIndex(service);
		if (serIndex != -1) {
			allService.moveTo(serIndex);
			if (service && service.type == DVB.SERVICE_TYPE_TV) {
				$G.sysDa.set("Mediaplayer.groupIndex", 0);
				$G.sysDa.submit();
				window.location.href = Utility.getEnv("ROOT_PATH") + "play/play.htm?chType=order&rand=" + Math.random();
			} else if (service && service.type == DVB.SERVICE_TYPE_RADIO) {
				$G.sysDa.set("Mediaplayer.groupIndex", 1);
				$G.sysDa.submit();
				window.location.href = Utility.getEnv("ROOT_PATH") + "play/radio.htm?chType=order&rand=" + Math.random();
			}
		}
	}
}
