$L.extend({
	NAME_0 : "顺序",
	NAME_1 : "全循环",
	NAME_2 : "单循环",
	NAME_3 : "随机",
	M_TITLE : "音乐地带",
	S_TITLE : "音乐列表",
	NOMUSIC : "没有音乐"
});
