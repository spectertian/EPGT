$L.extend({
	NAME_0 : "sequence",
	NAME_1 : "Full cycle",
	NAME_2 : "Round robin",
	NAME_3 : "Random",
	M_TITLE : "Music Zone",
	S_TITLE : "Music list",
	NOMUSIC : "No music"
});
