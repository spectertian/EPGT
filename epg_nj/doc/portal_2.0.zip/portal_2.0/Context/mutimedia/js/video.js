var mp = new MediaPlayer();
mp.stop();

var currIndex = 0;
var currFile;
var playStatus = "stop";
var progress = 0;
var progressTimer, infoBarTimer;
var duration = 0;
var fileListObj = new List(13, onShow, onFocusMove, onFocus, onBlur, onNoData, "focus", 41, 44);
var okListFlag = false;
var infoBarFlag = false;
var btnImgs = [['images/btn_pre_last.png', 'images/btn_pre_last0.png'], ['images/btn_pre_l.png', 'images/btn_pre_l0.png'], ['images/btn_now.png', 'images/music_5.png'], ['images/btn_pre_r.png', 'images/btn_pre_r0.png'], ['images/btn_pre_next.png', 'images/btn_pre_next0.png']];
var playButtonImg = ['images/btn_now.png', 'images/music_5.png'];
var pauseButtonImg = ['images/music_6.png', 'images/MP3_03.png'];
var btnPos = 2;
SysSetting.panelDisplayText("USb");
var exitTipFlag = false;
var exitType = "toPlay";
var subText = "";

var playFlag = 0, progressTimer0 = -1, isPlay = false;
function eventHandler(evt){
	if (exitTipFlag) {
		if (confirmEventHandler(evt)) { return; }
	}
	switch (evt.code) {
		case "KEY_EXIT":
		case "KEY_BACK":
			if (okListFlag) {
				if (playStatus == "play") {
					hideOKList();
				} else {
					doBack();
				}
			} else if (infoBarFlag) {
				hideInfoBar();
			} else {
				doBack();
			}
			break;
		case "KEY_ENTER":
			if (okListFlag) {
				hideOKList();
				if (videoList.length > 0) {
					currIndex = fileListObj.currIndex;
					mp.stop();
					play(currIndex);
					showInfoBar();
					showFileInfo();
				}
			} else if (infoBarFlag) {
				hideInfoBar();
				showOKList();
				//showInfoBar();
			//doEnter();
			} else {
				showOKList();
			}
			break;
		case "KEY_VOLUME_DOWN":
			if (!okListFlag) {
				changeVolume(-1);
				showInfoBar();
			}
			break;
		case "KEY_VOLUME_UP":
			if (!okListFlag) {
				changeVolume(1);
				showInfoBar();
			}
			break;
		case "KEY_UP":
			if (okListFlag) {
				fileListObj.up();
			}else {
				hideInfoBar();
				showOKList();
			}
			break;
		case "KEY_DOWN":
			if (okListFlag) {
				fileListObj.down();
			}else {
				hideInfoBar();
				showOKList();
			}
			break;
		case "KEY_LEFT":
			if (okListFlag) {
				fileListObj.pageUp();
			} else if (infoBarFlag) {
				//moveFocus(-1);
				seek(-1);
			} else {
				showInfoBar();
			}
			break;
		case "KEY_RIGHT":
			if (okListFlag) {
				fileListObj.pageDown();
			} else if (infoBarFlag) {
				//moveFocus(1);
				seek(1);
			} else {
				showInfoBar();
			}
			break;
		case "KEY_RW": //快退
			if (!isPlay) return;
			seek(-1);
			break;
		case "KEY_FF": //快进
			if (!isPlay) return;
			seek(1);
			break;
		case "MEDIA_SHOW_SUBTITLE":
			var subStr = DVB.getEvent(40209, evt.userInt);
			var jsonObj = eval('('+subStr+')');
			subText = jsonObj.subtitle;
			showSubTitle(subText);
			break;
		case "MEDIA_CLEAR_SUBTITLE":
			subText = "";
			showSubTitle(subText);
			break;
		case "KEY_PAGE_UP":
			switchMedia(-1);
			break;
		case "KEY_PAGE_DOWN":
			switchMedia(1);
			break;
		case "MP3_PLAY_END":
			switchMedia(1);
			break;
		case "USB_DEVICE_EVULSION":
			$G.exitToPlay();
			break;
		case "KEY_MUTE":
			setMute();
			break;
		case "KEY_ENTER_PAUSE":
			if (okListFlag) {
			
			} else if (infoBarFlag) {
				pauseAndResume();
			} else {
				showInfoBar();
			}
			break;
	}
}

function confirmEventHandler(evt){
	var flag = false;
	switch (evt.code) {
		case "KEY_LEFT":
		case "KEY_RIGHT":
		case "KEY_UP":
		case "KEY_DOWN":
			flag = true;
			break;
		case "KEY_BACK":
			hideExitTip();
			flag = true;
			break;
		case "KEY_ENTER":
			switch (exitType) {
				case "toPlay":
					$G.exitToPlay();
					break;
				case "toMenu":
					$G.exitToMenu();
					break;
				case "toPrev":
					window.location.href = $G.root + "setting/menu_usb.htm";
					break;
			}
			flag = true;
			break;
	}
	return flag;
}
var videoList = [];
function searchMediaFile(){
	var storageList = StorageService.getStorageInfos();
	Utility.println("-------storageList.length = " + storageList.length);
	for (var n = 0, m = storageList.length; n < m; n++) {
		if (!storageList[n].removeAble) continue;
		var partitionList = storageList[n].getPartitionsInfo();
		Utility.println("---" + n + "----partitionList.length = " + partitionList.length);
		for (var i = 0, j = partitionList.length; i < j; i++) {
			var file = new File(partitionList[i].path);
			Utility.println("-------path = " + partitionList[i].path);
			videoList = videoList.concat(file.listFiles('*.f4v;*.ts;*.rm;*.rmvb;*.mp4;*.flv;*.mkv;*.avi;*.mov;*.mpg;', true));
		}
		Utility.println("--------videoList.length = " + videoList.length);
	}
}
function init(){
	searchMediaFile();
	$G.debug("==========video duration==========", mp.getMediaDuration());
	showOKList();
	if (videoList.length > 0) {
		fileListObj.bindData(videoList, 0);
		fileListObj.setFocus();
	}
	if (mp.getMuteFlag() == 1) {
		$('mutePic').style.visibility = "visible";
	}
	if (muteFlag == 1) {
		$('volumeBar').style.width = "0px";
	} else {
		$('volumeBar').style.width = volume / 31 * 90 + "px";
	}
	var volume = Number($G.sysDa.get('UniformVolume'));
	$('volumeBar').style.width = volume / 31 * 90 + "px";
}
var muteFlag = mp.getMuteFlag();
function setMute(){
	muteFlag = mp.getMuteFlag();
	muteFlag = muteFlag == 0 ? 1 : 0;
	setMuteFlag(muteFlag);
}

function setMuteFlag(flag){
	mp.setMuteFlag(flag);
	if (flag == 0) {//有声
		$('mutePic').style.visibility = "hidden";
	} else {
		$('mutePic').style.visibility = "visible";
	}
}

function showFileInfo(){
	currFile = videoList[currIndex];
	duration = new MP3File(currFile.getPath()).durationTime;
	if (duration == -1) duration = 0;
	$("name").innerText = currFile.getName().sub(20);
	var volume = mp.getVolume();
	$("volume").innerText = volume;
	var barCount = Math.floor(120 * (volume / 31) / 12);
	if (volume > 0 && volume <= 3) barCount = 1;
	var barWidth = barCount * 12;
	$("volume_bar").style.width = barWidth + "px";
	if (duration > 0) {
		showProgress();
	}	
}

function resume(){
	playStatus = "play";
	mp.resume();
	progressTimer = setTimeout(showProgress, 1000);
	//showInfoBar();
}

function pause(){
	playStatus = "pause";
	mp.pause();
	clearTimeout(progressTimer);
	clearTimeout(progressTimer0);
	//showInfoBar();
}

function stop(){
	playStatus = "stop";
	mp.stop();
	clearTimeout(progressTimer);
	clearTimeout(progressTimer0);
	progress = 0;
	$("play_time").innerText = formatSec(progress);
	$("progress_bar").style.width = "0px";
	//showProgress();
}

function showProgress(){
	if (progress < duration) {
		$("play_time").innerText = formatSec(progress);
		progress++;
		if (progress > duration) {
			clearTimeout(progressTimer);
			clearTimeout(progressTimer0);
			progress = duration;
		} else {
			clearTimeout(progressTimer);
			clearTimeout(progressTimer0);
			progressTimer = setTimeout(showProgress, 1000);
		}
		$G.debug('progress=', progress)
		$("progress_bar").style.width = progress / duration * 1260 + "px";
	} else {
		//progressTimer = -1;
		//isPlay = false;
		//switchMedia(1);
		showExitTip();
	}
}

function formatSec(sec){
	var hour = Math.floor(sec / 3600);
	hour = hour < 10 ? "0" + hour : hour;
	var minute = Math.floor((sec % 3600) / 60);
	minute = minute < 10 ? "0" + minute : minute;
	var second = Math.floor(sec % 60);
	second = second < 10 ? "0" + second : second;
	var str = hour + ":" + minute + ":" + second;
	return str;
}

function changeVolume(_type){
	var volume = Number($G.sysDa.get('UniformVolume'));
	if (muteFlag == 1) {
		mp.setMuteFlag(0);
		muteFlag = 0;
		$('volumeBar').style.width = volume / 31 * 90 + "px";
		return;
	}
	var temp = volume + _type;
	if (temp > 31 || temp < 0) return;
	volume = temp;
	mp.setVolume(volume);
	$('volumeBar').style.width = volume / 31 * 90 + "px";
	$G.sysDa.set('UniformVolume', volume);
	if (mp.getMuteFlag() == 1) {
		setMuteFlag(0);
	}
}

function showInfoBar(){
	$("info_bar").style.visibility = "visible";
	infoBarFlag = true;
	clearTimeout(infoBarTimer);
	infoBarTimer = setTimeout(hideInfoBar, 3000);
}

function hideInfoBar(){
	clearTimeout(infoBarTimer);
	infoBarFlag = false;
	$("info_bar").style.visibility = "hidden";
}

function switchMedia(offset){
	if (videoList.length < 2) return;
	currIndex += offset;
	if (currIndex < 0) currIndex = videoList.length - 1;
	else if (currIndex > videoList.length - 1) currIndex = 0;
	showFileInfo();
	mp.stop();
	$G.debug("==========================switchMedia");
	setTimeout("play(currIndex)", 500);
}

var step = 0;
function play(idx){
	isPlay = true;
	var mediaFile = new MediaFile(videoList[idx].getPath());//MP3File
	duration = mediaFile.durationTime;
	step = Math.floor(duration / 10);
	playStatus = "play";
	var musicFile = videoList[idx];
	currFile = musicFile;
	progress = 0;
	mp.setSingleMedia("file://" + musicFile.getPath());
	mp.playFromStart();
	btnImgs[2] = pauseButtonImg;
	if (btnPos == 2) $("btn_2").src = btnImgs[2][1];
	
	if (progressTimer0 != -1) {
		clearTimeout(progressTimer0);
	}
	progressTimer0 = setTimeout(showProgress, 1000);
}

function exitPage(){
	mp.stop();
	SysSetting.panelDisplayText("");
}

function onShow(_item, _index, _focusIndex){
	if (_item) {
		$('f' + _focusIndex).innerHTML = $G.leftPadStr(_index + 1, "0", 3) + "&nbsp;" + _item.getName().sub(18);
	} else {
		$('f' + _focusIndex).innerText = "";
	}
}
function onFocusMove(_oldFocusIndex, _newFocusIndex){

}
function onFocus(_focusIndex) {
	$('focus').style.top = (41 + _focusIndex * 44) + "px";
}
function onBlur(_focusIndex) {
	$('focus').style.top = (41 + _focusIndex * 44) + "px";
}
function onNoData(){
	$('focus').style.visibility = "hidden";
}

function showOKList() {
	$("file_list").style.visibility = "visible";
	fileListObj.bindData(videoList, currIndex);
	fileListObj.setFocus();
	okListFlag = true;
}

function hideOKList() {
	$("file_list").style.visibility = "hidden";
	okListFlag = false;
}

function doEnter(){
	switch (btnPos) {
		case 2:
			if (playStatus == "play") {
				btnImgs[2] = playButtonImg;
				$("btn_2").src = btnImgs[2][1];
				$("btn_txt2").innerText = "播放";
				pause();
				clearTimeout(infoBarTimer);
			} else if (playStatus == "pause" || playStatus == "stop") {
				btnImgs[2] = pauseButtonImg;
				$("btn_2").src = btnImgs[2][1];
				$("btn_txt2").innerText = "暂停";
				if (playStatus == "pause") {
					resume();
				} else {
					showFileInfo();
					play(currIndex);
				}
			}
			break;
		case 1:
			seek(-1);
			break;
		case 0:
			switchMedia(-1);
			break;
		case 4:
			switchMedia(1);
			break;
		case 3:
			seek(1);
			break;
	}
}

function pauseAndResume(){
	if (playStatus == "play") {
		btnImgs[2] = playButtonImg;
		$("btn_2").src = btnImgs[2][1];
		$("btn_txt2").innerText = "播放";
		pause();
		clearTimeout(infoBarTimer);
		infoBarTimer = setTimeout(hideInfoBar, 5000);
	} else if (playStatus == "pause" || playStatus == "stop") {
		btnImgs[2] = pauseButtonImg;
		$("btn_2").src = btnImgs[2][1];
		$("btn_txt2").innerText = "暂停";
		if (playStatus == "pause") {
			resume();
		} else {
			showFileInfo();
			play(currIndex);
		}
		clearTimeout(infoBarTimer);
		infoBarTimer = setTimeout(hideInfoBar, 5000);
	}
}

function doMenu() {
	exitType = "toMenu";
	showExitTip();
}

function doExit() {
	exitType = "toPlay";
	showExitTip();
}

function doBack() {
	window.location.href = "usb.htm";
}

function moveFocus(type) {
	$("btn_" + btnPos).src = btnImgs[btnPos][0];
	btnPos += type;
	if (btnPos < 0) btnPos = 4;
	else if (btnPos > 4) btnPos = 0;
	$G.debug("=====================btnPos", btnPos);
	$("btn_" + btnPos).src = btnImgs[btnPos][1];
	clearTimeout(infoBarTimer);
	infoBarTimer = setTimeout(hideInfoBar, 5000);
}

function showExitTip() {
	$("error_tip").style.visibility = "visible";
	exitTipFlag = true;
}

function hideExitTip() {
	$("error_tip").style.visibility = "hidden";
	exitTipFlag = false;
}

function seek(_pos){//快进快退调用
	if (_pos < 0) {
		progress -= step;
		if (progress < 0) progress = 0;
		mp.playByTime(1, progress, 0);//从某个时间点开始播放
	} else {
		if (progress + step < duration) {
			progress += step;
			mp.playByTime(1, progress, 0);//从某个时间点开始播放
		} else {
			progress = duration - 1;
			mp.playByTime(1, progress, 0);//从某个时间点开始播放
		}
	}
}

function showSubTitle(msg){
	$("subText").innerText = msg;
}