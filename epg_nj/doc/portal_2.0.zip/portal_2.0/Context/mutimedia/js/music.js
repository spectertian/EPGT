
var musicList = [], playArr = [], listObj, playFlag = currDurationTime = playedTime = 0, progressTimer = -1, currMusic, pauseFlag = isPlay = false;
var mp = new MediaPlayer();
var volume = Number($G.sysDa.get('UniformVolume'));
mp.setVolume(volume);
var muteFlag = mp.getMuteFlag(), volume = mp.getVolume();
var currIndex = 0;
var area = 0;

function eventHandler(evt){
	switch (evt.code) {
		case "KEY_UP":
			if(area == 1) return;
			listObj.up();
			break;
		case "KEY_DOWN":
			if(area == 1) return;
			listObj.down();
			break;
		case "KEY_LEFT":
			if(area == 0){
				//listObj.pageUp();	
				seek(-1);
			}else{
				leftRight(-1);		
			}
			break;
		case "KEY_RIGHT":
			if(area == 0){
				//listObj.pageDown();
				seek(1);	
			}else{
				leftRight(1);		
			}
			break;
		case "KEY_ENTER":
			doEnter();
			break;
		case "KEY_ENTER_PAUSE":
			pauseAndResume();
			break;
		case "KEY_PAGE_UP":
			switchMedia(-1);
			listObj.up();
			break;
		case "KEY_PAGE_DOWN":
			switchMedia(1);
			listObj.down();
			break;			
		case "KEY_RW": //快退
			if(!isPlay) return;
			seek(-1);
			break;
		case "KEY_FF": //快进
			if(!isPlay) return;
			seek(1);
			break;
		case "KEY_VOLUME_UP":
			changeVolume(1);
			break;
		case "KEY_VOLUME_DOWN":
			changeVolume(-1);
			break;
		case "KEY_MUTE":
			setMute();
			break;
		case "KEY_BACK":
		case "KEY_EXIT":
			window.location.href = "usb.htm";
			break;
		case "USB_DEVICE_INSERTED":
		case "USB_DEVICE_EVULSION":
			setTimeout("window.location.reload();", 3000);
			break;
		case "KEY_RED":
			if(area == 0){
				area = 1;
				$('focus').src = "images/focus0.png";
			}else{
				area = 0;
				$('focus').src = "images/musicbar.png";
			}
			break;
	}
}

function init(){
	mp.setAllowTrickmodeFlag(0);
	mp.setCurrentAudioChannel("Stereo"); 
	mp.setVideoDisplayMode(1);
	
	playArr = [{
		name: $L.NAME_0,
		pic: ["images/music_2.png", "images/music_02.png"]
	}, {
		name: $L.NAME_1,
		pic: ["images/music_3.png", "images/music_03.png"]
	}, {
		name: $L.NAME_2,
		pic: ["images/music_4.png", "images/music_04.png"]
	}];
	musicList = searchMP3();
	listObj = new List(9, iteratorShow, onFocusMove, onFocus, onBlur, onNoData, "focus", 234, 44);
	listObj.bindData(musicList, 0);
	if (muteFlag == 1) {
		$('volumeBar').style.width = "0px";
	} else {
		$('volumeBar').style.width = volume / 31 * 90 + "px";
	}
	var volume = Number($G.sysDa.get('UniformVolume'));
	$('volumeBar').style.width = volume / 31 * 90 + "px";
}


function switchMedia(offset) {
	if (musicList.length < 2) return;
	progress = 0;
	currIndex += offset;
	if (currIndex < 0) currIndex = musicList.length - 1;
	else if (currIndex > musicList.length - 1) currIndex = 0;
	mp.stop();
	currMusic = musicList[currIndex];
	playMusic(currMusic);
}

function leftRight(_type){
	$('pic_' + playFlag).src = playArr[playFlag].pic[0];
	playFlag = (playFlag + _type + 3) % 3;
	$('pic_' + playFlag).src = playArr[playFlag].pic[1];
}

function doEnter(){
	if (musicList.length > 0) {
		currIndex = listObj.currIndex;
		currMusic = musicList[listObj.currIndex];
		playMusic(currMusic);
	}
}

function setMute(){
	if (muteFlag == 1) {
		mp.setMuteFlag(0);
		muteFlag = 0;
		$("mute").style.visibility = "hidden";
	} else {
		mp.setMuteFlag(1);
		muteFlag = 1;
		$("mute").style.visibility = "visible";
	}
}

function changeVolume(_type){
	$("mute").style.visibility = "hidden";
	var volume = Number($G.sysDa.get('UniformVolume'));
	if (muteFlag == 1) {
		mp.setMuteFlag(0);
		muteFlag = 0;
		$('volumeBar').style.width = volume / 31 * 90 + "px";
		return;
	}
	var temp = volume + _type;
	if (temp > 31 || temp < 0) return;
	volume = temp;
	mp.setVolume(volume);
	$('volumeBar').style.width = volume / 31 * 90 + "px";
	$G.sysDa.set('UniformVolume',volume);
	
}

var step = 0;
function playMusic(file){
//	mp.stop();
	var _currMusic = new MP3File(file.getPath());
	isPlay = true;
	currDurationTime = _currMusic.durationTime;
	step = Math.floor(currDurationTime / 10);
	$('playPic').src = "images/music_5.png";
	//alert(_currMusic.fileName);
	$('currMusicMsg').innerText = file.getName().sub(36) + (!_currMusic.singer ? "" : ' — ' + _currMusic.singer.sub(6));
	$('durationTime').innerText = sedToMin(currDurationTime);
	$('currPlayTime').innerText = "00:00";
	$('bar').width = 0;
	//added by lixiaole 
    mp.refreshVideoDisplay();
	
	mp.setSingleMedia(_currMusic.location);
	
	$G.debug("the muteFlag befor music play: " + mp.getMuteFlag());// test add 2-28
	
	mp.playFromStart();
	
	$G.debug("the muteFlag after music play: " + mp.getMuteFlag());// test add 2-28
	
	playedTime = 0;
	if (progressTimer != -1) {
		clearTimeout(progressTimer);
	}
	progressTimer = setTimeout(progressBar, 1000);
}

function pauseAndResume(){
	if (isPlay) {
		if (!pauseFlag) {
			mp.pause();
			pauseFlag = true;
			clearTimeout(progressTimer);
			$('playPic').src = "images/music_6.png";
		} else {
			mp.resume();
			pauseFlag = false;
			progressTimer = setTimeout(progressBar, 1000);
			$('playPic').src = "images/music_5.png";
		}
	}
}

function progressBar(){
	if (playedTime < currDurationTime) {
		playedTime++;
		var percent = playedTime / currDurationTime;
		//if(percent>1) percent=1;
		$('bar').width = 312 * percent;
		progressTimer = setTimeout(progressBar, 1000);
		$('currPlayTime').innerText = sedToMin(playedTime);
	} else {
		progressTimer = -1;
		$('playPic').src = "images/btn_now.png";
		isPlay = false;
		playNextMusic();
	}
}

function playNextMusic(){
	switch (playFlag) {
		/*case 0://顺序
			if (listObj.currIndex < musicList.length - 1) {
				listObj.down();
				currMusic = musicList[listObj.currIndex];
				playMusic(currMusic);
			}
			break;*/
		case 0://全循环
			listObj.down();
			currIndex = listObj.currIndex;
			currMusic = musicList[listObj.currIndex];
			playMusic(currMusic);
			break;
		case 1://单循环
			playMusic(currMusic);
			break;
		case 2://随机
			var index = Math.round(Math.random() * (musicList.length - 1));
			listObj.bindData(musicList, index);
			listObj.setFocus();
			currIndex = listObj.currIndex;
			currMusic = musicList[listObj.currIndex];
			playMusic(currMusic);
			break;
	}
}

/**
 * 转化为小时和分钟
 * @param {Number} second 秒
 */
function sedToMin(second){
	var min = parseInt(second / 60);
	var sed = second % 60;
	return $G.leftPadStr(min, "0", 2) + ":" + $G.leftPadStr(sed, "0", 2);
}

function iteratorShow(_item, _index, _focusIndex){
	if (_item) {
		//$('sn_' + _focusIndex).innerText = sedToMin(_item.durationTime);
		$('name_' + _focusIndex).innerText = _item.getName().sub(24);
		//$('singer_' + _focusIndex).innerText = _item.singer == "" ? "-" : _item.singer.sub(6);
	} else {
		$('sn_' + _focusIndex).innerText = "";
		$('name_' + _focusIndex).innerText = "";
		$('singer_' + _focusIndex).innerText = "";
	}
}

function onFocusMove(_oldFocusIndex, _newFocusIndex){
}

function onFocus(_focusIndex){
	$('focus').style.top = 234 + 44 * _focusIndex + 'px';
}

function onBlur(){

}

function onNoData(){
	$("focus").style.visibility = "hidden";
	$('name_0').innerText = $L.NOMUSIC;
}

function searchMP3(){
	var storageList = StorageService.getStorageInfos();
	var MP3FileArr = [];
	Utility.println("-------storageList.length = "+storageList.length);
	for (var n = 0, m = storageList.length; n < m; n++) {
		var partitionList = storageList[n].getPartitionsInfo();
		var fileArr = [];
		Utility.println("---"+n+"----partitionList.length = "+partitionList.length);
		for (var i = 0, j = partitionList.length; i < j; i++) {
			var file = new File(partitionList[i].path);
			Utility.println("-------path = "+partitionList[i].path);
			fileArr = fileArr.concat(file.listFiles('*.mp3;*.m4a', true));
		}
		Utility.println("--------fileArr.length = "+fileArr.length);
		for (var x = 0, y = fileArr.length; x < y; x++) {
			MP3FileArr.push(fileArr[x]);
		}
	}
	return MP3FileArr;
}

function exitPage(){
	mp.stop();
}

function seek(_pos){//快进快退调用
	if(_pos < 0){
		playedTime -= step;
		if(playedTime < 0) playedTime = 0;
		mp.playByTime(1, playedTime, 0);//从某个时间点开始播放
	}else{
		if(playedTime + step < currDurationTime){
			playedTime += step;
			mp.playByTime(1, playedTime, 0);//从某个时间点开始播放
		}
	}
}