﻿Coship.setDrawFocusRing(1);
Utility.setDrawFocusRing(0);
var speedArray = [-33, -18, -9, -3, 60, 1, 66, 3, 9, 18, 33], nowSpeed = 1, preSpeed = 0;
var spos = 5;
var isDragOpeartion = false;	//拖动生效
var DragOpearStart = false;		//开始拖动
var isOperTimeout = false;		//拖动失效
var isFast = false;				//当前是否为快进会快退状态
var mode = 0,index = 'play',currentIndex = '',audioChannelArrayIndex=0;
var timeIntegretStr;
var secondsStart = 0;
var haveKeyEvent = false, isHelpkeyEvent = false,isTimeKeyEvent = false,lock = false,quick = false,netErrorEvent = false,isSigalEvent = true,
isSigalTooBadEvent = false;
var timer = 0,clockInterVal = 0,audioChannelTimer = 0;
var mp = new MediaPlayer();
var count = 1;
var	startShiTime_hour = 0,startShiftTime_min = 0,startShiftTime_sec = 0;
var	endShiftime_hour = 0,endShiftTime_min = 0,endShiftTime_sec = 0,passTime = 0,shiftTotalTime = 0,shiftTimeStr ="",shiftBeginTime = "",shiftEndTime  = "";
var $ = function(id) { return typeof id == 'string' ? document.getElementById(id) : id; };
var audioChannelArrayName_en, audioChannelArrayName_cn, audioTrackMode, audioTrackStr;
var isPlay = true;
var totalProgressWidth = 255; //进度条总长度
var recordBarWidth = 0;
var currentTime = 0,totalTime = 0,realCurrentTime_Hour = 0,realCurrentTime_min = 0,realCurrentTime_sec = 0,realTotalTime_Hour = 0,realTotalTime_min = 0,realTotalTime_sec = 0;

var isStreamRun = false;	//前端码流是否恢复
var isInitSucess = false;	//初始化成功与否
var sysDa = new DataAccess("Systemsetting.properties");
var ts_startTime, ts_endTime;
var timeShiftTimer;
var step = 0;
var initProcess;
var realProcess = 0;
var dragTimer;				//拖动定时器
var MpegName = "";			//节目名称
var MPEG_STOP_EXIT = 0x72;	//退出键值
var MPEG_STOP_BACK = 0x25;	//后退键值
var MPEG_STOP_DOWN = 0x1D;	//向下键值
var pageFlags = 0;			//0表示标清，1表示高清
var endpointShift =0 ;		//时移结束点的位置
var endpointvod = 321;		//点播结束点的位置

mp.setStopMode(1);
function secToTimeStr(sec) {
	var hours_rec = parseInt(sec/3600);
	if (hours_rec >= 24) {
		hours_rec = hours_rec - 24;
	}
	var minus_rec = parseInt((sec%3600)/60);
	var sec_rec = parseInt(sec%60);
	var result = addZero(hours_rec) + ":" + addZero(minus_rec) + ":" + addZero(sec_rec);
	return result;
}

function leftOperation(){
	index = 'left';
	setIndexIsVisible();
	spos--;
	if(spos>4){
		 spos = 4;
	} else if(spos<0) { 
		 spos=0;
	}
	
	nowSpeed = speedArray[spos];
	if(isDragOpeartion){
		nowSpeed = -totalTime/20;
		return;
	}
	
	if(nowSpeed == 1){
		 MotoVod.playControl("resume",0,0);
	} else{
		 MotoVod.playControl("forward",nowSpeed,0);
	}
}

function showHelp(){
	var helpID = mode == 1 ? "helpShow" : "helpShow2";
	if(isDragOpeartion){
		$(helpID).innerHTML = "播放";
		return;
	}
	Utility.println("============nowSpeed=============="+nowSpeed+"==============spos"+spos);
	switch (nowSpeed) {
		case 60:
			$(helpID).innerHTML = "慢退 1/2 倍 ";
			break;
		case -3:
			$(helpID).innerHTML = "快退 3   倍";
			break;
		case -9:
			$(helpID).innerHTML = "快退 9   倍 ";
			break;
		case -18:
			$(helpID).innerHTML = "快退 18  倍 ";
			break;
		case -33:
			$(helpID).innerHTML = "快退 33  倍 ";
			break;
		case 66:
			$(helpID).innerHTML = "慢进 1/2 倍 ";
			break;
		case 3:
			$(helpID).innerHTML = "快进 3   倍 ";
			break;
		case 9:
			$(helpID).innerHTML = "快进 9   倍 ";
			break;
		case 18:
			$(helpID).innerHTML = "快进 18  倍 ";
			break;
		case 33:
			$(helpID).innerHTML =  "快进 33  倍 ";
			break;
	}
}

function rightOperation(){
	index = 'right';
	setIndexIsVisible();
	spos++;
	if(spos<6){
		spos=6;
	} else if(spos>10){ 
		spos=10;
	}
	
	nowSpeed = speedArray[spos];
	if(isDragOpeartion){
		nowSpeed = totalTime/20;
		return;
	}
	
	if(nowSpeed == 1){
		MotoVod.playControl("resume",0,0);
	}else{
		MotoVod.playControl("forward",nowSpeed,0);
	}
}

function changeBtn(id,m){
    var obj = $(id);
	var focusClassName,blurClassName;
	switch (id){
		case 'inputText1':
		case 'inputText2':
		case 'inputText3':
			focusClassName = "inputText_foc";blurClassName = "";
			break;
		default:
		    break;
	}
    m==0?obj.className = focusClassName:obj.className = blurClassName;
}


function closeBoxSelf(){
	lock = false;
	$('ALERT_EXAMPLE').style.visibility = "hidden";
	$('ALERT_BTN').style.display = 'none';
	$('alert_title').style.display = 'none';
	$('ALERT_BTN').blur();
}

function transform(){ 	
	if(isDragOpeartion){
		currentTime += nowSpeed;
	}else{
		currentTime = MotoVod.getCurrentTime(); 
	}
	if(isDragOpeartion && currentTime > totalTime){
		currentTime = totalTime;
	}
	if(currentTime > totalTime){
		currentTime = totalTime;
	}
	
	currentTime = currentTime > 0 ? currentTime : 0;
	realCurrentTime_Hour =  addZero(parseInt(currentTime/3600));
	realCurrentTime_min  =  addZero(parseInt((currentTime%3600)/60));
	realCurrentTime_sec  =  addZero(parseInt(currentTime%60));
	realTotalTime_Hour   =  addZero(parseInt(totalTime/3600));
	realTotalTime_min    =  addZero(parseInt((totalTime%3600)/60));
	realTotalTime_sec    =  addZero(parseInt(totalTime%60));
	
	$("progress2").style.width = parseInt((currentTime/totalTime)*totalProgressWidth) +"px";
	$("endpoint2").style.left = endpointvod + parseInt((currentTime/totalTime)*totalProgressWidth) +"px";
	$("Mpeg_CurrTime2").innerText = realCurrentTime_Hour+":"+realCurrentTime_min+":"+realCurrentTime_sec;
} 

function getprogress(){  
	transform();
}

function removeZero(str){
	var istr = str.toString();
	istr = parseInt(str, 10);
	return istr;
}

function clock(){	//时移	
	if(isDragOpeartion){
		currentTime += nowSpeed;
	}else{
		currentTime = MotoVod.getCurrentTime();
	}
	
	if(currentTime > totalTime){
		currentTime = totalTime;
	}
	
	currentTime = currentTime > 0 ? currentTime : 0;
	if(!MotoVod.isRecordOver() && isDragOpeartion){
		var now = new Date();
		if((currentTime + ts_startTime.getHours()*3600 + ts_startTime.getMinutes()*60 + ts_startTime.getSeconds()) > now.getHours()*3600 + now.getMinutes()*60 + 						            now.getSeconds()){
			currentTime =  now.getHours()*3600 + now.getMinutes()*60 + now.getSeconds() - (ts_startTime.getHours()*3600 + ts_startTime.getMinutes()*60 + ts_startTime.getSeconds());
		}
	}
	
	$("progress").style.width = parseInt((currentTime/totalTime)*totalProgressWidth) +"px";
	$("endshiftCurrent").style.left = endpointShift +  parseInt((currentTime/totalTime)*totalProgressWidth) +"px";
	$("ts_startTime").innerText = secToTimeStr(currentTime + ts_startTime.getHours()*3600 + ts_startTime.getMinutes()*60 + ts_startTime.getSeconds());
}

var mainTimer;
function appear(){
	mode = MotoVod.isTimeShift();
	clearTimeout(mainTimer);
	var showcontrol = mode==1 ? "main" : "main2";
	var hidecontrol = mode==1 ? "main2" : "main";
	
	// 获取播放器广告。该判断是为防止重复获取广告
	if ($(showcontrol).style.display != "block") {
		$("control_ad").src = "misads://typeIndex=26";
	}
	
	$(showcontrol).style.display  = "block";
	$(hidecontrol).style.display  = "none";
	
	if(pageFlags == 1){										//高清播放器，显示图片
		var visiblecontrolimage = mode == 1 ? "main_bg_01" : "main_bg_02";
		var hidecontrolimage = mode == 1 ? "main_bg_02" : "main_bg_01";
		$(visiblecontrolimage).style.visibility  = "visible";	//隐藏高清播放器图片
		$(hidecontrolimage).style.visibility  = "hidden";
	}

	$(index).style.visbility = "visible";
	mainTimer = setTimeout("disAppearNew()", 5000);
}

function disAppearNew(){
	currentIndex = index;
	if(quick == true){
		return;
	}
	
	// 隐藏播放器广告
	$("control_ad_div").style.visibility = "hidden";
	
	// 隐藏暂停广告
	$("pause_ad_div").style.visibility = "hidden";
	
	$("main").style.display  = "none";
	$("main2").style.display  = "none";
	if(pageFlags == 1){										//高清播放器，显示图片
		$("main_bg_01").style.visibility  = "hidden";	//隐藏高清播放器图片
		$("main_bg_02").style.visibility  = "hidden";
	}
	$(currentIndex).style.visibility = "hidden";
}  	 

function closeSelf(){
	$("helpMenu").style.display = "none";
	isHelpkeyEvent = false;
}

function closeInputMenu(){
     $("inputTimeMenu").style.display = "none"; 	
}

function showInputTimePageTime(){
	var span = $("inputTime_se").getElementsByTagName("span");
	if(mode==1){           
		var startTime = MotoVod.getBeginTime();
		var endTime = MotoVod.getEndTime();
		var now = new Date();
		var iHour;
		var iMinutes;
		var iSecondds;
		
		if(endTime > now && !MotoVod.isRecordOver()){
			iHour = now.getHours();
			iMinutes = now.getMinutes();
			iSecondds = now.getSeconds();
		}else{
			iHour = endTime.getHours();
			iMinutes = endTime.getMinutes();
			iSecondds = endTime.getSeconds();
		}
		
		span[0].innerHTML = "开始时间：" + addZero(startTime.getHours())+":"+ addZero(startTime.getMinutes())+":"+ addZero(startTime.getSeconds()); 
		span[1].innerHTML = "结束时间：" + addZero(iHour)+":"+ addZero(iMinutes)+":"+ addZero(iSecondds); 
	} else if(mode==0){
		span[0].innerHTML = "开始时间：" + '00' +":" + '00' +":" + '00'; 
		span[1].innerHTML = "结束时间：" +realTotalTime_Hour +":" +realTotalTime_min +":" + 	realTotalTime_sec; 
	}
}

function inputTimeEnter(){
	 $("inputTimeMenu").style.display = "none"; 
	 isTimekeyEvent = false;
	 timeIntegretStr = $("fre0").innerHTML + $("fre1").innerHTML + $("fre2").innerHTML +$("fre3").innerHTML+$("fre4").innerHTML+$("fre5").innerHTML;
	 judge();
}

function addZero(num){
	var istr = num + "";
	if(istr.length == 2){ return istr;}
	if(istr.length ==1 ){ return "0" + istr;}
	if(istr.length ==0 ){ return "00";}
}
var alertFlag = false;
function judge(){
    var realTimeCount = 0;
	var inputHours,inputMinutes,intputSeconds;
	inputHours = parseInt(timeIntegretStr.charAt(0))*10 + parseInt(timeIntegretStr.charAt(1));	//小时
	inputMinutes = parseInt(timeIntegretStr.charAt(2))*10 + parseInt(timeIntegretStr.charAt(3));
	intputSeconds = parseInt(timeIntegretStr.charAt(4))*10 + parseInt(timeIntegretStr.charAt(5));

	if(mode==1)
	{ 
		var istart = MotoVod.getBeginTime().getHours();
		var iend =  MotoVod.getEndTime().getHours();
		
		if((removeZero(startShiTime_hour) > inputHours) && (removeZero(istart) > removeZero(iend))) //当为24:00---00:00时
		{	
			inputHours = 24 + inputHours;	//25:00形式
		}
		
		realTimeCount = (inputHours - removeZero(startShiTime_hour))*3600 + 
						(inputMinutes - removeZero(startShiftTime_min))*60 + 
						(intputSeconds - removeZero(startShiftTime_sec));
	} 
	else
	{
		realTimeCount = inputHours*3600 + inputMinutes*60 + intputSeconds;
	}
	
	if(mode==1){
		var isBeforeOver = true;
		var theend = MotoVod.getEndTime();
		var nowTime = new Date();
		
		var endtime = theend.getHours() < removeZero(startShiTime_hour) ? (24 + theend.getHours()) : theend.getHours();//23--1点形式
		endtime = endtime*3600 + theend.getMinutes()*60 + theend.getSeconds();
		endtime = endtime - MotoVod.getBeginTime().getHours()*3600 - MotoVod.getBeginTime().getMinutes()*60 -MotoVod.getBeginTime().getSeconds() ;
		if(!MotoVod.isRecordOver()){
			var time = (nowTime.getHours() - removeZero(startShiTime_hour))*3600 + 
		   			   (nowTime.getMinutes() - removeZero(startShiftTime_min))*60 + 
		   			   (nowTime.getSeconds() - removeZero(startShiftTime_sec)); 
			if(realTimeCount > time){
				isBeforeOver = false;
			}
		}
		
		Utility.println("realTimeCount ="+realTimeCount+"endtime ="+endtime+"isBeforeOver ="+isBeforeOver);
		if(realTimeCount <= endtime && isBeforeOver && realTimeCount >= 0 && inputMinutes <= 60 && intputSeconds <= 60)
		{   
			if(realTimeCount == 0)
			{
				realTimeCount =1;
			}
			 MotoVod.playControl("play",0,realTimeCount);
			 $("inputTimeMenu").style.display = "none";
			 $('inputButton').blur();//释放焦点；
		} 
		else 
		{
			alertFlag = true;
			$('ALERT_EXAMPLE').style.background = "url(../images/box_bg.gif) no-repeat";
			$("ALERT_EXAMPLE").style.visibility = "visible";
			$('error_content_example').innerText =  "尊敬的用户，输入时间范围不正确，请重新输入！";
			$("btn").style.visibility = "visible";
		}
	} else{
		if(realTimeCount <= MotoVod.getTotalTime()&& realTimeCount >= 0)
		{   
			if(realTimeCount == 0)
			{
				realTimeCount =1;
			}
			 MotoVod.playControl("play",0,realTimeCount);
			 $("inputTimeMenu").style.display = "none";
			 $('inputButton').blur();//释放焦点；
		} else {
			alertFlag = true;
			$('ALERT_EXAMPLE').style.background = "url(../images/box_bg.gif) no-repeat";
			$("ALERT_EXAMPLE").style.visibility = "visible";
			$('error_content_example').innerText =  "尊敬的用户，输入时间范围不正确，请重新输入！";
			$("btn").style.visibility = "visible";
		}
	}
	isTimeKeyEvent = false;
}
var alertTimer;
function showAlertWindow(p3){
	clearTimeout(alertTimer);
	$('ALERT_EXAMPLE').style.background = "url(../images/box_bg.gif) no-repeat";
	$('ALERT_EXAMPLE').style.visibility = "visible";
	if(p3=='undefined'){
		p3="";
	}
	if(netErrorEvent == true){
		$("btn").style.visibility = "visible";
	}else{
		$("btn").style.visibility = "hidden";
	}
	$('error_content_example').innerHTML = p3 ;
}

function closeAlertWindow(){
	$('ALERT_EXAMPLE').style.visibility = "hidden";
}

function closeCableWindow(){
	closeAlertWindow();
	if(isSigalEvent || isStreamRun)
	{
		isStreamRun = true;
		return;
	}
	
	activeExitPage(MPEG_STOP_EXIT);
}

function closeFiberWindow(){
	Utility.println("信号太差，8秒钟内没有恢复将自动退出\n错误代码0x9051");
	closeAlertWindow();
	if(!isSigalTooBadEvent || isStreamRun){
		isStreamRun = true;
		return;
	}
	
	isStreamRun = false;
	activeExitPage(MPEG_STOP_EXIT);
}
 /*
 退出Motovod播放
 */
function activeExitPage(keycode){
	closeAudioChannelWindow();
	hiddenAllWindow();
	var exitPage= MotoUI.getMainPage();
	var loadPage = MotoUI.getMotoPage();
	isInitSucess = false;
	
	MotoUI.activePage(exitPage);
	MotoUI.hidePage(loadPage);
	MotoVod.playControl("stop",keycode,0); 
}

/*
节目正常播放到尾,MotoVod向界面发送消息
*/
function stopMotoPlay(){
	closeAudioChannelWindow();
	hiddenAllWindow();
	var exitPage= MotoUI.getMainPage();
	var loadPage = MotoUI.getMotoPage();
	isInitSucess = false;
	MotoUI.activePage(exitPage);
	MotoUI.hidePage(loadPage);
}

/*
小视屏窗口播放，如果是标清则这时不销毁销毁窗口，是高清请在MotoUI.activePage(mainPage);之后在调用MotoUI.hidePage().
*/
function exitSmallPlay(){
	hiddenAllWindow();
	var mainPage= MotoUI.getMainPage();
	var motoPage = MotoUI.getMotoPage();
	MotoUI.hidePage(motoPage);
	MotoUI.activePage(mainPage);
	MotoVod.playControl("stop",0,0);	
	MotoVod.playControl("resume",0,0);	//恢复播放
	spos=0;
}

/*
当播放完成或则是退出播放时，将页面上的控制台、时间输入框、帮助信息隐藏
*/
function hiddenAllWindow(){
	quick = false;
	disAppearNew();							   		//消失控制台
	$("ALERT_EXAMPLE").style.visibility = "hidden";	//隐藏错误提示
	$("audio_channel").style.display = "none";		//隐藏声道
	$("audio_channel_text").style.display = "none";
	$("inputTimeMenu").style.display = "none"; 		//隐藏时间输入框
	$("helpMenu").style.display = "none";	   		//隐藏帮助信息
		
	$("control_ad_div").style.visibility = "hidden";// 隐藏播放器广告
	$("pause_ad_div").style.visibility = "hidden";	// 隐藏暂停广告
}

function closeAudioChannelWindow(){
	if (audioTrackMode == 1) 
	{	//	每次在声道DIV消失的时候保存改变的声道值
		audioChannelArrayIndex--;
		if (audioChannelArrayIndex < 0)
		{
			audioChannelArrayIndex = 2;
		}
		sysDa.set("AudioTrack", audioChannelArrayName_en[audioChannelArrayIndex]);
		sysDa.submit();
	}
	else 
	{	//在单独声道设置模式下保存声道值
		 service.audioTrack = audioChannelArray[audioChannelArrayIndex];
		 ServiceDB.save();
	}

    $("audio_channel").style.display = "none";	
}

var indexArray = ['play','left','right','up','down'];
function setIndexIsVisible(){
	for(var i = 0; i <indexArray.length; i++){
	    if(index != indexArray[i]){	
		    $( indexArray[i]).style.visibility  = "hidden";
        } else{
			$( indexArray[i]).style.visibility  = "visible";
		}
	}
}
var errorTimer = 0;
function clearAllTimer(){
	clearTimeout(timer);
	clearTimeout(audioChannelTimer);
	clearTimeout(sigalErrorTimer);
	clearTimeout(errorTimer);
	clearInterval(progressTimer);
	clearInterval(clockInterVal);
	clearInterval(dragTimer);	//清除拖动的timer
}

function initAudioPara() {
	//获取有关声道的参数
	audioTrackMode = parseInt(sysDa.get("audioTrackMode"));
	audioChannelArrayName_en = ["Left","Right","Stereo"];
	audioChannelArrayName_cn = ["左声道","右声道","立体声"];

	audioTrackStr = sysDa.get("AudioTrack");
	
	switch (audioTrackStr) {
		case "Left":
			audioChannelArrayIndex = 0;
			break;
		case "Right":
			audioChannelArrayIndex = 1;
			break;
		case "Stereo":
			audioChannelArrayIndex = 2;
			break;
		default:
			break;
	}
}

function MotoOperation(type)
{
	isPlay = false;
	if(isHelpkeyEvent){
		return;
	}
	
	if(isTimeKeyEvent){
		if(type == "left"){
			leftRigth(-1);
		}
		else{
			leftRigth(1);
		}
		
		return;
	}
	
	if(lock==true){
		return;	
	}
	
	clearTimeout(timer);
	if(type == "left"){
		leftOperation();
	}else{
		rightOperation();
	}
}


function timeToLocal(d) {
	var str = "";
	var time_hours = (d.getHours() + "").length >= 2 ? (d.getHours() + "") : ("0" + d.getHours());
	var time_minus = (d.getMinutes() + "").length >= 2 ? (d.getMinutes() + "") : ("0" + d.getMinutes());
	var time_sec = (d.getSeconds() + "").length >= 2 ? (d.getSeconds() + "") : ("0" + d.getSeconds());
	return (time_hours + ":" + time_minus + ":" + time_sec);
}

function isTimeshiftOut(endTime) {
	var time = new Date();
	if (MotoVod.isRecordOver() || time.getTime() >= endTime.getTime()) {
			//表明已经是完全录制完毕，即时移时间已过失
			$("progress_2").style.width = recordBarWidth +"px";							//时移结束点
			$("endshiftRecord").style.left = recordBarWidth + endpointShift +"px";		//时移结束点
			$("ts_endTime").innerText = timeToLocal(ts_endTime);
		} else {
			$("ts_endTime").innerText = timeToLocal(time);
			var diff = timeShortOf(time, ts_startTime);
			//添加保护，当前端下发的总时长不对的时候，编码进度条超出
			initProcess = parseInt(diff*step);
			initProcess = initProcess > recordBarWidth ? recordBarWidth : initProcess;
			$("progress_2").style.width = initProcess +"px";
			$("endshiftRecord").style.left = initProcess + endpointShift +"px";		//时移结束点
			clearInterval(timeShiftTimer);
			timeShiftTimer = setInterval("plusOne();", 1000);
		}
}

function timeShortOf(nowTime, oldTime) {
	return (dateToSec(nowTime) - dateToSec(oldTime));
}

function dateToSec(dt) {
	return dt.getHours()*3600 + dt.getMinutes()*60 +dt.getSeconds();
}

function plusOne() {
	var realTime = new Date();
	var currentTime =parseInt((realTime.getTime() - ts_startTime.getTime())/1000);	//add by lihuaide,match
	if (timeShortOf(realTime, ts_endTime) == 0) {
		clearInterval(timeShiftTimer);
		$("ts_endTime").innerText = timeToLocal(realTime);
	} else {
		$("ts_endTime").innerText = timeToLocal(realTime);
	}
	//添加保护，当前端下发的总时长不对的时候，编码进度条超出
	var progress = (currentTime/totalTime) > 1 ? 1 : (currentTime/totalTime);
	$("progress_2").style.width = progress*recordBarWidth + "px";
	$("endshiftRecord").style.left = progress*recordBarWidth + endpointShift +"px";		//时移结束点
}
